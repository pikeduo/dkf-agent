# Non-billable local smoke: GET routes only; no LLM calls, DB writes or uploads.
$ErrorActionPreference = 'Stop'
$routes = @(
    @{ name = 'Contest process'; uri = 'http://127.0.0.1:8001/api/health' },
    @{ name = 'DKF process'; uri = 'http://127.0.0.1:8000/health' },
    @{ name = 'Contest source registry'; uri = 'http://127.0.0.1:8001/api/catalog/sources' },
    @{ name = 'DKF knowledge-base list'; uri = 'http://127.0.0.1:8000/api/admin/knowledge-bases?limit=1&offset=0' }
)
foreach ($item in $routes) {
    try {
        $data = Invoke-RestMethod -Uri $item.uri -Method GET -TimeoutSec 12 -ErrorAction Stop
        Write-Host ('OK  ' + $item.name + '  ' + $item.uri) -ForegroundColor Green
    }
    catch {
        Write-Warning ('FAIL ' + $item.name + ': ' + $_.Exception.Message)
    }
}
Write-Host 'Note: GET health only confirms a running process; it does not prove DB, GPU, or LLM readiness.'
