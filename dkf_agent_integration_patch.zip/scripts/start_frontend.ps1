# Run from the dkf-agent repository root. Requires Node.js >= 20.
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$frontend = Join-Path $repoRoot 'frontend'
Push-Location $frontend
try {
    if (-not (Test-Path 'node_modules')) {
        Write-Host 'Installing frontend dependencies (requires npm network)...' -ForegroundColor Cyan
        npm install
        if ($LASTEXITCODE -ne 0) { throw 'npm install failed' }
    }
    npm run dev
}
finally { Pop-Location }
