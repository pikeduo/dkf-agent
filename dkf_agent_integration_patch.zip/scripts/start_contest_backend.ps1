# Run from the dkf-agent repository root, after activating the dedicated contest env.
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$serviceDir = Join-Path $repoRoot 'contest_backend'
if (-not (Test-Path (Join-Path $serviceDir '.env'))) {
    Write-Host 'Missing contest_backend/.env; copy .env.example and fill database/LLM config.' -ForegroundColor Yellow
    exit 2
}
Push-Location $serviceDir
try {
    python -m uvicorn backend.main:app --host 127.0.0.1 --port 8001
}
finally { Pop-Location }
