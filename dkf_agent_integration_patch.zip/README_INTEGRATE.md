# 中国电子杯赛题八 | DKF-Agent + 问数模块整合补丁

> 基于用户提供的 `code_package.zip` 与 `pikeduo/dkf-agent`（检查时默认分支）制作的**增量补丁**。不覆盖现有 `app/`、`alembic/`、`tests/` 与项目根目录 `.env`。这是源代码交付，不代表已经在用户机器上部署或完成赛题全部验收。

## 目录

```text
dkf-agent/                 # 你的原项目根目录
├─ app/                    # 原有知识服务后端：不改动
├─ contest_backend/        # 用户提供的问数/意图/公式后端（独立 Python 进程）
│  ├─ backend/              # FastAPI、NL2SQL、澄清、公式、Trace
│  ├─ processed/            # 原包内注册表/示例文档映射；不等于业务库已经导入
│  ├─ schemas/              # 原包内数据库 Schema/FK 图
│  ├─ tests/                # 原包内后端回归用例
│  ├─ .env.example          # 独立环境变量
│  └─ requirements.txt
├─ frontend/               # 新增 Vue3 + Vite 竞赛工作台
│  └─ src/pages/            # NL2SQL、澄清、知识问答、文档管理、跨源演示、Trace 等
├─ docs/CONTEST_INTEGRATION.md
└─ scripts/                 # 新增本地启动和只读检查脚本
```

## 最快启动（Windows PowerShell）

**前提**：请先备份/提交你本地的工作区；把本补丁目录内容复制到你自己的 `dkf-agent` 根目录，同名文件按实际差异逐项确认，**不要复制覆盖整个仓库**。

1. 启动现有 DKF-Agent。项目根目录（已经准备好其 PostgreSQL/Redis/Worker/Embedding/Reranker 的情况下）：

   ```powershell
   conda activate dkf-agent
   python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
   ```

   `GET http://127.0.0.1:8000/health` 只检测进程存活，不代表 PostgreSQL、GPU 或大模型可用。

2. 首次配置竞赛问数服务，建议单独使用 Python 3.11 环境：

   ```powershell
   conda create -n ict-sql python=3.11 -y
   conda activate ict-sql
   pip install -r contest_backend/requirements.txt
   Copy-Item contest_backend/.env.example contest_backend/.env
   notepad contest_backend/.env
   ```

   只在**本机 `.env`** 中填 `LLM_PROVIDER=wb`、`WB_BASE_URL`（推荐受信任 HTTPS 网关的 `/v1` 根地址）、`WB_API_KEY`、`WB_CHAT_MODEL`。必须先确认 `processed/knowledge_base/databases.json` 中的 PostgreSQL DSN / 数据库清单对应真实已导入数据；原包中仍有占位和其他机器的 Windows 绝对路径，无法直接用作本机数据库。然后启动（保持在项目根目录）：

   ```powershell
   .\scripts\start_contest_backend.ps1
   ```

   需要使用 `ict-sql` 环境中的 Python 解释器。若 `conda activate` 未生效，先运行 `conda activate ict-sql`。

3. 另开 PowerShell 终端启动前端（需要 Node.js 20+ 和可访问 npm 的网络）：

   ```powershell
   .\scripts\start_frontend.ps1
   ```

   打开 <http://127.0.0.1:5173>。默认代理把 `/api/contest/*` 路由到竞赛问数服务 `127.0.0.1:8001/api/*`，把 `/api/*` 路由到现有知识服务 `127.0.0.1:8000/api/*`。

4. 只读检测：

   ```powershell
   .\scripts\smoke_local.ps1
   ```

   只检测 HTTP 路由和知识库清单，不会上传文件、调用收费模型、重试任务、写入数据库。

## 关键注意事项

- 两个后端**进程隔离**，各自维护依赖、`.env` 与数据库连接。不要将 `contest_backend/backend` 直接复制到现有 `app/` 内；不要把竞赛包的 `docker-compose.reference.yml` 当作可以直接部署的 compose 文件。
- 竞赛后端 `DATA_REGISTRY_PATH` 默认定位 `contest_backend/processed/knowledge_base/databases.json`；原包包含 schema 索引和注册表，但**没有保证这些 PostgreSQL 数据库已导入你的电脑**。原有数据映射包含创建者机器上的绝对路径，应在公开提交前去标识化并改成本机有效路径。
- DKF 原有知识库和文档流程仍需真实 PostgreSQL、pgvector、MinerU/Native、Redis/Celery Worker、BGE-M3 / Reranker。仅上传成功不表示 READY。
- 竞赛前端是集成演示层；`/api/query/run` 能完成意图和部分工具调用，未必生成真正文档答案。RAG 页面只调用 DKF 的真实 `/api/knowledge/query`。
- 「跨源联合演示」是**两阶段、人工确认实体**的显式流程；没有伪装成赛题要求的“自然语言一次输入 → Agent 自主规划多跳跨源任务”。正式决赛还需实现后端统一任务规划、结果校验和跨源 Trace。
- DKF 后端管理接口目前无权限体系，竞赛后端开发时 CORS 仅允许本地前端；所有服务默认只监听 `127.0.0.1`。不可直接暴露到公网。数据库账号应限制为只读查询权限。
- 前端 **不**持有任何第三方 LLM API Key；只在各自后端 `.env` 填写。不要把真正的 `.env` 加入 Git。建议只通过有 TLS 的可信网关发送问题与证据，HTTP 明文会暴露密钥和数据。
- 首次实际 SQL/RAG 测试可能调用付费模型；失败或超时后应检查服务及费用，不要盲目反复提交。

更多接口映射、赛题要求差距、测试方案见 [`docs/CONTEST_INTEGRATION.md`](docs/CONTEST_INTEGRATION.md)。
