# DKF-Agent + code_package 适配与赛题八验收说明

## 1. 源码整合方式与理由

本补丁对照了用户上传的 `code_package.zip`、用户已有的 `pikeduo/dkf-agent` 仓库与《赛题八：多模态数据驱动的可解释精准问数/问答智能体》。**建议先采用双 FastAPI + 单 Vue 的增量适配**，暂不把两套后端强制合成一个 Python 包。

- **现有 DKF 后端** (`app/`)：知识库 CRUD、文档上传/解析/MinerU、Block/Chunk/Embedding、混合检索、Reranker、RAG 可追溯引用、公式语义等；沿用其 `app.main:app` 与现有数据库/Worker。
- **用户上传的问数后端** (`contest_backend/backend/`)：意图与澄清（任务 3）、表定位（任务 4）、Text2SQL、数据库只读执行、公式工具（任务 6）、查询 Trace。拷贝时保持原结构及 tests、schema/registry 数据；原示例 Docker Compose 改名为参考文件，避免默认端口和 PostgreSQL 资源发生冲突。
- **新前端** (`frontend/`)：统一入口、真实后端接口，不包含假数据或写死的成功率，保留服务失败/文档缺证据/SQL 未执行状态。默认 Vite Proxy 单域访问，避免浏览器直连不同端口的跨域问题。

> 本补丁没有调用 GitHub 写入操作，也没有合并到你的工作区。请你自行备份并复制补丁，之后运行后端与前端测试。

## 2. 实际接口对照

| 前端能力 | HTTP 接口 | 对应后端 | 响应及注意事项 |
|---|---|---|---|
| 服务健康状态 | `GET /api/contest/health` / `GET /health` | 竞赛/DKF | 仅进程存活，不代表数据库/GPU/LLM 可用 |
| 可用数据库 ID 目录 | `GET /api/contest/catalog/sources` | 竞赛（补丁新增） | 仅返回数据库 ID、名称、表数量线索，不泄露 DSN |
| 创建会话 | `POST /api/contest/sessions/` | 竞赛 | 随机 token 仅驻留浏览器内存 |
| 意图澄清与受控执行 | `POST /api/contest/query/run` | 竞赛 | `stage=needs_user` 代表需要追问；`stage=evidence_ready` 仅表明摘录就绪；不能当完整 RAG |
| 独立 NL2SQL | `POST /api/contest/query/text2sql` | 竞赛 | 显式 `db_id`/`sub_db`/`question`；`ok=true` 仅证明查询执行成功，不代表答案完全准确 |
| 查询 Trace | `GET /api/contest/trace/{trace_id}` | 竞赛 | 展示真实调用记录；空/缺失记录明确说明 |
| 知识库管理 | `GET/POST /api/admin/knowledge-bases` | DKF | 真实 UUID，不由浏览器自造 |
| 文档上传 | `POST /api/admin/knowledge-bases/{kb_id}/documents` | DKF | Multipart 多文件 `file` + `parse_mode`；单/批响应分支处理 |
| 文档进度 | `GET /api/admin/documents/{doc_id}/status` | DKF | `READY`/`PARTIAL_READY`/`FAILED` 等；查看块/切片/向量数量 |
| 重试与原文块 | `POST /api/admin/documents/{doc_id}/retry`, `GET /.../blocks` | DKF | 重试前必须先修复故障，避免重复外部成本 |
| 知识证据检索 | `POST /api/knowledge/search` | DKF | `status=success/empty`, `evidence[]`，不调用生成模型 |
| 带真实引用的回答 | `POST /api/knowledge/query` | DKF | `{kb_id,question,doc_ids,top_k,allow_cloud}` -> `{status,answer,citations,insufficient_evidence}` |

其中 Vue 源码 `frontend/src/utils/api.js` 统一封装接口；注意 Vite 前缀 `/api/contest` 和后端原生 `/api` 是**不同路径**，由代理负责映射。

## 3. 赛题要求逐项映射（真实完成状态须另行实测）

| 赛题点 | 前端演示位置 | 现有源码支持范围 | 仍缺少的验收证据/能力 |
|---|---|---|---|
| 基础：至少 10 个单表 NL2SQL | 自然语言问数 | 原包 Text2SQL + SQL 执行 + 表定位 | 导入真实 DB，固定 10+ 测试题，核对执行正确率 |
| 基础：至少 10 个单文档 RAG | 文档问答 | DKF 证据、RAG、引用来源 | 上传 10+ 不同类型文档，检验 READY 和回答真实性 |
| 基础：可解释性 | SQL/知识库/Trace | SQL、Query Trace、Citation、页/片段 | 记录端到端真实链路，并人工验证引用无误 |
| 中级 3：主动澄清 | 意图分析与澄清 | 原包提供会话澄清逻辑 | 真实模糊问题、多轮连续 5 次以上及上下文测试 |
| 中级 4：Schema Linking | 自然语言问数 | 原包表定位/FK 图/SQL 生成 | 数据库干扰表、字段歧义、跨库泛化对照实验 |
| 中级 6：文档公式 | 意图分析与澄清；DKF 文档解析 | 原包公式工具 + DKF 公式抽取/绑定 | 证明 6a 参数来源与 6b 公式解析均正确并可追溯 |
| 决赛多源融合 | 跨源联合演示 | SQL → 人工实体绑定 → DKF RAG | **没有后端自动规划器**：需自然语言一次输入、自动两类工具、跨源统一回答、统一 Trace、多跳回归 |
| OCR/多模态解析鲁棒性 | 知识库管理 | DKF MinerU/Native + 处理可观测性 | 扫描件、颠倒页、复杂表格及质量对比数据 |
| 系统效率 | 赛题验收清单 | 各后端有部分时延字段和日志 | 1千/1万行及多文档规模的端到端实测、瓶颈分析 |

**赛题 PDF 提交规定**：校内初赛至少解决 1 个中级任务，提供 Word+PDF 设计报告（建议不超过 20 页）、技术实现说明书（建议不超过 30 页）、源码 ZIP、数据库 Schema、不同格式知识库样本至少 10 份、依赖/版本与快速启动脚本。前端/补丁不包含这些完成证明；决赛要至少 3 个中级难题，并展示跨源融合、多轮和鲁棒性。

## 4. 后续真正统一为智能体的建议（不在本补丁中伪造完成）

1. **以统一编排层为唯一入口**：新增 `orchestrator` 服务接收 `question, session_id, kb_id, db_id`。先判断 `SQL_ONLY` / `RAG_ONLY` / `HYBRID` / `NEEDS_CLARIFICATION`。校验数据范围及隐私许可后生成有界任务计划。
2. **两个工具拥有强类型输入输出**：数据库工具只收 `{db_id, sub_db, question, confirmed_slots}`，结果含 `sql,columns,rows,table_ids,trace_id`；知识工具只收 `{kb_id,question,doc_ids,allow_cloud}`，结果含 `answer,citations`；两种 evidence 采用不同来源命名空间，不允许模型伪造 `chunk_id` 或 SQL。
3. **Hybrid 计划可安全受控地传值**：例如 `SQL 查询冠军 ID → 检查实体归属与唯一性 → 在指定 KB RAG 检索其案例 → 合成答案`。不能把 SQL 原样带入文档，或把文档生成的文字插入可执行 SQL；每步都要做结构化验证。
4. **统一可解释结果对象**：业务 `plan_steps`、`tool_calls`、`sql_result_refs`、`document_citations`、`warnings`、`latency` 与 `answer`；统一记录可审核的业务步骤，不泄露模型隐藏思维链、Prompt、令牌或敏感连接串。
5. **统一身份、RBAC、安全和成本边界**：SQL 使用真正只读数据库账号、允许的数据范围，文档按照 kb_id 授权；API 加身份验证、调用限额、日志脱敏与请求幂等；付费/跨公网调用使用可信 HTTPS，禁止前端持有网关密钥。
6. **离线标准数据集与可复现评测**：将 `tests`、OHR-Bench/OCR 场景、Chinook SQL、FAQ，整理为可复现脚本；独立测试 Schema Linking 准确率、NL2SQL Execution Accuracy、RAG 忠实度、澄清通过率和跨源多跳完成率。

## 5. 本机验收顺序

建议首先启动两个后端和 Vue，打开总览确认接口可达：`127.0.0.1:8000/health`、`127.0.0.1:8001/api/health`、`127.0.0.1:5173`。然后：

1. 向 DKF 创建知识库、上传 1-2 份小文档，查看 `READY` 和来源 Block；先不调用云模型，仅搜索并检查证据。
2. 使用真实可访问的 Chinook 测试 NL2SQL，核对 `ok`、SQL、返回行列、Trace；不要认为有结果就是正确。
3. 获得云调用明确许可后，对单文档 RAG 测试回答和引用；人工对照 `file_name`, `page_start`, `text`。
4. 使用最小跨源样本确认 SQL 实体与文档之间**真的有可匹配事实**，再做两阶段演示；没有匹配则保留“证据不足”结果。
5. 最后整理至少 10 + 10 的基础样例，中级任务多组反例、多轮、效率实验，记录数据快照版本、模型配置版本和实际成功率。

## 6. 当前交付的已知限制

- 补丁已完成 Python 静态编译；前端依赖安装需实际 npm 网络，本交付没有使用虚构的运行截图、成功率或调用结果。任何成功需要你在本机连接真实数据后复测。
- 原 code_package 的数据源注册表和 schema 索引包含来源机器绝对路径/占位 DSN，使用前必须定位本地数据并检查脱敏。
- 本地演示使用同步 HTTP 接口、开发内存 Session；没有生产级高并发/动态部署/完整统一任务队列。
- 现有 DKF 服务和新竞赛服务依然是两套独立的数据库/追踪命名空间；文档引用属于 DKF，SQL Trace 属于竞赛后端，不应将两个单独的 Trace 误称为一个自动多跳执行链。
