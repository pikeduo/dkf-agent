import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Two existing FastAPI apps stay separate. Proxy order is significant.
const contestTarget = process.env.CONTEST_BACKEND_URL || 'http://127.0.0.1:8001'
const knowledgeTarget = process.env.DKF_BACKEND_URL || 'http://127.0.0.1:8000'

export default defineConfig({
  plugins: [vue()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api/contest': {
        target: contestTarget,
        changeOrigin: true,
        rewrite: path => path.replace(/^\/api\/contest(?=\/|$)/, '/api')
      },
      '/api': { target: knowledgeTarget, changeOrigin: true },
      '/health': { target: knowledgeTarget, changeOrigin: true }
    }
  }
})
