export const CHAT_EXAMPLES = [
  { label: '公式运算', text: '按 F=m*a 计算，m=2 kg，a=3 m/s²' },
  { label: '主动澄清', text: '销售额增长率是多少？' },
  { label: '业务查询', text: 'Chinook 数据库中一共有多少位艺术家？' },
  { label: '参数补充', text: '按 F=m*a 计算，m=2 kg' }
]
export const SQL_EXAMPLES = [
  'Chinook 中有多少位艺术家？',
  '查询每个音乐流派对应的曲目数量，并按数量降序排列',
  '找出购买金额最高的前五位客户及其总消费金额'
]
