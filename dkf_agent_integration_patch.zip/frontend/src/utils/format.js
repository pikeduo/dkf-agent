export const statusTitle = status => ({
  READY: '可检索', PARTIAL_READY: '部分就绪', FAILED: '处理失败',
  UPLOADED: '已接收', PARSING: '正在解析', OCR_PROCESSING: 'OCR处理中',
  CHUNKING: '正在切片', EMBEDDING: '正在向量化', INDEXING: '正在入库'
}[status] || status || '未知状态')

export const shortId = id => typeof id === 'string' && id.length > 18
  ? `${id.slice(0, 8)}…${id.slice(-6)}` : (id || '—')
export const pageLabel = citation => {
  if (citation?.page_start == null) return '页码未提供'
  if (citation.page_end && citation.page_end !== citation.page_start) {
    return `第 ${citation.page_start}–${citation.page_end} 页`
  }
  return `第 ${citation.page_start} 页`
}
export const cleanCell = cell => cell == null ? 'NULL' : typeof cell === 'object'
  ? JSON.stringify(cell) : String(cell)
