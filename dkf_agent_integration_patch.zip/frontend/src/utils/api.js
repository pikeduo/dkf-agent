import axios from 'axios'

const contest = axios.create({
  baseURL: import.meta.env.VITE_CONTEST_API_BASE || '/api/contest', timeout: 125000
})
const dkf = axios.create({
  baseURL: import.meta.env.VITE_DKF_API_BASE || '/api', timeout: 310000
})

export function errorMessage(error) {
  const status = error?.response?.status
  const detail = error?.response?.data?.detail
  if (typeof detail === 'string') return detail
  if (typeof detail?.message === 'string') return detail.message
  if (Array.isArray(detail)) return detail.map(item => item.msg || '参数格式错误').join('；')
  if (error?.code === 'ECONNABORTED') return '请求超时。模型或检索可能仍在执行，请确认后台任务/计费后再决定是否重试。'
  if (status === 403) return '没有本次请求所需的许可或权限。请检查云调用授权。'
  if (status === 404) return '所请求的资源不存在，或会话已过期。'
  if (status === 409) return '当前数据状态冲突。请刷新状态，不要重复上传。'
  if (status === 422) return '请求参数未通过服务端校验，请检查数据库、知识库和问题。'
  if (status === 503) return '服务暂时不可用，请检查依赖服务、上游模型或任务状态。'
  if (status) return `服务响应 HTTP ${status}，请检查后端日志。`
  return '无法连接服务，请确认 Vite 代理和两个后端是否已启动。'
}

// Contest backend: capability-token session; never persist token in storage.
export const getContestHealth = async () => (await contest.get('/health', { timeout: 5000 })).data
export const createSession = async () => {
  const { data } = await contest.post('/sessions/')
  return { id: data.session_id, token: data.session_token }
}
export const deleteSession = async session => {
  await contest.delete(`/sessions/${encodeURIComponent(session.id)}`, {
    headers: { 'X-Session-Token': session.token }
  })
}
export const runQuery = async (payload, session) => {
  const body = session ? { ...payload, session_id: session.id } : payload
  const { data } = await contest.post('/query/run', body, {
    headers: session ? { 'X-Session-Token': session.token } : {}
  })
  return data
}
export const runText2Sql = async ({ question, dbId, subDb, confirmedSlots }) => {
  const { data } = await contest.post('/query/text2sql', {
    db_id: dbId, sub_db: subDb || null, question,
    ...(confirmedSlots ? { confirmed_slots: confirmedSlots } : {})
  })
  return data
}
export const getTrace = async traceId => (
  await contest.get(`/trace/${encodeURIComponent(traceId)}`)
).data

// DKF backend: knowledge-base scope and every source are assigned on server.
export const getDkfHealth = async () => (await axios.get('/health', { timeout: 5000 })).data
export const listKnowledgeBases = async (limit = 100, offset = 0) => (
  await dkf.get('/admin/knowledge-bases', { params: { limit, offset } })
).data
export const createKnowledgeBase = async payload => (
  await dkf.post('/admin/knowledge-bases', payload)
).data
export const listDocuments = async (kbId, limit = 100, offset = 0) => (
  await dkf.get(`/admin/knowledge-bases/${encodeURIComponent(kbId)}/documents`, { params: { limit, offset } })
).data
export const uploadDocuments = async (kbId, files, parseMode = 'auto') => {
  const form = new FormData()
  for (const file of files) form.append('file', file)
  form.append('parse_mode', parseMode)
  return (await dkf.post(`/admin/knowledge-bases/${encodeURIComponent(kbId)}/documents`, form, {
    timeout: 120000
  })).data
}
export const getDocumentStatus = async docId => (
  await dkf.get(`/admin/documents/${encodeURIComponent(docId)}/status`)
).data
export const getDocumentBlocks = async (docId, limit = 20, offset = 0) => (
  await dkf.get(`/admin/documents/${encodeURIComponent(docId)}/blocks`, { params: { limit, offset } })
).data
export const retryDocument = async docId => (
  await dkf.post(`/admin/documents/${encodeURIComponent(docId)}/retry`)
).data
export const searchKnowledge = async ({ kbId, question, docIds = null, topK = 30 }) => (
  await dkf.post('/knowledge/search', {
    kb_id: kbId, question, doc_ids: docIds?.length ? docIds : null, top_k: topK
  })
).data
export const askKnowledge = async ({ kbId, question, docIds = null, allowCloud = false, topK = 30 }) => (
  await dkf.post('/knowledge/query', {
    kb_id: kbId, question, doc_ids: docIds?.length ? docIds : null,
    allow_cloud: allowCloud, top_k: topK
  })
).data
export const listContestSources = async () => (
  await contest.get('/catalog/sources', { timeout: 10000 })
).data
