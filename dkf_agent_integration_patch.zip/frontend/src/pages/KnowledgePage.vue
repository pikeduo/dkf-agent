<script setup>
import { onMounted, ref, watch } from 'vue'
import { askKnowledge, errorMessage, listDocuments, listKnowledgeBases, searchKnowledge } from '../utils/api'
import EvidencePanel from '../components/EvidencePanel.vue'
import { statusTitle } from '../utils/format'
const kbs = ref([])
const docs = ref([])
const kbId = ref('')
const selectedDocIds = ref([])
const question = ref('文档中提出了哪些主要发现？请注明来源和页码。')
const allowCloud = ref(false)
const loading = ref(false)
const loadError = ref('')
const error = ref('')
const result = ref(null)
const action = ref('')

async function loadKbs() {
  loadError.value = ''
  try {
    const data = await listKnowledgeBases(100, 0)
    kbs.value = data.items || []
    if (!kbs.value.some(item => item.kb_id === kbId.value)) {
      kbId.value = kbs.value.find(item => item.status === 'ACTIVE')?.kb_id || ''
    }
  } catch(e) { loadError.value = errorMessage(e) }
}
watch(kbId, async (id) => {
  selectedDocIds.value = []
  docs.value = []
  result.value = null
  if (!id) return
  try { docs.value = (await listDocuments(id, 100, 0)).items || [] }
  catch(e) { loadError.value = errorMessage(e) }
})
onMounted(loadKbs)

async function submit(kind) {
  if (loading.value || !kbId.value || !question.value.trim()) return
  if (kind === 'qa' && !allowCloud.value) {
    error.value = '生成式问答需要先勾选本次云模型许可。未发送模型请求。'
    return
  }
  loading.value = true; error.value = ''; result.value = null; action.value = kind
  const options = { kbId: kbId.value, question: question.value, docIds: selectedDocIds.value,
    allowCloud: allowCloud.value, topK: 30 }
  try { result.value = kind === 'qa' ? await askKnowledge(options) : await searchKnowledge(options) }
  catch(e) { error.value = errorMessage(e) }
  finally { loading.value = false }
}
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">UNSTRUCTURED DATA / RAG</div><h1 class="page-title">文档知识问答</h1><p class="page-subtitle">基于 DKF-Agent 原有 MinerU、混合检索与 LlamaIndex RAG；回答与引用由服务端验证。</p></div><span class="pill">单文档 RAG · 来源可追溯</span></header>
    <div class="split">
      <section class="card card-pad">
        <div class="panel-heading"><h3>限定证据范围</h3><button class="btn small outline" type="button" @click="loadKbs">刷新知识库</button></div>
        <div class="field"><label for="rag-kb">知识库</label><select id="rag-kb" v-model="kbId" class="select"><option value="" disabled>选择已存在的知识库</option><option v-for="kb in kbs" :key="kb.kb_id" :value="kb.kb_id" :disabled="kb.status !== 'ACTIVE'">{{ kb.name }}（{{ kb.status }}）</option></select></div>
        <div class="field" style="margin-top:15px"><label for="rag-doc">具体文档（可多选；不选为全库检索）</label><select id="rag-doc" v-model="selectedDocIds" class="select multi" multiple size="5"><option v-for="doc in docs" :key="doc.doc_id" :value="doc.doc_id" :disabled="!['READY','PARTIAL_READY'].includes(doc.status)">{{ doc.file_name }} · {{ statusTitle(doc.status) }}</option></select><span class="hint">Ctrl 或 Command 多选；只有就绪文档可参与问答。基础任务建议只选一份文档。</span></div>
        <div class="field" style="margin-top:18px"><label for="rag-question">文档问题</label><textarea id="rag-question" v-model="question" class="textarea" rows="4" maxlength="12000" placeholder="例如：该报告关于营收增长有哪些主要结论？"></textarea></div>
        <label class="check" style="margin-top:14px"><input v-model="allowCloud" type="checkbox" />本次允许将问题及检索证据发送给已配置的云端模型，并接受可能的费用（仅对生成答案生效）</label>
        <div class="rag-actions"><button class="btn outline" :disabled="loading || !kbId || !question.trim()" type="button" @click="submit('search')">仅检索原文证据</button><button class="btn primary" :disabled="loading || !kbId || !question.trim() || !allowCloud" type="button" @click="submit('qa')">{{ loading ? '正在请求…' : '生成带引用的回答 →' }}</button></div>
        <div v-if="loadError" class="notice warn" style="margin-top:14px">{{ loadError }}</div>
        <div v-if="error" class="notice danger" style="margin-top:14px">{{ error }}</div>
      </section>
      <section class="card card-pad">
        <div class="eyebrow">EVIDENCE-BASED ANSWERING</div><h3 class="how-heading">答案是如何得出的？</h3>
        <div class="step-item"><b>01</b><span><strong>范围约束</strong><small>固定知识库 UUID 与文档范围，避免跨库检索。</small></span></div>
        <div class="step-item"><b>02</b><span><strong>检索融合</strong><small>BGE-M3 Dense + BM25 / RRF，最终重排取证据。</small></span></div>
        <div class="step-item"><b>03</b><span><strong>回答与来源</strong><small>生成答案仅引用当前检索快照的真实 Chunk。</small></span></div>
        <div class="notice" style="margin-top:23px">「仅检索」返回相关片段，不代表问题已回答；「生成回答」会调用云端模型且可能收费。</div>
      </section>
    </div>
    <div v-if="result" class="card card-pad result-card">
      <div class="panel-heading"><h3>{{ action === 'qa' ? '生成式回答' : '检索结果' }}</h3><span :class="['pill', result.status === 'success' ? 'ok' : 'warn']">{{ result.status === 'success' ? '完成' : result.status === 'empty' ? '无相关证据' : '证据不足' }}</span></div>
      <div v-if="action === 'qa'" class="answer-result"><div class="answer-label">ANSWER</div><p class="answer-text">{{ result.answer }}</p><div v-if="result.insufficient_evidence" class="notice warn">当前证据不足，服务端未构造无依据的答案。</div></div>
      <div v-else class="notice">检索完成。下面是实际匹配的文档片段，不是模型生成的最终答案。</div>
      <div class="divider"></div>
      <EvidencePanel :items="action === 'qa' ? (result.citations || []) : (result.evidence || [])" :title="action === 'qa' ? '答案所用的真实引用' : '检索到的原文片段'" />
      <p class="hint" style="margin-top:16px">页码和重排分数只来自返回字段；分数不是事实正确率或概率。请对照原件核对。</p>
    </div>
  </div>
</template>
<style scoped>
.multi { height: auto; min-height: 123px; padding: 5px; }
.multi option { padding: 8px 10px; border-radius: 4px; }
.rag-actions { display:flex; gap:10px; flex-wrap:wrap; margin-top:23px; }
.how-heading { margin:9px 0 17px; font-size:20px; }
.step-item { display:flex; align-items:flex-start; gap:14px; padding:17px 0; border-bottom:1px solid #edf2f5; }
.step-item b { color:#1595af; font:760 11px Consolas,monospace; margin-top:2px; }
.step-item strong { color:#29465a; font-size:12px; display:block; }
.step-item small { color:#8396a4; font-size:11px; display:block; margin-top:7px; line-height:1.65; }
.result-card { margin-top:18px; }
.answer-result { padding:5px 3px 6px; }
.answer-label { color:#39a0ae; font-size:10px; letter-spacing:1.7px; font-weight:800; margin-bottom:12px; }
</style>
