<script setup>
import { computed } from 'vue'
const props = defineProps({ services: Object, kbCount: Number })
const emit = defineEmits(['navigate'])
const cards = [
  { id:'chat', icon:'✳', tone:'a', label:'语义理解', title:'智能澄清与多轮对话', detail:'识别问题缺口，确认关键业务口径后再执行。', tag:'中级任务 3' },
  { id:'sql', icon:'▤', tone:'b', label:'结构化数据', title:'精准自然语言问数', detail:'业务要素 → Schema Linking → SQL 只读执行。', tag:'中级任务 4' },
  { id:'knowledge', icon:'◈', tone:'c', label:'非结构化知识', title:'带来源的文档问答', detail:'文档解析、混合检索、重排序与原文引用。', tag:'基础 RAG' },
  { id:'library', icon:'▣', tone:'d', label:'多模态数据', title:'知识库导入与追踪', detail:'PDF / Office / 图片入库，实时跟踪解析与向量化状态。', tag:'多模态' }
]
const knowledgeTitle = computed(() => props.kbCount == null ? '待连接' : `${props.kbCount} 个`)
</script>
<template>
  <section class="page home-page">
    <div class="welcome-hero">
      <div class="hero-body">
        <div class="hero-eyebrow"><span class="hero-pin"></span> THE INTELLIGENT DATA WORKSPACE · 2026</div>
        <h1>让数据可问，让答案<span>有据可查。</span></h1>
        <p>多模态数据驱动的可解释精准问数 / 问答智能体。<br>融合数据库查询、文档知识检索与可验证的执行链路。</p>
        <div class="hero-actions">
          <button class="btn hero-primary" type="button" @click="emit('navigate','chat')">开始智能问答 <span>→</span></button>
          <button class="btn hero-secondary" type="button" @click="emit('navigate','fusion')">探索跨源联合演示 ↗</button>
        </div>
      </div>
      <div class="hero-art" aria-hidden="true">
        <div class="art-grid"></div>
        <div class="art-node n1">问 <span>意图澄清</span></div>
        <div class="art-node n2">SQL <span>结构化查询</span></div>
        <div class="art-node n3">RAG <span>原文证据</span></div>
        <div class="art-core"><span class="core-icon">∞</span><small>DKF ENGINE</small></div>
        <div class="art-ring ring1"></div><div class="art-ring ring2"></div>
      </div>
    </div>

    <div class="section-caption"><div><div class="eyebrow">SYSTEM OVERVIEW</div><h2>系统运行概览</h2></div><span>实时检测 · 不展示虚构指标</span></div>
    <div class="stats-grid">
      <div class="stat-card card"><span class="stat-label">问数服务</span><div class="stat-value"><span :class="['light',services?.contest]"></span>{{ services?.contest === 'online' ? '已连接' : services?.contest === 'offline' ? '未连接' : '检测中' }}</div><small>意图识别 / NL2SQL / Trace</small></div>
      <div class="stat-card card"><span class="stat-label">知识服务</span><div class="stat-value"><span :class="['light',services?.dkf]"></span>{{ services?.dkf === 'online' ? '已连接' : services?.dkf === 'offline' ? '未连接' : '检测中' }}</div><small>文档解析 / 检索 / RAG</small></div>
      <div class="stat-card card"><span class="stat-label">知识库总量</span><div class="stat-value">{{ knowledgeTitle }}</div><small>仅来自实时后端列表</small></div>
      <div class="stat-card card"><span class="stat-label">当前参赛重点</span><div class="stat-value">3 / 4 / 6</div><small>主动澄清 · 表定位 · 公式</small></div>
    </div>

    <div class="section-caption"><div><div class="eyebrow">EXPLORE CAPABILITIES</div><h2>核心能力模块</h2></div><span>点击进入工作台</span></div>
    <div class="feature-grid">
      <button v-for="card in cards" :key="card.id" type="button" class="feature card" @click="emit('navigate',card.id)">
        <div class="feature-top"><div :class="['feature-icon',card.tone]">{{ card.icon }}</div><span class="feature-pill">{{ card.tag }}</span></div>
        <div class="feature-kicker">{{ card.label }}</div><h3>{{ card.title }}</h3><p>{{ card.detail }}</p>
        <div class="feature-link">进入模块 <span>↗</span></div>
      </button>
    </div>
    <div class="home-footnote">赛题八 · 校内初赛强调基础问数、单文档 RAG、可解释性及真实测试。跨源自主规划仍需后端编排和基准评估，详见「赛题验收清单」。</div>
  </section>
</template>
<style scoped>
.welcome-hero { position: relative; overflow: hidden; min-height: 300px; border-radius: 19px; color: white; display: flex; background: radial-gradient(circle at 84% 35%,#155770 0%, transparent 35%),linear-gradient(108deg,#0c3148 0%,#0d4258 58%,#0c3449 100%); box-shadow: 0 14px 32px #0f3a501a; }
.hero-body { padding: 42px 47px 42px; position: relative; z-index: 2; flex: 1; }
.hero-eyebrow { color: #9cdde4; font-size: 10px; font-weight: 740; letter-spacing: 1.1px; display: flex; align-items: center; gap: 9px; }
.hero-pin { background: #54e0c0; width: 7px; height: 7px; border-radius: 50%; }
h1 { font-size: clamp(26px,3vw,35px); letter-spacing: -.7px; line-height: 1.35; margin: 22px 0 13px; font-weight: 800; }
h1 span { color: #65ded4; }
.hero-body p { font-size: 12px; line-height: 1.95; color: #aac9d7; }
.hero-actions { display: flex; flex-wrap: wrap; gap: 11px; margin-top: 24px; }
.hero-primary { background: #e9f8f8; color: #135775; border: none; padding: 11px 17px; }
.hero-primary span { margin-left: 11px; }
.hero-primary:hover { background: #fff; }
.hero-secondary { color: #bde7ed; background: #ffffff0c; border: 1px solid #588299; padding: 11px 17px; }
.hero-secondary:hover { background: #ffffff18; }
.hero-art { width: 39%; flex: none; position: relative; min-height: 300px; overflow: hidden; }
.art-grid { position: absolute; inset: 0; opacity: .22; background-size: 23px 23px; background-image: linear-gradient(#58a4bb33 1px, transparent 1px),linear-gradient(90deg,#58a4bb33 1px,transparent 1px); mask-image: radial-gradient(circle at 54% 54%,#000, transparent 72%); }
.art-ring { position: absolute; border: 1px solid #78d6e129; border-radius: 50%; left: 50%; top: 50%; transform: translate(-50%,-50%); }
.ring1 { width: 260px; height: 260px; }
.ring2 { width: 380px; height: 380px; }
.art-core { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); z-index: 2; width: 137px; height: 137px; border-radius: 24px; background: #125a6e; border: 1px solid #5dced080; box-shadow: 0 0 0 10px #39d7d00e,0 14px 44px #042a3b; display: grid; align-content: center; justify-items: center; }
.core-icon { color: #69ead8; font-size: 69px; font-weight: 200; line-height: .9; }
.art-core small { font-size: 9px; color: #a6ecdc; letter-spacing: 1px; font-weight: 700; margin-top: 18px; }
.art-node { position: absolute; z-index: 3; color: #b0eeeb; font-size: 12px; font-weight: 900; background: #143f55; border: 1px solid #35788d; border-radius: 10px; padding: 9px 11px; box-shadow: 0 7px 23px #021f2a66; }
.art-node span { color: #a7cedb; display: block; font-size: 10px; font-weight: 500; margin-top: 3px; }
.n1 { top: 27px; right: 48px; } .n2 { top: 112px; left: 2px; } .n3 { right: 19px; bottom: 18px; }
.section-caption { display: flex; align-items: end; justify-content: space-between; margin: 36px 0 18px; }
.section-caption h2 { font-size: 18px; font-weight: 780; margin: 8px 0 0; }
.section-caption > span { color: #91a0ad; font-size: 11px; }
.stats-grid { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 13px; }
.stat-card { padding: 20px 20px 17px; }
.stat-label { color: #7e92a3; font-size: 11px; }
.stat-value { display: flex; gap: 10px; align-items: center; color: #16394f; font-size: 22px; font-weight: 800; margin: 11px 0 8px; }
.stat-card small { font-size: 10px; color: #a0afbc; }
.light { width: 9px; height: 9px; border-radius: 50%; background: #acb5bd; }
.light.online { background: #1eb690; } .light.offline { background: #df806f; }
.feature-grid { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 13px; }
.feature { padding: 23px 19px 18px; text-align: left; transition: box-shadow .17s, transform .17s; }
.feature:hover { box-shadow: 0 12px 30px #26486218; transform: translateY(-3px); }
.feature-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
.feature-icon { font-size: 24px; width: 45px; height: 45px; border-radius: 12px; display: grid; place-items: center; font-weight: 700; }
.a { color: #0975a2; background: #e6f4fb; } .b { color: #7d68bc; background: #f1edfc; } .c { color: #238972; background: #e8f8f0; } .d { color: #bc814b; background: #fff3e9; }
.feature-pill { color: #7991a1; background: #f2f6f8; border: 1px solid #eaf0f4; padding: 5px 8px; border-radius: 7px; font-size: 9px; }
.feature-kicker { font-size: 10px; color: #91a4ae; margin: 23px 0 8px; letter-spacing: 1px; }
.feature h3 { font-size: 14px; color: #254057; margin: 0 0 9px; }
.feature p { font-size: 11px; color: #7890a2; line-height: 1.85; min-height: 40px; margin-bottom: 20px; }
.feature-link { color: #0e83a9; font-size: 11px; font-weight: 750; display: flex; justify-content: space-between; border-top: 1px solid #eff3f6; padding-top: 12px; }
.home-footnote { margin-top: 28px; color: #9aabb6; font-size: 11px; line-height: 1.7; }
@media (max-width: 1270px) { .feature-grid { grid-template-columns: repeat(2,1fr); } .stats-grid { grid-template-columns: repeat(2,1fr); } }
@media (max-width: 680px) { .hero-body { padding: 31px 25px; } .hero-art { display: none; } .feature-grid,.stats-grid { grid-template-columns: 1fr; } .section-caption > span { display: none; } }
</style>
