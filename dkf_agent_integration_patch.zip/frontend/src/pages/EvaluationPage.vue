<script setup>
const emit = defineEmits(['navigate'])
// Values from the contest PDF's campus preliminary-round 100-point rubric.
// Displayed points are maxima, not achievements of this repository.
const items = [
  {title:'基础 NL2SQL 单表查询',score:10,desc:'至少 10 道单表问题，每题核验生成 SQL 能否在真实数据库正确执行。',view:'sql',tag:'功能 · 30分'},
  {title:'基础 RAG 单文档问答',score:10,desc:'至少 10 道单文档题，答案必须根据原文核对，不以模型主观评价替代事实。',view:'knowledge',tag:'功能 · 30分'},
  {title:'答案可解释性',score:5,desc:'完整展示所执行 SQL、引用片段/页码与可查询的工具链路。',view:'trace',tag:'功能 · 30分'},
  {title:'交互 Demo 可用性',score:5,desc:'提供可交互界面，覆盖成功、失败、需澄清及无证据结果。',view:'chat',tag:'功能 · 30分'},
  {title:'NL2SQL 执行准确率',score:10,desc:'固定评测集与数据库快照；评测结果一致率 ≥70% / 80% / 90% 对应评分分档。',view:'sql',tag:'性能 · 25分'},
  {title:'RAG 答案忠实度',score:10,desc:'逐条与检索原文比对；准确率 ≥70% / 80% / 90% 对应评分分档。',view:'knowledge',tag:'性能 · 25分'},
  {title:'系统效率与规模分析',score:5,desc:'提交复杂度分析、至少 2 种数据规模的端到端延迟与优化策略。',view:'sql',tag:'性能 · 25分'},
  {title:'中级任务攻克质量与数量',score:15,desc:'至少 1 个中级方向才满足初赛有效参赛门槛；建议重点验证任务 3 澄清、4 Schema Linking、6 公式。',view:'chat',tag:'优化 · 30分'},
  {title:'系统鲁棒性',score:10,desc:'对模糊输入、错别字、错误数据源、解析失败及重复请求进行回归测试。',view:'chat',tag:'优化 · 30分'},
  {title:'多轮对话上下文保持',score:5,desc:'至少进行连续 5 轮的真实业务追问，核验条件继承和纠错。',view:'chat',tag:'优化 · 30分'},
  {title:'技术文档质量',score:10,desc:'设计报告、技术实现说明书、Schema、实验指标、明确创新点与局限性。',view:'evaluation',tag:'文档 · 10分'},
  {title:'线上演示效果',score:5,desc:'通过视频或答辩现场演示完整链路与可验证结果。',view:'home',tag:'演示 · 5分'}
]
const fullScore = items.reduce((total,item) => total + item.score,0)
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">COMPETITION / ACCEPTANCE PLAN</div><h1 class="page-title">赛题要求与客观验收</h1><p class="page-subtitle">依据赛题八校内初赛完整评分条款整理。页面显示的是满分标准，绝非已经获得的分数。</p></div><span class="pill warn">{{ fullScore }} 分评分体系 · 全部待实测</span></header>
    <div class="notice warn" style="margin-bottom:19px"><strong>有效参赛门槛：</strong>校内初赛至少完成 1 个中级任务。决赛需至少 3 个中级任务，并着重评测多源融合。前端有界面并不意味着准确率、忠实度、鲁棒性指标已通过。</div>
    <div class="eval-grid"><article v-for="(item,i) in items" :key="item.title" class="eval-card card"><div class="eval-top"><span class="eval-number">{{String(i+1).padStart(2,'0')}}</span><span class="pill">{{item.tag}}</span></div><h3>{{item.title}} <small>满分 {{item.score}}</small></h3><p>{{item.desc}}</p><div class="eval-bottom"><span class="pill warn">待实测 / 待举证</span><button v-if="item.view!=='evaluation'" class="btn small outline" type="button" @click="emit('navigate',item.view)">进入演示 ↗</button></div></article></div>
    <section class="card card-pad" style="margin-top:20px"><div class="panel-heading"><h3>初赛提交材料核对</h3><span class="pill">缺一项应在提交前补齐</span></div><div class="deliver-grid"><div><b>设计报告</b><p>Word + PDF，建议 ≤20 页；封面/目录后 1–2 页为核心亮点预览，必须引用真实指标。</p></div><div><b>技术实现说明书</b><p>建议 ≤30 页；覆盖 NL2SQL、RAG、跨源策略、解释性、中级任务与实验。</p></div><div><b>技术数据 ZIP</b><p>源码、Schema、至少 10 份不同类型知识库样本、依赖版本、启动脚本及必要模型权重。</p></div><div><b>决赛补全项</b><p>至少 3 个中级任务；单问题自动跨源规划、多跳、5 轮以上上下文、鲁棒性与性能证明。</p></div></div></section>
  </div>
</template>
<style scoped>
.eval-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:14px; }
.eval-card { padding:21px; }.eval-top { display:flex; justify-content:space-between; align-items:center; }.eval-number {font:700 12px Consolas,monospace;color:#1798ae;}.eval-card h3 {font-size:14px; margin:14px 0 9px;color:#29465a;}.eval-card h3 small{font-size:10px;color:#208ca9;margin-left:5px;}.eval-card p{font-size:12px;color:#8195a4;line-height:1.8;min-height:42px;}.eval-bottom {display:flex;align-items:center;justify-content:space-between;border-top:1px solid #e9f0f4;padding-top:13px;margin-top:14px;}
.deliver-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;}.deliver-grid div{background:#f7fafc;border-radius:9px;padding:17px;}.deliver-grid b{font-size:12px;color:#27536a;}.deliver-grid p{font-size:11px;line-height:1.75;color:#7f95a5;margin:9px 0 0;}
@media(max-width:650px){.eval-grid,.deliver-grid{grid-template-columns:1fr;}}
</style>
