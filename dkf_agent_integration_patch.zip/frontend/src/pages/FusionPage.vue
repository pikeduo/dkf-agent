<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { askKnowledge, errorMessage, listKnowledgeBases, runText2Sql } from '../utils/api'
import ResultTable from '../components/ResultTable.vue'
import EvidencePanel from '../components/EvidencePanel.vue'
import { cleanCell } from '../utils/format'
const dbId = ref('chinook')
const subDb = ref('')
const sqlQuestion = ref('找出消费金额最高的客户姓名')
const kbId = ref('')
const kbs = ref([])
const docTemplate = ref('根据文档，{{entity}} 有哪些可以验证的成功经验或相关描述？请给出引用。')
const sourceRow = ref(0)
const sourceColumn = ref(0)
const allowCloud = ref(false)
const sqlResult = ref(null)
const ragResult = ref(null)
const ragQuestion = ref('')
const busy = ref('')
const error = ref('')
const info = ref('')

const rows = computed(() => sqlResult.value?.rows || [])
const columns = computed(() => sqlResult.value?.columns || [])
const entity = computed(() => {
  const raw = rows.value[sourceRow.value]?.[sourceColumn.value]
  const str = raw == null ? '' : cleanCell(raw)
  return str.length <= 160 ? str : ''
})
const composed = computed(() => docTemplate.value.replaceAll('{{entity}}', entity.value))
watch([sqlQuestion,dbId,subDb], () => { sqlResult.value=null; ragResult.value=null })
onMounted(async () => { try { kbs.value = (await listKnowledgeBases(100,0)).items || []; kbId.value = kbs.value.find(x=>x.status==='ACTIVE')?.kb_id || '' } catch(e) { error.value=errorMessage(e) } })

async function executeSql() {
  if (!sqlQuestion.value.trim() || busy.value) return
  busy.value='sql'; error.value=''; info.value=''; sqlResult.value=null; ragResult.value=null
  try {
    sqlResult.value = await runText2Sql({question:sqlQuestion.value.trim(),dbId:dbId.value,subDb:subDb.value.trim()})
    sourceRow.value=0; sourceColumn.value=0
    if (sqlResult.value.ok && rows.value.length) info.value='第一阶段已完成。请确认下面选定的结构化结果，再决定是否发送给文档问答。'
    else info.value='未获得可用结构化记录，联合查询已经停止，未发送文档请求。'
  } catch(e) { error.value=errorMessage(e) }
  finally { busy.value='' }
}
async function executeRag() {
  if (busy.value || !sqlResult.value?.ok || !entity.value || !kbId.value) return
  if (!allowCloud.value) {error.value='必须明确勾选本次云端调用许可。';return}
  if (!docTemplate.value.includes('{{entity}}')) {error.value='文档问题模板必须包含 {{entity}}，以明确绑定已查得的实体。';return}
  busy.value='rag'; error.value=''; ragResult.value=null
  ragQuestion.value=composed.value
  try { ragResult.value=await askKnowledge({kbId:kbId.value,question:ragQuestion.value,allowCloud:true,topK:30}) }
  catch(e) {error.value=errorMessage(e)}
  finally {busy.value=''}
}
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">EXPLICIT CROSS-SOURCE DEMO</div><h1 class="page-title">跨源联合查询演示</h1><p class="page-subtitle">先查数据库、人工确认实体，再用真实文档证据回答关联问题。每一步都保留原始出处。</p></div><span class="pill warn">显式两阶段 · 非自主规划</span></header>
    <div class="notice warn" style="margin-bottom:20px"><strong>能力边界：</strong>本页实现可复现的 SQL → 实体绑定 → RAG 两阶段跨源演示，不宣称已完成单问题自主分解、多跳 Agent 规划或赛题决赛完整融合能力。</div>
    <div class="split">
      <section class="card card-pad">
        <div class="panel-heading"><h3><span class="number">01</span> 结构化问数</h3><span class="pill">SQL 来源</span></div>
        <div class="form-grid"><div class="field"><label for="fusion-db">数据库</label><select id="fusion-db" v-model="dbId" class="select"><option value="chinook">chinook</option><option value="bird">bird</option><option value="cosql">cosql</option><option value="adventureworks">adventureworks</option></select></div><div class="field"><label for="fusion-subdb">子库 ID（按需）</label><input id="fusion-subdb" v-model="subDb" class="input" placeholder="如实际 BIRD 子库" /></div></div>
        <div class="field" style="margin-top:18px"><label for="fusion-question">第一阶段的结构化问题</label><textarea id="fusion-question" v-model="sqlQuestion" class="textarea" rows="3" maxlength="12000"></textarea></div>
        <button class="btn primary" style="margin-top:19px" type="button" :disabled="!!busy || !sqlQuestion.trim()" @click="executeSql">{{ busy==='sql' ? '正在执行 SQL…' : '第一步：查询数据库 →' }}</button>
        <div v-if="sqlResult" class="phase-result"><div class="notice" :class="sqlResult.ok?'success':'warn'">{{ sqlResult.ok ? 'SQL 只读执行成功' : `查询未完成：${sqlResult.error || sqlResult.stage}` }}</div><pre class="code-block" style="margin-top:12px">{{ sqlResult.sql || '-- 无已执行 SQL' }}</pre><ResultTable :columns="columns" :rows="rows" :truncated="sqlResult.truncated" /></div>
      </section>
      <section class="card card-pad">
        <div class="panel-heading"><h3><span class="number">02</span> 知识库问答</h3><span class="pill">文档来源</span></div>
        <div class="field"><label for="fusion-kb">目标知识库</label><select id="fusion-kb" v-model="kbId" class="select"><option value="">选择知识库</option><option v-for="kb in kbs" :key="kb.kb_id" :value="kb.kb_id" :disabled="kb.status!=='ACTIVE'">{{ kb.name }}</option></select></div>
        <div class="form-grid" style="margin-top:15px"><div class="field"><label for="fusion-row">使用哪一行</label><select id="fusion-row" v-model.number="sourceRow" class="select" :disabled="!rows.length"><option v-for="(_,idx) in rows.slice(0,50)" :key="idx" :value="idx">第 {{ idx+1 }} 行</option></select></div><div class="field"><label for="fusion-col">绑定哪个字段</label><select id="fusion-col" v-model.number="sourceColumn" class="select" :disabled="!columns.length"><option v-for="(col,idx) in columns" :key="idx" :value="idx">{{ col }}</option></select></div></div>
        <div v-if="entity" class="entity-box">已确认的结构化实体：<strong>{{ entity }}</strong></div>
        <div class="field" style="margin-top:17px"><label for="fusion-prompt">文档检索问题模板（必须包含 <code class="monospace" v-text="'{{entity}}'"></code>）</label><textarea id="fusion-prompt" v-model="docTemplate" class="textarea" rows="3"></textarea></div>
        <div v-if="entity" class="query-preview"><small>将向知识库提交的实际问题</small><p>{{ composed }}</p></div>
        <label class="check" style="margin:14px 0"><input v-model="allowCloud" type="checkbox" />确认选中的数据库实体与文档问题可以发送给模型，并接受费用。</label>
        <button class="btn primary" type="button" :disabled="!!busy || !sqlResult?.ok || !entity || !kbId || !allowCloud || !docTemplate.includes('{{entity}}')" @click="executeRag">{{ busy==='rag'?'检索与生成中…':'第二步：结合实体检索文档 →' }}</button>
      </section>
    </div>
    <div v-if="error" class="notice danger" style="margin-top:18px">{{ error }}</div><div v-if="info" class="notice" style="margin-top:18px">{{ info }}</div>
    <section v-if="ragResult" class="card card-pad" style="margin-top:20px"><div class="panel-heading"><h3>跨源演示结果</h3><span :class="['pill',ragResult.status==='success'?'ok':'warn']">{{ ragResult.status==='success'?'文档回答成功':'证据不足' }}</span></div><p class="answer-text">{{ ragResult.answer }}</p><div class="notice">结构化事实来自上方 SQL 执行结果；以下文档引用来自本次 DKF-Agent 查询。最终答案并未额外验证二者是否存在因果关系。</div><div class="divider"></div><EvidencePanel :items="ragResult.citations || []" /></section>
  </div>
</template>
<style scoped>
.number { display:inline-grid; place-items:center; margin-right:7px; color:#0d8dab; background:#eaf6fb; border-radius:7px; width:27px; height:27px; font:800 12px Consolas,monospace; }
.phase-result { margin-top:18px; }.phase-result .table-scroll { margin-top:14px; }.entity-box { background:#eaf8f6; padding:11px 12px; font-size:12px; border-radius:9px; margin-top:15px; color:#4b7e78; }.entity-box strong { color:#0d756d; font-size:14px; margin-left:7px; }
.query-preview { padding:13px; background:#f5f9fb; border:1px solid #e5edf2; border-radius:9px; margin-top:14px; }.query-preview small { color:#7f94a4; font-size:10px; }.query-preview p { margin:7px 0 0; color:#3e6276; font-size:12px; line-height:1.65; }
</style>
