<script setup>
import { nextTick, onBeforeUnmount, ref } from 'vue'
import { CHAT_EXAMPLES } from '../constants'
import { createSession, deleteSession, errorMessage, runQuery } from '../utils/api'
import ResultTable from '../components/ResultTable.vue'
const messages = ref([])
const userInput = ref('')
const busy = ref(false)
const dbId = ref('chinook')
const pending = ref(null)
const scroll = ref(null)
let session = null
let seq = 0
const add = data => messages.value.push({ id: ++seq, ...data })
const jump = async () => { await nextTick(); scroll.value?.scrollTo({top:scroll.value.scrollHeight,behavior:'smooth'}) }

async function newChat() {
  if (busy.value) return
  const old = session
  session = null
  messages.value = []; pending.value = null; userInput.value=''
  if (old) deleteSession(old).catch(() => {})
}
async function ask(sample) { if (busy.value) return; await newChat(); userInput.value=sample; await send() }

async function send(choice=null) {
  const question = (choice || userInput.value || '').trim()
  if (!question || busy.value) return
  busy.value = true
  const reply = pending.value
  if (!choice) userInput.value = ''
  add({ role:'user', text: question, replyTo: reply?.text || '' })
  await jump()
  try {
    if (!session) session = await createSession()
    const body = reply
      ? { question, reply_to:reply.id, isClarify:true }
      : { question, database:dbId.value || null }
    let result
    try { result = await runQuery(body,session) }
    catch(error) {
      // Only a new question may recover from an expired development session.
      if (error?.response?.status !== 404 || reply) throw error
      session = await createSession()
      result = await runQuery(body,session)
    }
    add({role:'assistant', payload:result, text: result.answer || result.intent?.decision?.message || result.error || '后端未返回说明。'})
    const questionId = result.clarification_message_id
    if (result.stage === 'needs_user' && questionId && result.ok) {
      pending.value = {id:questionId,text:result.answer || result.intent?.decision?.message}
    } else pending.value = null
  } catch(error) {
    add({role:'assistant',error:errorMessage(error),text:'本次请求未完成。请检查服务状态，确认是否收费后再决定是否重新发送。'})
    if (error?.response?.status === 404 && reply) { session=null; pending.value=null }
  } finally { busy.value=false; await jump() }
}
onBeforeUnmount(() => { if (session) deleteSession(session).catch(() => {}) })
const isSuccessful = p => !!(p?.ok && p?.answer_ready && p?.stage === 'answered')
const notice = p => {
  if (!p) return ''
  if (p.stage==='evidence_ready') return '已检索到原文摘录，但没有生成完整、已验证的最终回答。正式 RAG 请使用「文档知识问答」。'
  if (p.stage==='needs_user') return p.clarification_message_id ? '请继续回复这条澄清问题。' : '服务端未提供有效追问标识，请重新完整描述问题。'
  if (p.stage==='intent_ready') return '仅完成意图分析，尚未执行最终查询或计算。'
  if (p.stage==='blocked') return '执行被安全策略阻止；没有擅自补齐缺失条件。'
  if (p.stage==='execution_failed') return '下游工具执行失败；不能将此结果作为答案。'
  if (p.stage==='answered' && p.answer_ready) return '已执行并返回结果。请根据引用与 SQL 自行核实。'
  return `当前执行阶段：${p.stage || '未知'}。`
}
const candidateList = p => p?.candidates?.length ? p.candidates : p?.intent?.decision?.candidates || []
</script>
<template>
  <section class="page">
    <header class="page-header"><div><div class="eyebrow">SEMANTIC UNDERSTANDING / TASK 3 & 6</div><h1 class="page-title">意图分析与主动澄清</h1><p class="page-subtitle">在问题条件不完整时先追问；公式计算与业务查询只在满足条件时执行。</p></div><span class="pill">多轮会话 · 令牌仅驻留内存</span></header>
    <div class="chat-workspace card">
      <div class="chat-header"><div><span class="chat-symbol">✳</span><strong>智能对话</strong><span class="chat-help">意图识别 / 公式 / 可验证问数</span></div><div class="chat-actions"><label for="chat-db">业务库</label><select id="chat-db" v-model="dbId" :disabled="busy || !!pending" class="select"><option value="chinook">Chinook</option><option value="">不指定数据库</option></select><button class="btn small outline" type="button" :disabled="busy" @click="newChat">＋ 新会话</button></div></div>
      <div ref="scroll" class="chat-messages" role="log" aria-live="polite">
        <div v-if="!messages.length" class="empty-chat"><div class="empty-icon">✳</div><h2>你好，有什么想了解的数据？</h2><p>我会先识别你的查询目标、缺失条件和来源，再决定是否执行工具。</p><div class="prompt-grid"><button v-for="s in CHAT_EXAMPLES" :key="s.text" class="prompt-button" type="button" @click="ask(s.text)"><span>{{ s.label }}</span>{{ s.text }} <b>↗</b></button></div></div>
        <template v-for="msg in messages" :key="msg.id">
          <div v-if="msg.role==='user'" class="chat-row own"><div class="user-bubble"><small v-if="msg.replyTo">回复澄清：{{ msg.replyTo }}</small>{{ msg.text }}</div></div>
          <div v-else class="chat-row bot"><span class="bot-avatar">✳</span><div class="bot-card">
            <div v-if="msg.error" class="notice danger">{{ msg.error }}</div>
            <div v-if="msg.payload" class="answer-status"><span :class="['pill',isSuccessful(msg.payload)?'ok':msg.payload.stage==='needs_user'?'warn':'']">{{ isSuccessful(msg.payload) ? '已执行' : msg.payload.stage==='needs_user'?'等待澄清':'未完成最终回答' }}</span><span>Trace {{ msg.payload.trace_id || '未提供' }}</span></div>
            <p class="answer-text">{{ msg.text }}</p>
            <div v-if="msg.payload" class="notice" :class="{warn:!isSuccessful(msg.payload)}">{{ notice(msg.payload) }}</div>
            <div v-if="msg.payload?.stage==='needs_user' && pending && pending.id===msg.payload.clarification_message_id" class="clarify-actions"><button v-for="option in candidateList(msg.payload)" :key="option" class="btn outline small" type="button" :disabled="busy" @click="send(option)">{{ option }}</button></div>
            <details v-if="msg.payload?.sql" class="chat-extra"><summary>查看实际 SQL</summary><pre class="code-block">{{ msg.payload.sql }}</pre></details>
            <details v-if="msg.payload?.calculation" class="chat-extra"><summary>查看公式与参数计算</summary><pre class="mini-json">{{ JSON.stringify(msg.payload.calculation,null,2) }}</pre></details>
            <details v-if="msg.payload?.rows?.length" class="chat-extra"><summary>查看数据库查询结果</summary><ResultTable :columns="msg.payload.columns || []" :rows="msg.payload.rows || []" :truncated="msg.payload.truncated" /></details>
            <details v-if="msg.payload?.citations?.length" class="chat-extra"><summary>查看来源说明</summary><pre class="mini-json">{{ JSON.stringify(msg.payload.citations,null,2) }}</pre></details>
            <details v-if="msg.payload?.intent?.interpretation" class="chat-extra"><summary>查看意图识别内容（非模型思维链）</summary><pre class="mini-json">{{ JSON.stringify({goals:msg.payload.intent.interpretation.goals,requirements:msg.payload.intent.interpretation.requirements},null,2) }}</pre></details>
          </div></div>
        </template>
        <div v-if="busy" class="chat-row bot"><span class="bot-avatar">✳</span><span class="pending-bubble">正在分析与调用已授权工具…</span></div>
      </div>
      <div class="composer-wrap"><div v-if="pending" class="reply-note"><span>等待澄清</span>{{ pending.text }}<button class="btn small outline" type="button" @click="newChat">另起会话</button></div><form class="chat-form" @submit.prevent="send()"><textarea v-model="userInput" rows="2" :placeholder="pending ? '请回复上一个澄清问题…' : '输入问题，例：Chinook 数据库一共有多少个艺术家？'" maxlength="12000" :disabled="busy" @keydown.enter.exact="e=>{if(!e.isComposing){e.preventDefault();send()}}"></textarea><button class="chat-send" type="submit" :disabled="busy || !userInput.trim()">↑</button></form><div class="chat-footer"><span>Enter 发送 · Shift + Enter 换行</span><span>不自动外传知识库资料</span></div></div>
    </div>
    <div class="notice warn" style="margin-top:15px">说明：此工作台调用竞赛包的 <span class="monospace">/api/query/run</span>。它不是完整跨源自主 Agent；文档生成式问答应转到 DKF-Agent 的正式 RAG 页面。</div>
  </section>
</template>
<style scoped>
.chat-workspace { display:flex; flex-direction:column; height:min(750px,calc(100vh - 245px)); min-height:510px; overflow:hidden; }
.chat-header { padding:16px 22px; border-bottom:1px solid #e8eef3; display:flex; align-items:center; justify-content:space-between; gap:15px; }
.chat-header >div:first-child { display:flex; gap:9px; align-items:center; }
.chat-header strong { font-size:14px; }
.chat-symbol { width:29px; height:29px; border-radius:9px; background:#e9f7fa; color:#198caf; display:grid; place-items:center; }
.chat-help { color:#9daeb9; font-size:11px; }
.chat-actions { display:flex; align-items:center; gap:11px; }
.chat-actions label { color:#98a9b6; font-size:11px; }
.chat-actions .select { width:125px; padding:8px; }
.chat-messages { flex:1; min-height:0; padding:25px 27px; overflow:auto; }
.empty-chat { max-width:750px; margin:35px auto 0; text-align:center; }
.empty-icon { color:#1e95ae; background:#e6f5fa; border-radius:19px; width:58px; height:58px; font-size:32px; margin:auto; display:grid; place-items:center; }
.empty-chat h2 { font-size:21px; margin:17px 0 9px; }.empty-chat p { font-size:12px; color:#90a3b0; }
.prompt-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:12px; margin:29px auto; }
.prompt-button { min-height:83px; text-align:left; border:1px solid #e0eaf0; background:#fbfdfe; border-radius:10px; padding:12px 14px; font-size:12px; line-height:1.6; color:#486277; position:relative; }.prompt-button:hover { border-color:#60b4cb; background:#f5fcfe; }
.prompt-button span { display:block; color:#2693af; font-size:11px; font-weight:700; margin-bottom:5px; }.prompt-button b { position:absolute; right:12px; top:12px; color:#abc7d3; }
.chat-row { display:flex; gap:11px; margin:16px 0; }.chat-row.own { justify-content:flex-end; }.user-bubble { background:#e5f4f8; color:#24556a; border-radius:14px 14px 4px 14px; padding:12px 16px; max-width:80%; font-size:13px; line-height:1.85; white-space:pre-wrap; }.user-bubble small { display:block; color:#51849a; font-size:10px; margin-bottom:6px; }
.bot-avatar { background:#125e7b; color:#fff; width:28px; height:28px; flex:none; border-radius:9px; display:grid; place-items:center; font-size:16px; }.bot-card { min-width:0; max-width:min(740px,90%); background:#fcfdfe; border:1px solid #e5edf3; border-radius:4px 14px 14px 14px; padding:15px 18px; }.bot-card .answer-text { margin:13px 0; }.answer-status { display:flex; justify-content:space-between; gap:10px; align-items:center; font-size:10px; color:#a0b0bb; }.bot-card .notice { margin-top:10px; }.clarify-actions { display:flex; gap:7px; flex-wrap:wrap; margin-top:12px; }
.chat-extra { margin-top:13px; border-top:1px solid #e8edf1; padding-top:10px; }.chat-extra summary { color:#107fa5; cursor:pointer; font-size:11px; }.chat-extra .code-block { margin-top:11px; }.mini-json { font-size:11px; line-height:1.6; overflow-wrap:anywhere; white-space:pre-wrap; color:#637c8e; padding:12px; background:#f2f7fa; border-radius:8px; }
.pending-bubble { color:#8ca3ae; font-size:12px; padding:7px 2px; }.composer-wrap { padding:15px 20px 14px; border-top:1px solid #e7edf2; }.reply-note { display:flex; align-items:center; gap:10px; background:#eef8fb; padding:8px 11px; border-radius:9px; color:#4b7487; font-size:12px; margin-bottom:9px; }.reply-note span { flex:none; font-size:10px; font-weight:700; color:#1287ac; }.reply-note .btn { margin-left:auto; }
.chat-form { display:flex; align-items:flex-end; gap:9px; background:#f9fcfd; border:1px solid #d9e6ec; border-radius:11px; padding:10px 11px; }.chat-form:focus-within { border-color:#46aac1; }.chat-form textarea { flex:1; border:none; outline:none; resize:vertical; min-height:52px; max-height:150px; font-size:13px; color:#204055; background:transparent; }.chat-send { background:#0a86b0; border:none; color:#fff; border-radius:8px; font-size:21px; font-weight:800; padding:8px 15px; }.chat-send:disabled { background:#9fc6d5; }.chat-footer { display:flex; justify-content:space-between; gap:10px; color:#a1afba; font-size:10px; padding:8px 4px 0; }
@media(max-width:670px) { .chat-header { padding:13px; flex-wrap:wrap; } .chat-help {display:none; } .chat-messages {padding:15px 12px; }.prompt-grid {grid-template-columns:1fr; }.chat-workspace { height:calc(100dvh - 230px); }.chat-actions {gap:5px; }.chat-actions label {display:none;} .user-bubble {max-width:93%;} }
</style>
