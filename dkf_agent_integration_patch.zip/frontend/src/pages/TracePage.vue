<script setup>
import { ref } from 'vue'
import { errorMessage, getTrace } from '../utils/api'
import TraceTimeline from '../components/TraceTimeline.vue'
const traceId = ref('')
const data = ref(null)
const error = ref('')
const busy = ref(false)
async function lookup() {
  if(!traceId.value.trim() || busy.value) return
  busy.value=true; error.value=''; data.value=null
  try { data.value=await getTrace(traceId.value.trim()) }
  catch(e) { error.value=errorMessage(e) }
  finally { busy.value=false }
}
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">TRACEABILITY / EXECUTION AUDIT</div><h1 class="page-title">执行链路追踪</h1><p class="page-subtitle">根据真实 Trace ID 获取工具调用记录、数据来源、执行阶段和耗时；不会在浏览器伪造步骤。</p></div></header>
    <section class="card card-pad"><div class="panel-heading"><h3>查询执行记录</h3><span class="pill">问数服务 Trace API</span></div><form class="toolbar" @submit.prevent="lookup"><div class="field"><label for="trace-id">Trace ID</label><input id="trace-id" v-model="traceId" class="input monospace" placeholder="粘贴 SQL 页面返回的 trace_id" /></div><button class="btn primary" :disabled="busy || !traceId.trim()">{{busy?'查询中…':'查询真实链路 →'}}</button></form><p class="hint" style="margin-top:13px">提示：目前 Text2SQL 等已登记的执行可查询；其他入口可能只返回 ID，尚未产生可查询轨迹。内存记录可能在服务重启后失效。</p><div v-if="error" class="notice warn">{{error}}</div></section>
    <section v-if="data" class="card card-pad" style="margin-top:17px"><div class="panel-heading"><h3>Trace 详情</h3><span class="pill ok">{{data.steps?.length || 0}} 步</span></div><p class="hint">关联问题：{{data.question || '未提供'}} · 时间：{{data.started_at || '未提供'}}</p><div class="divider"></div><TraceTimeline :trace="data" /></section>
    <section v-else-if="!error" class="card card-pad" style="margin-top:17px"><div class="empty">请先在「自然语言问数」页面完成一次真实查询并获得 Trace ID。</div></section>
  </div>
</template>
