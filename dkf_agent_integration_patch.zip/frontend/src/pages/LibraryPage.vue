<script setup>
import { onMounted, ref, watch } from 'vue'
import { createKnowledgeBase, errorMessage, getDocumentBlocks, getDocumentStatus,
  listDocuments, listKnowledgeBases, retryDocument, uploadDocuments } from '../utils/api'
import { shortId, statusTitle } from '../utils/format'

const bases = ref([]); const kbId = ref(''); const docs = ref([]); const kbName = ref('')
const selected = ref(null); const blocks = ref(null); const loading = ref(false); const busy = ref('')
const error = ref(''); const info = ref(''); const mode = ref('auto'); const uploadFiles = ref([])
const filesRef = ref(null)

async function refreshBases() {
  error.value = ''
  try {
    bases.value = (await listKnowledgeBases(100,0)).items || []
    if (!bases.value.some(b => b.kb_id === kbId.value)) kbId.value = bases.value[0]?.kb_id || ''
  } catch(e) { error.value = errorMessage(e) }
}
async function refreshDocs() {
  if (!kbId.value) { docs.value=[]; return }
  loading.value = true
  try { docs.value = (await listDocuments(kbId.value,100,0)).items || [] }
  catch(e) { error.value = errorMessage(e) }
  finally { loading.value=false }
}
watch(kbId,() => { selected.value=null; blocks.value=null; refreshDocs() })
onMounted(refreshBases)

async function addBase() {
  const name = kbName.value.trim()
  if (!name) return
  busy.value = 'create'; error.value=''; info.value=''
  try { const created = await createKnowledgeBase({name}); kbName.value=''; await refreshBases(); kbId.value=created.kb_id; info.value=`已创建知识库：${created.name}` }
  catch(e) { error.value=errorMessage(e) }
  finally { busy.value='' }
}
function handleFiles(ev) { uploadFiles.value = Array.from(ev.target.files || []) }
async function upload() {
  if (!kbId.value || !uploadFiles.value.length) return
  if (uploadFiles.value.length > 50) {error.value='单次最多选择 50 个文件。'; return}
  busy.value = 'upload'; info.value=''; error.value=''
  try {
    const response = await uploadDocuments(kbId.value, uploadFiles.value, mode.value)
    if (response.items) {
      info.value = `批量接收：${response.accepted_count} 项成功，${response.failed_count} 项失败。后台解析仍需按文档状态确认。`
      if (response.failed_count) error.value = '有部分文件未成功接收；请先核对已有 doc_id，勿直接整批重传。'
    } else {
      info.value = `文件已接收（Doc ${shortId(response.doc_id)}），不代表已解析完成。`
    }
    uploadFiles.value=[]
    if (filesRef.value) filesRef.value.value=''
    await refreshDocs()
  } catch(e) { error.value=`${errorMessage(e)} 上传可能已经保存原件，请先刷新列表核对，不要直接重传。` }
  finally { busy.value='' }
}
async function showDoc(doc) {
  selected.value = null; blocks.value = null; busy.value='detail'; error.value=''
  try { selected.value = await getDocumentStatus(doc.doc_id) }
  catch(e) { error.value = errorMessage(e) }
  finally { busy.value='' }
}
async function showBlocks() {
  if (!selected.value) return
  busy.value='blocks'; error.value=''
  try { blocks.value = (await getDocumentBlocks(selected.value.doc_id,20,0)).items || [] }
  catch(e) { error.value=errorMessage(e) }
  finally { busy.value='' }
}
async function retry() {
  if (!selected.value || busy.value) return
  if (!window.confirm('仅在确认失败原因已解决后重试该文档。继续吗？')) return
  busy.value='retry'; error.value=''
  try { await retryDocument(selected.value.doc_id); info.value='已提交重试；请稍后刷新状态确认。'; selected.value = await getDocumentStatus(selected.value.doc_id); await refreshDocs() }
  catch(e) { error.value=errorMessage(e) }
  finally { busy.value='' }
}
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">KNOWLEDGE BASE / DOCUMENT LIFECYCLE</div><h1 class="page-title">知识库与多模态文档管理</h1><p class="page-subtitle">创建知识库、上传 PDF / Word / 表格 / 图片，跟踪 MinerU / Native 解析、切片与向量入库。</p></div><span class="pill">真实异步处理 · READY 才可验收</span></header>
    <div class="split">
      <section class="card card-pad">
        <div class="panel-heading"><h3>当前知识库</h3><button type="button" class="btn small outline" @click="refreshBases">刷新列表</button></div>
        <div class="field"><label for="kb-select">知识库</label><select id="kb-select" v-model="kbId" class="select"><option value="">请选择知识库</option><option v-for="kb in bases" :key="kb.kb_id" :value="kb.kb_id">{{ kb.name }}</option></select></div>
        <div class="divider"></div>
        <div class="field"><label for="kb-name">新建知识库</label><div class="input-row"><input id="kb-name" v-model="kbName" class="input" placeholder="如：竞赛演示知识库" maxlength="255" @keydown.enter.prevent="addBase" /><button class="btn outline" type="button" :disabled="busy === 'create' || !kbName.trim()" @click="addBase">创建</button></div></div>
        <div class="divider"></div>
        <div class="panel-heading"><h3>上传文档</h3><span class="pill">最多 50 份 / 次</span></div>
        <div class="field"><label for="file-input">选择本地文件</label><input id="file-input" ref="filesRef" class="file" type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.md,.png,.jpg,.jpeg,.webp,.ppt,.pptx" @change="handleFiles" /><span class="hint">文档能否接收由后端白名单最终确认；上传后异步解析，不应重复发送相同原件。</span></div>
        <div class="field" style="margin-top:13px"><label for="parse-mode">解析策略</label><select id="parse-mode" v-model="mode" class="select"><option value="auto">自动路由（推荐）</option><option value="native">原生解析</option><option value="mineru">MinerU 云解析</option></select></div>
        <div class="toolbar" style="margin-top:19px"><button class="btn primary" type="button" :disabled="!kbId || !uploadFiles.length || !!busy" @click="upload">{{ busy==='upload' ? '正在上传…' : `上传并提交解析${uploadFiles.length ? ' ('+uploadFiles.length+')' : ''} →` }}</button></div>
        <p v-if="error" class="notice danger" style="margin-top:16px">{{ error }}</p><p v-if="info" class="notice success" style="margin-top:16px">{{ info }}</p>
      </section>
      <section class="card card-pad">
        <div class="panel-heading"><h3>文档处理进度</h3><button class="btn small outline" type="button" :disabled="loading || !kbId" @click="refreshDocs">{{ loading ? '读取中…' : '刷新状态' }}</button></div>
        <div v-if="!docs.length" class="empty">当前知识库暂无文档，或尚未加载成功。</div>
        <div v-else class="doc-list"><button v-for="doc in docs" :key="doc.doc_id" class="doc-item" type="button" @click="showDoc(doc)"><span class="doc-file">▤</span><span class="doc-text"><strong :title="doc.file_name">{{ doc.file_name }}</strong><small>{{ doc.file_type?.toUpperCase() }} · {{ shortId(doc.doc_id) }}</small></span><span :class="['pill', ['READY','PARTIAL_READY'].includes(doc.status) ? 'ok' : doc.status==='FAILED' ? 'danger' : 'warn']">{{ statusTitle(doc.status) }}</span></button></div>
        <p class="hint" style="margin-top:16px">此处返回的是前 100 份文档。状态变化请点击“刷新状态”；解析成功不等于内容质量通过人工验收。</p>
      </section>
    </div>
    <section v-if="selected" class="card card-pad detail-panel">
      <div class="panel-heading"><h3>文档可观测详情</h3><span :class="['pill',selected.status==='FAILED'?'danger':['READY','PARTIAL_READY'].includes(selected.status)?'ok':'warn']">{{ statusTitle(selected.status) }}</span></div>
      <p class="hint">{{ selected.doc_id }}</p>
      <div class="mini-metrics"><div><small>解析 Block</small><strong>{{ selected.block_count }}</strong></div><div><small>切片 Chunk</small><strong>{{ selected.chunk_count }}</strong></div><div><small>Embedding</small><strong>{{ selected.vector_count }}</strong></div><div><small>异常向量</small><strong>{{ selected.invalid_vector_count }}</strong></div></div>
      <div v-if="selected.parse_quality" class="notice" style="margin-top:14px">解析质量信号：<pre class="quality">{{ JSON.stringify(selected.parse_quality,null,2) }}</pre></div>
      <div v-if="selected.error_message || selected.management?.error_code" class="notice danger" style="margin-top:14px">{{ selected.error_message || selected.management?.error_code }}</div>
      <div class="toolbar" style="margin-top:19px"><button class="btn outline" type="button" :disabled="!!busy" @click="showDoc(selected)">刷新文档状态</button><button class="btn outline" type="button" :disabled="!!busy" @click="showBlocks">查看 Block 阅读顺序</button><button v-if="selected.status==='FAILED'" class="btn danger" type="button" :disabled="!!busy" @click="retry">修复后重试</button></div>
      <div v-if="blocks" class="block-list"><div v-for="block in blocks" :key="block.block_id" class="evidence-item"><div class="evidence-head"><strong>Block {{ block.block_index ?? '未排序' }} · 第 {{ block.page }} 页</strong><span>{{ block.block_type }} · {{ block.section || '无章节' }}</span></div><p class="evidence-text">{{ block.text }}</p><small class="hint">来源：{{ block.source }} · bbox：{{ block.bbox ? JSON.stringify(block.bbox) : '未提供' }}</small></div></div>
    </section>
  </div>
</template>
<style scoped>
.input-row { display:flex; gap:8px; }.input-row .input { flex:1; min-width:0; }.file { border:1px dashed #abd2e0; border-radius:10px; width:100%; padding:17px; background:#f7fcfd; font-size:12px; color:#53788a; }
.doc-list { display:grid; gap:5px; max-height:426px; overflow:auto; }
.doc-item { background:transparent; border:1px solid transparent; border-radius:9px; padding:11px 8px; display:flex; align-items:center; gap:10px; width:100%; text-align:left; }
.doc-item:hover { border-color:#dcecf2; background:#f8fcff; }
.doc-file { width:33px; height:36px; display:grid; place-items:center; border-radius:8px; color:#318eae; background:#eaf6fa; font-size:20px; flex:none; }
.doc-text { min-width:0; flex:1; }.doc-text strong { font-size:12px; display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:#2b485b; }.doc-text small { font-size:10px; margin-top:6px; display:block; color:#98abb8; }
.detail-panel { margin-top:18px; }.mini-metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }.mini-metrics >div { border-radius:10px; padding:16px; background:#f6fafc; }.mini-metrics small { font-size:11px; color:#7890a3; display:block; }.mini-metrics strong { margin-top:7px; display:block; font-size:22px; color:#1e5670; }
.quality { white-space:pre-wrap; overflow-wrap:anywhere; margin:7px 0 0; font-size:11px; }.block-list { margin-top:20px; display:grid; gap:12px; }.block-list .evidence-text { max-height:140px; }
@media (max-width:650px) { .mini-metrics { grid-template-columns:repeat(2,1fr); } }
</style>
