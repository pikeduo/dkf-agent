<script setup>
import { onMounted, ref } from 'vue'
import { errorMessage, getTrace, listContestSources, runText2Sql } from '../utils/api'
import { SQL_EXAMPLES } from '../constants'
import ResultTable from '../components/ResultTable.vue'
import TraceTimeline from '../components/TraceTimeline.vue'

const sources = ref([{db_id:'chinook',name:'Chinook（示例数据库）'}])
const sourceError = ref('')
const dbId = ref('chinook')
const subDb = ref('')
const question = ref(SQL_EXAMPLES[0])
const busy = ref(false)
const error = ref('')
const result = ref(null)
const trace = ref(null)
const traceError = ref('')
const loadingTrace = ref(false)

onMounted(async () => {
  try { sources.value = (await listContestSources()).items || sources.value }
  catch(e) { sourceError.value = errorMessage(e) }
})
async function submit() {
  if (!question.value.trim() || busy.value) return
  busy.value = true; error.value = ''; result.value = null; trace.value = null; traceError.value = ''
  try {
    result.value = await runText2Sql({ question: question.value.trim(), dbId: dbId.value, subDb: subDb.value.trim() })
  } catch(e) { error.value = errorMessage(e) }
  finally { busy.value = false }
}
async function copySql() {
  if (!result.value?.sql) return
  try { await navigator.clipboard.writeText(result.value.sql) }
  catch(e) { traceError.value = '无法复制 SQL，请手动从下方文本框复制。' }
}
async function loadTrace() {
  if (!result.value?.trace_id || loadingTrace.value) return
  loadingTrace.value = true; traceError.value = ''
  try { trace.value = await getTrace(result.value.trace_id) }
  catch(e) { traceError.value = errorMessage(e) }
  finally { loadingTrace.value = false }
}
</script>
<template>
  <div class="page">
    <header class="page-header"><div><div class="eyebrow">STRUCTURED DATA / NL2SQL</div><h1 class="page-title">精准自然语言问数</h1><p class="page-subtitle">业务要素识别、Schema Linking、SQL 生成校验与只读执行，一步到结果与来源。</p></div><span class="pill">任务 4 · Schema Linking</span></header>
    <div class="split">
      <section class="card card-pad">
        <div class="panel-heading"><h3>配置查询范围</h3><span class="pill">明确数据库 / 子库</span></div>
        <div class="form-grid">
          <div class="field"><label for="sql-db">数据集</label><select id="sql-db" v-model="dbId" class="select"><option v-for="item in sources" :key="item.db_id" :value="item.db_id">{{ item.db_id }}</option></select></div>
          <div class="field"><label for="sql-subdb">业务子库（可选）</label><input id="sql-subdb" v-model="subDb" class="input" placeholder="BIRD / CoSQL 需要真实子库 ID" /></div>
        </div>
        <p v-if="sourceError" class="hint">数据源目录读取失败，暂用 Chinook 选项：{{ sourceError }}</p>
        <div class="field" style="margin-top:20px"><label for="sql-question">你的业务问题</label><textarea id="sql-question" v-model="question" class="textarea" rows="4" maxlength="12000" placeholder="请用自然语言描述需要查询的指标、筛选条件和维度…"></textarea></div>
        <div class="sample-label">建议尝试</div><div class="samples"><button v-for="sample in SQL_EXAMPLES" :key="sample" class="sample" type="button" @click="question = sample">{{ sample }} ↗</button></div>
        <div class="sql-actions"><button type="button" class="btn primary" :disabled="busy || !question.trim()" @click="submit">{{ busy ? '查询执行中…' : '执行问数查询 →' }}</button><span class="hint">只读 SQL · 不自动更改业务数据</span></div>
        <div v-if="error" class="notice danger" style="margin-top:17px">{{ error }}</div>
      </section>
      <section class="card card-pad side-info"><div class="eyebrow">EXECUTION PIPELINE</div><h3>数据问数执行链路</h3><div v-for="(item,i) in ['业务问题 → 要素识别','Schema Linking → 精准表定位','SQL 生成 → 安全校验','只读执行 → 返回行列','Trace 追溯 → 校验结果']" :key="i" class="pipeline-row"><span>{{ String(i+1).padStart(2,'0') }}</span><strong>{{ item }}</strong></div><p class="hint">未导入实际业务数据库、Schema 索引或上游不可用时，后端将报告失败；界面不会提供模拟查询结果。</p></section>
    </div>
    <div v-if="result" class="result-stack">
      <section class="card card-pad">
        <div class="panel-heading"><h3>查询结果</h3><span :class="['pill',result.ok ? 'ok' : 'danger']">{{ result.ok ? 'SQL 已执行' : '未完成执行' }} · {{ result.stage }}</span></div>
        <div v-if="!result.ok" class="notice warn">{{ result.error || '查询未通过校验或未执行；不能将其视为正确结果。' }}</div>
        <div class="result-metrics"><span>返回行数 <b>{{ result.row_count ?? result.rows?.length ?? '—' }}</b></span><span>执行耗时 <b>{{ result.latency_s ?? '—' }} s</b></span><span>命中表 <b>{{ result.tables?.length ?? 0 }}</b></span><span>自动修复 <b>{{ result.repaired ? '是' : '否' }}</b></span></div>
        <div class="panel-heading"><h3>实际 SQL 语句</h3><button v-if="result.sql" class="btn small outline" type="button" @click="copySql">复制 SQL</button></div>
        <pre class="code-block">{{ result.sql || '-- 服务端未返回可执行 SQL' }}</pre>
        <div v-if="result.tables?.length" class="source-tags"><span v-for="(table,i) in result.tables" :key="i" class="pill">{{ typeof table === 'string' ? table : JSON.stringify(table) }}</span></div>
        <div class="divider"></div>
        <div class="panel-heading"><h3>查询数据表格</h3><span class="hint">严格展示服务端返回结果</span></div>
        <ResultTable :columns="result.columns || []" :rows="result.rows || []" :truncated="result.truncated" />
      </section>
      <section class="card card-pad">
        <div class="panel-heading"><h3>可解释执行日志</h3><button class="btn small outline" type="button" :disabled="loadingTrace || !result.trace_id" @click="loadTrace">{{ loadingTrace ? '加载中…' : trace ? '刷新链路' : '读取真实 Trace' }}</button></div>
        <p class="hint">Trace ID：{{ result.trace_id || '本次未返回' }}。内容来自后端登记的工具执行记录。</p>
        <div v-if="traceError" class="notice warn">{{ traceError }}</div>
        <TraceTimeline :trace="trace" />
      </section>
    </div>
  </div>
</template>
<style scoped>
.samples { display:flex; flex-wrap:wrap; gap:8px; }
.sample-label { margin:22px 0 9px; font-size:11px; color:#8296a7; }
.sample { border:1px solid #e3edf3; background:#f9fcfd; border-radius:7px; padding:8px 10px; color:#3f6c80; font-size:11px; text-align:left; }
.sample:hover { border-color:#8bc5d6; }
.sql-actions { display:flex; gap:15px; align-items:center; margin-top:23px; flex-wrap:wrap; }
.side-info h3 { font-size:20px; margin:9px 0 22px; color:#1b3548; }
.pipeline-row { display:flex; align-items:center; gap:12px; padding:14px 0; border-bottom:1px solid #eaf0f4; font-size:12px; }
.pipeline-row span { font:700 11px Consolas,monospace; color:#1393ab; }
.pipeline-row strong { font-weight:620; color:#496578; }
.side-info .hint { margin-top:24px; }
.result-stack { display:grid; gap:19px; margin-top:19px; }
.result-metrics { display:flex; flex-wrap:wrap; gap:28px; padding:18px 0 22px; font-size:11px; color:#7f95a5; }
.result-metrics b { color:#154b63; font-size:14px; margin-left:4px; }
.source-tags { display:flex; gap:6px; margin-top:12px; flex-wrap:wrap; }
</style>
