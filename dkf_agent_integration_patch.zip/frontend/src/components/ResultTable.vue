<script setup>
import { cleanCell } from '../utils/format'
defineProps({ columns: { type: Array, default: () => [] }, rows: { type: Array, default: () => [] }, truncated: Boolean })
</script>
<template>
  <div v-if="columns.length && rows.length" class="table-scroll">
    <table class="data-table"><thead><tr><th v-for="(col,i) in columns" :key="i">{{ col }}</th></tr></thead>
      <tbody><tr v-for="(row,i) in rows.slice(0,50)" :key="i"><td v-for="(col,j) in columns" :key="j" :title="cleanCell(row[j])">{{ cleanCell(row[j]) }}</td></tr></tbody>
    </table>
  </div>
  <div v-else class="empty">{{ columns.length ? '查询成功，结果为空。' : '尚未收到结构化查询结果。' }}</div>
  <p v-if="truncated || rows.length > 50" class="hint">服务端结果可能已截断；此处最多展示 50 行。未展示的记录不视为零。</p>
</template>
