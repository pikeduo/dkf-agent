<script setup>
import { pageLabel, shortId } from '../utils/format'
defineProps({ items: { type: Array, default: () => [] }, title: { type: String, default: '文档引用与来源' } })
</script>
<template>
  <div class="evidence-panel">
    <div class="panel-heading"><h3>{{ title }}</h3><span class="pill">{{ items.length }} 条原文证据</span></div>
    <div v-if="items.length" class="evidence-list">
      <article v-for="(source,idx) in items" :key="source.chunk_id || idx" class="evidence-item">
        <div class="evidence-head">
          <div class="source-info"><span class="source-n">{{ source.citation_id ? `[${source.citation_id}]` : `#${idx+1}` }}</span>
            <strong>{{ source.file_name || shortId(source.doc_id) }}</strong>
          </div>
          <span>{{ pageLabel(source) }} · {{ source.section || '未标注章节' }}</span>
        </div>
        <p class="evidence-text">{{ source.text || source.quote || '未返回可展示的来源文本' }}</p>
        <div class="source-foot">
          <span>Doc {{ shortId(source.doc_id) }} · Chunk {{ shortId(source.chunk_id) }}</span>
          <span v-if="source.rerank_score != null">重排序分数 {{ Number(source.rerank_score).toFixed(3) }}（非概率）</span>
          <span v-else-if="source.fusion_score != null">融合分 {{ Number(source.fusion_score).toFixed(4) }}（非概率）</span>
        </div>
      </article>
    </div>
    <div v-else class="empty">暂无可验证的原文引用。</div>
  </div>
</template>
<style scoped>
.source-info { display: flex; align-items: center; gap: 8px; }
.source-n { color: #067ca3; font-size: 12px; font-weight: 800; }
.source-foot { display: flex; gap: 13px; flex-wrap: wrap; justify-content: space-between; border-top: 1px solid #e7f0f5; padding-top: 10px; margin-top: 11px; font-size: 10px; color: #91a1af; }
</style>
