<script setup>
defineProps({ trace: { type: Object, default: null } })
const asJson = obj => { try { return JSON.stringify(obj, null, 2) } catch { return '数据结构无法格式化' } }
</script>
<template>
  <section v-if="trace" class="timeline-section">
    <div class="panel-heading"><h3>真实工具调用与执行链路</h3><span class="pill">{{ trace.steps?.length || 0 }} 步 · {{ trace.total_tokens ?? '未统计' }} Tokens</span></div>
    <div v-if="!trace.steps?.length" class="notice warn">当前 trace 未记录步骤；不能用前端推测结果来填充执行链。</div>
    <ol v-else class="timeline">
      <li v-for="(step,i) in trace.steps" :key="i" class="trace-step">
        <div class="step-marker">{{ i + 1 }}</div>
        <div class="step-content">
          <div class="step-head"><strong>{{ step.module || '未命名模块' }}</strong><span>{{ step.time || '' }}</span></div>
          <p>{{ step.action || '无步骤名称' }}</p>
          <div class="step-metrics"><span v-if="step.latency">{{ step.latency }} s</span><span v-if="step.tokens">{{ step.tokens }} Tokens</span></div>
          <details v-if="step.input || step.output || Object.keys(step.evidence || {}).length" class="step-extra">
            <summary>查看输入 / 输出 / 证据</summary>
            <pre>{{ asJson({input: step.input || null, output: step.output || null, evidence: step.evidence || null}) }}</pre>
          </details>
        </div>
      </li>
    </ol>
  </section>
</template>
<style scoped>
.timeline { list-style: none; padding: 0; margin: 0; }
.trace-step { display: flex; gap: 12px; position: relative; padding-bottom: 22px; }
.trace-step:not(:last-child)::before { content:''; position: absolute; left: 13px; top: 28px; bottom: 0; border-left: 1px dashed #c4d7e2; }
.step-marker { flex: none; width: 27px; height: 27px; border-radius: 50%; display: grid; place-items:center; background: #e7f6fa; color:#1685a4; font-size: 11px; font-weight: 760; position: relative; z-index: 1; }
.step-content { flex:1; border: 1px solid #e8eef2; border-radius: 9px; padding: 13px 15px; min-width: 0; background: #fcfeff; }
.step-head { display: flex; justify-content: space-between; align-items:center; gap:8px; font-size: 12px; }
.step-head span { color:#9caeba; font-size:10px; }
.step-content p { color:#556e82; font-size: 12px; margin: 9px 0 0; }
.step-metrics { display: flex; gap: 9px; color: #8aa0af; font-size: 10px; margin-top: 8px; }
.step-extra summary { font-size: 11px; color:#0b83ab; cursor:pointer; margin-top: 10px; }
.step-extra pre { white-space: pre-wrap; overflow-wrap:anywhere; font-size:10px; padding: 12px; background:#f0f6f8; border-radius:8px; color:#426475; }
</style>
