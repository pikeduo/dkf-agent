<script setup>
import { computed, onMounted, ref } from 'vue'
import { getContestHealth, getDkfHealth, listKnowledgeBases } from './utils/api'
import HomePage from './pages/HomePage.vue'
import ChatPage from './pages/ChatPage.vue'
import SqlPage from './pages/SqlPage.vue'
import KnowledgePage from './pages/KnowledgePage.vue'
import LibraryPage from './pages/LibraryPage.vue'
import FusionPage from './pages/FusionPage.vue'
import TracePage from './pages/TracePage.vue'
import EvaluationPage from './pages/EvaluationPage.vue'

const nav = [
  { id: 'home', name: '总览', icon: '◫', group: 'WORKSPACE' },
  { id: 'chat', name: '意图分析与澄清', icon: '✳', group: 'WORKSPACE' },
  { id: 'sql', name: '自然语言问数', icon: '▤', group: 'WORKSPACE' },
  { id: 'knowledge', name: '文档知识问答', icon: '◈', group: 'WORKSPACE' },
  { id: 'fusion', name: '跨源联合演示', icon: '◇', group: 'WORKSPACE' },
  { id: 'library', name: '知识库管理', icon: '▣', group: 'DATA & OPS' },
  { id: 'trace', name: '执行链路追踪', icon: '⌁', group: 'DATA & OPS' },
  { id: 'evaluation', name: '赛题验收清单', icon: '▥', group: 'DATA & OPS' }
]
const views = { home: HomePage, chat: ChatPage, sql: SqlPage, knowledge: KnowledgePage,
  fusion: FusionPage, library: LibraryPage, trace: TracePage, evaluation: EvaluationPage }
const current = ref('home')
const menuOpen = ref(false)
const currentMeta = computed(() => nav.find(item => item.id === current.value) || nav[0])
const activeView = computed(() => views[current.value])
const services = ref({ contest: 'checking', dkf: 'checking' })
const kbCount = ref(null)
const refreshing = ref(false)

function navigate(id) {
  current.value = id
  menuOpen.value = false
}

async function checkHealth() {
  refreshing.value = true
  const result = await Promise.allSettled([
    getContestHealth(), getDkfHealth(), listKnowledgeBases(1, 0)
  ])
  services.value.contest = result[0].status === 'fulfilled' ? 'online' : 'offline'
  services.value.dkf = result[1].status === 'fulfilled' ? 'online' : 'offline'
  kbCount.value = result[2].status === 'fulfilled' ? result[2].value.total : null
  refreshing.value = false
}
onMounted(checkHealth)

const stateText = state => ({ checking: '检测中', online: '已连接', offline: '未连接' }[state])
</script>

<template>
  <div class="app-shell">
    <div v-if="menuOpen" class="mobile-shade" @click="menuOpen = false"></div>
    <aside class="app-sidebar" :class="{ 'is-open': menuOpen }" aria-label="主导航">
      <div class="brand-wrap">
        <div class="brand-mark">D<span>·</span></div>
        <div class="brand-copy">
          <div class="brand-name">数知融问<span class="brand-dot">.</span></div>
          <div class="brand-subtitle">DKF DATA INTELLIGENCE</div>
        </div>
      </div>

      <div class="sidebar-caption">中国电子杯 · 赛题八</div>
      <nav class="nav-area">
        <template v-for="group in ['WORKSPACE', 'DATA & OPS']" :key="group">
          <div class="nav-group-title">{{ group === 'WORKSPACE' ? '智能工作台' : '数据与可解释性' }}</div>
          <button v-for="item in nav.filter(x => x.group === group)" :key="item.id"
            class="nav-item" :class="{ selected: current === item.id }"
            type="button" :aria-current="current === item.id ? 'page' : undefined"
            @click="navigate(item.id)">
            <span class="nav-icon" aria-hidden="true">{{ item.icon }}</span>
            <span>{{ item.name }}</span>
            <span v-if="current === item.id" class="nav-current" aria-hidden="true"></span>
          </button>
        </template>
      </nav>
      <div class="sidebar-foot">
        <div class="sidebar-foot-title"><span class="online-pulse"></span> 竞赛演示环境</div>
        <p>SQL 结果、文档引用与真实调用状态均来自后端。未完成能力不会伪装为成功。</p>
        <span class="sidebar-version">UI v1.0 · Python + Vue 3</span>
      </div>
    </aside>

    <div class="app-body">
      <header class="topbar">
        <div class="crumb">
          <button class="mobile-menu icon-btn" type="button" aria-label="打开导航" @click="menuOpen = !menuOpen">☰</button>
          <span class="crumb-prefix">工作台</span><span class="crumb-slash">/</span>
          <strong>{{ currentMeta.name }}</strong>
        </div>
        <div class="header-right">
          <div class="connection-pill" :class="services.contest"><span class="status-dot"></span><span class="status-name">问数服务</span> {{ stateText(services.contest) }}</div>
          <div class="connection-pill" :class="services.dkf"><span class="status-dot"></span><span class="status-name">知识服务</span> {{ stateText(services.dkf) }}</div>
          <button type="button" class="icon-btn refresh" :disabled="refreshing" title="重新检查连接状态" @click="checkHealth">↻</button>
        </div>
      </header>
      <main class="app-content">
        <KeepAlive>
          <component :is="activeView" :key="current" :services="services" :kb-count="kbCount" @navigate="navigate" />
        </KeepAlive>
      </main>
    </div>
  </div>
</template>
