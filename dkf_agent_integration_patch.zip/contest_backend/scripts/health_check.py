"""环境冒烟自检：PostgreSQL 连接、pgvector 扩展、嵌入 API、Anna 聊天 API。

用法：python -B scripts/health_check.py
全部通过退出码为 0；任一项失败打印 FAIL 原因。
模型冒烟各发一条最小请求（可能产生少量费用）。
"""
import sys
import time
from pathlib import Path

# 允许从任意目录运行：把 agent/ 加入模块搜索路径
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import psycopg2


def check_pg() -> bool:
    """检查 PG 连接、pgvector 扩展与 doc_chunks 表。"""
    from backend.config import get_settings
    url = get_settings().database_url
    try:
        with psycopg2.connect(url, connect_timeout=10) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT current_database()")
                db = cur.fetchone()[0]
                cur.execute("SELECT count(*) FROM pg_extension WHERE extname = 'vector'")
                has_pgvector = cur.fetchone()[0] > 0
                cur.execute("""
                    SELECT to_regclass('public.doc_chunks') IS NOT NULL
                """)
                has_chunks = cur.fetchone()[0]
            print(f"PASS PG 已连接：{db}（pgvector={has_pgvector}, doc_chunks表={has_chunks}）")
            return True
    except Exception as exc:
        print(f"FAIL PG 连接失败：{exc.__class__.__name__}: {str(exc)[:160]}")
        return False


def check_embedding() -> bool:
    """嵌入 API 冒烟：一条文本。"""
    try:
        from backend.integrations.embedder import SiliconFlowEmbedder
        t0 = time.perf_counter()
        vec = SiliconFlowEmbedder().embed("健康检查")
        print(f"PASS 嵌入 API：{len(vec)} 维向量，耗时 {time.perf_counter() - t0:.1f}s")
        return True
    except Exception as exc:
        print(f"FAIL 嵌入 API：{exc.__class__.__name__}: {str(exc)[:160]}")
        return False


def check_llm() -> bool:
    """聊天 API 冒烟：一条最小请求，确认当前供应商可用。"""
    try:
        from backend.core.llm_client import LLMClient
        client = LLMClient()
        prov = client._select_provider()
        t0 = time.perf_counter()
        text = client.chat([{"role": "user", "content": '只回复JSON：{"ok":true}'}], temperature=0.0)
        print(f"PASS 聊天 API：供应商 {prov['name']} 模型 {prov['model']}，"
              f"耗时 {time.perf_counter() - t0:.1f}s，输出 {text[:60]!r}")
        return True
    except Exception as exc:
        print(f"FAIL 聊天 API：{exc.__class__.__name__}: {str(exc)[:160]}")
        return False


if __name__ == "__main__":
    results = [check_pg(), check_embedding(), check_llm()]
    print("自检结果：", "全部通过" if all(results) else "存在失败项")
    sys.exit(0 if all(results) else 1)
