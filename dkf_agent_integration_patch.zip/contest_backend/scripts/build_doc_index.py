"""任务4：OHR-Bench 文档向量入库流水线（幂等、断点续跑）。

流程（DocMath-Eval 分层思想 + FINDER 原文证据回配）：
1. 解析 data/raw/ohr_bench 下的 PDF（PyMuPDF）→ 按段落/公式行/表格切块，
   保留 doc_id / physical_page / source_bbox；取不到真实 bbox 的只存序列化的证据标识，
   不编造坐标。
2. SiliconFlowEmbedder 批量嵌入（bge-m3，1024 维）。
3. VectorStore.upsert_chunks 写入 doc_chunks；按 doc_id 先删后插，幂等。
4. 断点续跑：记录已完成的 doc_id，中断后重跑只补漏。

边界：本脚本一次构建离线产物；生产检索经 backend.agents.rag_retriever。
不读取 qas_v2.json 的 answers/evidence（评测隔离），只解析 PDF 原文。
"""
import json
import os
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

OHR_BASE = Path(os.environ.get("OHR_BENCH_DIR", "data/raw/ohr_bench"))
# doc_id 前缀映射：qas_v2 用 textbook_needrop_en_*，PDF 文件名为 jiaocai_needrop_en_*
# 一一对应（AGENTS.md 第四节已知的命名不一致）
_DOC_PREFIX_MAP = {"textbook_needrop_en_": "jiaocai_needrop_en_"}
CHECKPOINT = HERE / "evaluation" / "reports" / "_doc_index_checkpoint.json"


def resolve_pdf_path(doc_id: str) -> Path | None:
    """doc_id（形如 finance/JPMORGAN_2021Q1_10K）→ 实际 PDF 路径。

    qas 的 doc_name 前缀与 PDF 文件名在 textbook 类上有 system 词替换，
    先按原名找，再按前缀映射找，仍无则返回 None。
    """
    name = doc_id.split("/", 1)[-1]
    candidates = [name]
    for src, dst in _DOC_PREFIX_MAP.items():
        if name.startswith(src):
            candidates.append(name.replace(src, dst, 1))
    for cand in candidates:
        p = OHR_BASE / "pdfs" / doc_id.split("/", 1)[0] / cand
        if p.suffix != ".pdf":
            p = Path(str(p) + ".pdf")
        if p.exists():
            return p
    # 兜底：全盘搜一次同名（去前缀差异）
    import glob
    for pattern in (str(OHR_BASE / "pdfs" / f"*{name}"),):
        hits = glob.glob(pattern)
        if hits:
            return Path(hits[0])
    return None


def chunk_document(pdf_path: Path, doc_id: str) -> list:
    """PDF → 切片列表。每片 {text, physical_page, source_bbox, evidence_kind}。

    切块策略：按行聚合到 ~400 字符一段；含数学符号/上下标的行标 formula，
    表格区域标 table（DocMath-Eval 分层归因用）。bbox 只存真实页框，
    取不到就置 null，不编造。
    """
    import fitz  # PyMuPDF
    chunks: list = []
    doc = fitz.open(str(pdf_path))
    para: list[str] = []
    para_page = None
    para_bbox = None

    def flush():
        nonlocal para, para_page, para_bbox
        text = " ".join(para).strip()
        if text:
            kind = "formula" if any(c in text for c in "∫∑√≈±≠→←·") else (
                "table" if text.count("\t") >= 2 else "text")
            chunks.append({"text": text[:1200], "physical_page": para_page,
                            "source_bbox": para_bbox, "evidence_kind": kind})
        para, para_page, para_bbox = [], None, None

    for page_idx in range(len(doc)):
        page = doc[page_idx]
        # 用带 bbox 的块级提取
        blocks = page.get_text("blocks")  # (x0,y0,x1,y1, text, block_no, type)
        for b in blocks:
            x0, y0, x1, y1, text = b[0], b[1], b[2], b[3], b[4]
            text = text.strip()
            if not text:
                continue
            if not para or len(" ".join(para)) + len(text) > 400:
                flush()
            para.append(text)
            para_page = page_idx + 1  # 物理页从 1 计
            para_bbox = [round(x0), round(y0), round(x1), round(y1)]
    flush()
    doc.close()
    return chunks


def main() -> None:
    from backend.data_access.vector import VectorSource
    from backend.integrations.embedder import SiliconFlowEmbedder

    from backend.config import get_settings
    settings = get_settings()

    # 已完成检查点
    done: set = set()
    if CHECKPOINT.exists():
        done = set(json.loads(CHECKPOINT.read_text(encoding="utf-8")))

    # 需要入库的 doc_id：优先补 10 个缺失的 textbook 文档；--all 时全量重建
    target_docs: list = []
    if "--all" in sys.argv:
        for sub in ("finance", "academic", "administration", "law", "manual", "textbook"):
            d = OHR_BASE / "pdfs" / sub
            if d.exists():
                for pdf in sorted(d.glob("*.pdf")):
                    target_docs.append(f"{sub}/{pdf.stem}")
    else:
        # 增量：只补 qas_v2 涉及但库里没有的文档（不重嵌全量）
        import psycopg2
        qas = json.loads((OHR_BASE / "qas_and_code/data/qas_v2.json").read_text(encoding="utf-8"))
        qdocs = {q["doc_name"] for q in qas}
        with psycopg2.connect(settings.database_url) as conn, conn.cursor() as cur:
            cur.execute("SELECT DISTINCT doc_id FROM doc_chunks")
            ingested = {r[0] for r in cur.fetchall()}
        target_docs = sorted(qdocs - ingested)
        print(f"待补文档 {len(target_docs)} 个（qas_v2 涉及 {len(qdocs)}，已入库 {len(ingested)}）")

    embedder = SiliconFlowEmbedder()
    src = VectorSource("ohr_bench", embedder=embedder.embed, database_url=settings.database_url)

    new_count = 0
    image_only: list = []
    for doc_id in target_docs:
        pdf = resolve_pdf_path(doc_id)
        if pdf is None:
            print(f"  跳过 {doc_id}：找不到 PDF")
            continue
        chunks = chunk_document(pdf, doc_id)
        if not chunks:
            # 纯扫描图 PDF 无文本层：不伪造切片，显式记录为图像文档未入向量库
            image_only.append(doc_id)
            print(f"  跳过 {doc_id}：无文本层（纯扫描图），需 OCR 才能入库")
            continue
        texts = [c["text"] for c in chunks]
        vecs = embedder.embed_batch(texts)
        src.upsert_chunks(doc_id, chunks, vecs)
        done.add(doc_id)
        new_count += 1
        print(f"  入库 {doc_id}：{len(chunks)} 片")
        # 每 10 个文档写一次检查点
        if new_count % 10 == 0:
            CHECKPOINT.write_text(json.dumps(sorted(done)), encoding="utf-8")

    CHECKPOINT.write_text(json.dumps(sorted(done)), encoding="utf-8")
    if image_only:
        (HERE / "evaluation" / "reports" / "doc_index_uncovered.json").write_text(
            json.dumps({"image_only_no_text_layer": image_only,
                        "note": "纯扫描图 PDF 无文本层，未伪造切片；需 OCR（ocr_client）补充"},
                       ensure_ascii=False, indent=2), encoding="utf-8")
    embedder.close()
    print(f"完成：本次入库 {new_count} 个文档，图像未覆盖 {len(image_only)} 个")
    if not new_count and "--all" not in sys.argv:
        print("已无缺失文档，跳过重建（全量重建用 --all）")
        CHECKPOINT.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
