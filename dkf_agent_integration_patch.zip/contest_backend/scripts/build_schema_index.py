"""
构建统一 Schema 索引 + 数据库注册表
=====================================
输入：data/postgresql/{cosql,bird,dr_spider,adventureworks}/database_mapping.json
      data/raw/chinook/.../Chinook_PostgreSql.sql（解析建表语句）
输出：agent/processed/task4_schema/schema_index.json   （任务4定位用）
      agent/processed/knowledge_base/databases.json    （数据库注册表，连接信息）

设计说明：
- 优先用 mapping JSON（已核验的元数据），不依赖运行中的 PG，重跑稳定。
- 每个数据集独立库，注册表记录 db_id / 连接 / schema / 来源。
- schema_index 结构与 backend/agents/task4_schema_linking/schema_index.py 对齐。
"""
import json
import re
from pathlib import Path

# 项目根（ICT/）
ROOT = Path(__file__).resolve().parents[2]

# 各数据集 mapping 与目标库名
# imported=True 表示该库已实际导入到本地 PG（ict_postgres 容器），
# 注册表才会为其生成可连接的 database_url；未导入的库保留元数据但不可连接。
DATASETS = {
    "cosql": {
        "mapping": ROOT / "data/postgresql/cosql/database_mapping.json",
        "db_name": "ict_cosql",
        "engine": "postgresql",
        "imported": True,
        "note": "多轮澄清基线（任务3），873表",
    },
    "bird": {
        "mapping": ROOT / "data/postgresql/bird/database_mapping.json",
        "db_name": "ict_bird",
        "engine": "postgresql",
        "imported": True,
        "note": "跨域复杂查询（任务4/5），原生PG",
    },
    "dr_spider": {
        "mapping": ROOT / "data/postgresql/dr_spider/database_mapping.json",
        "db_name": "ict_dr_spider",
        "engine": "postgresql",
        "imported": False,
        "note": "鲁棒性扰动（任务1/4），1209表，可选",
    },
    "adventureworks": {
        "mapping": ROOT / "data/postgresql/adventureworks/database_mapping.json",
        "db_name": "ict_adventureworks",
        "engine": "postgresql",
        "imported": False,
        "note": "多表关联（任务4/5），68表，可选（决赛极限规模）",
    },
}

# 本地 PostgreSQL（ict_postgres 容器，pgvector/pgvector:pg16）
LOCAL_PG = "postgresql://DB_USER:DB_PASSWORD@localhost:5432"

CHINOOK_SQL = ROOT / "data/raw/chinook/ChinookDatabase/DataSources/Chinook_PostgreSql.sql"

# 输出目录
OUT_SCHEMA = ROOT / "agent/processed/task4_schema"
OUT_KB = ROOT / "agent/processed/knowledge_base"


# ---------------------------------------------------------------------------
# mapping JSON 解析
# ---------------------------------------------------------------------------
def _col_name(c):
    """列名：兼容 dict 与 list 两种表示。"""
    if isinstance(c, dict):
        return c.get("name") or c.get("source_name")
    if isinstance(c, (list, tuple)):
        # BIRD 用 [idx, name, type, notnull, default, pk]
        return c[1] if len(c) > 1 else None
    return None


def _col_type(c):
    """列类型：兼容 dict 与 list。"""
    if isinstance(c, dict):
        return c.get("pg_type") or c.get("declared_type")
    if isinstance(c, (list, tuple)):
        return c[2] if len(c) > 2 else None
    return None


def parse_mapping_generic(db_id, mapping):
    """解析 CoSQL / Dr.Spider 风格 mapping（列是 dict）。"""
    schemas = mapping[0].get("schema") if mapping else None
    tables = []
    for db in mapping:
        schema = db.get("schema")
        source = str(db.get("source_key") or db.get("source") or "").replace("\\", "/")
        dbid = db.get("db_id") or Path(source).stem or db_id
        for t in db.get("tables", []):
            cols = []
            for c in t.get("columns", []):
                cols.append({
                    "name": _col_name(c),
                    "type": _col_type(c),
                })
            tables.append({
                "db_id": dbid,
                "schema": schema,
                "table": t.get("name"),
                "source_name": t.get("source_name"),
                "rows": t.get("rows"),
                "columns": [c["name"] for c in cols],
                "column_types": {c["name"]: c["type"] for c in cols if c["name"]},
            })
    return tables


def parse_bird_mapping(mapping):
    """解析 BIRD mapping（列是 list）。"""
    tables = []
    for db in mapping:
        schema = db.get("schema")
        dbid = db.get("db_id")
        for t in db.get("tables", []):
            cols = []
            for c in t.get("columns", []):
                cols.append({
                    "name": _col_name(c),
                    "type": _col_type(c),
                })
            tables.append({
                "db_id": dbid,
                "schema": schema,
                "table": t.get("name"),
                "source_name": t.get("source_name"),
                "rows": t.get("rows"),
                "columns": [c["name"] for c in cols if c["name"]],
                "column_types": {c["name"]: c["type"] for c in cols if c["name"]},
            })
    return tables


# ---------------------------------------------------------------------------
# Chinook 建表脚本解析（不依赖运行 PG）
# ---------------------------------------------------------------------------
def parse_chinook_sql() -> list:
    """从 Chinook PG 脚本解析 CREATE TABLE，得到表列清单。"""
    text = CHINOOK_SQL.read_text(encoding="utf-8")
    tables = []
    # 匹配 CREATE TABLE name ( ... );
    pattern = re.compile(
        r"CREATE TABLE\s+(\w+)\s*\((.*?)\);",
        re.DOTALL | re.IGNORECASE,
    )
    for m in pattern.finditer(text):
        name = m.group(1)
        body = m.group(2)
        cols = []
        for line in body.splitlines():
            line = line.strip().rstrip(",")
            # 跳过约束行（PRIMARY KEY / FOREIGN KEY / CONSTRAINT / UNIQUE）
            low = line.lower()
            if not line:
                continue
            if low.startswith(("constraint", "primary key", "foreign key",
                               "unique", "check", "exclude")):
                continue
            # 取第一列名
            first = line.split()[0].strip('"')
            if first and first.lower() not in (
                "constraint", "primary", "foreign", "unique", "check"
            ):
                cols.append(first)
        tables.append({
            "db_id": "chinook",
            "schema": "public",
            "table": name,
            "source_name": name,
            "rows": None,  # 脚本内可数，但保持 None，接入后按需采样
            "columns": cols,
            "column_types": {},
        })
    return tables


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def build_schema_index():
    """汇总所有数据库的表列结构，输出 schema_index.json。"""
    OUT_SCHEMA.mkdir(parents=True, exist_ok=True)

    all_tables = {}

    # Chinook
    chinook = parse_chinook_sql()
    all_tables["chinook"] = chinook
    print(f"  chinook: {len(chinook)} 表")

    # 其余四个
    for key, cfg in DATASETS.items():
        mapping = json.loads(cfg["mapping"].read_text(encoding="utf-8"))
        if key == "bird":
            tables = parse_bird_mapping(mapping)
        else:
            tables = parse_mapping_generic(key, mapping)
        # 用数据集 key 作为分组
        all_tables[key] = tables
        print(f"  {key}: {len(tables)} 表")

    # 顶层别名映射（任务1用，先占位，后续人工补）
    alias_map = {
        "帝都": ["北京", "北京市"],
        "专辑": ["Album"],
        "唱片": ["Album"],
        "销售额": ["Invoice", "Total"],
        "冠军": ["Top"],
    }

    index = {
        "version": "1.0",
        "generated_from": [
            "data/postgresql/*/database_mapping.json",
            "data/raw/chinook/.../Chinook_PostgreSql.sql",
        ],
        "datasets": all_tables,
        "alias_map": alias_map,
        "note": "列名/类型来自已核验 mapping；外键关系见各库信息_schema，"
                "首次接入智能体时可用 fk_graph_builder 在线补全。",
    }
    out = OUT_SCHEMA / "schema_index.json"
    out.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n已写入：{out.relative_to(ROOT)}")
    return index


def build_database_registry():
    """生成数据库注册表，记录每个库的连接信息，供数据接入层动态连接。"""
    OUT_KB.mkdir(parents=True, exist_ok=True)

    registry = {
        "version": "1.0",
        "databases": []
    }

    # Chinook：脚本自建 chinook 库
    registry["databases"].append({
        "db_id": "chinook",
        "db_name": "chinook",
        "engine": "postgresql",
        "source_dataset": "chinook",
        "database_url": f"{LOCAL_PG}/chinook",
        "import_file": str(CHINOOK_SQL.relative_to(ROOT)),
        "schemas": ["public"],
        "note": DATASETS_NOTE.get("chinook", "官方推荐基础库"),
        "table_count_hint": len(parse_chinook_sql()),
    })

    for key, cfg in DATASETS.items():
        mapping = json.loads(cfg["mapping"].read_text(encoding="utf-8"))
        schemas = sorted({
            db.get("schema") for db in mapping if db.get("schema")
        })
        entry = {
            "db_id": key,
            "db_name": cfg["db_name"],
            "engine": cfg["engine"],
            "source_dataset": key,
            "import_file": (
                str(ROOT / f"data/postgresql/{key}/import.sql")
                if key == "adventureworks"
                else str(ROOT / f"data/postgresql/{key}/import_all.sql")
            ),
            "schemas": schemas,
            "note": cfg["note"],
            "table_count_hint": len(
                parse_bird_mapping(mapping) if key == "bird"
                else parse_mapping_generic(key, mapping)
            ),
        }
        # 仅已导入的库给出可连接的 DSN；未导入的库不写 database_url，
        # 数据接入层加载时会自动跳过（registry.load_from_json 行为）
        if cfg.get("imported"):
            entry["database_url"] = f"{LOCAL_PG}/{cfg['db_name']}"
        else:
            entry["note"] += "（未导入，暂不可连接）"
        registry["databases"].append(entry)

    # 向量库（OHR-Bench pgvector）：与结构化库同实例，doc_chunks 表
    registry["databases"].append({
        "db_id": "ohr_bench",
        "db_name": "ict_main",
        "engine": "pgvector",
        "source_dataset": "ohr_bench",
        "database_url": f"{LOCAL_PG}/ict_main",
        "table": "doc_chunks",
        "embedding_model": "BAAI/bge-m3",
        "embedding_dim": 1024,
        "note": "OHR-Bench gt 逐页文本向量库（硅基流动 bge-m3，1024维）",
    })

    out = OUT_KB / "databases.json"
    out.write_text(
        json.dumps(registry, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"已写入：{out.relative_to(ROOT)}")
    print(f"共注册 {len(registry['databases'])} 个数据库")
    return registry


# 备注映射
DATASETS_NOTE = {
    "chinook": "官方推荐基础库，11张表",
}


if __name__ == "__main__":
    print("=== 构建统一 Schema 索引 ===")
    build_schema_index()
    print("\n=== 构建数据库注册表 ===")
    build_database_registry()
    print("\n完成。")
