-- 向量库与公式卡片表：模块4/模块5 使用
-- doc_chunks：OHR-Bench 文档切片（VectorStore 约定，幂等）
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS doc_chunks (
    id          BIGSERIAL PRIMARY KEY,
    doc_id      TEXT NOT NULL,
    physical_page INT,
    text        TEXT NOT NULL,
    embedding   vector(1024),
    source_bbox JSONB
);

CREATE INDEX IF NOT EXISTS idx_doc_chunks_doc ON doc_chunks (doc_id);
CREATE INDEX IF NOT EXISTS idx_doc_chunks_embedding ON doc_chunks USING hnsw (embedding vector_l2_ops);

-- formula_cards：任务6 公式知识卡片（入库侧；不含任何测试集答案）
CREATE TABLE IF NOT EXISTS formula_cards (
    formula_id    TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    latex         TEXT NOT NULL,
    variables     JSONB,
    units         JSONB,
    applicable    JSONB,
    precision_rule TEXT,
    source        TEXT
);
