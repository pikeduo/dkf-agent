-- 元数据索引建表脚本
-- 用途：统一管理所有数据库（Chinook/BIRD/CoSQL）的表结构
-- 执行：psql -h localhost -U agent -d agent_db -f init_metadata_schema.sql

-- 创建 metadata schema
DROP SCHEMA IF EXISTS metadata CASCADE;
CREATE SCHEMA metadata;

-- 1. 数据库注册表
CREATE TABLE metadata.databases (
    db_id VARCHAR(50) PRIMARY KEY,
    db_name VARCHAR(100) NOT NULL,
    db_type VARCHAR(20) NOT NULL,  -- 'postgresql' / 'sqlite' / 'mysql'
    schema_name VARCHAR(50),         -- PG schema 名（如 chinook）
    connection_info JSONB,           -- 连接配置（加密）
    description TEXT,
    source VARCHAR(50),              -- 'chinook' / 'bird' / 'cosql'
    row_count_total BIGINT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- 2. 表元数据
CREATE TABLE metadata.tables (
    table_id VARCHAR(100) PRIMARY KEY,  -- 格式: db_id.table_name
    db_id VARCHAR(50) NOT NULL REFERENCES metadata.databases(db_id) ON DELETE CASCADE,
    table_name VARCHAR(100) NOT NULL,
    comment TEXT,
    row_count_estimate INT,
    business_description TEXT,      -- 中文业务含义
    last_synced TIMESTAMP DEFAULT NOW(),
    UNIQUE(db_id, table_name)
);

-- 3. 列元数据
CREATE TABLE metadata.columns (
    column_id VARCHAR(150) PRIMARY KEY,  -- 格式: table_id.column_name
    table_id VARCHAR(100) NOT NULL REFERENCES metadata.tables(table_id) ON DELETE CASCADE,
    column_name VARCHAR(100) NOT NULL,
    data_type VARCHAR(50),
    comment TEXT,
    unit VARCHAR(20),                -- 单位（元/个/%）
    sample_values JSONB,             -- 采样值 [val1, val2, ...]
    business_meaning TEXT,           -- 中文业务含义
    is_primary_key BOOLEAN DEFAULT FALSE,
    is_foreign_key BOOLEAN DEFAULT FALSE,
    UNIQUE(table_id, column_name)
);

-- 4. 外键关系
CREATE TABLE metadata.foreign_keys (
    fk_id SERIAL PRIMARY KEY,
    source_table VARCHAR(100) NOT NULL REFERENCES metadata.tables(table_id),
    source_column VARCHAR(100) NOT NULL,
    target_table VARCHAR(100) NOT NULL REFERENCES metadata.tables(table_id),
    target_column VARCHAR(100) NOT NULL,
    fk_name VARCHAR(100),
    UNIQUE(source_table, source_column, target_table, target_column)
);

-- 5. 业务别名映射（任务1用）
CREATE TABLE metadata.aliases (
    alias_id SERIAL PRIMARY KEY,
    alias_text VARCHAR(100) NOT NULL,  -- 别名（帝都/唱片）
    target_type VARCHAR(20),            -- 'table' / 'column' / 'value'
    target_id VARCHAR(150) NOT NULL,    -- 表ID/列ID
    canonical_text VARCHAR(100),        -- 规范名（北京/Album）
    confidence FLOAT DEFAULT 1.0
);

-- 创建索引
CREATE INDEX idx_tables_db ON metadata.tables(db_id);
CREATE INDEX idx_columns_table ON metadata.columns(table_id);
CREATE INDEX idx_fk_source ON metadata.foreign_keys(source_table);
CREATE INDEX idx_fk_target ON metadata.foreign_keys(target_table);
CREATE INDEX idx_aliases_text ON metadata.aliases(alias_text);

-- 注释
COMMENT ON SCHEMA metadata IS '统一元数据索引，供 Schema Linking 使用';
COMMENT ON TABLE metadata.databases IS '所有接入的数据库注册表';
COMMENT ON TABLE metadata.tables IS '跨库的表元数据';
COMMENT ON TABLE metadata.columns IS '列元数据，含业务含义和采样值';
COMMENT ON TABLE metadata.foreign_keys IS '外键关系，供任务4构建关联图';
COMMENT ON TABLE metadata.aliases IS '业务别名映射，供任务1泛化识别';
