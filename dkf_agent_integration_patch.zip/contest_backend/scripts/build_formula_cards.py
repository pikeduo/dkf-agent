"""任务6：公式知识卡片构建（formulas.json 272 条 → PG formula_cards 表）。

卡片内容只含公式知识（表达式、变量、中英符号），不含任何测试集答案；
HoF_test.json 的 solution/arguments/answer 永远不进入本表与 RAG 正文。

用法：python -B scripts/build_formula_cards.py
幂等：按 formula_id upsert。
"""
import json
import sys
from pathlib import Path

import psycopg2

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

FORMULAS = HERE.parent / "data" / "raw" / "formula_reasoning" / "formulas.json"


def main() -> None:
    from backend.config import get_settings
    url = get_settings().database_url
    items = json.loads(FORMULAS.read_text(encoding="utf-8"))
    sql = """
        INSERT INTO formula_cards (formula_id, name, latex, variables, units, applicable, precision_rule, source)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (formula_id) DO UPDATE SET
            name = EXCLUDED.name,
            latex = EXCLUDED.latex,
            variables = EXCLUDED.variables,
            units = EXCLUDED.units
    """
    n = 0
    with psycopg2.connect(url, connect_timeout=15) as conn, conn.cursor() as cur:
        for it in items:
            key = it["key"]
            expr_zh = it["formula"].get("zh", "")
            expr_en = it["formula"].get("en", "")
            syms = it.get("symbol_map", [])
            # 把 [占位符] 展平为「占位符=符号」形式，卡片只记符号映射与表达式，不做计算
            variables = {s.get("zh_symbol") or s.get("en_symbol"): {
                "zh_name": s.get("zh_name"), "en_name": s.get("en_name"),
            } for s in syms}
            name = expr_zh.replace("[", "").replace("]", "").split("=")[0].strip() or key[:8]
            cur.execute(sql, (key, name, expr_zh,
                              json.dumps(variables, ensure_ascii=False),
                              "[]", "[]", "", "formulas.json"))
            n += 1
        conn.commit()
        cur.execute("SELECT count(*) FROM formula_cards")
        print(f"upsert {n} 张卡片，库内共 {cur.fetchone()[0]} 张")


if __name__ == "__main__":
    main()
