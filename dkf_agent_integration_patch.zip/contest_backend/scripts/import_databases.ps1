# ============================================================================
# 一键导入五个结构化数据集到 PostgreSQL
# ============================================================================
# 使用：powershell -File agent\scripts\import_databases.ps1
# 前提：本地 PostgreSQL 16 已启动，能接受 .env 中配置的用户账号
# 说明：
#   - 每套数据导入独立的 PG 数据库（不混到同一个业务库）
#   - 各套的 schema 命名保持原 mapping 中的记录，便于追溯
#   - Chinook 使用赛题推荐的原生 PG 脚本
#   - 其余四套使用 data/postgresql/ 下已核验的 psql 入口
# ============================================================================

# 连接参数（按需调整）
$PG_BIN = "C:\Program Files\PostgreSQL\16\bin"
$USER   = "DB_USER"   # 由环境变量 PG_USER 覆盖：$USER = $env:PG_USER
$PASS   = $env:PG_PASSWORD  # 密码仅从环境变量读取，不入包
$HOST   = "localhost"
$PORT   = "5432"

# 把 PG 客户端工具加入 PATH
$env:PGPASSWORD = $PASS
$env:Path       = "$PG_BIN;$env:Path"

# 各数据集配置：数据库名 + 导入脚本
$Datasets = @(
    @{
        DbName      = "ict_chinook"
        ImportFile  = "data\raw\chinook\ChinookDatabase\DataSources\Chinook_PostgreSql.sql"
        Note        = "官方推荐：11张表，单表查询基础"
        # 注意：Chinook 原生脚本自带 CREATE DATABASE chinook，需要在 chinook 库上下文执行
        # 因此这里先建 ict_chinook，再用脚本内 \c chinook 会切到 chinook 库
        # 解决：直接用脚本，最终数据落在 chinook 库
    },
    @{
        DbName      = "ict_cosql"
        ImportFile  = "data\postgresql\cosql\import_all.sql"
        Note        = "873张表，多轮澄清基线（任务3）"
    },
    @{
        DbName      = "ict_bird"
        ImportFile  = "data\postgresql\bird\import_all.sql"
        Note        = "75张表，跨域复杂查询（任务4/5）"
    },
    @{
        DbName      = "ict_dr_spider"
        ImportFile  = "data\postgresql\dr_spider\import_all.sql"
        Note        = "1209张表，鲁棒性扰动（任务1/4）"
    },
    @{
        DbName      = "ict_adventureworks"
        ImportFile  = "data\postgresql\adventureworks\import.sql"
        Note        = "68张表，多表关联（任务4/5）"
        # AdventureWorks 需要 uuid-ossp 扩展
        NeedsExtension = $true
    }
)

# ---- 执行导入 ----
foreach ($d in $Datasets) {
    Write-Host "================================================================" -ForegroundColor Cyan
    Write-Host "导入 $($d.DbName)  ($($d.Note))" -ForegroundColor Cyan
    Write-Host "脚本：$($d.ImportFile)"
    Write-Host ""

    # 若需要 uuid-ossp 扩展（AdventureWorks）
    if ($d.NeedsExtension) {
        & "$PG_BIN\createdb.exe" -h $HOST -p $PORT -U $USER -w $d.DbName 2>&1 | Out-Host
        & "$PG_BIN\psql.exe" -X -h $HOST -p $PORT -U $USER -w -d $d.DbName `
            -c "CREATE EXTENSION IF NOT EXISTS 'uuid-ossp';"
        Write-Host "已安装 uuid-ossp 扩展"
    } else {
        & "$PG_BIN\createdb.exe" -h $HOST -p $PORT -U $USER -w $d.DbName 2>&1 | Out-Host
    }

    # 执行导入脚本（Chinook 例外：它会自己建 chinook 库）
    if ($d.DbName -eq "ict_chinook") {
        # Chinook 原生脚本会 CREATE DATABASE chinook + \c chinook
        # 直接用 psql 连到 postgres 库执行即可
        & "$PG_BIN\psql.exe" -X -v ON_ERROR_STOP=1 -h $HOST -p $PORT -U $USER -w `
            -d postgres -f $d.ImportFile
    } else {
        & "$PG_BIN\psql.exe" -X -v ON_ERROR_STOP=1 -h $HOST -p $PORT -U $USER -w `
            -d $d.DbName -f $d.ImportFile
    }

    if ($LASTEXITCODE -ne 0) {
        Write-Host "!!! $($d.DbName) 导入失败（exit=$LASTEXITCODE）" -ForegroundColor Red
        Write-Host "继续处理下一个..."
        continue
    }

    # 验证：查总表数
    if ($d.DbName -eq "ict_chinook") {
        $verifyDb = "chinook"
    } else {
        $verifyDb = $d.DbName
    }
    $tableCount = & "$PG_BIN\psql.exe" -t -A -h $HOST -p $PORT -U $USER -w `
        -d $verifyDb -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema');"
    Write-Host "✓ $($d.DbName) 完成：共 $tableCount 张表" -ForegroundColor Green
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "全部导入完成。数据库列表：" -ForegroundColor Cyan
& "$PG_BIN\psql.exe" -X -h $HOST -p $PORT -U $USER -w -d postgres -c "\l"
Write-Host ""
Write-Host "下一步：构建统一 schema 索引"
Write-Host "  python -B agent\scripts\build_schema_index.py"
