"""
构建任务4 外键图（静态JSON）。
从 PostgreSQL catalog 抽取各库真实外键约束（含复合键的全部列对），
写入 processed/task4_schema/fk_graph.json，供 fk_graph_builder.py 离线加载，
运行时不依赖数据库在线。

用法：python -B scripts/build_fk_graph.py
"""
import json
import sys
from pathlib import Path

import psycopg2

# agent/ 目录
HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

# 参与外键图构建的库：db_id → (PG库名, schema 或 None 表示 public)
TARGETS = {
    "chinook": ("chinook", "public"),
    "bird": ("ict_bird", "bird_native"),
}
# CoSQL 导入时丢弃了外键（catalog 外键数为 0），不构建
OUTPUT = HERE / "processed" / "task4_schema" / "fk_graph.json"


def extract_fks(conn, schema: str) -> list[dict]:
    """抽取指定 schema 下全部外键约束，保留复合键的完整列对。"""
    query = """
        SELECT c.constraint_name,
               kcu.table_name AS from_table,
               ccu.table_name AS to_table,
               kcu.ordinal_position AS pos,
               kcu.column_name AS from_column,
               ccu.column_name AS to_column
        FROM information_schema.table_constraints c
        JOIN information_schema.key_column_usage kcu
            ON kcu.constraint_name = c.constraint_name
            AND kcu.table_schema = c.constraint_schema
        JOIN information_schema.constraint_column_usage ccu
            ON ccu.constraint_name = c.constraint_name
            AND ccu.table_schema = c.constraint_schema
        WHERE c.constraint_type = 'FOREIGN KEY'
          AND c.constraint_schema = %s
        ORDER BY c.constraint_name, kcu.ordinal_position
    """
    rows = []
    with conn.cursor() as cur:
        cur.execute(query, (schema,))
        rows = cur.fetchall()
    # 按约束聚合，复合键保留全部列对
    grouped: dict[tuple[str, str, str], list[tuple[str, str]]] = {}
    order = []
    for conname, from_tbl, to_tbl, pos, from_col, to_col in rows:
        key = (conname, from_tbl, to_tbl)
        if key not in grouped:
            grouped[key] = []
            order.append(key)
        grouped[key].append((from_col, to_col))
    result = []
    for conname, from_tbl, to_tbl in order:
        pairs = sorted(grouped[(conname, from_tbl, to_tbl)], key=lambda p: p[0])
        result.append({
            "constraint": conname,
            "from_table": from_tbl,
            "to_table": to_tbl,
            "pairs": [{"from_column": p[0], "to_column": p[1]} for p in pairs],
        })
    return result


def main() -> None:
    # 各库连接信息：优先注册表中的 database_url，缺省用主库
    out: dict = {"version": 2, "generated_from": "pg_catalog", "databases": {}}
    for db_id, (db_name, schema) in TARGETS.items():
        url = f"postgresql://DB_USER:DB_PASSWORD@localhost:5432/{db_name}"
        with psycopg2.connect(url, connect_timeout=15) as conn:
            fks = extract_fks(conn, schema)
        out["databases"][db_id] = {"pg_database": db_name, "schema": schema, "foreignKey": fks}
        print(f"{db_id}: {len(fks)} 条外键约束")
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("已写入", OUTPUT)


if __name__ == "__main__":
    main()
