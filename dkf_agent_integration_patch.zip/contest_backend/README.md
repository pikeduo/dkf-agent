﻿# 多模态数据驱动的可解释精准问数/问答智能体

针对“中国电子杯”第三届高校 ICT 产教融合创新大赛——赛题八的项目。
本仓库聚焦**中级任务 3（语义澄清）、任务 4（精准表定位）、任务 6（公式识别与计算）**，
以官方推荐数据集 **Chinook** 与 **OHR-Bench** 为基础，辅以公开基准 CoSQL / BIRD /
FormulaReasoning 等，实现一套可解释、可溯源的多模态问数/问答智能体。

## 一、数据集策略（方案一：官方推荐 + 合理扩展）

| 层次 | 任务 | 数据集 | 说明 |
| ---- | ---- | ------ | ---- |
| 基础任务（40分） | 单表NL2SQL | Chinook | 官方推荐，11张表 |
| 基础任务（40分） | 单文档RAG | OHR-Bench | 官方推荐，8498条问答 |
| 任务3 语义澄清 | 澄清对话 | CoSQL + OHR 扩展 | CoSQL提供AMBIGUOUS/CLARIFY标注 |
| 任务4 表定位 | SchemaLinking | Chinook + BIRD + AdventureWorks | BIRD/AW提供数十张表场景 |
| 任务6 公式计算 | 公式识别与计算 | FormulaReasoning + OHR + TAT-DQA | FR提供细粒度参数标注 |

> 基础任务100%使用官方推荐的 Chinook 与 OHR-Bench；
> 中级任务在其基础上引入公开基准补充能力缺口，并在技术文档中说明理由。

## 二、目录结构

```
ICT/
├── backend/                  # Python 后端（FastAPI）
│   ├── main.py               # 服务入口
│   ├── config.py             # 配置
│   ├── core/                 # 核心能力（LLM/向量/SQL执行/追踪/状态）
│   ├── agents/               # 三大任务智能体模块
│   │   ├── task3_clarification/
│   │   ├── task4_schema_linking/
│   │   └── task6_formula/
│   ├── integrations/         # 国产大模型/OCR/Embedding 集成
│   ├── api/                  # 路由
│   ├── models/               # 数据模型
│   └── utils/                # 工具
├── frontend/                 # Vue 3 前端
├── evaluation/               # 评测模块（任务3/4/6 指标）
├── data/
│   ├── raw/                  # 已下载的原始数据
│   ├── processed/            # 预处理产物（澄清对话/Schema索引/公式卡片）
│   ├── test_cases/           # 评测用例
│   └── postgresql/          # PG16 导入文件
├── scripts/                  # 数据预处理与初始化脚本
├── tests/                    # 单元/集成测试
├── docs/                     # 架构与部署文档
└── docker-compose.yml        # 容器编排
```

## 三、快速启动

```bash
# 1. 启动数据库与依赖
docker compose up -d

# 2. 安装依赖
pip install -r requirements.txt

# 3. 初始化数据库（导入 Chinook / BIRD / AdventureWorks）
python -B scripts/init_database.py

# 4. 构建预处理产物（Schema索引、公式卡片、澄清对话）
python -B scripts/build_schema_index.py
python -B scripts/build_formula_cards.py

# 5. 启动后端
uvicorn backend.main:app --reload

# 6. 启动前端
cd frontend && npm install && npm run dev
```

## 四、意图识别层（已接入后端）

`POST /api/query/intent` 与原 `POST /api/query/` 当前均返回意图识别结果：目标、输入事实、信息缺口和下一步动作。`ok=true` 仅表示本阶段成功，尚未执行检索、SQL或计算，答案字段保持为空。

模块契约、调用方式、限制与测试见 [意图识别层说明](docs/intent_layer.md)。会话令牌、必要历史保护和可选imajev多选筛选见 [历史筛选说明](docs/history_selection.md)。聊天模型由 `.env` 中的 `LLM_PROVIDER` 选择，本地当前为 Anna 的 `DeepSeek-V4.1-Flash`（配置项见 `.env.example`）；嵌入仍走硅基流动。imajev不会自动启动。

## 五、许可与评测数据隔离

- 各公开数据集许可随 `data/README.md` 与 `data/manifest.json` 说明保存。
- 标准答案（SQL gold、公式 solution、标题树、质量标签）仅用于评分，
  不得混入可检索知识库或生产提示词，保证评测隔离。
