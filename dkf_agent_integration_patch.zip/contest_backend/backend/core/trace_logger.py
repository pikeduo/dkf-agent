"""
可解释性追踪器：记录从问题输入到最终答案的全链路推理。
每一步记录所属模块、动作、输入输出、证据来源与成本，供前端可视化。
"""
from datetime import datetime
from typing import List, Dict, Optional
import uuid


class ExecutionTrace:
    """单次查询的完整推理链路。

    设计原则：
    - 每一步都携带证据（doc_id / physical_page / source_bbox / evidence_id）。
    - 区分“模型候选推断”与“用户已确认事实”，二者不混存。
    - 记录 token 消耗与延迟，支撑系统效率指标。
    """

    def __init__(self, question: str) -> None:
        self.trace_id = str(uuid.uuid4())
        self.question = question
        self.start_time = datetime.now()
        self.steps: List[Dict] = []

    def log(
        self,
        module: str,
        action: str,
        input_data: Optional[Dict] = None,
        output_data: Optional[Dict] = None,
        evidence: Optional[Dict] = None,
        tokens: int = 0,
        latency: float = 0.0,
    ) -> None:
        """记录一个可审计的步骤。

        module: 如 "任务3-澄清" / "任务4-定位" / "任务6-计算"
        action: 如 "检测歧义" / "匹配表" / "提取公式"
        evidence: 来源引用，保证答案“有迹可循”
        """
        self.steps.append({
            "time": datetime.now().isoformat(),
            "module": module,
            "action": action,
            "input": input_data,
            "output": output_data,
            "evidence": evidence or {},
            "tokens": tokens,
            "latency": latency,
        })

    def by_module(self, module_prefix: str) -> List[Dict]:
        """按模块前缀筛选步骤。"""
        return [s for s in self.steps if s["module"].startswith(module_prefix)]

    def collect_evidence(self) -> List[Dict]:
        """汇总所有步骤的证据来源。"""
        merged: List[Dict] = []
        seen = set()

        def hashable_key(ev: Dict) -> tuple:
            # 值里可能含 list/dict（如表定位的 evidence 数组），递归转成可哈希结构做去重键
            def norm(v):
                if isinstance(v, list):
                    return tuple(norm(x) for x in v)
                if isinstance(v, dict):
                    return tuple((k, norm(x)) for k, x in sorted(v.items()))
                return v
            return tuple((k, norm(val)) for k, val in sorted(ev.items()))

        for s in self.steps:
            for ev in s.get("evidence", {}).get("citations", []):
                key = hashable_key(ev)
                if key not in seen:
                    seen.add(key)
                    merged.append(ev)
        return merged

    def to_dict(self) -> Dict:
        """导出为可序列化结构，供 API 与前端使用。"""
        return {
            "trace_id": self.trace_id,
            "question": self.question,
            "started_at": self.start_time.isoformat(),
            "steps": self.steps,
            "citations": self.collect_evidence(),
            "total_tokens": sum(s["tokens"] for s in self.steps),
        }
