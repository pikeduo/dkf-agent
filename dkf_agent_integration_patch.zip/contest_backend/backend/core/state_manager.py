"""
对话状态管理：保存多轮交互中的上下文，实现短期/长期记忆。
候选推断与用户确认事实分区保存，避免把模型推测当成用户事实。
"""
from typing import List, Dict, Set, Optional
from dataclasses import dataclass, field


@dataclass
class DialogState:
    """单次会话的完整状态。

    - confirmed_slots: 用户明确确认的事实（可按作用域/版本去重）
    - open_candidates: 尚未澄清的多义候选
    - asked_dimensions: 已经追问过的维度，防止重复提问
    - schema_version: 当前使用的 schema/文档版本，变更时失效旧确认
    """

    session_id: str
    original_question: str
    messages: List[Dict] = field(default_factory=list)
    confirmed_slots: Dict[str, Dict] = field(default_factory=dict)
    open_candidates: List[Dict] = field(default_factory=list)
    asked_dimensions: Set[str] = field(default_factory=set)
    schema_version: str = "v1"
    citations: List[Dict] = field(default_factory=list)
    round_count: int = 0
    clarification_budget: int = 3  # 默认最多澄清 3 轮
    technical_errors: List[str] = field(default_factory=list)

    def confirm(self, dimension: str, value: Dict) -> None:
        """记录用户确认的一个槽位，附带作用域与版本。

        value 里的自由字段（free_text / dimension / source 等）原样保留，
        只补充统一的 confirmed/version 元信息。
        """
        slot = dict(value)
        slot.update({
            "scope": value.get("scope", "session"),
            "version": self.schema_version,
            "confirmed": True,
        })
        self.confirmed_slots[dimension] = slot

    def has_confirmed(self, dimension: str) -> bool:
        """某维度是否已确认且版本未变。"""
        slot = self.confirmed_slots.get(dimension)
        return bool(
            slot
            and slot["confirmed"]
            and slot["version"] == self.schema_version
        )

    def budget_left(self) -> int:
        """剩余澄清预算。"""
        return max(0, self.clarification_budget - self.round_count)

    def mark_asked(self, dimension: str) -> None:
        """标记某维度已追问，避免重复。"""
        self.asked_dimensions.add(dimension)
        self.round_count += 1
