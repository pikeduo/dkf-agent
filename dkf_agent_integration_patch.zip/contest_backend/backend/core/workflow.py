"""最小受控工作流：解释成功后才交接执行，保留真实结果与失败阶段。"""
from typing import Callable

from backend.core.intent.contracts import IntentResult


class WorkflowService:
    """单目标执行门面；不自由调用工具、不检索公式卡片、不猜参数来源。"""

    def __init__(self, client, pipeline_factory: Callable | None = None,
                 retriever_factory: Callable | None = None):
        self.client = client
        self.pipeline_factory = pipeline_factory
        self.retriever_factory = retriever_factory

    @staticmethod
    def _result(stage, answer, *, ok=True, executed=False, ready=False, **data):
        return {"ok": ok, "stage": stage, "answer": answer,
                "execution_performed": executed, "answer_ready": ready, **data}

    def run(self, intent: IntentResult, question: str,
            database: str | None = None, doc_id: str | None = None,
            sub_db: str | None = None) -> dict:
        """只使用已经通过结构与来源校验的解释；尚未满足条件时不执行。"""
        if not intent.ok or intent.interpretation is None:
            return self._result("intent_failed", intent.decision.message, ok=False,
                                error=intent.error_code)
        draft = intent.interpretation
        if len(draft.goals) != 1:
            return self._result("blocked", "当前仅支持一个独立目标，请将复合问题拆开提交。")
        # 控制器的解释并非工具执行授权；执行层再次检查未决的用户条件。
        gaps = [r for r in draft.requirements
                if r.status != "satisfied" and r.resolver == "user"]
        if gaps or intent.decision.action == "CLARIFY":
            gap = gaps[0] if gaps else None
            return self._result("needs_user", gap.description if gap else intent.decision.message,
                                candidates=list(gap.candidates if gap else intent.decision.candidates))
        if intent.decision.action == "STOP":
            return self._result("blocked", intent.decision.message)
        goal = draft.goals[0]
        if goal.operation == "calculate":
            return self._calculate(draft, goal.id, question)
        if any(r.status != "satisfied" and r.resolver in ("unknown", "read_input")
               for r in draft.requirements):
            return self._result("blocked", "所提供内容尚未完成解析，不能据此执行或生成答案。")
        if doc_id or database == "ohr_bench":
            return self._retrieve(question, doc_id)
        if not database:
            return self._result("needs_user", "请指定要查询的业务数据库或文档。")
        return self._query(draft, question, database, sub_db)

    def _calculate(self, draft, goal_id, question):
        from backend.agents.task6_formula.formula_spec import spec_from_user_formula
        from backend.agents.task6_formula.safe_calculator import SafeCalculator
        formulas = [f for f in draft.formulas if f.goal_id == goal_id]
        if len(formulas) != 1:
            # 对完整纯算术原文可直接结构校验；自然语言题面不猜隐含公式。
            import re
            if not formulas and re.fullmatch(r"[\d\s.+\-*/^()%×÷−eE]+", question.strip()):
                expression = question.strip()
            else:
                return self._result("needs_user", "请提供本次要使用的明确公式；当前不检索公式卡片。")
        else:
            expression = formulas[0].source.quote
        spec = spec_from_user_formula(expression)
        if spec.parse_status != "ok":
            return self._result("blocked", "公式结构未通过受限解析，请确认公式写法或解域。",
                                calculation={"ok": False, "check_failed": "parse_status",
                                             "error": list(spec.constraints)})
        bindings = {}
        facts = [f for f in draft.facts if f.goal_id == goal_id]
        for symbol in spec.input_symbols:
            info = spec.variables.get(symbol) or {}
            # 仅使用精确原名/明确占位符含义，不使用包含匹配或模型补默认值。
            names = {symbol}
            names.update(v for k, v in info.items()
                         if k in ("zh_name", "en_name", "name", "original_symbol", "source_symbol")
                         and isinstance(v, str) and v)
            matches = [f for f in facts if f.name in names]
            choices = {(f.value, f.unit) for f in matches}
            if not choices:
                label = info.get("zh_name") or info.get("en_name") or symbol
                return self._result("needs_user", f"请提供变量 {label} 的数值及适用单位。")
            if len(choices) != 1:
                return self._result("needs_user", f"变量 {symbol} 存在多个值或单位，请确认本次使用哪一个。")
            fact = matches[0]
            bindings[symbol] = {"raw_value": fact.value, "unit": fact.unit,
                                "source": fact.source.model_dump()}
        try:
            output = SafeCalculator().compute_spec(spec, bindings)
        except (TypeError, ValueError, ArithmeticError, RecursionError):
            return self._result("execution_failed", "参数或公式计算未通过校验，未返回计算结果。",
                                ok=False, error="calculation_invalid")
        output = {**output, "expression": expression, "bindings": bindings}
        if not output.get("ok"):
            return self._result("blocked", output.get("error") or "计算校验失败。",
                                calculation=output)
        value = output.get("display_value", output["result"])
        unit = output.get("unit")
        answer = f"按公式 {expression}，计算结果为 {value}" + (f" {unit}" if unit else "") + "。"
        return self._result("answered", answer, executed=True, ready=True, calculation=output,
                            citations=[f.source.model_dump() for f in facts])

    @staticmethod
    def _scope(database, sub_db):
        """用真实目录解析唯一业务作用域，未知库不回退到 Chinook。"""
        from backend.agents.task4_schema_linking.schema_index import SchemaIndex
        index = SchemaIndex()
        if sub_db:
            index.load(database, sub_db=sub_db)
        else:
            try:
                index.load(database)
            except KeyError:
                resolved = []
                for dataset in ("bird", "cosql"):
                    candidate = SchemaIndex()
                    try:
                        candidate.load(dataset, sub_db=database)
                    except KeyError:
                        continue
                    resolved.append(candidate)
                if len(resolved) != 1:
                    raise KeyError("数据源无法唯一定位")
                index = resolved[0]
        dataset = index.current_dataset
        actual = index.current_db
        if dataset in ("bird", "cosql") and actual == dataset:
            raise ValueError("请指定该数据集下的真实业务子库，不能跨库混合查询。")
        return dataset, None if actual == dataset else actual

    def _query(self, draft, question, database, sub_db):
        try:
            dataset, scope = self._scope(database, sub_db)
        except ValueError as exc:
            return self._result("needs_user", str(exc))
        except (KeyError, OSError):
            return self._result("blocked", "指定数据库的目录不可用或无法唯一定位，未查询其他数据库。")
        try:
            if self.pipeline_factory:
                pipeline = self.pipeline_factory()
            else:
                from backend.agents.text2sql.pipeline import Text2SQLPipeline
                pipeline = Text2SQLPipeline(self.client)
            # 多轮回复常是短语，完整目标与已核验的用户条件一并交给查询生成器。
            constraints = "；".join(f.source.quote for f in draft.facts)
            query = f"{draft.goals[0].description}\n当前用户输入：{question}"
            if constraints:
                query += f"\n用户已提供条件：{constraints}"
            result = pipeline.run(dataset, scope, query)
        except Exception:
            return self._result("execution_failed", "数据查询服务暂时不可用，未返回未经验证的数字。",
                                ok=False, error="query_unavailable")
        if not result.get("ok"):
            return self._result("execution_failed", "查询未通过校验或执行失败，请检查来源与服务状态。",
                                ok=False, error=result.get("stage", "query_failed"),
                                sql=result.get("sql"))
        columns, rows = result.get("columns") or [], result.get("rows") or []
        if not rows:
            answer = "按当前查询条件未找到匹配记录。空结果未被替换为零或放宽查询条件。"
        elif len(rows) == 1 and len(rows[0]) == 1:
            value = rows[0][0]
            answer = f"查询结果：{value if value is not None else '空值（NULL）'}。"
        else:
            lines = ["；".join(f"{name}：{value}" for name, value in zip(columns, row)) for row in rows[:20]]
            answer = "查询结果：\n" + "\n".join(lines)
            if len(rows) > 20 or result.get("truncated"):
                answer += "\n仅展示部分记录，请缩小查询范围以获取完整明细。"
        return self._result("answered", answer, executed=True, ready=True,
                            sql=result.get("sql"), rows=rows, columns=columns,
                            truncated=bool(result.get("truncated")),
                            citations=[{"kind": "database_query", "dataset": dataset,
                                        "sub_db": scope, "tables": result.get("tables", [])}])

    def _retrieve(self, question, doc_id):
        if not doc_id:
            return self._result("needs_user", "请指定要查询的文档，当前不自动扩大文档范围。")
        registry = None
        try:
            if self.retriever_factory:
                retriever = self.retriever_factory()
            else:
                from backend.config import get_settings
                from backend.data_access.registry import SourceRegistry
                from backend.agents.rag_retriever import RAGRetriever
                registry = SourceRegistry.load_from_json(get_settings().data_registry_path)
                source = registry.get_vector("ohr_bench")
                if source is None:
                    raise ValueError("文档源未注册")
                retriever = RAGRetriever(source)
            hits = retriever.retrieve(question, doc_id=doc_id, top_k=3)
        except Exception:
            return self._result("execution_failed", "文档检索服务不可用，未编造文档内容或来源。",
                                ok=False, error="retrieval_unavailable")
        finally:
            if registry is not None:
                registry.close_all()
        hits = [h for h in hits if h.get("doc_id") == doc_id and h.get("text")]
        if not hits:
            return self._result("blocked", "指定文档中未获得可用证据，暂时无法回答。")
        # 保守返回原文摘录；检索命中不声称已经证明结论正确或充分。
        answer = "已找到相关原文证据，以下为摘录（尚未证明足以回答全部问题）：\n" + "\n".join(
            str(h["text"])[:1200] for h in hits)
        return self._result("evidence_ready", answer, executed=True, ready=False,
                            citations=hits, evidence_ready=True)
