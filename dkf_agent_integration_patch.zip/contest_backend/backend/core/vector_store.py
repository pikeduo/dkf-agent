"""
向量检索封装：基于 pgvector，无需独立向量服务。
负责文档切片、嵌入、写入与近邻检索。
"""
from typing import List, Dict, Optional
import psycopg2
from backend.config import get_settings


class VectorStore:
    """PostgreSQL + pgvector 向量库封装。

    建表约定（首次初始化时执行）：
        CREATE EXTENSION IF NOT EXISTS vector;
        CREATE TABLE IF NOT EXISTS doc_chunks (
            id          BIGSERIAL PRIMARY KEY,
            doc_id      TEXT NOT NULL,
            physical_page INT,
            text        TEXT NOT NULL,
            embedding   VECTOR(1024),
            source_bbox JSONB
        );
    """

    def __init__(self, database_url: Optional[str] = None) -> None:
        self.database_url = database_url or get_settings().database_url
        self.dim = get_settings().embedding_dim

    def _conn(self) -> psycopg2.connection:
        return psycopg2.connect(self.database_url)

    def upsert_chunks(
        self,
        doc_id: str,
        chunks: List[Dict],
        embeddings: List[List[float]],
    ) -> None:
        """写入/更新文档切片及其向量。

        每个 chunk 需包含 text、可选 physical_page、source_bbox。
        """
        assert len(chunks) == len(embeddings), "切片数量必须与向量数量一致"
        sql = """
        INSERT INTO doc_chunks (doc_id, physical_page, text, embedding, source_bbox)
        VALUES (%s, %s, %s, %s, %s)
        """
        import json

        with self._conn() as conn, conn.cursor() as cur:
            for c, e in zip(chunks, embeddings):
                cur.execute(sql, (
                    doc_id,
                    c.get("physical_page"),
                    c["text"],
                    e,
                    json.dumps(c.get("source_bbox")),
                ))

    def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        doc_id: Optional[str] = None,
    ) -> List[Dict]:
        """按向量相似度检索 top_k 个切片。"""
        # 占位符顺序须与 SQL 一致：距离向量 →（可选）doc_id 过滤 → LIMIT
        sql = """
            SELECT doc_id, physical_page, text, source_bbox,
                   embedding <-> %s::vector AS distance
            FROM doc_chunks
        """
        params = [query_embedding]
        if doc_id:
            sql += " WHERE doc_id = %s"
            params.append(doc_id)
        sql += " ORDER BY distance ASC LIMIT %s"
        params.append(top_k)

        import psycopg2.extras
        with self._conn() as conn, conn.cursor(
            cursor_factory=psycopg2.extras.RealDictCursor
        ) as cur:
            cur.execute(sql, params)
            return cur.fetchall()
