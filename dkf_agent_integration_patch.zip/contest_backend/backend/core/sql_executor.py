"""
只读 SQL 执行器：保证数据库访问安全。
- 仅允许 SELECT（禁止 DDL/DML）
- 独立只读用户
- 语句超时与结果行数上限
- 校验通过后执行并返回结构化结果
"""
from typing import List, Dict
import psycopg2
import sqlglot
from backend.config import get_settings

# 结果行数上限，防止全量数据泄露
MAX_RESULT_ROWS = 500
# 语句超时（秒）
STATEMENT_TIMEOUT_MS = 30_000


class SQLExecutor:
    """受限 SQL 执行器。

    安全边界不依赖提示词：
    1. 语法校验：用 sqlglot 解析，仅接受单条 SELECT。
    2. 白名单：拒绝 INSERT/UPDATE/DELETE/DROP/ALTER/TRUNCATE 等。
    3. 运行时：设置 statement_timeout，限制结果行数。
    """

    def __init__(self, database_url: str = None) -> None:
        self.database_url = database_url or get_settings().database_url

    @staticmethod
    def validate_select_only(sql: str) -> bool:
        """解析 SQL，确认是纯只读 SELECT 语句。"""
        try:
            parsed = sqlglot.parse(sql)
        except Exception:
            return False
        for stmt in parsed:
            if stmt is None:
                continue
            # 只允许 Query（SELECT）
            if not isinstance(stmt, sqlglot.exp.Query):
                return False
        return True

    def execute(self, sql: str) -> Dict:
        """校验并执行 SQL，返回结果与元信息。"""
        if not self.validate_select_only(sql):
            return {"ok": False, "error": "SQL 非只读 SELECT，已拒绝执行"}

        with self._conn() as conn, conn.cursor() as cur:
            cur.execute(f"SET statement_timeout TO {STATEMENT_TIMEOUT_MS}")
            cur.execute(sql)
            columns = [desc[0] for desc in cur.description]
            rows = cur.fetchmany(MAX_RESULT_ROWS + 1)
            truncated = len(rows) > MAX_RESULT_ROWS
            rows = rows[:MAX_RESULT_ROWS]

        return {
            "ok": True,
            "columns": columns,
            "rows": [list(r) for r in rows],
            "row_count": len(rows),
            "truncated": truncated,
        }

    def _conn(self):
        return psycopg2.connect(self.database_url)
