"""
大模型统一接口：屏蔽不同供应商（智谱/硅基流动/通义/Anna）的调用差异。
使用 OpenAI 兼容协议，按 LLM_PROVIDER 配置选择具体服务商。
"""
from typing import List, Dict, Optional
import httpx
import time

from backend.config import get_settings


class LLMClient:
    """国产大模型统一客户端。

    说明：
    - 通过 base_url + api_key 调用 OpenAI 风格 chat/completions 接口。
    - 本类不缓存密钥到磁盘，仅运行期内存持有。
    """

    def __init__(self) -> None:
        self.settings = get_settings()

    # auto 模式的选择顺序，与引入显式配置前的行为保持一致
    _AUTO_ORDER = ("zhipu", "siliconflow", "qwen")

    def _provider_config(self, name: str) -> Dict[str, str]:
        """返回单个供应商的地址、密钥与聊天模型名（均来自配置）。"""
        s = self.settings
        table = {
            # 智谱与通义沿用原有的 default_model
            "zhipu": (s.zhipu_base_url, s.zhipu_api_key, s.default_model),
            "siliconflow": (s.siliconflow_base_url, s.siliconflow_api_key, s.siliconflow_chat_model),
            "qwen": (s.qwen_base_url, s.qwen_api_key, s.default_model),
            "anna": (s.anna_base_url, s.anna_api_key, s.anna_chat_model),
            "wb": (s.wb_base_url, s.wb_api_key, s.wb_chat_model),
        }
        base_url, api_key, model = table[name]
        base_url = base_url.rstrip("/")
        if name == "wb" and not base_url.endswith("/v1"):
            base_url += "/v1"
        result: Dict[str, str] = {
            "name": name, "base_url": base_url, "api_key": api_key, "model": model
        }
        # 思考程度（sub2api 的 OpenAI 协议字段 reasoning_effort），只在 Anna 侧生效
        if name == "anna" and s.anna_reasoning_effort:
            result["reasoning_effort"] = s.anna_reasoning_effort
        return result

    def _select_provider(self) -> Dict[str, str]:
        """显式指定时只用该供应商；auto 时按密钥可用性依次选择。"""
        if self.settings.llm_provider != "auto":
            provider = self._provider_config(self.settings.llm_provider)
            if not provider["api_key"]:
                # 不回退到其他供应商，避免在不知情时换用别的模型
                raise RuntimeError(f"已指定供应商 {provider['name']}，但未配置其 API 密钥，请填写 .env。")
            return provider
        for name in self._AUTO_ORDER:
            provider = self._provider_config(name)
            if provider["api_key"]:
                return provider
        raise RuntimeError("未配置任何大模型 API 密钥，请填写 .env。")

    def chat(self, messages: List[Dict], temperature: float = 0.1,
             max_retries: Optional[int] = None,
             reasoning_effort: Optional[str] = "default") -> str:
        """发送对话请求，返回模型文本输出。

        有界重试：仅对「瞬时故障」重试（连接/SSL 抖动、读超时、协议断连、
        429 限流、5xx、模型偶发空正文），退避 2→4s。
        重试次数取 LLM_MAX_RETRIES（默认 2，即最多 3 次尝试）；
        单次请求读超时取 LLM_REQUEST_TIMEOUT（默认 60s），避免接口挂起时长时间等待。
        4xx 参数/鉴权错误不重试，快速失败。重试耗尽抛最后一次的异常。

        reasoning_effort（思考程度，按调用覆盖，支持简单题少想、复杂题多想）：
        - "default"（缺省）：用供应商配置值（Anna 为 .env 的 ANNA_REASONING_EFFORT，默认 xhigh）；
        - None：本次不发送该字段（等效"不设置思考程度"，走模型默认）；
        - 具体字符串（minimal/low/medium/high/xhigh/max）：覆盖本次请求的思考强度。
        简单任务（纯算术/单表/直套公式）传 None 或 "low" 可显著降延迟且不损正确率。
        """
        if max_retries is None:
            max_retries = self.settings.llm_max_retries
        if type(max_retries) is not int or not 0 <= max_retries <= 2:
            raise ValueError("额外重试次数必须为0到2的整数")
        provider = self._select_provider()
        payload = {
            "model": provider["model"],
            "messages": messages,
            "temperature": temperature,
        }
        # 思考程度（OpenAI 协议 reasoning_effort）：按次覆盖，未配置时透传供应商默认
        if reasoning_effort == "default":
            effort = provider.get("reasoning_effort")
        else:
            effort = reasoning_effort  # None=不发送；具体值=覆盖
        if effort:
            payload["reasoning_effort"] = effort
        headers = {"Authorization": f"Bearer {provider['api_key']}"}
        url = f"{provider['base_url']}/chat/completions"

        # 可重试的瞬时故障类型
        retryable = (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout,
                     httpx.WriteTimeout, httpx.PoolTimeout,
                     httpx.RemoteProtocolError, httpx.ReadError, RuntimeError)
        last_reason = "接口异常"
        for attempt in range(max_retries + 1):
            try:
                # 连接/写入用 10s 固定超时快速失败；读超时按配置（挂起型故障不硬等）
                timeout = httpx.Timeout(connect=10.0, read=self.settings.llm_request_timeout,
                                        write=10.0, pool=10.0)
                with httpx.Client(timeout=timeout) as client:
                    resp = client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                    data = resp.json()
                msg = data["choices"][0]["message"]
                content = msg.get("content")
                if not content:
                    # 深度推理模型偶尔只给 reasoning_content 而正文为空：视为瞬时，重试
                    raise RuntimeError("模型返回正文为空")
                return content
            except httpx.HTTPStatusError as exc:
                status = exc.response.status_code
                # 仅限流和服务端瞬时故障重试；鉴权及参数错误直接返回给上层脱敏。
                if status != 429 and not 500 <= status < 600:
                    raise
                last_reason = f"HTTP {status}"
            except retryable as exc:
                # 不将异常正文、请求地址或密钥拼入可展示错误。
                last_reason = exc.__class__.__name__
            if attempt < max_retries:
                time.sleep(2 ** (attempt + 1))
        raise RuntimeError(f"模型接口不可用（额外重试{max_retries}次）：{last_reason}")

    def chat_json(self, messages: List[Dict], temperature: float = 0.0) -> Dict:
        """要求模型返回 JSON，并做稳健解析。

        实际项目中需处理模型返回被 ```json 包裹等常见情况。
        """
        import json
        import re

        raw = self.chat(messages, temperature=temperature)
        # 提取首个 JSON 对象
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            raise ValueError(f"模型输出中未找到 JSON：{raw[:200]}")
        return json.loads(match.group(0))
