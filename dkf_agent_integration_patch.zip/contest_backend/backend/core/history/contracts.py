"""会话查询请求：历史身份和角色不能由客户端伪造。"""
from pydantic import Field, model_validator

from backend.core.intent.contracts import Contract, Identifier, IntentRequest


class ConditionUpdate(Contract):
    """用户显式指定当前输入中的有效条件；同键更新替代旧条件。"""

    key: Identifier
    quote: str = Field(min_length=1, max_length=2000)


class ConversationRequest(IntentRequest):
    """不传会话标识时保留原有无状态接口。"""

    session_id: Identifier | None = None
    new_task: bool = False
    reply_to: Identifier | None = None
    is_clarify: bool = Field(default=False, alias="isClarify")
    history_refs: list[Identifier] = Field(default_factory=list, max_length=8)
    condition_updates: list[ConditionUpdate] = Field(default_factory=list, max_length=8)

    @model_validator(mode="after")
    def check_session_fields(self):
        if not self.session_id and (self.new_task or self.reply_to or self.is_clarify or self.history_refs or self.condition_updates):
            raise ValueError("会话操作需要session_id，身份令牌通过请求头提供")
        if self.is_clarify and not self.reply_to:
            raise ValueError("澄清回复必须指定reply_to，防止回复错绑")
        if self.new_task and (self.reply_to or self.is_clarify or self.history_refs):
            raise ValueError("新任务不能同时回复或引用旧任务")
        keys = [item.key for item in self.condition_updates]
        if len(keys) != len(set(keys)):
            raise ValueError("同一请求的条件键不能重复")
        return self

    def intent_request(self, database: str | None = None, doc_id: str | None = None) -> IntentRequest:
        """只向意图模块转交问题和来源提示，不传会话令牌或控制字段。"""
        return IntentRequest(question=self.question, context=self.context,
                             database=database if database is not None else self.database,
                             doc_id=doc_id if doc_id is not None else self.doc_id,
                             trace_id=self.trace_id)
