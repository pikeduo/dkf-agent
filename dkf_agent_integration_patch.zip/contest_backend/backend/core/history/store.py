"""单进程会话存储：能力令牌隔离、任务作用域和显式条件替换。"""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import secrets
import threading
import time
from typing import Literal


# 被用户替换的旧条件在模型视图中的遮蔽文本；证据检查会拒绝引用它。
MASK_TEXT = "[该条件已被用户替换，不可作为当前事实]"


class SessionError(Exception):
    """会话访问或更新失败，不包含历史正文和令牌。"""

    def __init__(self, message: str, status_code: int = 409):
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class HistoryMessage:
    """保留消息角色与依赖；助手文本不可作为用户事实。"""

    id: str
    task_id: str
    turn_id: str
    sequence: int
    role: Literal["user", "assistant"]
    text: str
    depends_on: tuple[str, ...] = ()


@dataclass(frozen=True)
class Condition:
    """仅由用户显式提交的条件更新，不自动确认模型推测。"""

    key: str
    message_id: str
    quote: str


@dataclass
class Session:
    """存储原文供审计；筛选与替换只影响交给模型的视图。"""

    id: str
    token_digest: str
    touched: float
    task_id: str = field(default_factory=lambda: secrets.token_hex(12))
    revision: int = 0
    messages: list[HistoryMessage] = field(default_factory=list)
    conditions: dict[str, Condition] = field(default_factory=dict)
    superseded: dict[str, list[str]] = field(default_factory=dict)
    protected: set[str] = field(default_factory=set)
    root_id: str | None = None
    pending_id: str | None = None
    database: str | None = None
    doc_id: str | None = None
    busy: bool = False
    # 为True时本次租约不提交，例如意图识别失败后不留下半截回合。
    discard: bool = False

    def start_task(self) -> None:
        """旧任务保留在存储中，但不参与新任务筛选。"""
        self.task_id = secrets.token_hex(12)
        self.conditions.clear()
        self.protected.clear()
        self.root_id = self.pending_id = None
        self.database = self.doc_id = None

    def append(self, role: Literal["user", "assistant"], text: str,
               turn_id: str, depends_on: tuple[str, ...] = ()) -> HistoryMessage:
        known = {m.id for m in self.messages if m.task_id == self.task_id}
        if not set(depends_on) <= known:
            raise SessionError("消息依赖不存在或属于其他任务", 422)
        message = HistoryMessage("history_" + secrets.token_hex(12), self.task_id,
                                 turn_id, len(self.messages), role, text, depends_on)
        self.messages.append(message)
        return message

    def update_condition(self, key: str, quote: str, message: HistoryMessage) -> None:
        """条件必须逐字存在于当前用户消息，且可无歧义定位。"""
        if message.role != "user" or message.task_id != self.task_id or message.text.count(quote) != 1:
            raise SessionError("确认条件必须唯一引用当前用户输入", 422)
        for condition in self.conditions.values():
            if condition.key != key and condition.message_id == message.id:
                start, old_start = message.text.index(quote), message.text.index(condition.quote)
                if start < old_start + len(condition.quote) and old_start < start + len(quote):
                    raise SessionError("不同条件的引用不能相互重叠", 422)
        previous = self.conditions.get(key)
        if previous:
            self.superseded.setdefault(previous.message_id, []).append(previous.quote)
        self.conditions[key] = Condition(key, message.id, quote)

    def model_view(self) -> list[HistoryMessage]:
        """遮蔽已替换条件，不删除同一消息内仍然有用的公式与上下文。"""
        result = []
        for message in self.messages:
            if message.task_id != self.task_id:
                continue
            text = message.text
            for quote in sorted(self.superseded.get(message.id, []), key=len, reverse=True):
                text = text.replace(quote, MASK_TEXT)
            result.append(HistoryMessage(message.id, message.task_id, message.turn_id,
                                         message.sequence, message.role, text, message.depends_on))
        return result


class SessionStore:
    """开发阶段内存存储；多进程部署需要替换为共享的认证会话存储。"""

    def __init__(self, ttl_seconds: float = 3600, max_sessions: int = 256,
                 max_messages: int = 512, max_characters: int = 200000):
        self.ttl_seconds = ttl_seconds
        self.max_sessions = max_sessions
        self.max_messages = max_messages
        self.max_characters = max_characters
        self._sessions: dict[str, Session] = {}
        self._lock = threading.Lock()

    @staticmethod
    def _digest(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def _prune(self):
        now = time.monotonic()
        expired = [key for key, value in self._sessions.items()
                   if not value.busy and now - value.touched > self.ttl_seconds]
        for key in expired:
            del self._sessions[key]

    def create(self) -> tuple[str, str]:
        """只在创建时返回原始令牌，存储中仅保留摘要。"""
        with self._lock:
            self._prune()
            if len(self._sessions) >= self.max_sessions:
                raise SessionError("会话容量已满，请稍后重试", 503)
            session_id, token = secrets.token_hex(16), secrets.token_urlsafe(32)
            self._sessions[session_id] = Session(session_id, self._digest(token), time.monotonic())
            return session_id, token

    def check_capacity(self, session: Session) -> None:
        """调用外部模型前及提交前均检查内存预算。"""
        if len(session.messages) > self.max_messages or sum(len(m.text) for m in session.messages) > self.max_characters:
            raise SessionError("会话存储预算已用尽，请创建新会话", 413)

    @contextmanager
    def lease(self, session_id: str, token: str | None):
        """同一会话串行更新；失败回滚，禁止并发覆盖状态。"""
        with self._lock:
            self._prune()
            stored = self._sessions.get(session_id)
            if not stored or not token or not secrets.compare_digest(stored.token_digest, self._digest(token)):
                raise SessionError("会话不存在、已过期或令牌无效", 404)
            if stored.busy:
                raise SessionError("该会话正在处理另一条消息，请稍后重试")
            working = deepcopy(stored)
            stored.busy = True
        try:
            yield working
            if working.discard:
                return
            self.check_capacity(working)
            with self._lock:
                working.revision = stored.revision + 1
                working.touched = time.monotonic()
                working.busy = False
                self._sessions[session_id] = working
        finally:
            with self._lock:
                stored.busy = False

    def delete(self, session_id: str, token: str | None) -> None:
        """用户可显式销毁会话；忙碌会话不能被同时删除。"""
        with self._lock:
            self._prune()
            stored = self._sessions.get(session_id)
            if not stored or not token or not secrets.compare_digest(stored.token_digest, self._digest(token)):
                raise SessionError("会话不存在、已过期或令牌无效", 404)
            if stored.busy:
                raise SessionError("会话正在处理中")
            del self._sessions[session_id]
