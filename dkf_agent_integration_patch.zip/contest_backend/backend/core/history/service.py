"""在意图识别之前执行历史筛选，成功后记录可继续回答的澄清问题。"""
from dataclasses import dataclass
import json
import secrets

from backend.core.intent import IntentResult, IntentService
from .contracts import ConversationRequest
from .selector import HistorySelector
from .store import SessionError, SessionStore


@dataclass
class ConversationResult:
    intent: IntentResult
    session_id: str
    task_id: str
    revision: int
    # 失败回合未写入会话时为空。
    user_message_id: str | None
    clarification_message_id: str | None
    history: dict


class ConversationService:
    """单次查询只推进意图分析；不执行计算、SQL或文档检索。"""

    def __init__(self, store: SessionStore, selector: HistorySelector):
        self.store = store
        self.selector = selector

    def analyze(self, request: ConversationRequest, token: str | None,
                intent_service: IntentService) -> ConversationResult:
        with self.store.lease(request.session_id, token) as session:
            if request.new_task:
                session.start_task()
            if request.reply_to and request.reply_to != session.pending_id:
                raise SessionError("回复不是当前待回答的澄清问题", 409)
            if request.database is not None:
                session.database = request.database
            if request.doc_id is not None:
                session.doc_id = request.doc_id
            active_ids = {m.id for m in session.messages if m.task_id == session.task_id}
            if not set(request.history_refs) <= active_ids:
                raise SessionError("引用的历史不存在或属于其他任务", 422)
            turn_id = "turn_" + secrets.token_hex(12)
            dependencies = set(request.history_refs)
            if request.reply_to:
                dependencies.add(request.reply_to)
            current = session.append("user", request.question, turn_id, tuple(sorted(dependencies)))
            if session.root_id is None:
                session.root_id = current.id
            if request.reply_to:
                # 明确的用户回复永久保护到当前任务结束，不将其值自动写成模型确认的槽位。
                session.protected.add(current.id)
            for item in request.context:
                session.append("user", item.text, turn_id)
            for update in request.condition_updates:
                session.update_condition(update.key, update.quote, current)
            if len(session.conditions) > 32:
                raise SessionError("当前任务确认条件过多，请拆分任务", 413)
            self.store.check_capacity(session)
            prior = [m for m in session.model_view() if m.turn_id != turn_id]
            prior_ids = {m.id for m in prior}
            required = set(request.history_refs) | (session.protected & prior_ids)
            required |= {c.message_id for c in session.conditions.values() if c.message_id in prior_ids}
            if session.root_id in prior_ids:
                required.add(session.root_id)
            if session.pending_id in prior_ids:
                required.add(session.pending_id)
            if request.reply_to:
                required.add(request.reply_to)
            selection_query = json.dumps({"question": request.question,
                                          "user_context": [item.model_dump() for item in request.context]}, ensure_ascii=False)
            selection = self.selector.select(selection_query, prior, required)
            result = intent_service.analyze(request.intent_request(session.database, session.doc_id), history=selection.messages)
            if not result.ok:
                # 失败回合整体回滚：重试时不会出现重复或互相冲突的用户回复。
                session.discard = True
                return ConversationResult(result, session.id, session.task_id,
                                          session.revision, None,
                                          session.pending_id, selection.summary())
            if result.ok:
                session.pending_id = None
                if result.decision.action == "CLARIFY":
                    text = result.decision.message
                    if result.decision.candidates:
                        text += "\n候选：" + "；".join(result.decision.candidates)
                    # 澄清问题保留其分析依据，后续选择该问题时依赖一并恢复。
                    parents = {current.id} | {e.input_id for e in result.evidence if e.input_id in prior_ids}
                    clarification = session.append("assistant", text, turn_id, tuple(sorted(parents)))
                    session.pending_id = clarification.id
            outcome = ConversationResult(result, session.id, session.task_id,
                                         session.revision + 1, current.id,
                                         session.pending_id, selection.summary())
        return outcome
