"""按完整对话片段筛选历史；必要状态与依赖由代码保护。"""
from dataclasses import dataclass, field
import json
import math
from typing import Protocol

from .store import HistoryMessage, SessionError


class Score(Protocol):
    """兼容多标签判断的保留分数与未知分数。"""

    score: float
    unknown: float


class Ranker(Protocol):
    """筛选器只返回标识及分数，不生成替代历史正文。"""

    def score(self, question: str, candidates: list[dict]) -> dict[str, Score]:
        ...


@dataclass
class Selection:
    """只公开筛选统计及标识，不回显被排除的历史。"""

    messages: list[HistoryMessage]
    mode: str
    reason: str
    candidate_count: int
    before_bytes: int
    after_bytes: int
    protected_ids: list[str] = field(default_factory=list)
    budget_omitted: bool = False

    def summary(self) -> dict:
        return {"mode": self.mode, "reason": self.reason,
                "candidate_count": self.candidate_count,
                "selected_message_ids": [m.id for m in self.messages],
                "protected_message_ids": self.protected_ids,
                "before_bytes": self.before_bytes, "after_bytes": self.after_bytes,
                "budget_omitted": self.budget_omitted}


def serialize_message(message: HistoryMessage) -> dict:
    return {"id": message.id, "role": message.role, "text": message.text,
            "depends_on": list(message.depends_on), "evidence_allowed": message.role == "user"}


def byte_size(messages: list[HistoryMessage]) -> int:
    """使用真实UTF-8字节预算，不冒充特定模型分词器的token数。"""
    return len(json.dumps([serialize_message(m) for m in messages], ensure_ascii=False).encode("utf-8"))


class HistorySelector:
    """低置信、弃答和故障均保守处理；不会删除原始会话消息。"""

    def __init__(self, ranker: Ranker | None = None, recent_turns: int = 16,
                 short_turns: int = 4, max_bytes: int = 16000,
                 keep_threshold: float = 0.65, reject_threshold: float = 0.35,
                 unknown_threshold: float = 0.25):
        if not 1 <= recent_turns <= 32 or not 0 <= short_turns <= recent_turns:
            raise ValueError("历史窗口配置不合法")
        if max_bytes < 256 or not 0 <= reject_threshold < keep_threshold <= 1 or not 0 <= unknown_threshold <= 1:
            raise ValueError("历史预算或分数阈值不合法")
        self.ranker = ranker
        self.recent_turns = recent_turns
        self.short_turns = short_turns
        self.max_bytes = max_bytes
        self.keep_threshold = keep_threshold
        self.reject_threshold = reject_threshold
        self.unknown_threshold = unknown_threshold

    def select(self, question: str, messages: list[HistoryMessage], required_ids: set[str]) -> Selection:
        if not messages:
            if required_ids:
                raise SessionError("必要历史引用不存在", 422)
            return Selection([], "empty", "没有历史", 0, 2, 2)
        if len({m.task_id for m in messages}) != 1 or len({m.id for m in messages}) != len(messages):
            raise SessionError("历史作用域或消息标识不合法", 422)
        ordered = sorted(messages, key=lambda m: m.sequence)
        by_id = {m.id: m for m in ordered}
        turns: dict[str, list[HistoryMessage]] = {}
        for message in ordered:
            turns.setdefault(message.turn_id, []).append(message)
        turn_ids = list(turns)
        if not required_ids <= by_id.keys():
            raise SessionError("必要历史引用不存在或不属于当前任务", 422)

        def closure(ids: set[str]) -> set[str]:
            expanded = set()
            pending = list(ids)
            while pending:
                mid = pending.pop()
                if mid in expanded:
                    continue
                if mid not in by_id:
                    raise SessionError("历史依赖不完整", 422)
                message = by_id[mid]
                # 只允许依赖更早消息，避免环以及跨任务错误。
                if any(dep not in by_id or by_id[dep].sequence >= message.sequence for dep in message.depends_on):
                    raise SessionError("历史依赖顺序不合法", 422)
                expanded.add(mid)
                pending.extend(message.depends_on)
                pending.extend(m.id for m in turns[message.turn_id] if m.id not in expanded)
            return expanded

        def selected_messages(ids):
            return [m for m in ordered if m.id in ids]

        # 至少保留最近一个完整片段，避免省略表达因筛选被切断。
        protected = closure(required_ids | {m.id for m in turns[turn_ids[-1]]})
        if byte_size(selected_messages(protected)) > self.max_bytes:
            raise SessionError("必要历史超过上下文预算，请新建任务或调整服务器预算", 413)
        candidate_turns = set(turn_ids[-self.recent_turns:]) | {by_id[mid].turn_id for mid in protected}
        candidates = [{"id": tid, "messages": [serialize_message(m) for m in turns[tid]],
                       "required": any(m.id in protected for m in turns[tid])}
                      for tid in turn_ids if tid in candidate_turns]
        optional = [tid for tid in turn_ids if tid in candidate_turns and not all(m.id in protected for m in turns[tid])]
        chosen = list(reversed(optional))
        mode, reason = "recent", "保留必要状态及最近完整片段"
        if len(turn_ids) <= self.short_turns:
            mode, reason = "short", "短历史跳过模型筛选"
        elif not optional:
            mode, reason = "protected", "候选均为必要历史，无需调用筛选模型"
        elif self.ranker is not None and len(candidates) <= 32:
            try:
                scores = self.ranker.score(question, candidates)
                if set(scores) != {c["id"] for c in candidates}:
                    raise ValueError("评分标识与候选不一致")
                for item in scores.values():
                    if any(type(v) not in (int, float) or not math.isfinite(v) or not 0 <= v <= 1
                           for v in (item.score, item.unknown)):
                        raise ValueError("评分值不合法")
                # 未知或灰区候选保留；只有明确低分且未知概率低时才排除。
                chosen = [tid for tid in optional if scores[tid].score >= self.reject_threshold
                          or scores[tid].unknown >= self.unknown_threshold]
                chosen.sort(key=lambda tid: (scores[tid].score >= self.keep_threshold,
                                             scores[tid].score, turn_ids.index(tid)), reverse=True)
                mode, reason = "imajev", "必要状态不受评分影响；灰区与未知候选保守保留"
            except Exception:
                # 评分只是一项优化，任何评分故障都不得清空必要上下文或泄露原始错误。
                chosen = list(reversed(optional))
                mode, reason = "fallback", "历史评分不可用，回退到必要状态及最近片段"
        elif self.ranker is not None:
            mode, reason = "fallback", "依赖补齐后的候选超出多选上限，使用保守窗口"
        keep = set(protected)
        omitted = False
        for tid in chosen:
            expanded = closure(keep | {m.id for m in turns[tid]})
            if byte_size(selected_messages(expanded)) <= self.max_bytes:
                keep = expanded
            else:
                omitted = True
        selected = selected_messages(keep)
        return Selection(selected, mode, reason, len(candidates), byte_size(ordered),
                         byte_size(selected), sorted(protected), omitted)
