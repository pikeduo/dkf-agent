"""只做前置条件检查和动作选择；不执行SQL、检索或数学表达式。"""
import ast
from decimal import Decimal, InvalidOperation

from .contracts import Decision, Interpretation, Requirement


class FormulaNeedsParsing(ValueError):
    """当前公式超出入口的保守识别范围，需要专业解析或确认。"""


def formula_variables(quote: str) -> set[str]:
    """从明确的代入表达式中读取变量，不求值，不调用符号解析执行器。"""
    text = quote.strip().replace("×", "*").replace("÷", "/").replace("−", "-").replace("^", "**")
    if len(text) > 500:
        raise FormulaNeedsParsing("公式长度超过入口解析范围")
    target = None
    if "=" in text:
        if text.count("=") != 1:
            raise FormulaNeedsParsing("需要专业模块处理等式")
        target, text = [part.strip() for part in text.split("=")]
        if not target.isidentifier():
            raise FormulaNeedsParsing("需要确认等式的目标变量")
    try:
        tree = ast.parse(text, mode="eval")
    except (SyntaxError, ValueError, RecursionError) as exc:
        raise FormulaNeedsParsing("需要识别公式结构或隐式乘法") from exc
    nodes = list(ast.walk(tree))
    if len(nodes) > 100:
        raise FormulaNeedsParsing("公式结构超出入口检查范围")
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Name, ast.Load,
               ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow,
               ast.Mod, ast.USub, ast.UAdd)
    for node in nodes:
        if not isinstance(node, allowed):
            raise FormulaNeedsParsing("需要专业模块确认函数或公式语法")
        if isinstance(node, ast.Constant):
            if type(node.value) not in (int, float) or len(str(node.value)) > 100:
                raise FormulaNeedsParsing("公式包含不支持的常量")
            if not Decimal(str(node.value)).is_finite():
                raise FormulaNeedsParsing("公式包含非有限常量")
    names = {node.id for node in nodes if isinstance(node, ast.Name)}
    if target in names or any(name.startswith("_") for name in names):
        raise FormulaNeedsParsing("需要方程求解或符号确认，而非直接代入")
    return names


def append_requirement(draft: Interpretation, **values) -> Requirement:
    """生成与模型标识不冲突的控制器需求。"""
    if len(draft.requirements) >= 64:
        raise ValueError("展开后的需求数量超过入口预算")
    existing = {r.id for r in draft.requirements}
    index = 1
    while f"control_{index}" in existing:
        index += 1
    requirement = Requirement(id=f"control_{index}", **values)
    draft.requirements.append(requirement)
    return requirement


def prepare_requirements(draft: Interpretation, question: str = "") -> None:
    """根据原文公式补齐变量；缺公式询问用户，不启动公式卡片检索。"""
    formulas = {f.goal_id: f for f in draft.formulas}
    fact_list = list(draft.facts)
    for goal in draft.goals:
        related = [r for r in draft.requirements if r.goal_id == goal.id]
        if goal.operation == "unknown":
            if not any(r.kind == "intent" for r in related):
                append_requirement(draft, goal_id=goal.id, kind="intent", description="请说明希望完成的目标", status="open", resolver="user")
            continue
        if goal.operation != "calculate":
            if not related:
                append_requirement(draft, goal_id=goal.id, kind="external_fact", description="发现能够支持目标的数据源与证据", status="open", resolver="retrieve")
            continue
        formula = formulas.get(goal.id)
        if formula is None:
            # 只有原题本身是无变量的算术表达式才短路，不能凭一个数字猜公式齐全。
            try:
                inline_arithmetic = bool(question.strip()) and not formula_variables(question)
            except FormulaNeedsParsing:
                inline_arithmetic = False
            definitions = [r for r in related if r.kind == "formula_definition"]
            if inline_arithmetic and not definitions:
                continue
            if not definitions:
                definitions = [append_requirement(draft, goal_id=goal.id, kind="formula_definition", description="请提供要使用的公式表达式及适用版本", status="open", resolver="user")]
            for definition in definitions:
                if definition.status != "satisfied":
                    definition.resolver = "user"
            if all(r.status == "satisfied" for r in definitions):
                append_requirement(draft, goal_id=goal.id, kind="input_content", description="从已提供的定义中确认可用公式", status="open", resolver="read_input")
            elif not any(r.kind == "parameter" and r.status == "deferred" for r in related):
                append_requirement(draft, goal_id=goal.id, kind="parameter", description="公式确定后展开必要参数，当前不能判定参数齐全", status="deferred", resolver="unknown", depends_on=[r.id for r in definitions])
            continue
        try:
            names = formula_variables(formula.source.quote)
            known = {f.name for f in fact_list if f.goal_id == goal.id}
            if any(len(name) > 1 and name not in known for name in names):
                raise FormulaNeedsParsing("需要区分多字母变量、隐式乘法及数学常量")
        except FormulaNeedsParsing as exc:
            append_requirement(draft, goal_id=goal.id, kind="input_content", description=str(exc), status="open", resolver="read_input")
            continue
        for name in sorted(names):
            facts = [f for f in fact_list if f.goal_id == goal.id and f.name == name]
            bindings = []
            for fact in facts:
                try:
                    numeric = Decimal(fact.value)
                except InvalidOperation:
                    continue
                if numeric.is_finite():
                    bindings.append(fact)
            distinct = {(Decimal(f.value), f.unit) for f in bindings}
            parameters = [r for r in related if r.kind == "parameter" and r.name == name]
            if len(distinct) == 1:
                if not parameters:
                    append_requirement(draft, goal_id=goal.id, kind="parameter", name=name, description=f"变量{name}具有输入值，仍需专业模块校验单位及语义", status="satisfied", resolver="user", fact_ids=[f.id for f in bindings])
                else:
                    for r in parameters:
                        # 明示冲突和依赖来源要求不能仅凭一个数字解除。
                        if r.status == "open" and not r.depends_on and r.source_hint is None:
                            r.status = "satisfied"
                            r.fact_ids = [f.id for f in bindings]
                continue
            if len(distinct) > 1:
                append_requirement(draft, goal_id=goal.id, kind="parameter", name=name, description=f"变量{name}存在多个值或单位，请确认适用值", status="conflict", resolver="user", candidates=[f"{f.value} {f.unit or ''}".strip() for f in bindings][:8])
                continue
            if not parameters:
                append_requirement(draft, goal_id=goal.id, kind="parameter", name=name, description=f"请提供变量{name}的数值及适用单位", status="open", resolver="user")
            else:
                for r in parameters:
                    if r.status == "satisfied":
                        r.status = "open"
                        r.fact_ids = []
                    if r.resolver == "retrieve" and r.source_hint is None:
                        r.resolver = "user"
    # 所有取参检索都必须有来自实际输入的来源依据。
    for requirement in draft.requirements:
        if requirement.kind == "parameter" and requirement.resolver == "retrieve" and requirement.source_hint is None:
            requirement.resolver = "user"


def supported_candidates(r: Requirement) -> list[str]:
    """业务候选逐项绑定原文或真实目录；只引用触发词不能支持所有候选。"""
    if r.kind != "business_scope":
        return list(r.candidates)
    return [c for c in r.candidates if r.candidate_sources.get(c) or r.candidate_schema_refs.get(c)]


def requirement_gap(requirement: Requirement) -> str:
    """意图层与澄清层共用的缺口分类；候选数量不能替代必要信息判断。"""
    r = requirement
    if r.status == "satisfied":
        return "satisfied"
    if r.status == "deferred":
        return "deferred"
    if r.gap_type in {"unanswerable", "insufficient_evidence"}:
        return r.gap_type
    if r.resolver == "user":
        if r.kind == "business_scope":
            if not (r.source_hint or r.schema_refs or r.candidate_schema_refs or r.candidate_sources):
                return "unsupported_ambiguity"
            if r.status == "conflict" or r.gap_type == "ambiguity":
                if not r.answer_changes or len(supported_candidates(r)) < 2:
                    return "unsupported_ambiguity"
                return "user_ambiguity"
        return "user_missing" if r.status != "conflict" else "user_ambiguity"
    return {"retrieve": "retrieve", "read_input": "read_input"}.get(r.resolver, "unknown")


def user_requirement_ids(draft: Interpretation) -> list[str]:
    """所有未解决用户条件，包含待验证口径；不能靠删掉候选变成已完成。"""
    return [r.id for r in draft.requirements if r.status != "satisfied" and r.resolver == "user"]


def clarification_readiness(draft: Interpretation, confirmed_ids=()) -> dict:
    """澄清完成仅表示用户条件齐备，检索、附件和答案仍可能未完成。"""
    confirmed = set(confirmed_ids)
    pending = [r for r in draft.requirements if r.status != "satisfied" and r.id not in confirmed]
    user_pending = [r.id for r in pending if r.resolver == "user"]
    kinds = {requirement_gap(r) for r in pending}
    if "unanswerable" in kinds:
        status = "unanswerable"
    elif "insufficient_evidence" in kinds or "unsupported_ambiguity" in kinds:
        status = "insufficient_evidence"
    elif user_pending:
        status = "needs_user"
    elif any(requirement_gap(r) in {"unknown", "deferred", "read_input"} for r in pending):
        status = "blocked"
    else:
        status = "ready"
    return {"status": status, "final_ready": status == "ready",
            "pending_user_ids": user_pending,
            "unresolved_ids": [r.id for r in pending],
            "retrieval_pending": any(r.resolver == "retrieve" for r in pending)}


def execution_gate(result, question: str = "") -> dict:
    """父接口的执行资格检查；ready只允许交给受控执行器，绝非答案已完成。"""
    blocked = lambda reason, status="blocked": {"ready": False, "status": status, "reason": reason}
    if not result.ok or result.interpretation is None:
        return blocked(result.error_code or "intent_failed", "error")
    draft = result.interpretation
    if len(draft.goals) != 1:
        return blocked("unsupported_multi_goal")
    if result.decision.action == "STOP":
        return blocked(result.decision.target)
    state = clarification_readiness(draft)
    if state["status"] in {"blocked", "unanswerable", "insufficient_evidence"}:
        return blocked(state["status"])
    if state["pending_user_ids"]:
        status = "needs_user" if result.decision.action == "CLARIFY" else "blocked"
        return blocked("unresolved_user_requirements", status)
    if state["status"] != "ready":
        return blocked(state["status"])
    goal = draft.goals[0]
    if goal.operation == "unknown":
        return blocked("unknown_intent")
    if goal.operation == "calculate":
        if any(r.kind in {"parameter", "formula_definition"} and r.status != "satisfied"
               for r in draft.requirements):
            return blocked("calculation_evidence_pending")
        if not any(f.goal_id == goal.id for f in draft.formulas):
            try:
                if not question.strip() or formula_variables(question):
                    return blocked("formula_missing")
            except FormulaNeedsParsing:
                return blocked("formula_missing")
        return {"ready": True, "status": "ready", "reason": "requires_formula_validation",
                "target": "task6_formula", "goal_id": goal.id}
    if goal.operation != "query":
        return blocked("unsupported_operation")
    metadata = result.schema_context
    if metadata.get("status") != "available":
        return blocked(metadata.get("error_code") or "database_scope_required")
    return {"ready": True, "status": "ready", "reason": "requires_sql_validation",
            "target": "task_execution", "goal_id": goal.id,
            "dataset": metadata["dataset"], "sub_db": metadata.get("sub_db")}


def choose_action(draft: Interpretation) -> tuple[Decision, str]:
    """用户条件先于执行；目录外事实可检索，但检索建议不等于答案完成。"""
    by_id = {r.id: r for r in draft.requirements}
    unresolved = [r for r in draft.requirements if r.status != "satisfied"]
    retrieval = "needed" if any(r.resolver == "retrieve" for r in unresolved) else (
        "undetermined" if any(r.resolver in {"unknown", "read_input"} for r in unresolved) else "not_needed")
    ready = [r for r in unresolved if all(by_id[d].status == "satisfied" for d in r.depends_on)]
    # 未支持口径和证据不足不可转成直接回答，也不可伪造选项来追问。
    for r in ready:
        kind = requirement_gap(r)
        if kind in {"unsupported_ambiguity", "unanswerable", "insufficient_evidence"}:
            return Decision(action="STOP", target=kind, goal_ids=[r.goal_id],
                            requirement_ids=[r.id], message=r.description), retrieval
    if ready:
        priority = {"user": 0, "read_input": 1, "retrieve": 2, "unknown": 3}
        selected = min(ready, key=lambda r: priority[r.resolver])
        action = {"read_input": "READ_INPUT", "retrieve": "RETRIEVE", "user": "CLARIFY", "unknown": "STOP"}[selected.resolver]
        target = {"read_input": "input_reader", "retrieve": "source_discovery", "user": "task3_clarification", "unknown": "intent_review"}[selected.resolver]
        if selected.resolver == "read_input" and any(f.goal_id == selected.goal_id for f in draft.formulas):
            target = "task6_formula"
        if selected.status == "deferred":
            action, target = "STOP", "intent_review"
        return Decision(action=action, target=target, goal_ids=[selected.goal_id],
                        requirement_ids=[selected.id], message=selected.description,
                        candidates=supported_candidates(selected)), retrieval
    if unresolved:
        return Decision(action="STOP", target="intent_review", message="仍存在未满足的需求依赖，禁止直接执行"), retrieval
    goal = draft.goals[0]
    return Decision(action="EXECUTE", target="task6_formula" if goal.operation == "calculate" else "task_execution",
                    goal_ids=[goal.id], message="入口前置检查完成；须由下游校验、执行并检查最终答案充分性"), retrieval
