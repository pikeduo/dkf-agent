"""一次模型解释，加来源校验与确定性动作选择。"""
import json
import re
from decimal import Decimal, InvalidOperation
from typing import Protocol
from uuid import uuid4

import httpx
from pydantic import ValidationError

from backend.core.history.store import MASK_TEXT, HistoryMessage
from backend.core.history.selector import serialize_message

from .contracts import Decision, Evidence, IntentRequest, IntentResult, Interpretation
from .policy import choose_action, prepare_requirements
from .prompts import SYSTEM_PROMPT
from .schema_context import SchemaContext, SchemaContextProvider


class TextClient(Protocol):
    """沿用现有LLMClient；测试可注入无网络客户端。"""

    def chat(self, messages: list[dict], temperature: float = 0.0,
             reasoning_effort: str | None = None) -> str:
        ...


def parse_response(raw: str) -> Interpretation:
    """允许完整代码围栏，不从混杂文本中贪婪提取对象。"""
    if not isinstance(raw, str) or len(raw) > 64000:
        raise ValueError("模型输出类型或长度不合法")
    text = raw.strip()
    if text.startswith("```"):
        match = re.fullmatch(r"```(?:json)?\s*\n(.*?)\n```", text, re.DOTALL)
        if not match:
            raise ValueError("模型输出围栏不完整")
        text = match.group(1)

    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("模型输出重复JSON字段")
            result[key] = value
        return result

    data = json.loads(text, object_pairs_hook=unique_keys)
    return Interpretation.model_validate(data)


def check_evidence(request: IntentRequest, draft: Interpretation,
                   history: list[HistoryMessage] | None = None) -> list[Evidence]:
    """只接受用户原文；助手消息仅用于理解对话，不能成为参数或公式事实。"""
    history = history or []
    history_inputs = {m.id: m.text for m in history if m.role == "user"}
    inputs = {"question": request.question, **{c.id: c.text for c in request.context}, **history_inputs}
    refs = [f.source for f in draft.facts] + [f.source for f in draft.formulas]
    refs += [r.source_hint for r in draft.requirements if r.source_hint is not None]
    refs += [ref for r in draft.requirements for ref in r.candidate_sources.values()]
    evidence = []
    seen = set()
    for ref in refs:
        text = inputs.get(ref.input_id)
        if text is None or ref.quote not in text:
            raise ValueError("来源片段不属于提交的输入")
        if MASK_TEXT in ref.quote:
            raise ValueError("被替换的旧条件不能作为来源")
        key = (ref.input_id, ref.quote)
        if key not in seen:
            start = text.index(ref.quote)
            evidence.append(Evidence(**ref.model_dump(), start=start, end=start + len(ref.quote),
                                     view="filtered_history" if ref.input_id in history_inputs else "input"))
            seen.add(key)
    for fact in draft.facts:
        # 数值允许紧邻中文与单位，但不得从年份、负数或科学计数法中截取一部分。
        number_pattern = r"(?<![A-Za-z0-9_.+\-])[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+\-]?\d+)?"
        try:
            is_number = Decimal(fact.value).is_finite()
        except InvalidOperation:
            is_number = False
        if is_number:
            supported = fact.value in re.findall(number_pattern, fact.source.quote)
        else:
            supported = fact.value in fact.source.quote
        if not supported:
            raise ValueError("事实取值没有逐字原文支持")
        # 显式符号赋值不得被重命名；自然语言变量映射仍由下游语义校验。
        assignment = re.match(r"^\s*([A-Za-z][A-Za-z0-9_]*)\s*[=＝]", fact.source.quote)
        if assignment and assignment.group(1) != fact.name:
            raise ValueError("显式赋值的变量名与绑定不一致")
        if assignment and is_number:
            tail = fact.source.quote[assignment.end():].lstrip()
            assigned = re.match(r"[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+\-]?\d+)?", tail)
            if assigned is None or assigned.group(0) != fact.value:
                raise ValueError("显式赋值的数值与绑定不一致")
        if fact.unit and fact.unit not in fact.source.quote:
            raise ValueError("单位没有原文支持")
    for formula in draft.formulas:
        ref = formula.source
        text = inputs[ref.input_id]
        start = text.index(ref.quote)
        before = text[:start].rstrip()
        after = text[start + len(ref.quote):].lstrip()
        # 防止只截取公式的一部分，漏掉等号、加项或乘项后错误放行。
        operators = "=＝+-*/^×÷−"
        if (before and before[-1] in operators) or (after and after[0] in operators):
            raise ValueError("公式引用截断了原始表达式")
    return evidence


class IntentService:
    """无持久化、无自动重试、无工具执行的入口服务。

    可选 system_prompt 参数为内部接点：传入非None时使用该显式提示（评测候选对照用）；
    传None（默认）时每次analyze从模块常量SYSTEM_PROMPT读取，保持现行为并兼容测试的
    模块级monkeypatch。绝不在线程间改全局常量。实例持有_last_failure_stage私有诊断。
    """

    # 受控失败阶段字符串：仅枚举值，不保存模型原文/异常正文/密钥
    _KNOWN_FAILURE_STAGES = frozenset({
        "parse_contract", "evidence", "schema_reference", "requirements_policy",
    })

    def __init__(self, client: TextClient, schema_provider: SchemaContextProvider | None = None,
                 *, system_prompt: str | None = None):
        self.client = client
        self.schema_provider = schema_provider or SchemaContextProvider()
        # 实例级：显式提示覆盖；None=每次analyze从模块常量读取（默认行为不变）
        self._system_prompt_override = system_prompt
        # 私有诊断：本实例最近一次失败阶段（受控字符串）；analyze开始清空，
        # 不跨实例、不跨线程共享，避免并发串统计
        self._last_failure_stage: str | None = None

    @property
    def last_failure_stage(self) -> str | None:
        """私有诊断读接口：返回本实例最近一次失败阶段（受控字符串）或None。

        仅评测侧在invalid_model_output时抄送；不改IntentResult对外字段。
        """
        return self._last_failure_stage

    def analyze(self, request: IntentRequest, *, history: list[HistoryMessage] | None = None,
                schema_context: SchemaContext | None = None) -> IntentResult:
        # 分析开始清空本实例诊断，避免上一实例/上一分析残留串入
        self._last_failure_stage = None
        history = history or []
        trace_id = request.trace_id or uuid4().hex
        context = schema_context if schema_context is not None else self.schema_provider.resolve(request.database)
        if context.status == "unavailable":
            self._last_failure_stage = "schema_reference"
            failure = self._failure(trace_id, context.error_code or "schema_unavailable", "指定数据库的目录作用域不可用；未调用模型或执行工具")
            failure.schema_context = context.to_dict()
            return failure
        # 系统提示：显式override优先；None=当前模块常量（支持monkeypatch，现行为不变）
        system_body = self._system_prompt_override if self._system_prompt_override is not None else SYSTEM_PROMPT
        messages = [
            {"role": "system", "content": system_body + "\nJSON Schema：\n" + json.dumps(Interpretation.model_json_schema(), ensure_ascii=False)},
            {"role": "user", "content": json.dumps({
                "inputs": [{"id": "question", "text": request.question}] + [c.model_dump() for c in request.context],
                "history": [serialize_message(m) for m in history],
                "source_hints": {"database": request.database, "doc_id": request.doc_id},
                "server_schema": context.to_dict(),
            }, ensure_ascii=False)},
        ]
        # 意图层是"理解+结构化"任务：不涉及复杂推理，不发送 reasoning_effort（走模型默认），
        # 避免为简单理解拉满 xhigh；下游需要深度推理的模块按各自复杂度定强度。
        try:
            raw = self.client.chat(messages, temperature=0.0, reasoning_effort=None)
        except (httpx.HTTPError, RuntimeError, KeyError, IndexError, ValueError, TypeError):
            self._last_failure_stage = "model_unavailable"
            return self._failure(trace_id, "model_unavailable", "模型接口不可用或响应异常，请检查配置与服务后重试")
        # _stage_mark记录当前阶段；仅在进入except时才是"最后失败阶段"，成功则清空
        _stage_mark = None
        try:
            _stage_mark = "parse_contract"
            draft = parse_response(raw)
            _stage_mark = "evidence"
            evidence = check_evidence(request, draft, history)
            _stage_mark = "schema_reference"
            for requirement in draft.requirements:
                refs = requirement.schema_refs + [ref for refs in requirement.candidate_schema_refs.values() for ref in refs]
                if any(not context.contains(ref) for ref in refs):
                    raise ValueError("需求引用未提供的目录对象")
                if (set(requirement.candidate_sources) | set(requirement.candidate_schema_refs)) - set(requirement.candidates):
                    raise ValueError("候选依据引用不存在的候选")
                if any(candidate not in source.quote for candidate, source in requirement.candidate_sources.items()):
                    raise ValueError("用户原文没有支持该候选")
                if requirement.gap_type == "unanswerable" and (context.status != "available" or context.truncated):
                    requirement.gap_type = "insufficient_evidence"
            _stage_mark = "requirements_policy"
            prepare_requirements(draft, request.question)
            draft = Interpretation.model_validate(draft.model_dump())
            decision, retrieval = choose_action(draft)
        except (ValidationError, ValueError, TypeError, RecursionError):
            self._last_failure_stage = _stage_mark
            return self._failure(trace_id, "invalid_model_output", "意图解释未通过结构或来源检查，未进行检索或执行，请重试")
        self._last_failure_stage = None
        return IntentResult(ok=True, stage="intent_ready", trace_id=trace_id,
                            interpretation=draft, evidence=evidence,
                            retrieval_need=retrieval, decision=decision,
                            schema_context=context.to_dict())

    @staticmethod
    def _failure(trace_id: str, code: str, message: str) -> IntentResult:
        """不回显供应商原文、输入内容、地址或密钥。"""
        return IntentResult(ok=False, stage="intent_failed", trace_id=trace_id,
                            decision=Decision(action="STOP", target="technical_error", message=message),
                            error_code=code)
