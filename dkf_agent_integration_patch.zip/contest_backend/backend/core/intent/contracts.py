"""意图层的输入、解释结果及下一步动作契约。"""
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Identifier = Annotated[str, Field(min_length=1, max_length=80, pattern=r"^[\w.-]+$")]
ShortText = Annotated[str, Field(min_length=1, max_length=1000)]
Action = Literal["READ_INPUT", "RETRIEVE", "CLARIFY", "EXECUTE", "RESPOND", "STOP"]


class Contract(BaseModel):
    """拒绝未知字段与隐式类型转换，避免吞掉错误动作或证据。"""

    model_config = ConfigDict(extra="forbid", strict=True, str_strip_whitespace=True)


class InputText(Contract):
    """由调用方提交的用户上下文；不是服务端持久化的已确认会话。"""

    id: Identifier
    text: Annotated[str, Field(min_length=1, max_length=4000)]


class IntentRequest(Contract):
    """当前仅接收文本与来源提示；不读取任意路径或自动授权数据源。"""

    question: Annotated[str, Field(min_length=1, max_length=12000)]
    context: list[InputText] = Field(default_factory=list, max_length=8)
    database: Identifier | None = None
    doc_id: Identifier | None = None
    trace_id: Identifier | None = None

    @model_validator(mode="after")
    def check_context(self):
        ids = [item.id for item in self.context]
        if any(i in {"question", "server_schema"} for i in ids) or any(i.startswith("history_") for i in ids) or len(ids) != len(set(ids)):
            raise ValueError("上下文标识重复或使用保留标识 question/server_schema/history_")
        if sum(len(item.text) for item in self.context) > 16000:
            raise ValueError("上下文总长度超过限制")
        return self


class SourceRef(Contract):
    """原始输入的逐字片段，由代码验证并定位字符区间。"""

    input_id: Identifier
    quote: Annotated[str, Field(min_length=1, max_length=2000)]


class Evidence(SourceRef):
    """字符区间以规范化后的请求文本为准，不编造文档页码。"""

    start: int
    end: int
    view: Literal["input", "filtered_history"] = "input"


class Goal(Contract):
    """能力目标不决定事实在哪类数据库中。"""

    id: Identifier
    operation: Literal["calculate", "query", "explain", "compare", "unknown"]
    description: ShortText


class Fact(Contract):
    """仅保存有输入片段支持的值，单位换算留给专业模块。"""

    id: Identifier
    goal_id: Identifier
    name: Annotated[str, Field(min_length=1, max_length=80)]
    value: Annotated[str, Field(min_length=1, max_length=300)]
    unit: Annotated[str, Field(max_length=80)] | None = None
    source: SourceRef


class Formula(Contract):
    """表达式只从原始输入读取，不接受模型另写可执行程序。"""

    goal_id: Identifier
    source: SourceRef


class Requirement(Contract):
    """依赖满足后才展开参数；已问、跳过均不能当作已满足。"""

    id: Identifier
    goal_id: Identifier
    kind: Literal["formula_definition", "parameter", "business_scope", "external_fact", "input_content", "intent"]
    name: Annotated[str, Field(max_length=80)] | None = None
    description: ShortText
    status: Literal["open", "satisfied", "deferred", "conflict"]
    resolver: Literal["user", "retrieve", "read_input", "unknown"]
    depends_on: list[Identifier] = Field(default_factory=list, max_length=12)
    fact_ids: list[Identifier] = Field(default_factory=list, max_length=32)
    candidates: list[ShortText] = Field(default_factory=list, max_length=8)
    source_hint: SourceRef | None = None
    gap_type: Literal["missing", "ambiguity", "unanswerable", "insufficient_evidence"] = "missing"
    schema_refs: list[ShortText] = Field(default_factory=list, max_length=16)
    candidate_schema_refs: dict[ShortText, Annotated[list[ShortText], Field(max_length=16)]] = Field(default_factory=dict, max_length=8)
    candidate_sources: dict[ShortText, SourceRef] = Field(default_factory=dict, max_length=8)
    answer_changes: bool = False


class Interpretation(Contract):
    """模型仅提出信息解释；最终动作由状态控制器选择。"""

    goals: list[Goal] = Field(min_length=1, max_length=8)
    facts: list[Fact] = Field(default_factory=list, max_length=64)
    formulas: list[Formula] = Field(default_factory=list, max_length=8)
    requirements: list[Requirement] = Field(default_factory=list, max_length=64)

    @model_validator(mode="after")
    def check_references(self):
        for items in (self.goals, self.facts, self.requirements):
            ids = [item.id for item in items]
            if len(ids) != len(set(ids)):
                raise ValueError("解释结果存在重复标识")
        goals = {g.id for g in self.goals}
        facts = {f.id for f in self.facts}
        requirements = {r.id: r for r in self.requirements}
        formula_goals = [f.goal_id for f in self.formulas]
        if len(formula_goals) != len(set(formula_goals)):
            raise ValueError("同一目标存在多条公式，应拆分或声明版本冲突")
        for formula in self.formulas:
            if formula.goal_id not in goals:
                raise ValueError("公式引用不存在的目标")
            if next(g for g in self.goals if g.id == formula.goal_id).operation != "calculate":
                raise ValueError("公式仅能绑定计算目标")
        for fact in self.facts:
            if fact.goal_id not in goals:
                raise ValueError("事实引用不存在的目标")
        for r in self.requirements:
            if r.goal_id not in goals or not set(r.fact_ids) <= facts:
                raise ValueError("需求引用不存在的目标或事实")
            if any(next(f for f in self.facts if f.id == fid).goal_id != r.goal_id for fid in r.fact_ids):
                raise ValueError("需求不能借用其他目标的事实绑定")
            if not set(r.depends_on) <= requirements.keys():
                raise ValueError("需求依赖不存在")
            if r.status == "satisfied" and not r.fact_ids:
                raise ValueError("已满足需求必须引用输入事实")
            if r.status == "deferred" and not r.depends_on:
                raise ValueError("待展开需求必须声明上游依赖")
        visiting, visited = set(), set()

        def visit(key):
            if key in visiting:
                raise ValueError("需求依赖存在环")
            if key in visited:
                return
            visiting.add(key)
            for dependency in requirements[key].depends_on:
                visit(dependency)
            visiting.remove(key)
            visited.add(key)

        for key in requirements:
            visit(key)
        for r in self.requirements:
            if r.status == "satisfied" and any(requirements[d].status != "satisfied" for d in r.depends_on):
                raise ValueError("上游需求未满足，下游不能标为已满足")
        return self


class Decision(Contract):
    """EXECUTE 仅交接到专业模块校验，不代表已经调用工具。"""

    action: Action
    target: str
    goal_ids: list[str] = Field(default_factory=list)
    requirement_ids: list[str] = Field(default_factory=list)
    message: str
    candidates: list[str] = Field(default_factory=list)
    validation_required: bool = True


class IntentResult(Contract):
    """本阶段永远不返回已经完成问答的标志。"""

    ok: bool
    stage: Literal["intent_ready", "intent_failed"]
    trace_id: str
    interpretation: Interpretation | None = None
    evidence: list[Evidence] = Field(default_factory=list)
    retrieval_need: Literal["needed", "not_needed", "undetermined"] = "undetermined"
    decision: Decision
    execution_performed: Literal[False] = False
    answer_ready: Literal[False] = False
    error_code: str | None = None
    schema_context: dict = Field(default_factory=dict)
