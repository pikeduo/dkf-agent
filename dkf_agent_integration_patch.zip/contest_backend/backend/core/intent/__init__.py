"""问题理解、信息需求与受约束的下一步决策。"""
from .contracts import IntentRequest, IntentResult
from .service import IntentService

from .policy import execution_gate, clarification_readiness, requirement_gap

__all__ = ["IntentRequest", "IntentResult", "IntentService", "execution_gate",
           "clarification_readiness", "requirement_gap"]
