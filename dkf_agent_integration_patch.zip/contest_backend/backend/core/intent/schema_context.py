"""有预算的服务端真实目录上下文；不读取问题标签、SQL、答案或业务别名。"""
import copy
import hashlib
import json
from dataclasses import dataclass, field
from typing import Callable

from backend.agents.task4_schema_linking.schema_index import SchemaIndex


@dataclass(frozen=True)
class SchemaContext:
    """目录与用户原文分区；目录命中永远不证明用户偏好唯一。"""

    status: str = "not_requested"
    dataset: str | None = None
    sub_db: str | None = None
    version: str | None = None
    tables: tuple = ()
    total_tables: int = 0
    total_columns: int = 0
    truncated: bool = False
    error_code: str | None = None
    index: object = field(default=None, repr=False, compare=False)

    def to_dict(self) -> dict:
        """仅返回允许展示的目录字段，不暴露本地路径、连接串或索引对象。"""
        return copy.deepcopy({
            "status": self.status, "dataset": self.dataset, "sub_db": self.sub_db,
            "version": self.version, "tables": list(self.tables),
            "total_tables": self.total_tables, "total_columns": self.total_columns,
            "truncated": self.truncated, "error_code": self.error_code,
            "unique_user_preference": False,
        })

    def contains(self, reference: str) -> bool:
        """验证模型引用的表列确实出现在本次已提供的目录中。"""
        low = reference.casefold()
        for table in self.tables:
            names = {table["table"].casefold(), f'{table["schema"]}.{table["table"]}'.casefold()}
            if low in names:
                return True
            for column in table["columns"]:
                if low in {f'{name}.{column}'.casefold() for name in names}:
                    return True
        return False


class SchemaContextProvider:
    """只加载唯一真实子库；数据集总库不能代替子库。"""

    def __init__(self, index_factory: Callable = SchemaIndex, *, max_tables: int = 16,
                 max_columns: int = 180, max_chars: int = 12000):
        if min(max_tables, max_columns, max_chars) <= 0:
            raise ValueError("目录预算必须为正数")
        self.index_factory = index_factory
        self.max_tables = max_tables
        self.max_columns = max_columns
        self.max_chars = max_chars

    def resolve(self, database: str | None) -> SchemaContext:
        """沿用原始database字段；仅在真实索引中唯一命中原始db_id时解析。"""
        if database is None:
            return SchemaContext()
        if database == "chinook":
            return self.load_scope("chinook")
        if database in {"bird", "cosql", "dr_spider", "adventureworks"}:
            return SchemaContext(status="unavailable", dataset=database, error_code="schema_scope_required")
        # 原始db_id可能由任务4在运行时从真实mapping恢复，不能依赖旧JSON里聚合的db_id。
        # 每次都显式传sub_db；绝不先load整套数据集再用同名表猜作用域。
        matches = [context for dataset in ("chinook", "bird", "cosql")
                   if (context := self.load_scope(dataset, database)).status == "available"]
        if len(matches) != 1:
            return SchemaContext(status="unavailable", error_code="schema_scope_not_unique")
        return matches[0]

    def load_scope(self, dataset: str, sub_db: str | None = None) -> SchemaContext:
        """供受控执行接口显式选择作用域；与任务4共用load(dataset, sub_db)。"""
        if dataset != "chinook" and not sub_db:
            return SchemaContext(status="unavailable", dataset=dataset, error_code="schema_scope_required")
        try:
            index = self.index_factory()
            index.load(dataset, sub_db=sub_db)
            entries = copy.deepcopy(index.tables)
            if not entries or (sub_db and any(e.get("db_id") != sub_db for e in entries)):
                raise ValueError("目录未隔离到指定原始子库")
            full = [{"schema": e.get("schema") or "public", "table": e["table"],
                     "columns": list(e.get("columns") or [])} for e in entries]
            full.sort(key=lambda t: (t["schema"], t["table"]))
            identities = [(t["schema"], t["table"]) for t in full]
            if len(identities) != len(set(identities)):
                raise ValueError("目录表标识重复")
            version = hashlib.sha256(json.dumps(full, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
            shown, columns = [], 0
            for table in full[:self.max_tables]:
                kept = dict(table)
                kept["columns"] = table["columns"][:max(0, self.max_columns - columns)]
                trial = shown + [kept]
                if len(json.dumps(trial, ensure_ascii=False)) > self.max_chars:
                    break
                shown = trial
                columns += len(kept["columns"])
            if not shown:
                return SchemaContext(status="unavailable", dataset=dataset, sub_db=sub_db,
                                     error_code="schema_budget_too_small", truncated=True)
            total_columns = sum(len(t["columns"]) for t in full)
            # 索引对象每次新建，会话不会因别人的load调用而改变作用域。
            return SchemaContext(status="available", dataset=dataset, sub_db=sub_db,
                                 version=version, tables=tuple(shown), index=index,
                                 total_tables=len(full), total_columns=total_columns,
                                 truncated=len(shown) < len(full) or columns < total_columns)
        except (OSError, KeyError, ValueError, TypeError, AttributeError, RuntimeError):
            return SchemaContext(status="unavailable", dataset=dataset, sub_db=sub_db,
                                 error_code="schema_unavailable")
