"""
数据接入协议层：统一关系型数据库与向量数据库的检索接口。

模块结构：
    protocol.py    — 核心抽象（Query / Response / Source）
    relational.py  — 关系型数据源（多库注册）
    vector.py      — 向量数据源（pgvector）
    registry.py    — 数据源注册表（加载 databases.json）
    manager.py     — DataAccessManager 统一门面
"""
from backend.data_access.protocol import DataQuery, DataResponse, DataSource
from backend.data_access.relational import RelationalSource
from backend.data_access.vector import VectorSource
from backend.data_access.registry import SourceRegistry
from backend.data_access.manager import DataAccessManager

__all__ = [
    "DataQuery",
    "DataResponse",
    "DataSource",
    "RelationalSource",
    "VectorSource",
    "SourceRegistry",
    "DataAccessManager",
]
