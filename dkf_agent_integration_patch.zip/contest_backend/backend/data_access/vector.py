"""
向量数据源：基于 pgvector 的语义检索。

支持：
    - 写入文档切片 + 嵌入向量（upsert_chunks）
    - 按文本语义检索（search，内部调 embedder 生成查询向量）

嵌入模型通过可注入的 embedder 函数传入，不在此模块中硬编码，
方便在开发环境与生产环境间切换（BGE 本地 / 在线 API 等）。
"""
from typing import Callable, Dict, List, Optional

import psycopg2
import psycopg2.extras

from backend.data_access.protocol import DataSource, DataResponse
from backend.config import get_settings

# 嵌入函数类型：输入文本，返回 1024 维浮点向量
Embedder = Callable[[str], List[float]]


class VectorSource(DataSource):
    """PostgreSQL + pgvector 向量数据源。

    表结构（首次初始化时执行）：
        CREATE EXTENSION IF NOT EXISTS vector;
        CREATE TABLE IF NOT EXISTS doc_chunks (
            id            BIGSERIAL PRIMARY KEY,
            doc_id        TEXT NOT NULL,
            physical_page INT,
            text          TEXT NOT NULL,
            embedding     VECTOR({dim}),
            source_bbox   JSONB
        );
    """

    source_type = "vector"

    def __init__(
        self,
        source_id: str,
        embedder: Optional[Embedder] = None,
        database_url: Optional[str] = None,
    ) -> None:
        """初始化。

        source_id: 数据源标识（如 "ohr_bench" / "doc_kb"）
        embedder:  嵌入函数，输入 str，输出 List[float]（dim 维）；
                   为 None 时只能做写入，不能做检索。
        database_url: DSN；为 None 时使用全局配置。
        """
        self.source_id = source_id
        self._embedder = embedder
        self._database_url = database_url or get_settings().database_url
        self._dim = get_settings().embedding_dim

    # ------------------------------------------------------------------
    # 健康检查
    # ------------------------------------------------------------------
    def ping(self) -> bool:
        """确认 pgvector 扩展可用。"""
        try:
            with self._conn() as conn, conn.cursor() as cur:
                cur.execute(
                    "SELECT 1 FROM pg_extension WHERE extname = 'vector'"
                )
                return cur.fetchone() is not None
        except Exception:
            return False

    # ------------------------------------------------------------------
    # 资源释放
    # ------------------------------------------------------------------
    def close(self) -> None:
        """释放资源（短连接模式下无副作用）。"""
        pass

    # ------------------------------------------------------------------
    # 向量检索
    # ------------------------------------------------------------------
    def search(
        self,
        query_text: str,
        top_k: int = 5,
        doc_id: Optional[str] = None,
    ) -> DataResponse:
        """按文本语义检索 top_k 个文档切片。

        流程：
        1. 用 embedder 把 query_text 转成向量
        2. 在 doc_chunks 表按余弦距离排序
        3. 可选按 doc_id 过滤（限定某份 OHR 文档）
        """
        if self._embedder is None:
            return DataResponse(
                ok=False,
                source_type=self.source_type,
                db_id=self.source_id,
                error="未配置 embedder，无法执行向量检索",
            )

        try:
            q_vec = self._embedder(query_text)
        except Exception as e:
            return DataResponse(
                ok=False,
                source_type=self.source_type,
                db_id=self.source_id,
                error=f"嵌入生成失败：{e}",
            )

        try:
            sql = (
                "SELECT doc_id, physical_page, text, source_bbox, "
                "       embedding <-> %s::vector AS distance "
                "FROM doc_chunks"
            )
            # 占位符顺序须与 SQL 一致：距离向量 →（可选）doc_id 过滤 → LIMIT
            params: List = [q_vec]
            if doc_id:
                sql += " WHERE doc_id = %s"
                params.append(doc_id)
            sql += " ORDER BY distance ASC LIMIT %s"
            params.append(top_k)

            with self._conn() as conn, conn.cursor(
                cursor_factory=psycopg2.extras.RealDictCursor
            ) as cur:
                cur.execute(sql, params)
                rows = cur.fetchall()

            hits: List[Dict] = []
            for r in rows:
                import json as _json
                bbox = r.get("source_bbox")
                if isinstance(bbox, str):
                    try:
                        bbox = _json.loads(bbox)
                    except Exception:
                        pass
                hits.append(
                    {
                        "doc_id": r.get("doc_id"),
                        "physical_page": r.get("physical_page"),
                        "text": r.get("text"),
                        "distance": float(r.get("distance", 0.0)),
                        "source_bbox": bbox,
                    }
                )

            return DataResponse(
                ok=True,
                source_type=self.source_type,
                db_id=self.source_id,
                hits=hits,
            )

        except psycopg2.Error as e:
            return DataResponse(
                ok=False,
                source_type=self.source_type,
                db_id=self.source_id,
                error=f"向量检索失败：{e}",
            )

    # ------------------------------------------------------------------
    # 写入切片
    # ------------------------------------------------------------------
    def upsert_chunks(
        self,
        doc_id: str,
        chunks: List[Dict],
        embeddings: List[List[float]],
    ) -> int:
        """写入/更新文档切片及其向量。

        每个 chunk 需包含 text，可选 physical_page、source_bbox。
        返回写入的切片数量。
        """
        assert len(chunks) == len(embeddings), "切片数量必须与向量数量一致"
        import json

        sql = (
            "INSERT INTO doc_chunks "
            "(doc_id, physical_page, text, embedding, source_bbox) "
            "VALUES (%s, %s, %s, %s, %s)"
        )
        with self._conn() as conn, conn.cursor() as cur:
            for c, e in zip(chunks, embeddings):
                cur.execute(
                    sql,
                    (
                        doc_id,
                        c.get("physical_page"),
                        c["text"],
                        e,
                        json.dumps(c.get("source_bbox")),
                    ),
                )
        return len(chunks)

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------
    def _conn(self) -> "psycopg2.extensions.connection":
        """获取数据库连接。"""
        return psycopg2.connect(self._database_url)


# ---------------------------------------------------------------------------
# 嵌入占位（开发环境用，生产请注入 SiliconFlowEmbedder）
# ---------------------------------------------------------------------------
def _placeholder_embedder(text: str) -> List[float]:
    """开发用占位嵌入：返回零向量。

    生产环境应注入 SiliconFlowEmbedder（backend.integrations），
    在注册 VectorSource 时通过 embedder=... 传入其 embed 方法。
    """
    s = get_settings().embedding_dim
    return [0.0] * s
