"""关系型数据源：单句全树校验、真实只读事务和明确的表作用域。"""
import json
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional

import psycopg2
from psycopg2 import sql as pgsql
import sqlglot
from sqlglot import exp
from sqlglot.optimizer.scope import traverse_scope

from backend.data_access.protocol import DataSource, DataResponse
from backend.config import get_settings

MAX_RESULT_ROWS = 500
STATEMENT_TIMEOUT_MS = 30_000
# 只开放内置无副作用的计算函数；未知函数和业务schema自定义函数一律拒绝。
_SAFE_FUNCTIONS = frozenset({
    "ABS", "AVG", "COUNT", "SUM", "MIN", "MAX", "ROUND", "FLOOR", "CEIL", "CEILING",
    "LOWER", "UPPER", "LENGTH", "CHAR_LENGTH", "CHARACTER_LENGTH", "TRIM", "LTRIM", "RTRIM",
    "SUBSTRING", "SUBSTR", "STR_POSITION", "STRPOS", "REPLACE", "CONCAT", "CONCAT_WS",
    "COALESCE", "NULLIF", "GREATEST", "LEAST", "CAST", "TRY_CAST", "EXTRACT", "DATE_TRUNC",
    "CURRENT_DATE", "CURRENT_TIMESTAMP", "CURRENT_TIME", "TO_CHAR", "TO_DATE", "TO_TIMESTAMP",
    "DATE_PART", "TIME_TO_STR", "STR_TO_DATE", "STR_TO_TIME", "TS_OR_DS_TO_DATE", "TS_OR_DS_TO_TIMESTAMP",
    "ROW_NUMBER", "RANK", "DENSE_RANK", "LAG", "LEAD", "FIRST_VALUE", "LAST_VALUE", "NTILE",
    "POWER", "SQRT", "MOD", "LOG", "LN", "EXP", "SIGN", "BOOL_AND", "BOOL_OR", "STRING_AGG",
    "ARRAY_AGG", "PERCENTILE_CONT", "PERCENTILE_DISC", "VARIANCE", "STDDEV", "STDDEV_POP", "STDDEV_SAMP",
    "AGE", "DATE", "DATE_DIFF", "TIMESTAMP_DIFF", "TIME_DIFF", "JSON_EXTRACT", "JSON_EXTRACT_SCALAR",
    "REGEXP_LIKE", "REGEXP_REPLACE", "SPLIT_PART", "POSITION", "ASCII", "CHR", "LEFT", "RIGHT",
})
_NATIVE_FUNCTIONS = _SAFE_FUNCTIONS - frozenset({"TRY_CAST", "STR_POSITION", "TIME_TO_STR", "STR_TO_DATE", "STR_TO_TIME",
    "TS_OR_DS_TO_DATE", "TS_OR_DS_TO_TIMESTAMP", "DATE_DIFF", "TIMESTAMP_DIFF", "TIME_DIFF",
    "JSON_EXTRACT", "JSON_EXTRACT_SCALAR"})
_FORBIDDEN_NODES = frozenset({"Insert", "Update", "Delete", "Merge", "Create", "Drop", "Alter",
    "Into", "Copy", "Command", "Execute", "Transaction", "Commit", "Rollback", "Grant", "Revoke",
    "Set", "Use", "Lock", "TableSample", "LoadData", "TruncateTable", "Cache", "Uncache"})


_POLICY_CODES = frozenset({"sql_empty", "sql_not_single_query", "sql_write_or_lock", "sql_custom_type",
    "sql_function_not_allowed", "sql_external_function", "sql_cross_database_or_table_function", "sql_table_outside_scope"})


def _identifier(value):
    """按PostgreSQL规则保留引号标识符大小写，无引号标识符折为小写。"""
    if isinstance(value, exp.Identifier):
        return value.name if value.args.get("quoted") else value.name.lower()
    return str(value or "").lower()


def parse_readonly(sql):
    """只校验语法与副作用；返回AST，不接受空句、多句或未知函数。"""
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError("sql_empty")
    statements = sqlglot.parse(sql, read="postgres")
    statements = [s for s in statements if s is not None]
    if len(statements) != 1 or not isinstance(statements[0], exp.Query):
        raise ValueError("sql_not_single_query")
    tree = statements[0]
    for node in tree.walk():
        if type(node).__name__ in _FORBIDDEN_NODES:
            raise ValueError("sql_write_or_lock")
        if isinstance(node, exp.DataType) and node.this == exp.DataType.Type.USERDEFINED:
            raise ValueError("sql_custom_type")
        # sqlglot把布尔连接、EXISTS和CASE分支也归为Func，它们并非数据库函数调用。
        if isinstance(node, (exp.And, exp.Or, exp.Exists, exp.Case)):
            continue
        if isinstance(node, exp.If) and isinstance(node.parent, exp.Case):
            continue
        if isinstance(node, exp.Func):
            name = node.name.upper() if isinstance(node, exp.Anonymous) else node.sql_name().upper()
            if name not in _SAFE_FUNCTIONS or (isinstance(node, exp.Anonymous) and name not in _NATIVE_FUNCTIONS):
                raise ValueError("sql_function_not_allowed")
            # 即使函数同名也不允许显式调用业务schema中的实现。
            parent = node.parent
            if isinstance(parent, exp.Dot):
                if not isinstance(parent.this, exp.Identifier) or _identifier(parent.this) != "pg_catalog":
                    raise ValueError("sql_external_function")
    return tree


def validate_sql(sql, allowed_tables: Optional[Mapping[str, Iterable[str]]] = None,
                 default_schema="public"):
    """CTE引用不当真实表；真实表必须属于明确允许集合，禁止跨库限定。"""
    tree = parse_readonly(sql)
    allowed = {s: set(t) for s, t in (allowed_tables or {}).items()}
    for scope in traverse_scope(tree):
        for _, source in scope.selected_sources.values():
            if not isinstance(source, exp.Table):
                continue
            if not isinstance(source.this, exp.Identifier) or source.args.get("catalog"):
                raise ValueError("sql_cross_database_or_table_function")
            schema = _identifier(source.args.get("db")) or default_schema
            table = _identifier(source.this)
            if schema not in allowed or table not in allowed[schema]:
                raise ValueError("sql_table_outside_scope")
    return tree


def prepare_sql(sql, allowed_tables=None, default_schema="public"):
    """将已验证语义节点渲染为PG方言再校验，避免别名函数名落到外部自定义实现。"""
    tree = validate_sql(sql, allowed_tables, default_schema)
    # 表显式限定业务schema，函数解析路径只保留pg_catalog，不能命中同名业务函数重载。
    for scope in traverse_scope(tree):
        for _, source in scope.selected_sources.values():
            if isinstance(source, exp.Table) and not source.args.get("db"):
                source.set("db", exp.Identifier(this=default_schema, quoted=True))
                source.set("this", exp.Identifier(this=_identifier(source.this), quoted=True))
    rendered = tree.sql(dialect="postgres", unsupported_level=sqlglot.ErrorLevel.RAISE)
    validate_sql(rendered, allowed_tables, default_schema)
    return rendered


class RelationalSource(DataSource):
    """一数据集一连接；多业务子库执行时必须传该子库的表允许集合。"""
    source_type = "relational"

    def __init__(self, source_id: str, database_url: Optional[str] = None,
                 allowed_schemas: Optional[Iterable[str]] = None,
                 allowed_tables: Optional[Mapping[str, Iterable[str]]] = None):
        self.source_id = source_id
        self._database_url = database_url or get_settings().database_url
        self.allowed_schemas = frozenset(allowed_schemas or ("public",))
        self.allowed_tables = {s: frozenset(t) for s, t in (allowed_tables or {}).items()}
        # Chinook是唯一单业务基础库，兼容原直接构造入口；其他数据集必须显式限定子库。
        if allowed_tables is None and source_id == "chinook":
            index = Path(__file__).resolve().parents[2] / "processed/task4_schema/schema_index.json"
            data = json.loads(index.read_text(encoding="utf-8"))
            self.allowed_tables = {"public": frozenset(e["table"] for e in data["datasets"]["chinook"])}

    @property
    def database_url(self):
        """供同一来源构建DDL，调用方不得将连接串写入日志或响应。"""
        return self._database_url

    def ping(self):
        conn = None
        try:
            conn = self._conn()
            conn.set_session(readonly=True, autocommit=False)
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            return True
        except Exception:
            return False
        finally:
            if conn is not None:
                conn.close()

    def close(self):
        """每次执行关闭短连接，不保留连接资源。"""

    @staticmethod
    def _validate_select_only(sql):
        """兼容原语法校验入口，真实执行仍需额外表作用域校验。"""
        try:
            parse_readonly(sql)
            return True
        except Exception:
            return False

    def execute_sql(self, sql, *, allowed_tables=None, default_schema=None):
        """执行受限只读查询；数据库异常仅返回分类和SQLSTATE，不泄露连接或字面值。"""
        tables = self.allowed_tables if allowed_tables is None else {s: set(t) for s, t in allowed_tables.items()}
        if not set(tables) <= self.allowed_schemas:
            return self._failure(sql, "SQL 作用域未授权：sql_schema_outside_scope")
        schema = default_schema or (next(iter(tables)) if len(tables) == 1 else "public")
        if schema not in self.allowed_schemas or (tables and schema not in tables):
            return self._failure(sql, "SQL 作用域未授权：sql_default_schema_outside_scope")
        try:
            query = prepare_sql(sql, tables, schema)
        except Exception as exc:
            code = str(exc) if isinstance(exc, ValueError) and str(exc) in _POLICY_CODES else "sql_parse_failed"
            return self._failure(sql, f"SQL 非只读 SELECT 或作用域未授权，已拒绝执行：{code}")
        conn = None
        try:
            conn = self._conn()
            conn.set_session(readonly=True, autocommit=False)
            with conn, conn.cursor() as cur:
                cur.execute(f"SET LOCAL statement_timeout TO {STATEMENT_TIMEOUT_MS}")
                # 表已显式限定来源；函数只在pg_catalog解析，关闭业务schema同名函数重载。
                cur.execute("SET LOCAL search_path TO pg_catalog")
                cur.execute(query)
                if not cur.description:
                    return self._failure(sql, "SQL 执行失败：missing_result_set")
                columns = [d[0] for d in cur.description]
                rows = cur.fetchmany(MAX_RESULT_ROWS + 1)
                return DataResponse(ok=True, source_type=self.source_type, db_id=self.source_id,
                    columns=columns, rows=[list(r) for r in rows[:MAX_RESULT_ROWS]],
                    row_count=min(len(rows), MAX_RESULT_ROWS), truncated=len(rows) > MAX_RESULT_ROWS,
                    executed_sql=query)
        except psycopg2.Error as exc:
            state = getattr(exc, "pgcode", None)
            kind = "timeout" if state == "57014" else "permission_denied" if state == "42501" else "connection_or_query_error"
            return self._failure(sql, f"SQL 执行失败：{kind}" + (f" SQLSTATE={state}" if state else ""))
        finally:
            if conn is not None:
                conn.close()

    def _failure(self, sql, error):
        return DataResponse(ok=False, source_type=self.source_type, db_id=self.source_id,
                            error=error, executed_sql=sql)

    def _conn(self):
        return psycopg2.connect(self._database_url, connect_timeout=10)


def build_relational_sources(database: Dict[str, str]) -> List[RelationalSource]:
    """兼容已有批量构造入口，非Chinook来源仍需调用方明确子库表作用域。"""
    return [RelationalSource(source_id=k, database_url=v) for k, v in database.items()]
