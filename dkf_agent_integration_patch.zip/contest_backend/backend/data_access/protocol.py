"""
数据接入协议层：核心抽象。

定义统一的 Query / Response / DataSource 接口，
让上层（任务3/4/6）通过同一种协议访问关系型和向量数据源，
不需要关心底层是 PG 库还是 pgvector。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# 查询请求
# ---------------------------------------------------------------------------
@dataclass
class DataQuery:
    """统一查询请求。

    两种模式（互斥）：
    - 结构化模式：sql 非空，对关系型库执行只读 SELECT
    - 向量模式  ：query_text 非空，对向量库做语义检索

    target 指定数据源 db_id；为 None 时由 Manager 自动路由。
    """

    # 模式一：结构化 SQL（只读）
    sql: Optional[str] = None

    # 模式二：向量语义检索
    query_text: Optional[str] = None
    top_k: int = 5
    # 限定某个 doc_id（OHR 文档标识），为 None 则全库检索
    doc_id: Optional[str] = None

    # 数据源路由（为空则由 Manager 按问题语义自动路由）
    target: Optional[str] = None

    # 可选：附带追踪信息（写入 trace 日志）
    trace_id: Optional[str] = None

    def is_structured(self) -> bool:
        """是否结构化 SQL 查询。"""
        return self.sql is not None

    def is_vector(self) -> bool:
        """是否向量检索查询。"""
        return self.query_text is not None


# ---------------------------------------------------------------------------
# 查询结果
# ---------------------------------------------------------------------------
@dataclass
class DataResponse:
    """统一查询结果。

    ok: 是否执行成功
    source_type: "relational" | "vector"
    db_id: 实际命中的数据源标识
    rows / columns: 结构化结果（sql 模式）
    hits: 向量检索结果（vector 模式），每条含 text / distance / source_bbox
    error: 失败原因
    """

    ok: bool
    source_type: str
    db_id: Optional[str] = None

    # 结构化结果
    columns: List[str] = field(default_factory=list)
    rows: List[List[Any]] = field(default_factory=list)
    row_count: int = 0
    truncated: bool = False

    # 向量结果
    hits: List[Dict[str, Any]] = field(default_factory=list)

    # 错误信息
    error: Optional[str] = None

    # 溯源：本次查询实际使用的 SQL 或检索策略
    executed_sql: Optional[str] = None

    def to_citation(self) -> Dict[str, Any]:
        """生成可解释的引用记录，供前端展示与追溯。"""
        if self.source_type == "relational":
            return {
                "type": "sql",
                "db_id": self.db_id,
                "sql": self.executed_sql,
                "row_count": self.row_count,
            }
        return {
            "type": "vector",
            "db_id": self.db_id,
            "top_k": len(self.hits),
            "doc_ids": [h.get("doc_id") for h in self.hits if h.get("doc_id")],
        }


# ---------------------------------------------------------------------------
# 数据源抽象基类
# ---------------------------------------------------------------------------
class DataSource(ABC):
    """数据源抽象接口。

    实现方只需提供 connect 生命周期 + 对应模式的 execute 方法。
    关系型实现只需实现 execute_sql；向量实现只需实现 search。
    """

    #: 数据源标识（注册表中的 db_id）
    source_id: str
    #: 数据源类型："relational" | "vector"
    source_type: str

    @abstractmethod
    def ping(self) -> bool:
        """健康检查：确认数据源可达。"""
        ...

    @abstractmethod
    def close(self) -> None:
        """释放资源（连接池等）。"""
        ...

    # -- 结构化查询（仅关系型实现）--
    def execute_sql(self, sql: str) -> DataResponse:
        """执行只读 SQL，返回结构化结果。默认不支持。"""
        raise NotImplementedError(
            f"数据源 {self.source_id} 不支持 SQL 查询（source_type={self.source_type}）"
        )

    # -- 向量检索（仅向量型实现）--
    def search(
        self,
        query_text: str,
        top_k: int = 5,
        doc_id: Optional[str] = None,
    ) -> DataResponse:
        """语义检索 top_k 个切片。默认不支持。"""
        raise NotImplementedError(
            f"数据源 {self.source_id} 不支持向量检索（source_type={self.source_type}）"
        )
