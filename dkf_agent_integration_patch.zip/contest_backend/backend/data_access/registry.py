"""
数据源注册表：从 JSON 配置文件加载各数据源的连接信息，
生成 RelationalSource / VectorSource 实例，供 DataAccessManager 使用。

注册表文件约定（`agent/processed/knowledge_base/databases.json`）：
{
  "version": "1.0",
  "databases": [
    {
      "db_id": "chinook",
      "db_name": "chinook",
      "engine": "postgresql",
      "source_dataset": "chinook",
      "database_url": "postgresql://DB_USER:DB_PASSWORD@DB_HOST:5432/chinook",
      "note": "官方推荐基础库，11张表"
    },
    ...
  ]
}
"""
import json
import os
from typing import Callable, Dict, List, Optional

from backend.data_access.relational import RelationalSource
from backend.data_access.vector import VectorSource, Embedder
from backend.integrations import SiliconFlowEmbedder


class SourceRegistry:
    """数据源注册表。

    职责：
    - 从 JSON 文件加载数据源配置
    - 批量创建 RelationalSource 实例
    - 按 engine 字段自动创建 VectorSource（嵌入模型经 embedder_factory 注入）
    - 手动注册额外数据源
    - 按 source_id 查询实例
    """

    def __init__(self) -> None:
        self._relational: Dict[str, RelationalSource] = {}
        self._vector: Dict[str, VectorSource] = {}
        #: 全局共享的嵌入客户端（惰性创建，close_all 时释放）
        self._embedder: Optional[SiliconFlowEmbedder] = None

    # ------------------------------------------------------------------
    # 加载数据源
    # ------------------------------------------------------------------
    @classmethod
    def load_from_json(
        cls,
        registry_path: str,
        default_url: Optional[str] = None,
        use_siliconflow_embedding: bool = True,
    ) -> "SourceRegistry":
        """从 JSON 注册表文件加载，返回已填充数据源的实例。

        registry_path: databases.json 的绝对/相对路径
        default_url:  当配置项缺少 database_url 字段时的兜底值
        use_siliconflow_embedding: 是否注册表中的 pgvector 向量源
        """
        reg = cls()
        with open(registry_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for entry in data.get("databases", []):
            db_id = entry.get("db_id")
            if not db_id:
                continue
            url = entry.get("database_url") or default_url
            engine = entry.get("engine", "postgresql")

            if engine == "pgvector":
                # 向量源：注册表里登记的是"哪张表在哪个库"，
                # 嵌入函数按配置注入硅基流动
                if not use_siliconflow_embedding:
                    continue
                embedder = reg._ensure_embedder()
                reg.register_vector(
                    VectorSource(
                        source_id=db_id,
                        embedder=embedder.embed,
                        database_url=url,
                    )
                )
                continue

            # 关系型：没有 DSN 的条目（未导入的库）跳过，仅保留元数据
            if url is None:
                continue
            reg.register_relational(
                RelationalSource(source_id=db_id, database_url=url,
                                 allowed_schemas=entry.get("schemas") or ["public"])
            )
        return reg

    def _ensure_embedder(self) -> SiliconFlowEmbedder:
        """惰性创建共享嵌入客户端（密钥取自 .env 的 SILICONFLOW_API_KEY）。"""
        if self._embedder is None:
            self._embedder = SiliconFlowEmbedder()
        return self._embedder

    # ------------------------------------------------------------------
    # 注册单个数据源
    # ------------------------------------------------------------------
    def register_relational(self, source: RelationalSource) -> None:
        """注册关系型数据源。"""
        self._relational[source.source_id] = source

    def register_vector(
        self,
        source: VectorSource,
    ) -> None:
        """注册向量数据源（embedder 由 load_from_json 或外部注入）。"""
        self._vector[source.source_id] = source

    # ------------------------------------------------------------------
    # 资源释放
    # ------------------------------------------------------------------
    def close_all(self) -> None:
        """释放注册表持有的共享资源（嵌入客户端 HTTP 连接）。"""
        if self._embedder is not None:
            self._embedder.close()
            self._embedder = None

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------
    def get_relational(self, source_id: str) -> Optional[RelationalSource]:
        """按 source_id 取关系型数据源。"""
        return self._relational.get(source_id)

    def get_vector(self, source_id: str) -> Optional[VectorSource]:
        """按 source_id 取向量数据源。"""
        return self._vector.get(source_id)

    def all_relational(self) -> Dict[str, RelationalSource]:
        """返回全部关系型数据源。"""
        return dict(self._relational)

    def all_vector(self) -> Dict[str, VectorSource]:
        """返回全部向量数据源。"""
        return dict(self._vector)

    @property
    def source_ids(self) -> List[str]:
        """所有已注册的数据源标识（关系型 + 向量）。"""
        return list(self._relational.keys()) + list(self._vector.keys())
