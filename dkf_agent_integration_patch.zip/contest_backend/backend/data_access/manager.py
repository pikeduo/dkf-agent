"""
DataAccessManager：异构数据源统一门面。

上层（任务3/4/6 智能体）只面对这一层，
不直接感知"哪个是 PG 库、哪个是向量库"的差异。

路由规则：
    1. query.target 指定了 source_id → 直接路由到该数据源
    2. 未指定 target：
       - query.is_structured()  → 默认路由到 primary 关系型库
       - query.is_vector()      → 默认路由到 primary 向量库
    3. 两者都未提供 → 返回错误
"""
from typing import Optional

from backend.data_access.protocol import DataQuery, DataResponse, DataSource
from backend.data_access.registry import SourceRegistry
from backend.data_access.relational import RelationalSource
from backend.data_access.vector import VectorSource


class DataAccessManager:
    """统一数据访问门面。

    用法：
        manager = DataAccessManager(registry)
        resp = manager.query(DataQuery(sql="SELECT ...", target="chinook"))
        resp = manager.query(DataQuery(query_text="合同违约金", target="ohr_bench"))
    """

    def __init__(
        self,
        registry: SourceRegistry,
        primary_relational: Optional[str] = "chinook",
        primary_vector: Optional[str] = "ohr_bench",
    ) -> None:
        """
        registry: 已填充数据源的注册表
        primary_relational: 结构化查询的默认库（对应赛题 Chinook 地基）
        primary_vector: 向量检索的默认库（对应 OHR-Bench 文档知识库）
        """
        self._registry = registry
        self._primary_relational = primary_relational
        self._primary_vector = primary_vector

    # ------------------------------------------------------------------
    # 统一查询入口
    # ------------------------------------------------------------------
    def query(self, dq: DataQuery) -> DataResponse:
        """按查询模式路由到对应数据源并执行。"""
        if dq.is_structured():
            source_id = dq.target or self._primary_relational
            src = self._registry.get_relational(source_id)
            if src is None:
                return DataResponse(
                    ok=False,
                    source_type="relational",
                    db_id=source_id,
                    error=f"关系型数据源 '{source_id}' 未注册",
                )
            resp = src.execute_sql(dq.sql)
            # 补充执行记录，便于追踪
            resp.executed_sql = dq.sql
            return resp

        if dq.is_vector():
            source_id = dq.target or self._primary_vector
            src = self._registry.get_vector(source_id)
            if src is None:
                return DataResponse(
                    ok=False,
                    source_type="vector",
                    db_id=source_id,
                    error=f"向量数据源 '{source_id}' 未注册",
                )
            return src.search(
                query_text=dq.query_text,
                top_k=dq.top_k,
                doc_id=dq.doc_id,
            )

        return DataResponse(
            ok=False,
            source_type="unknown",
            error="查询请求必须提供 sql（结构化）或 query_text（向量）之一",
        )

    # ------------------------------------------------------------------
    # 健康检查
    # ------------------------------------------------------------------
    def ping_all(self) -> dict:
        """检查所有已注册数据源的健康状态。

        返回：{source_id: ok}
        """
        result: dict = {}
        for db_id, src in self._registry.all_relational().items():
            result[db_id] = src.ping()
        for db_id, src in self._registry.all_vector().items():
            result[db_id] = src.ping()
        return result

    # ------------------------------------------------------------------
    # 资源管理
    # ------------------------------------------------------------------
    def close_all(self) -> None:
        """释放所有数据源资源。"""
        for src in self._registry.all_relational().values():
            src.close()
        for src in self._registry.all_vector().values():
            src.close()
