"""
多模态问数/问答智能体 - FastAPI 服务入口
负责装配路由、初始化核心组件，暴露 REST API 供前端调用。
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# 导入路由模块
from backend.api import query, clarification, trace, sessions, text2sql, catalog

# 创建应用实例
app = FastAPI(
    title="多模态可解释问数/问答智能体",
    version="0.1.0",
    description="赛题八：同时支持结构化问数与非结构化知识问答，并输出全链路可解释过程。",
)

# 允许前端跨域访问
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载各路由
app.include_router(sessions.router, prefix="/api/sessions", tags=["会话"])
app.include_router(query.router, prefix="/api/query", tags=["查询"])
app.include_router(text2sql.router, prefix="/api/query", tags=["Text2SQL"])
app.include_router(clarification.router, prefix="/api/clarification", tags=["澄清"])
app.include_router(trace.router, prefix="/api/trace", tags=["可解释性"])
app.include_router(catalog.router, prefix="/api/catalog", tags=["安全数据源目录"])


@app.get("/", tags=["根"])
def root():
    """服务健康检查"""
    return {"status": "ok", "service": "ict-agent"}


@app.get("/api/health", tags=["健康检查"])
def api_health():
    """For the single-origin Vite proxy. Does not claim DB/LLM readiness."""
    return {"status": "ok", "service": "contest-backend"}
