"""
大模型协议层：Anthropic Messages 协议实现。

对接 Claude 系列模型及所有兼容 Anthropic Messages API 的端点。
协议差异（相对 OpenAI）：
- 认证头为 x-api-key + anthropic-version（而非 Bearer）
- system 提示不放在 messages 里，而是顶层 system 字段
- 请求需显式 max_tokens；响应 content 是 block 列表
- usage 字段名为 input_tokens / output_tokens
"""
import httpx
from typing import List, Optional

from backend.models.protocol import LLMMessage, LLMResponse, LLMProtocol


class AnthropicProtocol(LLMProtocol):
    """Anthropic Messages 协议客户端。

    - base_url 形如 "https://api.anthropic.com/v1"，拼接 /messages。
    - 也适用于走 Anthropic 协议代理/中转的第三方端点。
    """

    protocol: str = "anthropic"

    #: Anthropic 当前协议版本（各代理端点普遍接受 "2023-06-01"）
    ANTHROPIC_VERSION = "2023-06-01"

    def __init__(
        self,
        base_url: str,
        api_key: str,
        default_model: str = "claude-sonnet-4-20250514",
        timeout: int = 120,
    ) -> None:
        if not api_key:
            raise ValueError("Anthropic 协议缺少 api_key")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.default_model = default_model
        self._client = httpx.Client(timeout=timeout)

    def _split_system(self, messages: List[LLMMessage]):
        """把 messages 中的 system 消息抽出到顶层 system 字段，其余原样保留。"""
        system_parts: List[str] = []
        rest: List[LLMMessage] = []
        for msg in messages:
            if msg.get("role") == "system":
                system_parts.append(msg.get("content", ""))
            else:
                rest.append(msg)
        system = "\n".join(p for p in system_parts if p) or None
        return system, rest

    def chat(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> LLMResponse:
        """调用 Anthropic /messages 接口，归一化 content block 为纯文本。"""
        system, rest = self._split_system(messages)

        payload: dict = {
            "model": model or self.default_model,
            "messages": rest,
            "temperature": temperature,
            # Anthropic 要求 max_tokens 必填，未指定时给保守默认值
            "max_tokens": max_tokens or 4096,
        }
        if system is not None:
            payload["system"] = system

        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": self.ANTHROPIC_VERSION,
        }
        url = f"{self.base_url}/messages"

        resp = self._client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

        # content 为 block 列表，拼接所有 text block（未来可扩展 thinking block）
        content = "".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        )
        usage = data.get("usage") or {}
        return LLMResponse(
            content=content,
            model=data.get("model", payload["model"]),
            finish_reason=data.get("stop_reason"),
            usage={
                "input_tokens": usage.get("input_tokens", 0),
                "output_tokens": usage.get("output_tokens", 0),
            },
            raw=data,
        )

    def close(self) -> None:
        """关闭底层 HTTP 客户端。"""
        self._client.close()
