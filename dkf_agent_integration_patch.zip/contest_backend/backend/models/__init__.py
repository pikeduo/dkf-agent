"""
大模型协议包。

导出两种协议实现与统一的请求/响应抽象，
上层通过同一接口调用不同协议族的供应商模型。
"""
from backend.models.protocol import LLMProtocol, LLMResponse, LLMMessage
from backend.models.openai import OpenAIProtocol
from backend.models.anthropic import AnthropicProtocol

__all__ = [
    "LLMProtocol",
    "LLMResponse",
    "LLMMessage",
    "OpenAIProtocol",
    "AnthropicProtocol",
]
