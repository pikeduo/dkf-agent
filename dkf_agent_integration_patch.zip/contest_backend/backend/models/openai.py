"""
大模型协议层：OpenAI 兼容协议实现。

覆盖：OpenAI 官方，以及所有兼容 OpenAI 的国产模型
（智谱 GLM / 阿里 Qwen-DashScope / 百度等）。
统一走 POST {base_url}/chat/completions。
"""
import httpx
from typing import List, Optional

from backend.models.protocol import LLMMessage, LLMResponse, LLMProtocol


class OpenAIProtocol(LLMProtocol):
    """OpenAI 兼容协议客户端。

    - base_url 形如 "https://open.bigmodel.cn/api/paas/v4"（智谱）
      或 "https://api.openai.com/v1"（OpenAI），拼接 /chat/completions。
    - 不同供应商仅需改 base_url + api_key + model。
    """

    protocol: str = "openai"

    def __init__(
        self,
        base_url: str,
        api_key: str,
        default_model: str = "glm-4",
        timeout: int = 120,
    ) -> None:
        if not api_key:
            raise ValueError("OpenAI 兼容协议缺少 api_key")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.default_model = default_model
        self._client = httpx.Client(timeout=timeout)

    def chat(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> LLMResponse:
        """调用 OpenAI 兼容 chat/completions 接口。"""
        payload: dict = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        headers = {"Authorization": f"Bearer {self.api_key}"}
        url = f"{self.base_url}/chat/completions"

        resp = self._client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

        choice = data.get("choices", [{}])[0]
        content = (choice.get("message") or {}).get("content") or ""
        usage = data.get("usage") or {}
        return LLMResponse(
            content=content,
            model=data.get("model", payload["model"]),
            finish_reason=choice.get("finish_reason"),
            usage={
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
            },
            raw=data,
        )

    def close(self) -> None:
        """关闭底层 HTTP 客户端。"""
        self._client.close()
