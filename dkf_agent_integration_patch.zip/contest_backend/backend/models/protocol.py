"""
大模型协议层：核心抽象。

定义统一的 LLM 调用协议（请求/响应/客户端接口），
让上层（任务3/4/6 智能体）通过同一种协议调用不同协议族（OpenAI 兼容 / Anthropic）的模型，
不需要关心底层是哪家供应商、哪个协议。

模块结构：
    protocol.py   — 核心抽象（LLMMessage / LLMResponse / LLMProtocol）
    openai.py     — OpenAI 兼容协议（OpenAI / 智谱 / Qwen-DashScope 等）
    anthropic.py  — Anthropic Messages 协议
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# 统一消息格式（与 OpenAI 消息格式对齐，各协议适配器内部自行转换）
# ---------------------------------------------------------------------------
# 一条消息：{"role": "system" | "user" | "assistant", "content": str}
# 用 Dict 而非独立 dataclass，便于与现有 LLMClient 的调用习惯（List[Dict]）兼容。
LLMMessage = Dict[str, str]


# ---------------------------------------------------------------------------
# 统一响应
# ---------------------------------------------------------------------------
@dataclass
class LLMResponse:
    """一次 LLM 调用的统一结果。

    content: 模型文本输出（已拼接多段，去除了协议差异）
    model: 实际使用的模型名（回显供应商侧模型标识）
    finish_reason: 结束原因（各协议差异已归一化，见各适配器）
    usage: token 用量，统一为 {"input_tokens": int, "output_tokens": int}
    raw: 供应商原始响应（调试/溯源用，生产展示层可不使用）
    """

    content: str
    model: str = ""
    finish_reason: Optional[str] = None
    usage: Dict[str, int] = field(default_factory=dict)
    raw: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# 协议抽象基类
# ---------------------------------------------------------------------------
class LLMProtocol(ABC):
    """大模型协议抽象接口。

    每个实现对应一种 API 协议族（OpenAI 兼容 / Anthropic），
    通过 base_url + api_key + 模型名指向具体供应商。
    密钥仅运行期内存持有，不落盘。
    """

    #: 协议标识："openai" | "anthropic"
    protocol: str

    @abstractmethod
    def chat(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> LLMResponse:
        """发送对话请求，返回统一响应。

        model 为空时使用客户端默认模型。
        """
        ...

    def chat_json(self, messages: List[LLMMessage], temperature: float = 0.0) -> Dict[str, Any]:
        """要求模型返回 JSON，并做稳健解析（提取首个 JSON 对象）。

        各实现共享此逻辑，保证解析行为一致。
        """
        import json
        import re

        resp = self.chat(messages, temperature=temperature)
        match = re.search(r"\{.*\}", resp.content, re.DOTALL)
        if not match:
            raise ValueError(f"模型输出中未找到 JSON：{resp.content[:200]}")
        return json.loads(match.group(0))

    @abstractmethod
    def close(self) -> None:
        """释放资源（HTTP 客户端等）。"""
        ...
