"""
配置管理：集中读取环境变量与默认值，供各模块使用。
敏感信息（API 密钥等）从 .env 加载，不写入代码库。
"""
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """全局配置。字段名与 .env.example 保持一致。"""

    model_config = SettingsConfigDict(
        # 固定从项目配置读取，避免从不同工作目录启动时静默丢失供应商配置。
        env_file=Path(__file__).resolve().parents[1] / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # 数据库
    # 脱敏配置模板：原默认连接示例（含示例账号/密码）已替换为占位变量，须由 .env 提供实际值
    database_url: str = "postgresql://DB_USER:DB_PASSWORD@DB_HOST:5432/DB_NAME"

    # 异构数据源注册表路径（相对项目根 agent/）
    data_registry_path: str = str(Path(__file__).resolve().parents[1] / "processed" / "knowledge_base" / "databases.json")

    # 默认主库标识（结构化查询的 fallback）
    primary_relational_db: str = "chinook"
    # 默认向量库标识（向量检索的 fallback）
    primary_vector_db: str = "ohr_bench"

    # 聊天模型供应商：auto 按 智谱→硅基流动→通义 的密钥可用性选择；
    # 显式指定时只用该供应商，缺密钥直接报错，不静默回退到其他供应商。
    llm_provider: Literal["auto", "zhipu", "siliconflow", "qwen", "anna", "wb"] = "auto"

    # 国产大模型
    zhipu_api_key: str = ""
    zhipu_base_url: str = "https://open.bigmodel.cn/api/paas/v4"
    qwen_api_key: str = ""
    qwen_base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    default_model: str = "glm-4"

    # 硅基流动（聊天为 OpenAI 兼容协议；嵌入走 /v1/embeddings）
    siliconflow_api_key: str = ""
    siliconflow_base_url: str = "https://api.siliconflow.cn/v1"
    siliconflow_chat_model: str = "Qwen/Qwen2.5-72B-Instruct"

    # Anna（OpenAI 兼容协议，根地址以 /v1 结尾；仅用于聊天，不提供嵌入）
    anna_api_key: str = ""
    anna_base_url: str = "https://ai.anna.tf/v1"
    anna_chat_model: str = "DeepSeek-V4.1-Flash"
    # 思考程度，按 sub2api 的 OpenAI 协议传 reasoning_effort（minimal/low/medium/high/xhigh/max）
    anna_reasoning_effort: str = "xhigh"

    # wb（OpenAI 兼容协议，直连网关；聊天模型名含命名空间前缀 global:）
    wb_api_key: str = ""
    wb_base_url: str = "http://LLM_GATEWAY_HOST:PORT"  # 脱敏：原网关内网地址已隐去，须由 .env 提供
    wb_chat_model: str = "global:deepseek-v4.1-flash"

    # LLM 请求容错：挂起型故障时避免长时间等待。
    # 单次请求读超时（秒）与最多额外重试次数；连接/写入用较短固定超时。
    llm_request_timeout: float = Field(default=60.0, gt=0, le=600)
    llm_max_retries: int = Field(default=2, ge=0, le=2)

    # 嵌入（硅基流动 BGE 系列，OpenAI 兼容嵌入协议）
    embedding_model: str = "BAAI/bge-m3"
    embedding_dim: int = 1024

    # OCR（可选）
    ocr_api_key: str = ""

    # 历史筛选默认使用保守窗口，显式启用后才向imajev发送历史。
    imajev_history_enabled: bool = False
    imajev_history_endpoint: str = "http://IMAJEV_HOST:PORT/v1/systemone"  # 脱敏：本地服务地址占位
    imajev_history_api_key: SecretStr = SecretStr("")
    imajev_history_timeout_seconds: float = Field(default=5.0, gt=0, le=60)
    history_recent_turns: int = Field(default=16, ge=1, le=32)
    history_short_turns: int = Field(default=4, ge=0, le=32)
    history_max_context_bytes: int = Field(default=16000, ge=256, le=128000)
    history_keep_threshold: float = Field(default=0.65, ge=0, le=1)
    history_reject_threshold: float = Field(default=0.35, ge=0, le=1)
    history_unknown_threshold: float = Field(default=0.25, ge=0, le=1)
    history_session_ttl_seconds: int = Field(default=3600, ge=60, le=86400)
    history_max_sessions: int = Field(default=256, ge=1, le=4096)

    @model_validator(mode="after")
    def check_history_config(self):
        if self.history_short_turns > self.history_recent_turns:
            raise ValueError("短历史阈值不能大于最近历史窗口")
        if self.history_reject_threshold >= self.history_keep_threshold:
            raise ValueError("排除阈值必须低于保留阈值")
        return self

    # 评测隔离目录
    gold_dir: str = "data/processed/gold"


@lru_cache
def get_settings() -> Settings:
    """返回单例配置对象。"""
    return Settings()
