"""从问题文本直接抽取实体（无 LLM），供评测与无解释输入的轻量路径使用。
抽取三类：
1. 引号内的值（如 "1994 FIFA World cup qualification"）；
2. 英文词（去停用词、保留专有名词与数字后缀）；
3. 中文连续实词（≥2 字）。
实体质量决定召回；不做分词器依赖。
"""
import re

# 常见英文停用词（查询意图类）
_STOPWORDS = {
    "the", "a", "an", "what", "which", "how", "many", "much", "most", "least",
    "all", "any", "some", "is", "are", "was", "were", "be", "been", "of", "in",
    "on", "at", "to", "for", "and", "or", "but", "do", "does", "did", "can",
    "could", "should", "will", "would", "about", "between", "from", "by", "with",
    "there", "their", "it", "its", "if", "than", "then", "when", "where", "who",
    "whom", "while", "this", "that", "these", "those", "not", "no", "yes",
    "you", "your", "we", "our", "i", "me", "my", "as", "per", "via", "since",
    "each", "every", "other", "such", "only", "own", "same", "s", "d", "t",
}


def extract_question_entities(question: str, max_entities: int = 40) -> list:
    """问题 → 实体列表（引号值优先，再去停用词）。"""
    entities = []
    # 1. 引号值（双语引号）
    entities.extend(m for m in re.findall(r"[\"“‘]([^\"“”‘]{2,60})[\"”’']", question))
    # 2. 英文词（保留 ≥3 字符、非停用词、非纯数字）
    for w in re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", question):
        low = w.lower()
        if low not in _STOPWORDS:
            entities.append(w)
    # 3. 中文连续实词：原词 + 逐字滑动 2 字子词（覆盖「艺人的专辑总数」这类粘连串）
    for run in re.findall(r"[\u4e00-\u9fff]{2,}", question):
        entities.append(run)
        entities.extend(run[i:i + 2] for i in range(len(run) - 1))
    # 去重保序
    seen = set()
    out = []
    for e in entities:
        key = e.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append(e.strip())
    return out[:max_entities]
