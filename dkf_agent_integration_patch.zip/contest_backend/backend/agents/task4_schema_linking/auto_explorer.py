"""
任务4：缺项定向探索（AutoLink 式小预算补漏）。
仅当问题实体在候选表列中零命中、且 alias_map 也无解释时触发；
用真实目录内的列名/值证据重新定向检索，输出标记为「候选推断」。
预算耗尽或仍无命中时返回空，由上层输出「候选不足」状态交任务3。
"""
from typing import List, Dict


class AutoExplorer:
    """候选缺项的小预算定向补漏。"""

    def __init__(self, schema_index, budget: int = 5) -> None:
        self.schema = schema_index
        self.budget = budget
        self.calls = 0

    def explore_missing(self, question_entities: List[str],
                        matched_entities: List[str]) -> List[Dict]:
        """对零命中实体做定向补漏。

        补漏手段（按成本递增，全部基于真实目录，不生成新词表）：
        1. 放宽词形（去掉数字、常见前后缀）再扫列名；
        2. 别名表反查（alias_map 里该实体的目标列）；
        命中的表都追加来源标注「定向补漏」，并标记为候选推断。
        """
        missing = [e for e in question_entities if e.lower() not in {m.lower() for m in matched_entities}]
        if not missing or self.calls >= self.budget:
            return []
        additions: List[Dict] = []
        known = {e.lower() for e in matched_entities}
        for entity in missing:
            if self.calls >= self.budget:
                break
            self.calls += 1
            hits = self._relaxed_column_scan(entity)
            alias_hits = self.schema.find_ambiguous_matches(entity)
            for h in hits + alias_hits:
                label = h.get("label") or h.get("target", "")
                if label and label not in {x["table"] for x in additions}:
                    item = {"table": label, "matched": entity}
                    item["sources"] = ["定向补漏"]
                    item["inferred"] = True  # 候选推断，不是已确认结构
                    additions.append(item)
        return additions

    def _relaxed_column_scan(self, entity: str) -> List[Dict]:
        """放宽词形扫描列名：去数字、去常见英语前缀/后缀。"""
        import re
        core = re.sub(r"[\d]+", "", entity.lower())
        core = re.sub(r"^(?:the|a|an)\s+|_?(?:id|no|num|code)$", "", core)
        if len(core) < 3:
            return []
        found: List[Dict] = []
        for tbl in self.schema.tables:
            for col in tbl.get("columns", []):
                if core in normalize_safe(col):
                    found.append({"label": f"{tbl['table']}.{col}"})
        return found[:6]


def normalize_safe(text: str) -> str:
    import re
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))
