"""指标目录仅保留真实Chinook人工口径；先校验库身份和精确列，再输出提示。"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class MetricDef:
    metric_id: str
    aliases: tuple
    amount_column: str
    aggregation: str
    time_column: Optional[str]
    grain: str
    caveats: tuple = field(default_factory=tuple)
    dataset: str = "chinook"
    sub_db: Optional[str] = None
    expression: Optional[str] = None
    required_columns: tuple = field(default_factory=tuple)

    def __post_init__(self):
        for name in ("aliases", "caveats", "required_columns"):
            if isinstance(getattr(self, name), str):
                object.__setattr__(self, name, (getattr(self, name),))

    @property
    def references(self):
        return tuple(r for r in (self.amount_column, self.time_column, *self.required_columns) if r)

    def as_hint(self):
        return {"metric_id": self.metric_id, "alias": self.aliases[0], "column": self.amount_column,
            "aggregation": self.aggregation, "time_column": self.time_column, "grain": self.grain,
            "caveats": list(self.caveats), "expression": self.expression,
            "required_columns": list(self.required_columns), "dataset": self.dataset}


# 条目为人工业务口径，不是目录自身证明；所有字段按真实Chinook命名。
_DEFAULT_METRICS = [
    MetricDef("total_sales", ("销售额", "销售总额", "销售金额", "收入", "revenue", "sales"),
        "invoice.total", "sum", "invoice.invoice_date", "一行一张发票",
        ("按发票实付总额统计，用户确认的口径优先",)),
    MetricDef("sales_by_track", ("曲目销售额",), "invoice_line.unit_price", "sum", None,
        "一行一个发票曲目明细", ("按数量乘成交单价求和，不直接汇总单价",),
        expression="invoice_line.unit_price * invoice_line.quantity", required_columns=("invoice_line.quantity",)),
    MetricDef("customer_count", ("顾客数", "客户数", "customer_count"), "customer.customer_id",
        "count_distinct", None, "一行一个客户"),
    MetricDef("track_count", ("曲目数", "歌曲数", "track_count"), "track.track_id", "count", None,
        "一行一条曲目", ("目录没有播放量字段，不把曲目数当播放量",)),
]


class MetricCatalog:
    def __init__(self, metrics=None):
        self.metrics = list(_DEFAULT_METRICS) if metrics is None else list(metrics)

    def _in_scope(self, metric, catalog):
        if catalog is None:
            return True
        return (metric.dataset == getattr(catalog, "current_dataset", metric.dataset)
                and (metric.sub_db is None or metric.sub_db == getattr(catalog, "current_db", None)))

    def _valid(self, metric, catalog):
        if not self._in_scope(metric, catalog):
            return False
        for ref in metric.references:
            table, column = ref.split(".", 1)
            entry = catalog.get_table(table)
            if entry is None or column not in entry.get("columns", []):
                return False
        return True

    def candidates(self, entity, limit=3, catalog=None):
        """只在合法本库指标中判断口径多义；不使用双向短子串制造歧义。"""
        low = entity.lower().strip()
        if not low:
            return []
        out = []
        for metric in self.metrics:
            if catalog is not None and not self._valid(metric, catalog):
                continue
            if any(a.lower() == low or (len(a) >= 2 and a.lower() in low) for a in metric.aliases):
                out.append(metric)
        # 销售额确实存在发票和曲目明细口径，明确保留供真实用户确认。
        if low == "销售额":
            for metric in self.metrics:
                if metric.metric_id == "sales_by_track" and metric not in out and (catalog is None or self._valid(metric, catalog)):
                    out.append(metric)
        elif len(out) > 1:
            # 明确提到曲目等更具体口径时，长别名优先，避免已明确问题再次被泛别名阻断。
            lengths = {m.metric_id: max(len(a) for a in m.aliases if a.lower() in low) for m in out}
            longest = max(lengths.values())
            out = [m for m in out if lengths[m.metric_id] == longest]
        return out[:limit]

    def resolve(self, entity, catalog=None):
        found = self.candidates(entity, catalog=catalog)
        return found[0] if found else None

    def verify_against_catalog(self, catalog):
        """忽略不属于该库的指标；只记录本库失效引用，禁止带病注入提示。"""
        problems = {}
        for metric in self.metrics:
            if not self._in_scope(metric, catalog):
                continue
            for ref in metric.references:
                table, column = ref.split(".", 1)
                entry = catalog.get_table(table)
                if entry is None or column not in entry.get("columns", []):
                    problems.setdefault(f"指标 {metric.metric_id} 引用不在当前目录", []).append(ref)
        return problems
