"""真实目录索引：保留旧JSON，通过已有mapping恢复子库身份和原始主键信息。"""
import json
import re
from pathlib import Path
from typing import Optional


class SchemaIndex:
    """任务3/4共享只读目录接口；多业务数据集必须显式指定sub_db。"""
    def __init__(self, index_dir: Optional[str] = None):
        self.index_dir = str(index_dir or Path(__file__).resolve().parents[3] / "processed/task4_schema/schema_index.json")
        self.tables, self._data, self._by_name = [], {}, {}
        self.current_db = self.current_dataset = None
        self.aliases = None
        self._load_key = None
        self._metadata = {}
        self._alias_map = {}

    def _mapping_metadata(self, database):
        """只读源目录mapping，不读取任何问答、gold或官方evidence。"""
        if database in self._metadata:
            return self._metadata[database]
        root = Path(__file__).resolve().parents[4]
        result = {}
        mapping = root / "data/postgresql" / database / "database_mapping.json"
        if mapping.exists():
            for db in json.loads(mapping.read_text(encoding="utf-8")):
                source = str(db.get("source_key") or db.get("source") or "").replace("\\", "/")
                dbid = db.get("db_id") or Path(source).stem
                for table in db.get("tables", []):
                    keys = []
                    for col in table.get("columns", []):
                        if isinstance(col, dict):
                            position, name = col.get("source_primary_key_order", 0), col.get("name")
                        else:
                            position, name = col[5] if len(col) > 5 else 0, col[1]
                        if position and name:
                            keys.append((position, name))
                    result[(db.get("schema"), table["name"])] = {"db_id": dbid,
                        "primary_key": [name for _, name in sorted(keys)]}
        elif database == "chinook":
            ddl = root / "data/raw/chinook/ChinookDatabase/DataSources/Chinook_PostgreSql.sql"
            if ddl.exists():
                text = ddl.read_text(encoding="utf-8")
                for match in re.finditer(r"CREATE TABLE\s+(\w+)\s*\((.*?)\);", text, re.I | re.S):
                    pk = re.search(r"PRIMARY KEY\s*\(([^)]+)\)", match[2], re.I)
                    result[("public", match[1])] = {"db_id": "chinook",
                        "primary_key": [v.strip().strip('"') for v in pk[1].split(",")] if pk else []}
        if database == "bird":
            from backend.agents.task4_schema_linking.catalog_snapshot import bird_native_columns
            native = bird_native_columns(root)
            for key, metadata in result.items():
                snapshot = native.get(key[1])
                if snapshot:
                    actual = {c.casefold(): c for c in snapshot["columns"]}
                    metadata["primary_key"] = [actual[c.casefold()] for c in metadata["primary_key"] if c.casefold() in actual]
                    metadata.update(snapshot)
                    metadata["catalog_source"] = "existing_postgresql_import_ddl"
        self._metadata[database] = result
        return result

    def load(self, database, sub_db=None):
        """缓存当前唯一业务子库；多库缺身份时拒绝而不合并同名表。"""
        key = (database, sub_db)
        if self._load_key == key and self.tables:
            return
        self.tables, self._by_name, self.aliases = [], {}, None
        self.current_db = self.current_dataset = self._load_key = None
        if not self._data:
            self._data = json.loads(Path(self.index_dir).read_text(encoding="utf-8"))
        raw = self._data.get("datasets", {}).get(database)
        if raw is None:
            raise KeyError("unknown_dataset")
        metadata = self._mapping_metadata(database)
        entries = []
        for value in raw:
            entry = dict(value)
            update = metadata.get((entry.get("schema"), entry["table"]), {})
            if update.get("columns"):
                original = {c.casefold(): c for c in entry["columns"]}
                if set(original) != {c.casefold() for c in update["columns"]}:
                    raise ValueError("native_catalog_mapping_mismatch")
                entry["column_source_names"] = {c: original[c.casefold()] for c in update["columns"]}
            entry.update(update)
            entries.append(entry)
        identities = {e.get("db_id", database) for e in entries}
        if sub_db is None and len(identities) > 1:
            raise KeyError("sub_db_required")
        target = sub_db or next(iter(identities), database)
        selected = [e for e in entries if e.get("db_id", database) == target]
        if not selected:
            raise KeyError("unknown_sub_db")
        if len({e["table"] for e in selected}) != len(selected):
            raise ValueError("duplicate_table_identity")
        schemas = {e.get("schema") or "public" for e in selected}
        if len(schemas) != 1:
            raise ValueError("multiple_schemas_require_explicit_table_ids")
        self.tables, self._by_name = selected, {e["table"]: e for e in selected}
        self.current_db, self.current_dataset, self._load_key = target, database, key
        self._alias_map = self._data.get("alias_map", {}) if database == "chinook" else {}
        from backend.agents.task4_schema_linking.alias_map import AliasMap
        self.aliases = AliasMap(self.index_dir, catalog=self)

    @property
    def schema_name(self):
        return self.tables[0].get("schema") or "public" if self.tables else None

    @property
    def allowed_tables(self):
        """执行允许集合仅覆盖当前真实业务子库，不使用测试金标收缩权限。"""
        return {self.schema_name: {e["table"] for e in self.tables}} if self.tables else {}

    def get_table(self, name):
        return self._by_name.get(name)

    def resolve_target(self, target):
        """仅供人工别名规范化；返回目录中实际表列名，失效标签直接排除。"""
        table, _, column = target.partition(".")
        entry = self._by_name.get(table)
        if entry is None:
            matches = [e for e in self.tables if e["table"].casefold() == table.casefold()]
            entry = matches[0] if len(matches) == 1 else None
        if entry is None:
            return None
        if not column:
            return entry["table"]
        matches = [c for c in entry["columns"] if c == column or c.casefold() == column.casefold()]
        return entry["table"] + "." + matches[0] if len(matches) == 1 else None

    def find_ambiguous_matches(self, entity):
        """只输出当前目录真实映射；结构多命中不等于已证明用户业务歧义。"""
        if not entity or not entity.strip():
            return []
        low = entity.lower().strip()
        results = [{"label": item["target"], "via": "alias", "source": item["source"]}
                   for item in (self.aliases.resolve(entity) if self.aliases else [])]
        for entry in self.tables:
            for column in entry["columns"]:
                if low in column.lower():
                    results.append({"label": f"{entry['table']}.{column}", "via": "column", "source": "catalog"})
        seen, output = set(), []
        for item in results:
            if item["label"] not in seen:
                seen.add(item["label"])
                output.append(item)
        return output
