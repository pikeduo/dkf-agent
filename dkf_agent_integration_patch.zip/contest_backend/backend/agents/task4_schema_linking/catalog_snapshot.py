"""从既有PostgreSQL导入文件只读抽取建表目录，保留真实引号规则，不扫描COPY数据。"""
import re
import sqlglot
from sqlglot import exp


def bird_native_columns(root):
    """原SQLite mapping不能代表PG实际大小写；导入DDL才是本地目录快照。"""
    path = root / "data/postgresql/bird/import_native.sql"
    if not path.exists():
        return {}
    output, block = {}, []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.startswith("COPY "):
                break
            if re.match(r"CREATE TABLE (?:bird_native|\"bird_native\")\.", line):
                block = [line]
            elif block:
                block.append(line)
                if line.strip() == ");":
                    tree = sqlglot.parse_one("".join(block), read="postgres")
                    table = tree.find(exp.Table)
                    columns, types = [], {}
                    for definition in tree.find_all(exp.ColumnDef):
                        identifier = definition.this
                        name = identifier.name if identifier.args.get("quoted") else identifier.name.lower()
                        columns.append(name)
                        types[name] = definition.args["kind"].sql(dialect="postgres")
                    output[table.name] = {"columns": columns, "column_types": types}
                    block = []
    return output
