"""任务4：精准表定位（SchemaLinking）模块。"""
