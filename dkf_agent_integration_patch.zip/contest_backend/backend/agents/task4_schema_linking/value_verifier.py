"""授权值采样：显式业务schema和表作用域，不跨schema探测同名表。"""
from pathlib import Path
import psycopg2
from psycopg2 import sql
from backend.data_access.registry import SourceRegistry


class ValueVerifier:
    def __init__(self, registry_path=None):
        path = registry_path or Path(__file__).resolve().parents[3] / "processed/knowledge_base/databases.json"
        self.registry = SourceRegistry.load_from_json(str(path), use_siliconflow_embedding=False)

    def sample_values(self, db_id, table, column, limit=8, *, schema=None, allowed_tables=None):
        source = self.registry.get_relational(db_id)
        if source is None or not schema or table not in (allowed_tables or {}).get(schema, set()):
            return [{"error": "value_scope_missing"}]
        conn = None
        try:
            conn = psycopg2.connect(source.database_url, connect_timeout=10)
            conn.set_session(readonly=True, autocommit=False)
            with conn, conn.cursor() as cur:
                cur.execute("SET LOCAL statement_timeout TO 3000")
                cur.execute(sql.SQL("SELECT DISTINCT {} FROM {}.{} WHERE {} IS NOT NULL LIMIT %s").format(
                    sql.Identifier(column), sql.Identifier(schema), sql.Identifier(table), sql.Identifier(column)),
                    (min(max(int(limit), 1), 8),))
                return [{"value": str(r[0])[:60], "table": table, "column": column,
                         "schema": schema, "source": "authorized_catalog_sampling"} for r in cur.fetchall()]
        except psycopg2.Error:
            return [{"error": "value_query_failed"}]
        finally:
            if conn is not None:
                conn.close()

    def value_hit(self, db_id, table, column, entity, limit=8, *, schema=None, allowed_tables=None):
        if not entity or not entity.strip():
            return None
        for item in self.sample_values(db_id, table, column, limit, schema=schema, allowed_tables=allowed_tables):
            if "value" in item and entity.casefold() in item["value"].casefold():
                return item
        return None
