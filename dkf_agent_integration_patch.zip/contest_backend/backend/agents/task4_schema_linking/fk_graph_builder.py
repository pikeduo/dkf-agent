"""真实外键图：与目录作用域一致，保留多约束并拒绝失真复合列对。"""
import json
from pathlib import Path
import networkx as nx


class FKGraphBuilder:
    def __init__(self, graph_path=None):
        self.graph_path = str(graph_path or Path(__file__).resolve().parents[3] / "processed/task4_schema/fk_graph.json")
        self.graph, self.undirected = nx.MultiDiGraph(), nx.Graph()
        self._load_key = None
        self.problems = []

    def load(self, database, sub_db=None, table_entries=None):
        """子库身份不明时由目录拒绝；无图时清空状态，绝不沿用上一个库。"""
        if table_entries is None:
            from backend.agents.task4_schema_linking.schema_index import SchemaIndex
            index = SchemaIndex()
            index.load(database, sub_db)
            table_entries = index.tables
        catalog = {e["table"]: set(e["columns"]) for e in table_entries}
        key = (database, sub_db, tuple(sorted(catalog)))
        if self._load_key == key:
            return
        self._load_key = key
        self.graph, self.undirected, self.problems = nx.MultiDiGraph(), nx.Graph(), []
        self.graph.add_nodes_from(catalog)
        self.undirected.add_nodes_from(catalog)
        path = Path(self.graph_path)
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        edges = data.get("databases", {}).get(database, {}).get("foreignKey", [])
        for edge in edges:
            a, b, pairs = edge["from_table"], edge["to_table"], edge["pairs"]
            if a not in catalog or b not in catalog:
                continue
            valid = pairs and all(p["from_column"] in catalog[a] and p["to_column"] in catalog[b] for p in pairs)
            valid = valid and len({p["from_column"] for p in pairs}) == len(pairs) and len({p["to_column"] for p in pairs}) == len(pairs)
            if not valid:
                self.problems.append({"constraint": edge["constraint"], "reason": "invalid_or_unpaired_columns"})
                continue
            self.graph.add_edge(a, b, key=edge["constraint"], constraint=edge["constraint"], pairs=pairs)
            self.undirected.add_edge(a, b)

    def _constraints(self, a, b):
        out = []
        for source, target, reverse in ((a, b, False), (b, a, True)):
            for _, edge in (self.graph.get_edge_data(source, target) or {}).items():
                pairs = [{"from_column": p["to_column"], "to_column": p["from_column"]} if reverse else dict(p)
                         for p in edge["pairs"]]
                out.append({"constraint": edge["constraint"], "pairs": pairs})
        return sorted(out, key=lambda x: x["constraint"])

    def find_join_path(self, table1, table2, max_hops=4):
        if table1 == table2 or table1 not in self.undirected or table2 not in self.undirected:
            return []
        try:
            # 排序后的节点邻接使等长路径选择可复现，最短路径不宣称业务正确。
            graph = nx.Graph()
            graph.add_nodes_from(sorted(self.undirected.nodes))
            graph.add_edges_from(sorted(tuple(sorted(e)) for e in self.undirected.edges))
            path = nx.shortest_path(graph, table1, table2)
        except nx.NetworkXNoPath:
            return []
        if len(path) - 1 > max_hops:
            return []
        out = []
        for i, (a, b) in enumerate(zip(path, path[1:])):
            constraints = self._constraints(a, b)
            out.append({"from_table": a, "to_table": b, "pairs": constraints[0]["pairs"],
                "constraint": constraints[0]["constraint"], "alternatives": constraints,
                "is_bridge": a not in (table1, table2) or b not in (table1, table2),
                "note": "最短结构候选；多约束需按问题选择，不得将全部备选条件同时AND"})
        return out

    def bridge_tables(self, selected):
        """合并实际路径证据；中间表由调用方按端点集合补入，而非依赖布尔标记。"""
        selected = list(dict.fromkeys(selected))
        results = {}
        for i, a in enumerate(selected):
            for b in selected[i + 1:]:
                for hop in self.find_join_path(a, b):
                    hop["between"] = [a, b]
                    identity = tuple(sorted((hop["from_table"], hop["to_table"])))
                    results.setdefault(identity, hop)
        return list(results.values())
