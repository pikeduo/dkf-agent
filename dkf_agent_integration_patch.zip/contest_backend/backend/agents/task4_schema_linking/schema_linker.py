"""任务4门面：本库候选检索、合法指标、桥接表与主外键闭包。"""
from backend.agents.task4_schema_linking.schema_index import SchemaIndex
from backend.agents.task4_schema_linking.fk_graph_builder import FKGraphBuilder
from backend.agents.task4_schema_linking.table_matcher import TableMatcher, extract_entities
from backend.agents.task4_schema_linking.auto_explorer import AutoExplorer
from backend.agents.task4_schema_linking.metric_catalog import MetricCatalog
from backend.agents.task4_schema_linking.granularity_checker import GranularityChecker


class SchemaLinker:
    def __init__(self, index_dir=None):
        self.index = SchemaIndex(index_dir)
        self.fk = FKGraphBuilder()
        self.metrics = MetricCatalog()
        self.granularity = GranularityChecker(self.fk)
        self.metric_problems = {}

    def load(self, database, sub_db=None, verify_metrics=True):
        self.index.load(database, sub_db)
        self.fk.load(database, sub_db, table_entries=self.index.tables)
        # 校验不可跳过：关闭告警显示不意味着允许失效字段进入提示。
        self.metric_problems = self.metrics.verify_against_catalog(self.index)

    def link(self, question, interpretation, top_k=6, use_value_evidence=False,
             full_baseline=False, confirmed_slots=None):
        """检索不足是技术状态；只有本库真实口径多义才需要用户确认。"""
        if not self.index.tables:
            raise ValueError("schema_not_loaded")
        entities = extract_entities(question, interpretation)
        slots = confirmed_slots or {}
        confirmations = {str(v) for v in slots.values() if isinstance(v, (str, int))}
        entities += [v for v in confirmations if self.index.resolve_target(v)]
        matcher = TableMatcher(self.index)
        candidates = matcher.match(entities)
        top = candidates[:top_k]
        tables = [c["table"] for c in top]
        columns = {c["table"]: list(c["hit_columns"]) for c in top}
        matched = {ev["matched"].lower() for c in candidates for ev in c["evidence"]}
        additions = AutoExplorer(self.index).explore_missing(entities, matched)
        valid_additions = []
        for addition in additions:
            label = self.index.resolve_target(addition["table"])
            if not label:
                continue
            table, _, column = label.partition(".")
            if table not in tables:
                tables.append(table)
            if column:
                columns.setdefault(table, []).append(column)
            valid_additions.append(dict(addition, table=label))

        hints, ambiguous = {}, {}
        for entity in entities:
            found = self.metrics.candidates(entity, catalog=self.index)
            selected = [m for m in found if m.metric_id in confirmations or m.amount_column in confirmations
                        or any(a in confirmations for a in m.aliases if a != "销售额")]
            if len(found) > 1 and len(selected) != 1:
                ambiguous[entity] = {"entity": entity, "candidates": [m.metric_id for m in found],
                                     "note": "真实业务指标口径待用户确认"}
                continue
            metric = selected[0] if len(selected) == 1 else found[0] if found else None
            if metric:
                hints[metric.metric_id] = metric.as_hint()
                for ref in metric.references:
                    table, column = ref.split(".", 1)
                    if table not in tables:
                        tables.append(table)
                    columns.setdefault(table, []).append(column)

        # 用户已确认的真实表列参与定位；任意字符串不被当作字段。
        for value in confirmations:
            label = self.index.resolve_target(value)
            if label:
                table, _, column = label.partition(".")
                if table not in tables:
                    tables.append(table)
                if column:
                    columns.setdefault(table, []).append(column)
        baseline = [e["table"] for e in self.index.tables] if full_baseline else []
        if full_baseline:
            tables = list(baseline)

        # 一跳邻表闭包：FK 图上与选表直接相连的真实表补入候选（只加表与键列，
        # 不改证据与指标歧义判断），避免裁剪丢掉一跳可达的金标桥表
        # （如 satscores 经 schools 连 frpm）。
        # 有界且数据集无关：按"连接的已选表数量"（连接度）降序，最多补 3 张，
        # 恢复关键桥表的同时防止大子库被无差别扩张成噪声。
        selected0 = set(dict.fromkeys(tables))
        neighbor_degree = {}  # 邻表 -> 连接了几张已选表
        neighbor_vias = {}    # 邻表 -> 经由的已选表（首个命中）
        for source, target in self.fk.undirected.edges:
            if source in selected0 and target not in selected0:
                neighbor_degree[target] = neighbor_degree.get(target, 0) + 1
                neighbor_vias.setdefault(target, source)
            elif target in selected0 and source not in selected0:
                neighbor_degree[source] = neighbor_degree.get(source, 0) + 1
                neighbor_vias.setdefault(source, target)
        # 连接度降序、名称升序保证可复现；截断到 3 张。
        ranked = [t for t, _ in sorted(neighbor_degree.items(), key=lambda kv: (-kv[1], kv[0]))][:3]
        for table in sorted(ranked):
            if table not in tables:
                tables.append(table)

        bridges = self.fk.bridge_tables(tables)
        # 证据只记录实际补入（≤3）的邻表，与被截断丢弃的区分，保证可解释。
        added = set(ranked)
        closure = [{"table": table, "source": "一跳外键邻表", "between": [neighbor_vias[table]]}
                   for table in sorted(added)]
        for hop in bridges:
            for table in (hop["from_table"], hop["to_table"]):
                if table not in tables:
                    tables.append(table)
                    closure.append({"table": table, "source": "真实外键路径", "between": hop["between"]})
            for constraint in hop.get("alternatives") or [hop]:
                for pair in constraint["pairs"]:
                    columns.setdefault(hop["from_table"], []).append(pair["from_column"])
                    columns.setdefault(hop["to_table"], []).append(pair["to_column"])
        # 保留当前表真实外键列（包括自引用），不因此把无关父表全部扩张入候选。
        selected_tables = set(tables)
        for source, target, data in self.fk.graph.edges(data=True):
            for pair in data["pairs"]:
                if source in selected_tables:
                    columns.setdefault(source, []).append(pair["from_column"])
                if target in selected_tables:
                    columns.setdefault(target, []).append(pair["to_column"])
        for table in tables:
            entry = self.index.get_table(table)
            if entry is None:
                raise ValueError("candidate_outside_scope")
            columns.setdefault(table, []).extend(entry.get("primary_key", []))
            columns[table] = list(dict.fromkeys(c for c in columns[table] if c in entry["columns"]))
        warnings = self.granularity.check(tables, columns)
        status = "business_ambiguous" if ambiguous else "ok" if tables else "candidate_insufficient"
        values = []
        if use_value_evidence:
            # 值证据需显式开启，并始终使用本库真实schema；空实体不形成值命中。
            from backend.agents.task4_schema_linking.value_verifier import ValueVerifier
            verifier = ValueVerifier()
            for candidate in top[:3]:
                for column in columns.get(candidate["table"], [])[:3]:
                    for entity in entities[:3]:
                        hit = verifier.value_hit(self.index.current_dataset, candidate["table"], column,
                            entity, schema=self.index.schema_name, allowed_tables=self.index.allowed_tables)
                        if hit:
                            values.append(hit)
        return {"database": self.index.current_dataset, "sub_db": self.index.current_db,
            "schema": self.index.schema_name, "entities": entities, "candidates": top,
            "tables": tables, "columns": columns, "bridges": bridges, "closure_evidence": closure,
            "value_evidence": values, "inferred_additions": valid_additions, "baseline_tables": baseline,
            "matched_entities": sorted(matched), "metric_hints": list(hints.values()),
            "metric_ambiguous": list(ambiguous.values()), "granularity_warnings": warnings,
            "negative_evidence": {"truncated_candidates": [c["table"] for c in candidates[top_k:]],
                "metric_catalog_problems": self.metric_problems, "fk_catalog_problems": self.fk.problems},
            "status": status, "coverage_proven": False, "needs_clarification": bool(ambiguous)}
