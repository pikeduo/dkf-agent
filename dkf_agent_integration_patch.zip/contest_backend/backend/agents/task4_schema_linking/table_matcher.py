"""可复现表列互补检索：词形拆分、目录内逆文档频率及受作用域约束的中文别名。"""
import math
import re
from collections import Counter


def tokens(text):
    """先拆驼峰再折小写；保留中文词，不让空归一化命中任意字符串。"""
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    text = re.sub(r"([A-Z])([A-Z][a-z])", r"\1 \2", text)
    result = set()
    for term in re.findall(r"[A-Za-z]+|[0-9]+|[\u4e00-\u9fff]+", text):
        term = term.lower()
        if term.endswith("ies") and len(term) > 4:
            term = term[:-3] + "y"
        elif term.endswith("s") and len(term) > 3 and not term.endswith(("ss", "us")):
            term = term[:-1]
        result.add(term)
    return result


def normalize(text):
    """兼容旧接口；生产匹配使用非空词集合，避免空串包含问题。"""
    return " ".join(sorted(tokens(text)))


class TableMatcher:
    def __init__(self, schema_index):
        self.schema = schema_index
        self.documents = {}
        frequency = Counter()
        for entry in self.schema.tables:
            table_terms = tokens(entry["table"])
            columns = {c: tokens(c) | tokens(entry.get("column_source_names", {}).get(c, c))
                       for c in entry["columns"]}
            all_terms = table_terms | tokens(entry.get("comment") or "")
            for words in columns.values():
                all_terms |= words
            frequency.update(all_terms)
            self.documents[entry["table"]] = (table_terms, columns)
        n = max(len(self.schema.tables), 1)
        self.idf = {t: math.log(1 + (n - df + 0.5) / (df + 0.5)) for t, df in frequency.items()}

    def match(self, entities):
        """每实体每表取最佳列证据而不按列数累加，避免宽表天然高分。"""
        scored = {}
        for entry in self.schema.tables:
            table = entry["table"]
            table_terms, col_terms = self.documents[table]
            score, evidence, hit_columns = 0.0, [], []
            for entity in entities:
                query = tokens(entity)
                if not query:
                    continue
                overlap = query & table_terms
                table_score = 3.0 * sum(self.idf[t] for t in overlap)
                column_score, best = 0.0, None
                for column, words in col_terms.items():
                    hit = query & words
                    if not hit:
                        continue
                    value = 1.8 * sum(self.idf[t] for t in hit) / math.sqrt(max(1, len(query)))
                    if value > column_score:
                        column_score, best = value, column
                    if column not in hit_columns:
                        hit_columns.append(column)
                if table_score or column_score:
                    score += max(table_score, column_score)
                    evidence.append({"source_type": "表名" if table_score >= column_score else "列名",
                        "matched": entity, "target": table if table_score >= column_score else f"{table}.{best}"})
                for alias in self.schema.aliases.resolve(entity) if self.schema.aliases else []:
                    target, _, column = alias["target"].partition(".")
                    if target == table:
                        score += 2.5
                        evidence.append({"source_type": f"别名({alias['source']})", "matched": entity,
                                         "target": alias["target"]})
                        if column and column not in hit_columns:
                            hit_columns.append(column)
            if evidence:
                scored[table] = {"table": table, "score": round(score, 6), "hit_columns": hit_columns,
                                 "evidence": evidence}
        return sorted(scored.values(), key=lambda x: (-x["score"], x["table"]))

    def column_hits(self, table, entities):
        entry = self.schema.get_table(table)
        if not entry:
            return []
        return [{"table": table, "column": c, "matched": e} for c in entry["columns"]
                for e in entities if tokens(e) and tokens(e) & tokens(c)]

    def find_ambiguous_entities(self, entities):
        return {e: found for e in entities if len(found := self.schema.find_ambiguous_matches(e)) >= 2}


def extract_entities(question, interpretation):
    """保留意图解释接口；无解释时使用问题词，绝不读取答案标签。"""
    from backend.agents.task4_schema_linking.question_entities import extract_question_entities
    entities = []
    if interpretation is not None:
        for fact in interpretation.facts:
            entities.append(fact.name)
            if fact.value and len(fact.value) <= 24:
                entities.append(fact.value)
        for req in interpretation.requirements:
            if req.name:
                entities.append(req.name)
            entities.extend(req.candidates)
    entities.extend(extract_question_entities(question))
    seen, result = set(), []
    for entity in entities:
        key = entity.strip().lower()
        if key and key not in seen:
            seen.add(key)
            result.append(entity.strip())
    return result[:40]
