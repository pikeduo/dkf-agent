"""任务4 别名词典（业务词典层，真实目录与人工维护分区标注）。

alias_map 存「实体 → 目标表/列标识列表」，仅供表定位加证据与任务3歧义检测。
条目来源分两类，写入时保留 source 标注：
- real：来自真实目录的常见中英文别名（表名、常用同义词）
- business：人工维护的业务口径别名（本竞赛允许，AGENTS.md 不引入新数据集）
不得放入测试集答案或 BIRD oracle evidence。
"""
import json
import os
from pathlib import Path
from typing import Dict, List

# 人工维护的最小业务词典：围绕 Chinook 真实 11 表（不引入新数据集）
_BUSINESS_ALIAS: Dict[str, List[dict]] = {
    # 实体 → 命中目标（表名），标注来源
    "艺人": [{"target": "artist", "source": "business", "note": "Artist 表：歌手/艺术家"}],
    "歌手": [{"target": "artist", "source": "business"}],
    "专辑": [{"target": "album", "source": "business", "note": "Album 表"}],
    "曲目": [{"target": "track", "source": "business"}],
    "歌曲": [{"target": "track", "source": "business"}],
    "发票": [{"target": "invoice", "source": "business"}],
    "账单": [{"target": "invoice", "source": "business"}],
    "发票明细": [{"target": "invoice_line", "source": "business"}],
    "顾客": [{"target": "customer", "source": "business"}],
    "客户": [{"target": "customer", "source": "business"}],
    "员工": [{"target": "employee", "source": "business"}],
    "职员": [{"target": "employee", "source": "business"}],
    "国家": [{"target": "customer", "source": "business", "note": "Country 列在 customer 表"}],
    "地区": [{"target": "customer", "source": "business", "note": "Region 列在 customer 表"}],
    "销售": [{"target": "invoice", "source": "business", "note": "销售额=invoice.Total"}],
    "销售额": [{"target": "invoice", "source": "business", "note": "Total 列"}],
    "媒体": [{"target": "media_type", "source": "business"}],
    "格式": [{"target": "media_type", "source": "business", "note": "MediaType.Name 如 MP3/FLAC"}],
    "流派": [{"target": "genre", "source": "business"}],
    "播放量": [{"target": "track", "source": "business", "note": "Track 表无播放列，候选口径需澄清"}],
    "播放列表": [{"target": "playlist", "source": "business"}],
    "歌单": [{"target": "playlist", "source": "business"}],
}


class AliasMap:
    """别名词典：alias_map(JSON) + 人工业务词典的合并视图。"""

    def __init__(self, index_path: str, business: Dict[str, List[dict]] = None, catalog=None) -> None:
        self.index_path = index_path
        self.catalog = catalog
        self._business = business if business is not None else (
            _BUSINESS_ALIAS if catalog is None or catalog.current_dataset == "chinook" else {})
        self._from_index: Dict[str, List[str]] = {}
        self._load_index()

    def _load_index(self) -> None:
        try:
            data = json.loads(Path(self.index_path).read_text(encoding="utf-8"))
            self._from_index = data.get("alias_map", {})
        except FileNotFoundError:
            pass
        self._from_index = self.catalog._alias_map if self.catalog is not None else {}

    def resolve(self, entity: str) -> List[dict]:
        """人工别名只在指定目录内生效，过滤失效标签并按实际标识去重。"""
        if not entity or not entity.strip():
            return []
        out, seen = [], set()
        low = entity.lower().strip()
        pairs = [(alias, [{"target": t, "source": "index"} for t in targets])
                 for alias, targets in self._from_index.items()]
        pairs += list(self._business.items())
        for alias, items in pairs:
            if low != alias.lower() and not (len(alias) >= 2 and alias.lower() in low):
                continue
            for value in items:
                target = self.catalog.resolve_target(value["target"]) if self.catalog else value["target"]
                if target and target not in seen:
                    item = dict(value, target=target)
                    out.append(item)
                    seen.add(target)
        return out
