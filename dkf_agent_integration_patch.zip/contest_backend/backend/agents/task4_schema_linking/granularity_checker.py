"""
任务4：粒度与 fan-out 检查（桥接链正确性守门）。

参考 SchemaGraphSQL 精读结论"最短外键链不等于业务正确链"与 dbt MetricFlow
"限制会引入 fan-out 的关联"的原则：
- 两个事实表直接经一对多桥接表 JOIN 后聚合，会出现重复计数（fan-out）；
- 建议在聚合前各自收敛到共同粒度，或用半连接/子查询替代。

本模块做**结构层告警**（不修改真实库、不代替业务判断）：
输入候选表集合、各表列与外键桥接，输出需要"聚合后再关联"的告警项。

注意：FKGraphBuilder 的 is_bridge 只标注"多跳路径的中间节点"，
单桥接表（如 invoice_line 连接 invoice 与 track）不会被打上该标记，
因此本模块直接基于无向外键图找"枢纽桥接表"，不依赖 is_bridge。
"""
from typing import Dict, List, Set

from backend.agents.task4_schema_linking.fk_graph_builder import FKGraphBuilder

# 金额/计数列名特征（结构层启发式，用于粗判"事实型"表；业务口径以指标库为准）
_MONEY_KEYWORDS = ("total", "amount", "price", "revenue", "count", "fee", "salary")


class GranularityChecker:
    """基于真实外键图判断候选表 JOIN 是否会放大计数。"""

    def __init__(self, fk: FKGraphBuilder) -> None:
        self.fk = fk

    def check(self, tables: List[str], columns: Dict[str, List[str]] = None) -> List[Dict]:
        """返回 fan-out 风险告警列表。

        判据（结构层，保守只报风险，不代替业务复核）：
        1. 存在"枢纽桥接表" m：m 在真实外键图上与 ≥2 个被选中的表直连，
           且这些被选中表含金额/计数列（事实表）。直接 JOIN m 后按事实表聚合会
           把 m 的多行摊到每个事实行上 → 重复计数。建议先各自聚合到共同粒度。
        2. 自引用外键表（如 employee.reports_to）被纳入但未收敛粒度。
        columns：候选表 → 列名列表（来自 SchemaLinker 的 schema 视图，真实目录），
        缺省 {} 时只能报自连接。
        """
        warnings: List[Dict] = []
        tables = list(dict.fromkeys(tables))
        columns = columns or {}
        if not tables:
            return warnings

        sel: Set[str] = set(tables)
        neighbors = self._neighbors(sel)

        def is_fact(t: str) -> bool:
            cols = [c.lower() for c in columns.get(t, [])]
            return any(any(k in c for k in _MONEY_KEYWORDS) for c in cols)

        fact_tables = [t for t in tables if is_fact(t)]

        # 风险1：枢纽桥接表（同时直连 ≥2 个选中表）且选中集合里有事实表
        for m in tables:
            nbrs = [n for n in neighbors.get(m, set()) if n != m]
            if len(nbrs) >= 2 and len(fact_tables) >= 1:
                warnings.append({
                    "type": "fanout_risk",
                    "bridge_table": m,
                    "linked_tables": sorted(nbrs),
                    "fact_tables": fact_tables,
                    "suggestion": (
                        f"{m} 同时外键连接 {sorted(nbrs)}（1:N 枢纽）；"
                        f"直接 JOIN 后按 {fact_tables or sorted(nbrs)} 聚合会把 {m} 的多行摊到每行上造成重复计数。"
                        f"建议各自先聚合到共同粒度再关联，或用子查询/半连接。"
                    ),
                    "evidence": "基于真实外键图直连关系推断（结构层），非业务确认；口径冲突交任务3",
                })

        # 风险2：自连接表
        for t in tables:
            if self._self_referencing(t):
                warnings.append({
                    "type": "self_join",
                    "table": t,
                    "suggestion": f"{t} 存在自引用外键，聚合需按层级 GROUP BY，避免笛卡尔放大",
                    "evidence": "真实外键图自环约束",
                })
        return warnings

    def _neighbors(self, selected: Set[str]) -> Dict[str, Set[str]]:
        """在无向外键图上取每个被选表在 selected 集合内的一跳邻居。"""
        out: Dict[str, Set[str]] = {t: set() for t in selected}
        if self.fk.undirected is None:
            return out
        for t in selected:
            if t not in self.fk.undirected:
                continue
            for nb in self.fk.undirected.neighbors(t):
                if nb in selected:
                    out[t].add(nb)
        return out

    def _self_referencing(self, table: str) -> bool:
        if self.fk.graph is None:
            return False
        try:
            return self.fk.graph.has_edge(table, table)
        except Exception:
            return False
