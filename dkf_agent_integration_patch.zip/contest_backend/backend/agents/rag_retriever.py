"""任务4/6 共用：文档检索增强（RAG）检索门面。

基于 pgvector + SiliconFlowEmbedder，在 doc_chunks 表上做语义近邻检索，
按 doc_id 过滤限定到某份 OHR 文档。输出证据带物理页码与区域（source_bbox），
区分「文档已确认事实」与「模型候选推断」——本模块只负责取文档证据，
不替调用方做数值/公式正确性结论（正确性由任务6 安全计算器与评测层判定）。
"""
from typing import Dict, List, Optional

from backend.data_access.vector import VectorSource


class RAGRetriever:
    """文档切片语义检索（封装 VectorSource，供任务5/6 消费）。"""

    def __init__(self, vector_source: VectorSource) -> None:
        self.v = vector_source

    def retrieve(self, question: str, doc_id: Optional[str] = None,
                 top_k: int = 5) -> List[Dict]:
        """问题 → 最相关文档切片（可限定 doc_id）。

        每项命中：{doc_id, physical_page, text, distance, source_bbox, evidence_kind}。
        距离是 L2 余弦近似值，越小越相关；不在此层判数值对错。
        """
        resp = self.v.search(query_text=question, top_k=top_k, doc_id=doc_id)
        if not resp.ok:
            raise RuntimeError(resp.error or "向量检索失败")
        hits: List[Dict] = []
        for h in resp.hits:
            hits.append({
                "doc_id": h.get("doc_id"),
                "physical_page": h.get("physical_page"),
                "text": h.get("text"),
                "distance": h.get("distance"),
                "source_bbox": h.get("source_bbox"),
                # 切片来源标注：文档原文（非模型推断），供任务6 回配校验
                "evidence_kind": "document",
            })
        return hits

    def grounded_check(self, candidate_value: str, question: str,
                       doc_id: str, top_k: int = 5) -> Dict:
        """FINDER 式参数回配：候选值能否在 doc_id 的原文命中里逐字核对。

        返回 {found, hit_chunk, evidence_id}；未命中说明该数值不是文档里
        出现的内容，不能当作文档事实（任务6 据此标证据不足）。
        """
        if not candidate_value:
            return {"found": False, "hit_chunk": None, "evidence_id": None,
                    "reason": "候选值为空"}
        hits = self.retrieve(question, doc_id=doc_id, top_k=top_k)
        for h in hits:
            if candidate_value.strip() in (h.get("text") or ""):
                return {"found": True, "hit_chunk": h, "evidence_id": h.get("doc_id")}
        return {"found": False, "hit_chunk": None, "evidence_id": None,
                "reason": "候选值未在该文档命中切片中逐字出现"}
