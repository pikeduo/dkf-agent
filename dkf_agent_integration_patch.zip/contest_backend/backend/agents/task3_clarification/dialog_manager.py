"""任务3有限澄清状态机；用户条件齐备与实际问答完成严格分离。"""
import copy
import re
from decimal import Decimal, InvalidOperation
from typing import Dict, Optional

from backend.agents.task3_clarification.ambiguity_detector import AmbiguityDetector
from backend.agents.task3_clarification.necessity_judge import NecessityJudge
from backend.core.intent.policy import clarification_readiness
from backend.core.state_manager import DialogState
from backend.core.trace_logger import ExecutionTrace

_REJECT_WORDS = {"都不是", "以上都不是", "没有"}
_SKIP_WORDS = {"不知道", "不确定", "跳过"}
_OPERATION_WORDS = {"由我提供", "由我提供数值", "我来指定", "自定义", "请填写"}


class DialogManager:
    """每个会话保留固定目录、候选修正和真实轮数，不默认确认第一项。"""

    def __init__(self, session_id: str, question: str, llm_client, schema_index,
                 interpretation=None, trace: Optional[ExecutionTrace] = None,
                 schema_context: Optional[dict] = None) -> None:
        self.state = DialogState(session_id=session_id, original_question=question)
        self.detector = AmbiguityDetector(llm_client, schema_index)
        self.judge = NecessityJudge(self.state)
        self.trace = trace or ExecutionTrace(question)
        self.interpretation = copy.deepcopy(interpretation)
        self.schema_context = copy.deepcopy(schema_context or {})
        self.state.schema_version = self.schema_context.get("version") or "v1"
        self._pending_dim = None
        self._undecided = {}
        self._revisions = {}
        self._overrides = {}
        self._last_output = None
        self._input_error = None

    def _confirmed_ids(self) -> set:
        return {s["requirement_id"] for s in self.state.confirmed_slots.values()
                if s.get("requirement_id") and s.get("version") == self.state.schema_version}

    def step(self, user_reply: Optional[str] = None) -> Dict:
        """首轮或用户回复推进一步；重复读取待答问题不消耗新的交互预算。"""
        if self.schema_context.get("status") == "unavailable":
            return self._finish("tool_error", self.schema_context.get("error_code") or "schema_unavailable")
        if self.interpretation is None:
            return self._finish("tool_error", "intent_missing")
        if user_reply is None and self._pending_dim and self._last_output:
            return copy.deepcopy(self._last_output)
        if user_reply is not None:
            if self._pending_dim is None:
                return self._finish("blocked", "no_pending_question")
            self._apply_reply(user_reply)
        confirmed = self._confirmed_ids()
        dims = self.detector.from_intent(self.state.original_question, self.interpretation, confirmed)
        for dim in dims:
            key = self.judge._dedup_key(dim)
            if key in self._overrides:
                dim["candidates"] = list(self._overrides[key])
        to_ask = self.judge.rank(dims, set(self._undecided))
        if to_ask:
            target = to_ask[0]
            target["options"] = self.detector.fill_options(target, self.state.original_question)
            self._pending_dim = target
            self.state.mark_asked(self.judge._dedup_key(target))
            clarify = self._build_question(target)
            self.trace.log(module="任务3-澄清", action="生成追问",
                           input_data={"requirement_id": target["requirement_id"], "goal_id": target["goal_id"]},
                           output_data=clarify)
            out = {"need_clarify": True, "status": "needs_user", "clarify": clarify,
                   "confirmed": copy.deepcopy(self.state.confirmed_slots), "final_ready": False,
                   "reason": target["gap"], "actual_turns": self.state.round_count,
                   "error": self._input_error}
            self._last_output = copy.deepcopy(out)
            self._input_error = None
            return out
        readiness = clarification_readiness(self.interpretation, confirmed)
        if self._undecided:
            return self._finish("undecided", "user_declined")
        if readiness["pending_user_ids"] and self.state.budget_left() <= 0:
            return self._finish("budget_exhausted", "clarification_budget")
        if readiness["status"] == "needs_user":
            return self._finish("blocked", "unmet_dependencies", readiness)
        return self._finish(readiness["status"], readiness["status"], readiness)

    def _finish(self, status: str, reason: str, readiness=None) -> dict:
        """所有终止状态明确标识；非ready永远不能作为成功闭环。"""
        self._pending_dim = None
        out = {"need_clarify": False, "status": status, "clarify": None,
               "confirmed": copy.deepcopy(self.state.confirmed_slots),
               "final_ready": status == "ready", "reason": reason,
               "actual_turns": self.state.round_count,
               "undecided": sorted(self._undecided.values())}
        if readiness:
            out.update({"unresolved_ids": readiness["unresolved_ids"],
                        "retrieval_pending": readiness["retrieval_pending"]})
        self._last_output = copy.deepcopy(out)
        return out

    def _apply_reply(self, user_reply: str) -> None:
        reply = user_reply.strip()
        target = self._pending_dim
        key = self.judge._dedup_key(target)
        if reply in _SKIP_WORDS:
            self._undecided[key] = target["dimension"]
            self.trace.log(module="任务3-澄清", action="用户跳过转未决", output_data={"requirement_id": target["requirement_id"]})
            self._pending_dim = None
            return
        if reply in _REJECT_WORDS:
            if self._revisions.get(key, 0) >= 1:
                self._undecided[key] = target["dimension"]
                self.trace.log(module="任务3-澄清", action="再次全拒绝转未决", output_data={"requirement_id": target["requirement_id"]})
            else:
                self._revisions[key] = 1
                rejected = set(target.get("options") or [])
                remaining = [c for c in target.get("candidates", []) if c not in rejected]
                # 没有新证据时转自由填写，绝不把被否决候选再次显示或生成假默认值。
                self._overrides[key] = remaining
                self.trace.log(module="任务3-澄清", action="全拒绝候选修正",
                               output_data={"requirement_id": target["requirement_id"],
                                            "rejected": sorted(rejected), "remaining": remaining})
            self._pending_dim = None
            return
        if not reply or reply in _OPERATION_WORDS:
            self._input_error = "请提供实际数值或具体口径；操作选项不是确认值"
            self._pending_dim = None
            return
        if target["kind"] == "parameter":
            match = re.match(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?=\s|$)", reply)
            try:
                valid = match is not None and Decimal(match.group(0)).is_finite()
            except InvalidOperation:
                valid = False
            if not valid:
                self._input_error = "请提供有限数值，可附带单位"
                self._pending_dim = None
                return
        self.state.confirm(key, {
            "value": reply, "dimension": target["dimension"], "scope": "session", "source": "user",
            "requirement_id": target["requirement_id"], "goal_id": target["goal_id"],
            "kind": target["kind"], "free_text": reply not in target.get("options", []),
            "schema_refs": list(target.get("schema_refs") or []),
        })
        self._pending_dim = None
        self.trace.log(module="任务3-澄清", action="登记确认",
                       output_data={"requirement_id": target["requirement_id"], "value": reply})

    def _build_question(self, dim: Dict) -> dict:
        options = list(dim.get("options") or [])
        text = dim["description"]
        if dim["kind"] == "parameter":
            text = f'请提供「{dim["dimension"]}」的实际数值及适用单位。'
        if options:
            text += " 请选一个，或直接补充具体说明。"
        else:
            text += " 请直接填写；不知道可以跳过。"
        return {"dimension": dim["dimension"], "kind": dim["kind"], "text": text,
                "options": options, "skippable": True, "reject_word": "都不是",
                "input_mode": "choice_or_text" if options else "free_text",
                "requirement_id": dim["requirement_id"], "goal_id": dim["goal_id"]}

    def rewrite(self, schema_view: Dict) -> Dict:
        """仅附加结构化确认约束，不猜测替换文本或删除主外键、共享列。"""
        return {"original_question": self.state.original_question,
                "confirmed_slots": copy.deepcopy(self.state.confirmed_slots),
                "schema_view": copy.deepcopy(schema_view), "excluded_columns": [],
                "undecided": sorted(self._undecided.values()),
                "note": "确认值仍需下游语义校验；原问题与真实目录保持不变"}
