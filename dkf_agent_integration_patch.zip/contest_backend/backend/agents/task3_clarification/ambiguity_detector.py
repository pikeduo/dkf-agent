"""把统一需求分类转换为澄清维度；多目录命中不自动产生歧义。"""
from typing import Dict, List, Optional

from backend.core.intent.policy import requirement_gap, supported_candidates
from backend.agents.task4_schema_linking.schema_index import SchemaIndex


class AmbiguityDetector:
    """保留完整必要需求标识及依赖；展示预算不得吞掉未解决条件。"""

    def __init__(self, llm_client, schema_index: Optional[SchemaIndex] = None) -> None:
        self.llm = llm_client
        self.schema = schema_index

    def from_intent(self, question: str, interpretation, confirmed_ids=()) -> List[Dict]:
        """只询问用户可解决、且有支持的缺口，不调用模型制造候选。"""
        if interpretation is None:
            return []
        confirmed = set(confirmed_ids)
        requirements = {r.id: r for r in interpretation.requirements}
        dims = []
        for r in interpretation.requirements:
            if r.status == "satisfied" or r.id in confirmed or r.resolver != "user":
                continue
            deps_ready = all(requirements[d].status == "satisfied" or d in confirmed for d in r.depends_on)
            dims.append({
                "id": f"req:{r.id}", "requirement_id": r.id, "goal_id": r.goal_id,
                "dimension": r.name or r.kind, "kind": r.kind, "status": r.status,
                "gap": requirement_gap(r), "candidates": supported_candidates(r),
                "source": "intent_requirement", "description": r.description,
                "depends_on": list(r.depends_on), "dependencies_ready": deps_ready,
                "schema_refs": list(r.schema_refs), "answer_changes": r.answer_changes,
                "supported": bool(r.source_hint or r.schema_refs),
            })
        return dims

    def fill_options(self, dim: Dict, question: str) -> List[str]:
        """展示已经支持的候选；缺信息直接自由填写，不制造年份、指标或默认值。"""
        dim["options_source"] = "supported_requirement" if dim.get("candidates") else "free_text"
        return list(dim.get("candidates") or [])[:4]
