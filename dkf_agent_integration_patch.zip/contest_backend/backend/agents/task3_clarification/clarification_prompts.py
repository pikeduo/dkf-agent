"""任务3：澄清相关提示词模板。

集中管理提示词，便于迭代与评测。
所有模板都不把标准答案（gold）写入，遵守评测隔离原则。
"""
from typing import Dict, List

# 歧义检测提示（供 ambiguity_detector 使用）
DETECT_AMBIGUITY = """你是数据查询歧义检测器。
判断以下问题是否存在「聚合方式、关联路径、NULL语义、单位、条件缺失」等歧义。
仅当多个合理含义会改变最终答案时才算歧义。
以JSON数组返回，每项含 type/dimension/candidates。无歧义返回[]。

问题：{question}
已确认信息：{confirmed}
"""

# 追问文案模板
CLARIFY_TEMPLATE = """根据您的问题，我理解您想查询「{intent}」。
不过{dimension}会影响结果，请从下列选项中选择，或补充说明（也可选择跳过）。
选项：{options}
"""
