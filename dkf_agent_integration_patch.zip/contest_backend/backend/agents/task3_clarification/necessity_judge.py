"""任务3必要性门控；只给已通过统一缺口分类的用户需求排序。"""
from typing import Dict, List


class NecessityJudge:
    """候选数量不决定缺参是否追问；价值分数只决定顺序。"""

    def __init__(self, dialog_state) -> None:
        self.state = dialog_state

    def should_clarify(self, dim: Dict, undecided: set = None) -> bool:
        key = self._dedup_key(dim)
        if self.state.has_confirmed(key) or key in (undecided or set()):
            return False
        if self.state.budget_left() <= 0 or not dim.get("dependencies_ready", True):
            return False
        gap = dim.get("gap")
        if gap is not None:
            return gap in {"user_missing", "user_ambiguity"}
        # 兼容直接调用的协议维度；业务含义不能仅凭两个候选获得支持。
        if dim.get("kind") in {"parameter", "intent", "formula_definition"}:
            return True
        return bool(dim.get("supported") and (dim.get("status") == "open" or
                    dim.get("answer_changes") and len(dim.get("candidates") or []) >= 2))

    @staticmethod
    def _dedup_key(dim: Dict) -> str:
        """需求标识与目标隔离；旧调用方没有标识时保留旧键形式。"""
        if dim.get("requirement_id"):
            return f'{dim.get("goal_id", "")}:{dim["requirement_id"]}:{dim.get("source", "")}'
        return f'{dim.get("dimension", "unknown")}:{dim.get("source", "")}'

    def rank(self, dims: List[Dict], undecided: set = None) -> List[Dict]:
        """确定性启发式排序，不声称复现意图熵或改变追问门控。"""
        ranked = [dict(d) for d in dims if self.should_clarify(d, undecided)]
        for dim in ranked:
            dim["value_score"] = self.value_score(dim)
        return sorted(ranked, key=lambda d: (-d["value_score"], d.get("goal_id", ""),
                                             d.get("dimension", ""), d.get("requirement_id", "")))

    def value_score(self, dim: Dict) -> float:
        """冲突优先；参数、业务范围与意图依次排序，不作阈值判断。"""
        if dim.get("status") == "conflict":
            return 1.5
        base = {"parameter": 0.8, "formula_definition": 0.8, "business_scope": 0.5,
                "column_ambiguity": 0.5, "intent": 0.3}.get(dim.get("kind"), 0.4)
        count = len(dim.get("candidates") or [])
        return round(base + (0.5 if count >= 2 else 0) + (0.2 if count >= 4 else 0), 2)
