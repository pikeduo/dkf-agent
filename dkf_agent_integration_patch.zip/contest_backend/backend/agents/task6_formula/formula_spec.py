"""统一的用户公式受限解析入口；保留原文、稳定符号映射和明确资源预算。"""
import ast as _ast
import io
import re
import tokenize
import unicodedata
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .numeric_units import FormulaError, MAX_EXPONENT, finite_real, normalize_scientific

MAX_FORMULA_LENGTH = 2048
MAX_AST_NODES = 256
MAX_AST_DEPTH = 32
_ALLOWED_FUNCS = {"abs", "round", "min", "max", "sqrt"}
_ALLOWED_BINOP = {_ast.Add: "+", _ast.Sub: "-", _ast.Mult: "*", _ast.Div: "/",
                  _ast.Pow: "**", _ast.Mod: "%", _ast.FloorDiv: "//"}
_ALLOWED_UNOP = {_ast.USub: "-", _ast.UAdd: "+"}


def normalize_symbol(name: str) -> str:
    """只去首尾空白并做标准组合归一，保留大小写、下标和温差符号。"""
    if not isinstance(name, str):
        raise FormulaError("invalid_binding", "变量名必须是字符串")
    return unicodedata.normalize("NFC", name.strip())


@dataclass
class FormulaSpec:
    """可校验的公式规格；状态标记不能替代计算时的 AST 复核。"""
    formula_id: str
    expression: str
    variables: Dict[str, Dict] = field(default_factory=dict)
    expected_unit: Optional[str] = None
    display: str = "number"
    constraints: List[str] = field(default_factory=list)
    parse_status: str = "unverified"
    ast_tree: Optional[_ast.AST] = None
    version: str = "v2_bounded"
    source: str = ""
    target_symbol: Optional[str] = None
    symbol_map: Dict[str, str] = field(default_factory=dict)
    output_representation: str = "auto"
    error_code: Optional[str] = None

    @property
    def input_symbols(self) -> List[str]:
        """仅从已验证右式读必要输入，不把自引用目标静默排除。"""
        if self.ast_tree is None:
            return []
        _validate_restricted(self.ast_tree)
        functions = {id(n.func) for n in _ast.walk(self.ast_tree) if isinstance(n, _ast.Call)}
        return list(dict.fromkeys(n.id for n in _ast.walk(self.ast_tree)
                                 if isinstance(n, _ast.Name) and id(n) not in functions))

    def unit_map(self) -> Dict[str, Optional[str]]:
        return {symbol: (self.variables.get(symbol) or {}).get("unit") for symbol in self.input_symbols}

    def resolve_symbol(self, name: str) -> str:
        """绑定查找接口：原名、生成名或显式别名必须唯一，不做包含匹配。"""
        name = normalize_symbol(name)
        matches = set()
        if name in self.variables or name in self.input_symbols or name == self.target_symbol:
            matches.add(name)
        if name in self.symbol_map:
            matches.add(self.symbol_map[name])
        for symbol, info in self.variables.items():
            aliases = [info.get("raw_name"), info.get("zh_name"), info.get("en_name")]
            if name in [normalize_symbol(alias) for alias in aliases if isinstance(alias, str)]:
                matches.add(symbol)
        if len(matches) != 1:
            raise FormulaError("ambiguous_binding" if matches else "unknown_symbol", f"变量不能唯一对应：{name}")
        return matches.pop()


def _validate_restricted(node: _ast.AST) -> None:
    """迭代验证实际 AST，包括常量、函数签名、深度和静态指数。"""
    if not isinstance(node, _ast.AST):
        raise FormulaError("parse_status", "缺少已解析表达式")
    stack = [(node, 0, False)]
    count = 0
    while stack:
        current, depth, function_position = stack.pop()
        count += 1
        if count > MAX_AST_NODES or depth > MAX_AST_DEPTH:
            raise FormulaError("resource_limit", "公式节点或深度超过预算")
        if isinstance(current, _ast.Expression):
            stack.append((current.body, depth + 1, False))
        elif isinstance(current, _ast.Constant):
            finite_real(current.value)
        elif isinstance(current, _ast.Name):
            if not current.id.isidentifier() or current.id.startswith("__"):
                raise FormulaError("parse_status", "非法变量名称")
            if current.id in _ALLOWED_FUNCS and not function_position:
                raise FormulaError("parse_status", "白名单函数名称不能作为普通变量")
        elif isinstance(current, _ast.BinOp):
            if type(current.op) not in _ALLOWED_BINOP:
                raise FormulaError("parse_status", "不支持的二元运算")
            if isinstance(current.op, _ast.Pow):
                exponent = current.right
                if isinstance(exponent, _ast.UnaryOp) and type(exponent.op) in _ALLOWED_UNOP:
                    exponent = exponent.operand
                if isinstance(exponent, _ast.Constant) and abs(finite_real(exponent.value)) > MAX_EXPONENT:
                    raise FormulaError("resource_limit", "幂指数超过预算")
            stack.extend([(current.left, depth + 1, False), (current.right, depth + 1, False)])
        elif isinstance(current, _ast.UnaryOp):
            if type(current.op) not in _ALLOWED_UNOP:
                raise FormulaError("parse_status", "不支持的一元运算")
            stack.append((current.operand, depth + 1, False))
        elif isinstance(current, _ast.Call):
            if not isinstance(current.func, _ast.Name) or current.func.id not in _ALLOWED_FUNCS or current.keywords:
                raise FormulaError("parse_status", "不支持的函数或关键字参数")
            arity = len(current.args)
            valid = (arity == 1 if current.func.id in {"abs", "sqrt"} else
                     arity in {1, 2} if current.func.id == "round" else 2 <= arity <= 16)
            if not valid:
                raise FormulaError("parse_status", "函数参数数量不合法")
            stack.append((current.func, depth + 1, True))
            stack.extend((argument, depth + 1, False) for argument in current.args)
        else:
            raise FormulaError("parse_status", f"不支持的结构：{type(current).__name__}")


def _tokenize_placeholders(expression: str) -> Tuple[str, List[str]]:
    """同名占位符复用生成名，替换前拒绝下标、嵌套和内部名碰撞。"""
    pattern = re.compile(r"\[([^\[\]\n]+)\]")
    plain = pattern.sub(" ", expression)
    if "[" in plain or "]" in plain or re.search(r"\b_v\d+\b", unicodedata.normalize("NFKC", plain)):
        raise FormulaError("parse_status", "方括号结构或内部符号名称冲突")
    names = []
    mapping = {}

    def replace(match):
        preceding = expression[:match.start()].rstrip()
        if preceding and (preceding[-1].isalnum() or preceding[-1] in "_)]"):
            raise FormulaError("parse_status", "不接受下标或隐式乘法")
        name = normalize_symbol(match.group(1))
        if (not name or len(name) > 128 or name in _ALLOWED_FUNCS or name.startswith("__")
                or re.fullmatch(r"_v\d+", unicodedata.normalize("NFKC", name)) or not any(character.isalpha() for character in name)
                or re.search(r"[=,:;{}<>+*/\\\"]", name)):
            # 占位符名称是隔离的文字标签，合法括号和英文所有格不进入 AST 代码。
            raise FormulaError("parse_status", "占位符名称不合法或含列表及注入结构")
        if name not in mapping:
            names.append(name)
            mapping[name] = f"_v{len(names)}"
        return mapping[name]
    return pattern.sub(replace, expression), names


def spec_from_user_formula(formula: str, variable_names: Optional[List[str]] = None,
                           source: str = "user_input") -> FormulaSpec:
    """单等式或纯算术式入口；不连接公式卡片、检索、模型或数据集。"""
    spec = FormulaSpec(formula_id="user_formula", expression=formula if isinstance(formula, str) else "",
                       source=source, parse_status="parse_error")
    try:
        if not isinstance(formula, str) or not formula.strip():
            raise FormulaError("parse_status", "公式为空")
        if len(formula) > MAX_FORMULA_LENGTH:
            raise FormulaError("resource_limit", "公式长度超过预算")
        if any(token in formula for token in ("±", "≈", "\x00", ";", "\n", "\r", "#")):
            raise FormulaError("parse_status", "公式包含歧义符号或非表达式内容")
        if formula.count("=") > 1:
            raise FormulaError("parse_status", "只接受一个明确等号")
        if re.search(r"\d{101,}", formula):
            raise FormulaError("resource_limit", "常量数字过长")
        code, names = _tokenize_placeholders(formula.strip())
        code = normalize_scientific(code).replace("×", "*").replace("÷", "/").replace("−", "-")
        code = code.replace("（", "(").replace("）", ")").replace("^", "**")
        # Python 标识符会做兼容归一；保守拒绝可能把两个原符号折叠成一个的写法。
        for token in tokenize.generate_tokens(io.StringIO(code).readline):
            if token.type == tokenize.NAME and unicodedata.normalize("NFKC", token.string) != normalize_symbol(token.string):
                raise FormulaError("parse_status", "兼容字形标识符需先明确确认，禁止静默合并变量")
        spec.symbol_map = {name: f"_v{index}" for index, name in enumerate(names, 1)}
        for index, name in enumerate(names, 1):
            alias = variable_names[index - 1] if variable_names and index <= len(variable_names) else name
            spec.variables[f"_v{index}"] = {"raw_name": name, "zh_name": alias, "en_name": name}
        body = code.strip()
        if "=" in code:
            lhs, body = [part.strip() for part in code.split("=")]
            if not lhs.isidentifier() or lhs in _ALLOWED_FUNCS or lhs.startswith("__"):
                raise FormulaError("parse_status", "等号左侧必须为单一目标量")
            spec.target_symbol = spec.symbol_map.get(lhs, lhs)
        elif re.fullmatch(r"_v\d+", body):
            raise FormulaError("parse_status", "单一占位符不构成计算式")
        tree = _ast.parse(body, mode="eval").body
        # 同一原名的显式变量和占位符共享语义，不让别名制造两个输入。
        for node in _ast.walk(tree):
            if isinstance(node, _ast.Name) and node.id in spec.symbol_map:
                node.id = spec.symbol_map[node.id]
        _validate_restricted(tree)
        spec.ast_tree = tree
        if spec.target_symbol in spec.input_symbols:
            raise FormulaError("parse_status", "自引用目标需要方程求解，不能直接代入")
        for symbol in spec.input_symbols:
            spec.variables.setdefault(symbol, {"raw_name": symbol, "zh_name": symbol, "en_name": symbol})
            spec.symbol_map.setdefault(symbol, symbol)
        if spec.target_symbol:
            spec.variables.setdefault(spec.target_symbol, {"raw_name": spec.target_symbol})
            spec.symbol_map.setdefault(spec.target_symbol, spec.target_symbol)
        spec.parse_status = "ok"
    except (FormulaError, SyntaxError, ValueError, RecursionError, tokenize.TokenError) as exc:
        spec.ast_tree = None
        spec.constraints = [str(exc)]
        spec.error_code = exc.code if isinstance(exc, FormulaError) else "parse_status"
    return spec


def parse_formula(expression: str) -> Tuple[str, Optional[_ast.AST], Optional[str]]:
    """兼容旧接口，所有表达式仍走同一个受限入口。"""
    spec = spec_from_user_formula(expression)
    return spec.parse_status, spec.ast_tree, spec.constraints[0] if spec.constraints else None


def spec_from_card(card: Dict) -> FormulaSpec:
    """兼容已有纯字典调用；此函数不加载卡片库或执行检索。"""
    spec = spec_from_user_formula(card.get("expression", ""), source=card.get("source", "formula_cards"))
    spec.formula_id = card.get("id", "unknown")
    spec.expected_unit = card.get("expected_unit")
    spec.display = card.get("display", "number")
    spec.output_representation = card.get("output_representation", "auto")
    for name, info in (card.get("variables") or {}).items():
        try:
            spec.variables[spec.resolve_symbol(name)].update(info or {})
        except FormulaError:
            continue
    return spec


def formula_cards_to_specs(cards: List[Dict]) -> List[FormulaSpec]:
    return [spec_from_card(card) for card in cards]
