"""受限 AST 安全计算器：实际分母求值、有限实数、量纲推导与结构化失败。"""
import ast
from decimal import Decimal
import json
import math
from typing import Dict

from .formula_spec import FormulaSpec, _validate_restricted, spec_from_user_formula
from .numeric_units import (FormulaError, MAX_EXPONENT, MAX_MAGNITUDE, Quantity,
                            canonical_unit, combine_dimensions, finite_real,
                            parse_real, parse_unit, power_dimensions, quantity_from_raw)


class SafeCalculator:
    """所有外部入口共用同一校验、绑定和求值流程，不执行生成程序。"""

    def compute(self, expression: str, bindings: Dict, expected_unit: str = None) -> Dict:
        spec = spec_from_user_formula(expression)
        spec.expected_unit = expected_unit
        return self.compute_spec(spec, bindings)

    def compute_spec(self, spec: FormulaSpec, bindings: Dict) -> Dict:
        """支持原名或生成名绑定；结果单位是推导后换算，失败没有可执行答案。"""
        base = {"ok": False, "result": None, "normalized_result": None, "unit": None,
                "steps": [], "trace": [], "error": None, "check_failed": None,
                "formula_id": getattr(spec, "formula_id", None),
                "expression": getattr(spec, "expression", None)}
        try:
            if not isinstance(spec, FormulaSpec) or spec.parse_status != "ok":
                raise FormulaError(getattr(spec, "error_code", None) or "parse_status", "公式未通过受限解析")
            _validate_restricted(spec.ast_tree)
            reparsed = spec_from_user_formula(spec.expression)
            if reparsed.parse_status != "ok":
                raise FormulaError(getattr(reparsed, "error_code", "parse_status"), "原公式不能通过重新解析")
            if ast.dump(reparsed.ast_tree) != ast.dump(spec.ast_tree) or reparsed.target_symbol != spec.target_symbol:
                raise FormulaError("ast_mismatch", "实际 AST 与原公式不一致")
            if spec.symbol_map != reparsed.symbol_map or any(
                    (spec.variables.get(symbol) or {}).get("raw_name") != info.get("raw_name")
                    for symbol, info in reparsed.variables.items()):
                raise FormulaError("symbol_map_mismatch", "原名映射与重新解析的符号身份不一致")
            if not isinstance(bindings, dict) or len(bindings) > 256:
                raise FormulaError("invalid_binding", "参数绑定必须是有限大小的字典")
            required = spec.input_symbols
            if spec.target_symbol in required:
                raise FormulaError("parse_status", "直接代入不允许自引用目标")
            base.update({"input_symbols": required, "symbol_map": dict(spec.symbol_map),
                         "target_symbol": spec.target_symbol})
            selected = {}
            for name, value in bindings.items():
                if not isinstance(name, str):
                    raise FormulaError("invalid_binding", "绑定名称必须为字符串")
                try:
                    symbol = spec.resolve_symbol(name)
                except FormulaError as exc:
                    if exc.code == "unknown_symbol":
                        # 额外变量不参与运算，但也不能携带非法数值而被静默放行。
                        if isinstance(value, dict):
                            quantity_from_raw(value.get("raw_value"), value.get("unit"), value.get("quantity_kind"))
                            if value.get("normalized_value") is not None:
                                parse_real(value["normalized_value"])
                        else:
                            quantity_from_raw(value)
                        continue
                    raise
                if symbol not in required:
                    continue
                if symbol in selected and selected[symbol] != value:
                    raise FormulaError("ambiguous_binding", f"变量存在冲突绑定：{symbol}")
                selected[symbol] = value
            missing = [symbol for symbol in required if symbol not in selected or selected[symbol] is None]
            if missing:
                raise FormulaError("missing_bindings", f"缺少必要绑定：{missing}")
            environment = {}
            binding_details = {}
            for symbol in required:
                supplied = selected[symbol]
                info = spec.variables.get(symbol) or {}
                if isinstance(supplied, dict):
                    if "raw_value" not in supplied or supplied["raw_value"] is None:
                        raise FormulaError("missing_bindings", f"缺少原始数值：{symbol}")
                    unit = supplied.get("unit")
                    if unit is None:
                        unit = info.get("unit")
                    quantity = quantity_from_raw(supplied["raw_value"], unit, supplied.get("quantity_kind"))
                    claimed = supplied.get("normalized_value")
                    if claimed is not None and not math.isclose(parse_real(claimed), quantity.value, rel_tol=1e-12, abs_tol=1e-12):
                        raise FormulaError("normalization_conflict", f"规范化值与原数值及单位不一致：{symbol}")
                    source = supplied.get("source")
                    raw = supplied["raw_value"]
                else:
                    unit, raw, source = info.get("unit"), supplied, None
                    quantity = quantity_from_raw(raw, unit)
                if source is not None:
                    try:
                        if not isinstance(source, (dict, str)) or len(json.dumps(source, ensure_ascii=False, allow_nan=False)) > 8192:
                            raise ValueError("来源格式或大小非法")
                    except (TypeError, ValueError, RecursionError):
                        raise FormulaError("invalid_binding", "来源必须是有界且可JSON序列化的字典或文字") from None
                if isinstance(raw, Decimal):
                    raw = str(raw)
                environment[symbol] = quantity
                binding_details[symbol] = {"raw_name": info.get("raw_name", symbol), "raw_value": raw,
                                           "unit": unit, "normalized_value": quantity.value,
                                           "normalized_unit": canonical_unit(quantity.dimensions), "source": source}
            typed = spec.expected_unit is not None or any(q.explicit_unit for q in environment.values())
            if typed and any(not q.explicit_unit for q in environment.values()):
                raise FormulaError("missing_unit", "带单位计算的全部必要输入需明确单位，无量纲请显式声明 1")
            trace = []
            result = self._eval(spec.ast_tree, environment, trace)
            representation = spec.output_representation
            if representation not in ("auto", "ratio", "percent_number"):
                raise FormulaError("unsupported_display", "未知输出表示约定")
            if representation == "percent_number":
                if result.dimensions:
                    raise FormulaError("unit_mismatch", "百分数表示要求无量纲结果")
                result = Quantity(finite_real(result.value / 100), (), True)
            if spec.display == "percent":
                if result.dimensions:
                    raise FormulaError("unit_mismatch", "有量纲结果不能显示为百分数")
                if representation == "auto" and any(isinstance(n, ast.Constant) and n.value == 100 for n in ast.walk(spec.ast_tree)):
                    raise FormulaError("ambiguous_representation", "公式含 100 时需声明结果为 ratio 或 percent_number，避免双重换算")
            elif spec.display != "number":
                raise FormulaError("unsupported_display", "未知展示形式")
            if (spec.display == "number" and isinstance(spec.expected_unit, str)
                    and spec.expected_unit.strip() in {"%", "百分比"} and not result.dimensions
                    and representation == "auto"
                    and any(isinstance(n, ast.Constant) and n.value == 100 for n in ast.walk(spec.ast_tree))):
                raise FormulaError("ambiguous_representation", "公式含 100 且请求百分数单位时需明确结果表示，避免双重换算")
            value = finite_real(result.value)
            output_unit = canonical_unit(result.dimensions) if typed else None
            if spec.expected_unit is not None:
                # 转数单位（r、r/min、rev、rpm）词典已撤回，经 parse_unit 全面拒绝；
                # 仅在字符串情形下做带稳定错误码的显式边界，非字符串交回 parse_unit
                # 返回结构化 missing_unit，不允许裸 AttributeError 漏出。
                if isinstance(spec.expected_unit, str) and spec.expected_unit.strip().lower() in ("r", "r/min", "rev", "rpm"):
                    raise FormulaError("unsupported_unit", "转数单位本轮不支持，弧度结果不能按转数输出")
                expected = parse_unit(spec.expected_unit)
                if expected.dimensions != result.dimensions:
                    raise FormulaError("unit_mismatch", "推导结果与期望输出单位量纲不同")
                value = finite_real(result.value / expected.scale)
                output_unit = spec.expected_unit or "1"
            base.update({"ok": True, "result": value, "normalized_result": result.value,
                         "unit": output_unit, "normalized_unit": canonical_unit(result.dimensions),
                         "unit_check": "validated" if typed else "scalar_only",
                         "bindings": binding_details, "trace": trace,
                         "steps": [f"{symbol} = {detail['normalized_value']:.12g} {detail['normalized_unit']}"
                                   for symbol, detail in binding_details.items()] +
                                  [f"结果 = {value:.12g}"],
                         "display_value": f"{result.value * 100:.6g}%" if spec.display == "percent" else f"{value:.12g}",
                         "output_representation": representation})
            return base
        except FormulaError as exc:
            base.update({"error": str(exc), "check_failed": exc.code})
        except (ZeroDivisionError, OverflowError, ValueError, TypeError, RecursionError) as exc:
            code = "divide_by_zero" if isinstance(exc, ZeroDivisionError) else "domain_error"
            base.update({"error": f"受控计算失败：{type(exc).__name__}", "check_failed": code})
        return base

    def _eval(self, node, environment, trace):
        """执行已经重新校验的 AST，每次运算记录真实规范数值与量纲。"""
        if isinstance(node, ast.Constant):
            return Quantity(finite_real(node.value))
        if isinstance(node, ast.Name):
            if node.id not in environment:
                raise FormulaError("missing_bindings", f"未绑定变量：{node.id}")
            return environment[node.id]
        if isinstance(node, ast.UnaryOp):
            operand = self._eval(node.operand, environment, trace)
            result = Quantity(finite_real(-operand.value if isinstance(node.op, ast.USub) else operand.value), operand.dimensions)
            operation, arguments = type(node.op).__name__, [operand]
        elif isinstance(node, ast.BinOp):
            left = self._eval(node.left, environment, trace)
            right = self._eval(node.right, environment, trace)
            operation, arguments = type(node.op).__name__, [left, right]
            if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)) and right.value == 0:
                raise FormulaError("divide_by_zero", "实际除数表达式为零")
            if isinstance(node.op, (ast.Add, ast.Sub, ast.Mod, ast.FloorDiv)):
                if left.dimensions != right.dimensions:
                    raise FormulaError("unit_mismatch", "加减、取余及整除要求兼容量纲")
                if isinstance(node.op, ast.Add):
                    value = left.value + right.value
                elif isinstance(node.op, ast.Sub):
                    value = left.value - right.value
                elif isinstance(node.op, ast.Mod):
                    value = left.value % right.value
                else:
                    value = left.value // right.value
                dimensions = () if isinstance(node.op, ast.FloorDiv) else left.dimensions
            elif isinstance(node.op, (ast.Mult, ast.Div)):
                divide = isinstance(node.op, ast.Div)
                value = left.value / right.value if divide else left.value * right.value
                dimensions = combine_dimensions(left.dimensions, right.dimensions, -1 if divide else 1)
                if left.value and right.value and value == 0:
                    raise FormulaError("resource_limit", "中间数值下溢")
            elif isinstance(node.op, ast.Pow):
                exponent = right.value
                if right.dimensions:
                    raise FormulaError("unit_mismatch", "幂指数必须无量纲")
                if abs(exponent) > MAX_EXPONENT:
                    raise FormulaError("resource_limit", "运行时幂指数超过预算")
                if left.value == 0 and exponent < 0:
                    raise FormulaError("divide_by_zero", "零不能取负幂")
                if left.value < 0 and not exponent.is_integer():
                    raise FormulaError("domain_error", "负数的非整数幂不属于支持的实数域")
                if left.value and math.log10(abs(left.value)) * exponent > math.log10(MAX_MAGNITUDE):
                    raise FormulaError("resource_limit", "幂结果超过预算，执行前停止")
                if left.dimensions:
                    literal = node.right.operand if isinstance(node.right, ast.UnaryOp) else node.right
                    if not isinstance(literal, ast.Constant) or not exponent.is_integer():
                        raise FormulaError("unsupported_unit", "有量纲的幂要求常整数指数")
                dimensions = power_dimensions(left.dimensions, int(exponent)) if left.dimensions else ()
                value = left.value ** exponent
                if left.value and value == 0:
                    raise FormulaError("resource_limit", "幂结果下溢")
            else:
                raise FormulaError("parse_status", "不支持的运算")
            result = Quantity(finite_real(value), dimensions)
        elif isinstance(node, ast.Call):
            operation = node.func.id
            arguments = [self._eval(argument, environment, trace) for argument in node.args]
            first = arguments[0]
            if operation in ("min", "max"):
                if any(argument.dimensions != first.dimensions for argument in arguments):
                    raise FormulaError("unit_mismatch", "极值函数的量纲不一致")
                chosen = (min if operation == "min" else max)(arguments, key=lambda q: q.value)
                result = Quantity(chosen.value, chosen.dimensions)
            elif operation == "abs":
                result = Quantity(abs(first.value), first.dimensions)
            elif operation == "round":
                digits = 0
                if len(arguments) == 2:
                    second = arguments[1]
                    if second.dimensions or not second.value.is_integer() or abs(second.value) > 15:
                        raise FormulaError("domain_error", "舍入位数必须是 -15 至 15 的无量纲整数")
                    digits = int(second.value)
                result = Quantity(finite_real(round(first.value, digits)), first.dimensions)
            elif operation == "sqrt":
                if first.value < 0 or any(power % 2 for _, power in first.dimensions):
                    raise FormulaError("domain_error", "平方根要求非负实数及偶数量纲指数")
                result = Quantity(finite_real(math.sqrt(first.value)), tuple((key, power // 2) for key, power in first.dimensions))
            else:
                raise FormulaError("parse_status", "不支持的函数")
        else:
            raise FormulaError("parse_status", "不支持的 AST 结构")
        trace.append({"operation": operation,
                      "inputs": [{"value": q.value, "unit": canonical_unit(q.dimensions)} for q in arguments],
                      "result": result.value, "unit": canonical_unit(result.dimensions)})
        return result

    @staticmethod
    def _to_number(value):
        """兼容旧工具调用，采用完整且有限的数值解析。"""
        return parse_real(value)
