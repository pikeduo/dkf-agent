"""有限实数、线性单位和量纲工具；仅使用标准库，不读取任何数据集。"""
import ast
import math
import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Optional

MAX_TEXT = 256
MAX_MAGNITUDE = 1e100
MAX_EXPONENT = 100
SUPERSCRIPTS = str.maketrans("⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹", "+-0123456789")
DECIMAL = r"[+-]?(?:\d{1,3}(?:,\d{3})+(?:\.\d*)?|\d+(?:\.\d*)?|\.\d+)"
NUMBER_TOKEN = re.compile(rf"(?:{DECIMAL})(?:[eE][+-]?\d+)?")


class FormulaError(ValueError):
    """携带稳定失败代码的受控异常。"""
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def finite_real(value) -> float:
    """拒绝布尔、复数、非有限值和超预算数值，不执行对象自定义转换。"""
    if type(value) not in (int, float, Decimal):
        raise FormulaError("invalid_number", "参数必须是有限实数")
    if isinstance(value, int) and value.bit_length() > 340:
        raise FormulaError("resource_limit", "整数超过数值预算")
    try:
        number = float(value)
    except (ValueError, OverflowError):
        raise FormulaError("invalid_number", "参数无法转换为有限实数") from None
    if not math.isfinite(number):
        raise FormulaError("non_finite", "禁止非有限数值")
    if abs(number) > MAX_MAGNITUDE:
        raise FormulaError("resource_limit", "数值超过范围预算")
    return number


def normalize_scientific(text: str) -> str:
    """只归一明确科学计数写法；指数按位转写，不相加。"""
    text = text.replace("−", "-").strip()
    text = re.sub(r"10([⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)",
                  lambda m: "10^" + m.group(1).translate(SUPERSCRIPTS), text)
    text = re.sub(r"10\s*\^\s*\{([+-]?\d+)\}", r"10^\1", text)
    text = re.sub(rf"({DECIMAL})\s*[×*]\s*10\s*\^\s*([+-]?\d+)",
                  lambda m: m.group(1) + "e" + m.group(2), text)
    text = re.sub(r"(?<![\w.])10\s*\^\s*([+-]?\d+)", r"1e\1", text)
    return text


def parse_real(value) -> float:
    """完整解析一个数值，不截取数字前缀、不计算任意字符串。"""
    if type(value) in (int, float, Decimal):
        return finite_real(value)
    if not isinstance(value, str) or not value.strip():
        raise FormulaError("invalid_number", "缺少完整数值")
    if len(value) > MAX_TEXT:
        raise FormulaError("resource_limit", "数值文本过长")
    text = normalize_scientific(value)
    if not NUMBER_TOKEN.fullmatch(text):
        raise FormulaError("invalid_number", "数值文本含不支持或含糊的结构")
    exponent = re.search(r"[eE]([+-]?\d+)$", text)
    if exponent and (len(exponent.group(1)) > 5 or abs(int(exponent.group(1))) > MAX_EXPONENT):
        raise FormulaError("resource_limit", "科学计数指数超过预算")
    try:
        decimal = Decimal(text.replace(",", ""))
    except InvalidOperation:
        raise FormulaError("invalid_number", "无法解析数值") from None
    number = finite_real(decimal)
    if decimal != 0 and number == 0:
        raise FormulaError("resource_limit", "数值下溢")
    return number


def _dims(**powers):
    return tuple(sorted((key, power) for key, power in powers.items() if power))


def combine_dimensions(left, right, sign=1):
    powers = dict(left)
    for key, power in right:
        powers[key] = powers.get(key, 0) + sign * power
    if any(abs(power) > 16 for power in powers.values()):
        raise FormulaError("resource_limit", "量纲指数超过预算")
    return tuple(sorted((key, power) for key, power in powers.items() if power))


def power_dimensions(dimensions, exponent: int):
    return combine_dimensions((), tuple((key, power * exponent) for key, power in dimensions))


@dataclass(frozen=True)
class Unit:
    """尺度相对规范单位，量纲中的币种和计数语义不自动合并。"""
    scale: float = 1.0
    dimensions: tuple = ()
    symbol: str = "1"


_BASE = {
    "1": Unit(), "%": Unit(0.01, (), "%"), "bps": Unit(0.0001, (), "bps"),
    "m": Unit(1, _dims(m=1), "m"), "dm": Unit(.1, _dims(m=1), "dm"),
    "cm": Unit(.01, _dims(m=1), "cm"),
    "mm": Unit(.001, _dims(m=1), "mm"), "km": Unit(1000, _dims(m=1), "km"),
    "kg": Unit(1, _dims(kg=1), "kg"), "g": Unit(.001, _dims(kg=1), "g"),
    "mg": Unit(1e-6, _dims(kg=1), "mg"), "t": Unit(1000, _dims(kg=1), "t"),
    "s": Unit(1, _dims(s=1), "s"), "ms": Unit(.001, _dims(s=1), "ms"),
    "min": Unit(60, _dims(s=1), "min"), "h": Unit(3600, _dims(s=1), "h"),
    "A": Unit(1, _dims(A=1), "A"), "mA": Unit(.001, _dims(A=1), "mA"),
    "K": Unit(1, _dims(K=1), "K"),
    "N": Unit(1, _dims(kg=1, m=1, s=-2), "N"),
    "J": Unit(1, _dims(kg=1, m=2, s=-2), "J"),
    "kJ": Unit(1000, _dims(kg=1, m=2, s=-2), "kJ"),
    "W": Unit(1, _dims(kg=1, m=2, s=-3), "W"),
    "kW": Unit(1000, _dims(kg=1, m=2, s=-3), "kW"),
    "Pa": Unit(1, _dims(kg=1, m=-1, s=-2), "Pa"),
    "kPa": Unit(1000, _dims(kg=1, m=-1, s=-2), "kPa"),
    "MPa": Unit(1e6, _dims(kg=1, m=-1, s=-2), "MPa"),
    "V": Unit(1, _dims(kg=1, m=2, s=-3, A=-1), "V"),
    "ohm": Unit(1, _dims(kg=1, m=2, s=-3, A=-2), "ohm"),
    "C": Unit(1, _dims(A=1, s=1), "C"), "Hz": Unit(1, _dims(s=-1), "Hz"),
    "L": Unit(.001, _dims(m=3), "L"), "mL": Unit(1e-6, _dims(m=3), "mL"),
    "CNY": Unit(1, _dims(CNY=1), "CNY"), "USD": Unit(1, _dims(USD=1), "USD"),
    "万元": Unit(10000, _dims(CNY=1), "万元"),
    "人": Unit(1, _dims(person=1), "人"), "个": Unit(1, _dims(item=1), "个"),
    # rad 按无量纲弧度处理并保留；转数 r 本轮保守不支持（不提供 r=rad 换算，
    # 也不把 rad 推导结果按转数输出），避免 2π 边界歧义。
    "rad": Unit(),
}
# 温差内部 token 不进入公共 _BASE：摄氏温差 scale=1、华氏温差 scale=5/9，量纲均为 K。
# 该受控表仅在 parse_unit 内部解析授权温差时使用，外部调用方直接提供这些名称
# （含全角等 NFKC 兼容写法）都查不到，不能绕过歧义拒绝。
_TEMP_TOKENS = {"tdC": Unit(1, _dims(K=1), "tdC"), "tdF": Unit(5 / 9, _dims(K=1), "tdF")}
# 私有保留命名空间：_tp数字（解析器受控占位名）、_t_数字（历史备用名）及 tdC/tdF。
# 词边界保证只匹配完整标识符，不误伤包含这些子串的合法单位写法。
_RESERVED_UNIT_TOKEN = re.compile(r"\b(?:_tp\d+|_t_\d+|tdC|tdF)\b")
_ALIASES = {"米": "m", "厘米": "cm", "毫米": "mm", "千米": "km", "公里": "km",
            "千克": "kg", "克": "g", "吨": "t", "秒": "s", "分钟": "min", "小时": "h",
            "牛": "N", "牛顿": "N", "焦": "J", "焦耳": "J", "瓦": "W", "瓦特": "W",
            "伏": "V", "伏特": "V", "欧姆": "ohm", "Ω": "ohm", "安": "A", "安培": "A",
            "升": "L", "l": "L", "毫升": "mL", "分米": "dm", "元": "CNY", "人民币": "CNY", "美元": "USD",
            "百分比": "%", "无量纲": "1", "dimensionless": "1"}
# 裸中文温标不作为别名提供：摄氏/华氏的绝对或温差含义含糊，
# 必须由调用方显式授权温差，而不是靠词典映射悄悄按温差处理。


def canonical_unit(dimensions) -> str:
    """规范显示不用猜测物理量名称。"""
    return "*".join(key if power == 1 else f"{key}^{power}" for key, power in dimensions) or "1"


def parse_unit(text: Optional[str], quantity_kind: Optional[str] = None) -> Unit:
    """有限线性单位语法；裸摄氏/华氏默认拒绝歧义温标。

    显式温差记号（每个温标紧邻 Δ/delta）与 quantity_kind='temperature_difference'
    可单独或并用授权按开尔文温差规范化（摄氏尺度 1、华氏尺度 5/9，量纲 K）；
    坏前缀（xΔ°C、5Δ°C、deltafoo°C）一律拒绝。
    """
    if text is None or not isinstance(text, str):
        raise FormulaError("missing_unit", "缺少明确单位")
    raw = text.strip()
    if len(raw) > 128:
        raise FormulaError("resource_limit", "单位文本过长")
    if raw in ("", "1"):
        return Unit()
    # 私有保留命名空间（_tp数字、_t_数字、tdC/tdF）的用户token在NFKC归一后整体扫描拒绝；
    # 规范化仅用于保留名拒绝，不用于单位计算，避免引入大小写/字形歧义。
    # 全角等兼容写法（如_ｔｐ０）也会被归一后命中，防止夹带进合法温差表达式绕过检查。
    if _RESERVED_UNIT_TOKEN.search(unicodedata.normalize("NFKC", raw)):
        raise FormulaError("unsupported_unit", "私有保留单位token不是合法用户单位")
    # 摄氏/华氏歧义检查：绝对温度或温差默认含糊（本量纲系统无参考零点），一律拒绝，
    # 只有明确温差记号或显式 kind 授权（可并用）才允许按 K 温差规范化；
    # 不按变量名或公式长相猜含义。
    _TEMP = (("℃", "tdC", "C"), ("°C", "tdC", "C"), ("℉", "tdF", "F"), ("°F", "tdF", "F"))
    occurrences = []
    for symbol, token, kind in _TEMP:
        start = 0
        while True:
            idx = raw.find(symbol, start)
            if idx < 0:
                break
            occurrences.append((idx, idx + len(symbol), token, kind))
            start = idx + len(symbol)
    kinds = {kind for _, _, _, kind in occurrences}
    if "C" in kinds and "F" in kinds:
        raise FormulaError("unsupported_unit", "摄氏与华氏温差混合的复合单位暂不支持")
    explicit_difference = quantity_kind == "temperature_difference"

    def prefix_cut(text_before):
        """返回温标紧邻前缀中 Δ/delta 标记的裁切位置；无标记则返回 None。

        标记必须紧邻温标：前面可以是单位边界（括号、点、乘号等），
        坏前缀 xΔ°C、deltafoo°C 一律拒绝，delta 自身不能夹带其他字母。
        """
        if text_before.endswith("Δ"):
            before = text_before[:-1]
            if before and (before[-1].isalnum() or before[-1] == "_"):
                return None
            return len(before)
        lower = text_before.lower()
        if lower.endswith("delta"):
            before = lower[:-5]
            if before and (before[-1].isalnum() or before[-1] == "_"):
                return None
            return len(before)
        return None

    if occurrences:
        code = raw
        # 先识别并去除合法显式温差前缀（紧邻 Δ/delta），kind 授权仅在前缀缺失时兜底，
        # 两者并用也成功；坏前缀（xΔ°C、5Δ°C、deltafoo°C）严格拒绝。
        # 每个真实温标替换为私有占位名（_tp0/_tp1…），可追溯为原文位置+显式授权；
        # 用户直接写出的内部token（ASCII或全角兼容）不产生占位名，无法进入映射表。
        placeholder_map = {}
        temp_trace = []
        for seq, (idx, end, _token, kind) in enumerate(sorted(occurrences, reverse=True)):
            cut = prefix_cut(raw[:idx])
            if cut is None:
                cut = idx if explicit_difference else None
            if cut is None:
                raise FormulaError("unsupported_unit",
                                   "裸摄氏/华氏温标歧义（绝对或温差）被拒绝；请提供显式Δ/delta温差记号或温差kind授权")
            placeholder = f"_tp{seq}"
            placeholder_map[placeholder] = _TEMP_TOKENS["tdC" if kind == "C" else "tdF"]
            temp_trace.append({"seq": seq, "origin": raw[idx:end], "kind": kind, "auth": "delta_prefix" if cut != idx else "quantity_kind"})
            code = code[:cut] + placeholder + code[end:]
        # 拒绝夹带的私有占位名或内部token：占位名仅在上方受控生成时才合法，
        # 用户原文自带 _tpN/tdC/tdF 会被 AST 识别但查不到映射，走未知单位拒绝。
    else:
        code = _ALIASES.get(raw, raw)
        if code in _BASE:
            return _BASE[code]
        placeholder_map = {}
    # 两个分支均须将乘号字符归一为 *，保证复合单位（如 J/(kg·℃)）可被 AST 解析。
    code = code.replace("·", "*").replace("⋅", "*").replace("•", "*").replace("×", "*").replace("÷", "/")
    code = re.sub(r"([⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)", lambda m: "^" + m.group(1).translate(SUPERSCRIPTS), code)
    code = re.sub(r"\^\{([+-]?\d+)\}", r"^\1", code)
    code = re.sub(r"(?<=[\w)])\s+(?=[\w(])", "*", code).replace("^", "**")
    try:
        tree = ast.parse(code, mode="eval").body
    except (SyntaxError, ValueError, RecursionError):
        raise FormulaError("unsupported_unit", f"单位语法不支持：{raw}") from None
    stack = [(tree, 0)]
    count = 0
    while stack:
        node, depth = stack.pop()
        count += 1
        if count > 64 or depth > 16:
            raise FormulaError("resource_limit", "单位结构超过预算")
        stack.extend((child, depth + 1) for child in ast.iter_child_nodes(node))

    def walk(node):
        if isinstance(node, ast.Name):
            # 全角等 NFKC 兼容写法会归一到私有内部token；凡非受控占位映射的用户侧
            # 同名标识一律拒绝，不能靠词典映射绕过歧义检查。
            if unicodedata.normalize("NFKC", node.id) in ("tdC", "tdF") and node.id not in placeholder_map:
                raise FormulaError("unsupported_unit", "温差内部token不是合法用户单位")
            if node.id in placeholder_map:
                return placeholder_map[node.id]
            name = _ALIASES.get(node.id, node.id)
            if name not in _BASE:
                raise FormulaError("unsupported_unit", f"未知单位：{node.id}")
            return _BASE[name]
        if isinstance(node, ast.Constant) and type(node.value) is int and node.value == 1:
            return Unit()
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Mult, ast.Div)):
            left, right = walk(node.left), walk(node.right)
            divide = isinstance(node.op, ast.Div)
            scale = finite_real(left.scale / right.scale if divide else left.scale * right.scale)
            return Unit(scale, combine_dimensions(left.dimensions, right.dimensions, -1 if divide else 1), raw)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            exponent_node = node.right
            sign = 1
            if isinstance(exponent_node, ast.UnaryOp) and isinstance(exponent_node.op, (ast.USub, ast.UAdd)):
                sign = -1 if isinstance(exponent_node.op, ast.USub) else 1
                exponent_node = exponent_node.operand
            if not isinstance(exponent_node, ast.Constant) or type(exponent_node.value) is not int:
                raise FormulaError("unsupported_unit", "单位幂必须是常整数")
            exponent = sign * exponent_node.value
            if abs(exponent) > 12:
                raise FormulaError("resource_limit", "单位幂超过预算")
            base = walk(node.left)
            return Unit(finite_real(base.scale ** exponent), power_dimensions(base.dimensions, exponent), raw)
        raise FormulaError("unsupported_unit", f"单位结构不支持：{raw}")
    return walk(tree)


@dataclass(frozen=True)
class Quantity:
    """数值已换算为规范单位；显式单位标志区分缺失单位与无量纲。"""
    value: float
    dimensions: tuple = ()
    explicit_unit: bool = False


def split_number_unit(value):
    """允许完整的数值加单位，但不接受数值前后的解释文字。"""
    if type(value) in (int, float, Decimal):
        return finite_real(value), None
    if not isinstance(value, str) or len(value) > MAX_TEXT:
        raise FormulaError("invalid_number", "数值类型非法或文本过长")
    text = normalize_scientific(value)
    match = NUMBER_TOKEN.match(text)
    if not match:
        raise FormulaError("invalid_number", "未找到完整数值")
    number = parse_real(match.group(0))
    suffix = text[match.end():].strip()
    return number, suffix or None


def quantity_from_raw(raw_value, unit=None, quantity_kind=None) -> Quantity:
    """只从原始数值和单位确定性规范化，不采用模型的规范化值。"""
    number, embedded = split_number_unit(raw_value)
    chosen = unit if unit is not None else embedded
    if chosen is None:
        return Quantity(number)
    parsed = parse_unit(chosen, quantity_kind)
    if embedded is not None and unit is not None:
        actual = parse_unit(embedded, quantity_kind)
        if actual.dimensions != parsed.dimensions or not math.isclose(actual.scale, parsed.scale, rel_tol=1e-12):
            raise FormulaError("unit_mismatch", "原始数值中的单位与声明单位冲突")
    return Quantity(finite_real(number * parsed.scale), parsed.dimensions, True)
