"""
任务6：公式提取与结构化（可选能力，非主链路）。
主链路场景为「用户提供公式」：公式原文由用户给出，直接走
spec_from_user_formula + SafeCalculator 计算，不需要从卡片库检索/选公式。
本模块保留用于后续"用户只给公式名称、需按库补定义"的扩展场景。

边界说明（来自精读）：
- 视觉/LaTeX 转写结果不是“已验证可运算 AST”。
- 需另建语义解析、白名单函数、单位/条件/主体绑定与除零检查。
"""
from typing import List, Dict, Optional


class FormulaExtractor:
    """从文档抽取候选公式并做结构化。

    边界说明（来自精读）：
    - 视觉/LaTeX 转写结果不是“已验证可运算 AST”。
    - 需另建语义解析、白名单函数、单位/条件/主体绑定与除零检查。
    """

    def __init__(self, llm_client, ocr_client=None) -> None:
        self.llm = llm_client
        self.ocr = ocr_client

    def extract(self, question: str, document_text: str, knowledge_cards: List[Dict]) -> List[Dict]:
        """结合问题与知识库卡片，选出适用公式候选。

        每个候选：
        {
            "formula_id": ...,
            "name": ...,
            "latex": ...,
            "variables": [...],
            "applicable": 需在上层校验主体/期间/条件,
            "source_card": ...
        }
        """
        candidates: List[Dict] = []
        for card in knowledge_cards:
            # 粗匹配：公式名或变量与问题词重叠
            overlap = self._term_overlap(question, card)
            if overlap:
                candidates.append({
                    "formula_id": card.get("id"),
                    "name": card.get("name"),
                    "latex": card.get("expression"),
                    "variables": list(card.get("variables", {}).keys()),
                    "applicable": card.get("适用条件", []),
                    "source_card": card.get("id"),
                    "match_score": overlap,
                })
        # 按匹配度排序
        candidates.sort(key=lambda c: c["match_score"], reverse=True)
        return candidates

    @staticmethod
    def _term_overlap(question: str, card: Dict) -> int:
        """问题与卡片的词重叠数（启发式）。"""
        import re
        q_tokens = set(re.findall(r"[\u4e00-\u9fffA-Za-z]{2,}", question.lower()))
        card_text = " ".join([
            card.get("name", ""),
            card.get("expression", ""),
            " ".join(card.get("variables", {}).keys()),
        ]).lower()
        c_tokens = set(re.findall(r"[\u4e00-\u9fffA-Za-z]{2,}", card_text))
        return len(q_tokens & c_tokens)
