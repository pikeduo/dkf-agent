"""严格参数取证：完整数值、变量关联、原单位和真实来源共同验证。"""
import json
import re
from typing import Dict, List, Optional

from .formula_spec import normalize_symbol
from .numeric_units import FormulaError, canonical_unit, quantity_from_raw, split_number_unit


class ParamFinder:
    """先读取明确赋值，模型仅可提出有原文支持的候选，不能决定规范化值。"""

    def __init__(self, llm_client=None, vector_store=None) -> None:
        self.llm = llm_client
        self.vector_store = vector_store

    def bind(self, formula_id: str, variables: List[str], question: str, context: str,
             document_text: Optional[str] = None) -> List[Dict]:
        if (not isinstance(variables, (list, tuple)) or len(variables) > 64
                or any(not isinstance(variable, str) or not variable.strip() or len(variable) > 128 for variable in variables)):
            return [{"formula_id": formula_id, "symbol": None, "status": "missing",
                     "error_code": "invalid_binding", "note": "变量清单非法或超出预算"}]
        found_map = self._find_values(variables, question, context, document_text)
        bindings = []
        for variable in variables:
            found = found_map.get(variable)
            if found and not found.get("error_code"):
                item = dict(found)
                item.pop("_reverified", None)
                item.update({"formula_id": formula_id, "symbol": variable, "status": "bound", "reverified": True})
            else:
                error = found.get("error_code") if found else "missing_evidence"
                item = {"formula_id": formula_id, "symbol": variable,
                        "status": "conflict" if error == "ambiguous_evidence" else "missing",
                        "error_code": error, "note": "未找到唯一证据或数值、单位校验失败"}
                if found and found.get("source"):
                    item["source"] = found["source"]
            bindings.append(item)
        return bindings

    @staticmethod
    def _assignments(variable, text, source_kind):
        """只接明确的变量赋值；数值在别的指标旁边出现不算证据。"""
        if not isinstance(text, str) or len(text) > 200000:
            return []
        name = re.escape(normalize_symbol(variable))
        pattern = re.compile(rf"(?<!\w){name}(?!\w)\s*(?:=|:|：|为|是)\s*")
        candidates = []
        for match in pattern.finditer(text):
            remaining = text[match.end():]
            boundary = re.search(r"[;；，。\n]|,\s*(?=[^,=]{1,128}=)", remaining)
            end = match.end() + (boundary.start() if boundary else len(remaining))
            raw_text = text[match.end():end].strip().rstrip(",")
            if not raw_text or len(raw_text) > 256:
                continue
            try:
                quantity = quantity_from_raw(raw_text)
                raw, unit = split_number_unit(raw_text)
            except FormulaError as exc:
                candidates.append({"error_code": exc.code,
                                   "source": {"kind": source_kind, "quote": text[match.start():end],
                                              "start": match.start(), "end": end}})
                continue
            candidates.append({"raw_value": raw, "raw_text": raw_text, "unit": unit,
                               "normalized_value": quantity.value,
                               "normalized_unit": canonical_unit(quantity.dimensions),
                               "source": {"kind": source_kind, "quote": text[match.start():end],
                                          "start": match.start(), "end": end},
                               "_quantity": quantity})
        return candidates

    def _find_values(self, variables, question, context, document_text):
        if not variables:
            return {}
        if (not isinstance(variables, (list, tuple)) or len(variables) > 64
                or any(not isinstance(variable, str) or not variable.strip() or len(variable) > 128 for variable in variables)):
            return {}
        sources = [("user_input", question or ""), ("context", context or ""),
                   ("document", document_text or "")]
        if any(not isinstance(text, str) for _, text in sources) or sum(len(text) for _, text in sources) > 200000:
            return {variable: {"error_code": "resource_limit"} for variable in variables}
        result = {}
        for variable in variables:
            candidates = [item for kind, text in sources for item in self._assignments(variable, text, kind)]
            source_errors = [item for item in candidates if item.get("error_code")]
            if source_errors:
                # 找到参数但单位或数值非法时明确停止，不伪装成没有来源或交给模型猜。
                result[variable] = dict(source_errors[0])
                continue
            signatures = {(item["_quantity"].value, item["_quantity"].dimensions,
                           item["_quantity"].explicit_unit) for item in candidates}
            if len(signatures) > 1:
                result[variable] = {"error_code": "ambiguous_evidence"}
            elif candidates:
                chosen = dict(candidates[0])
                chosen.pop("_quantity")
                result[variable] = chosen
        missing = [variable for variable in variables if variable not in result]
        if not missing or self.llm is None or not any(text for _, text in sources):
            return result
        # 候选不能替代来源校验；单次调用且不传入任何评测答案。
        prompt = ("为明确变量提出来源候选。返回JSON对象，键必须与变量原名完全一致，"
                  "值含raw_value、unit、source_quote、entity、period。找不到就返回null；不要转换数值。\n"
                  + json.dumps({"variables": missing, "sources": sources}, ensure_ascii=False))
        try:
            raw = self.llm.chat([{"role": "user", "content": prompt}], temperature=0.0, reasoning_effort=None)
            if not isinstance(raw, str) or len(raw) > 65536:
                return result
            text = raw.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
            data = json.loads(text)
            if not isinstance(data, dict):
                return result
        except Exception:
            return result
        for variable in missing:
            matches = [value for key, value in data.items()
                       if isinstance(key, str) and normalize_symbol(key) == normalize_symbol(variable)]
            if len(matches) != 1 or not isinstance(matches[0], dict):
                continue
            proposal = matches[0]
            quote = proposal.get("source_quote")
            if not isinstance(quote, str) or not quote or not any(quote in text for _, text in sources):
                continue
            try:
                claimed = quantity_from_raw(proposal.get("raw_value"), proposal.get("unit"))
            except FormulaError:
                continue
            verified = self._assignments(variable, quote, "verified_quote")
            verified = [item for item in verified if item.get("_quantity") == claimed]
            if len(verified) != 1:
                continue
            chosen = dict(verified[0])
            chosen.pop("_quantity")
            if any(proposal.get(field) is not None and str(proposal[field]) not in quote for field in ("entity", "period")):
                continue
            chosen.update({field: proposal.get(field) for field in ("entity", "period")})
            # 引文仍需指回真实来源，不能保留模型伪造的页码或证据标识。
            kind, original = next((kind, original) for kind, original in sources if quote in original)
            offset = original.index(quote)
            chosen["source"].update({"kind": kind, "start": offset + chosen["source"]["start"],
                                     "end": offset + chosen["source"]["end"]})
            result[variable] = chosen
        return result

    def _find_value(self, var, question, context, document_text):
        return self._find_values([var], question, context, document_text).get(var)
