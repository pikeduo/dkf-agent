"""
任务6：公式知识卡片构建与检索（FinanceReasoning 思路：卡片含表达式/变量/符号映射）。
卡片从 PG formula_cards 表读取（由 scripts/build_formula_cards.py 从
data/raw/formula_reasoning/formulas.json 构建），只含公式知识，不含测试集答案。

【非主链路】当前场景为「用户提供公式」：主链路是
spec_from_user_formula（解析用户原文公式）→ 参数绑定 → SafeCalculator 白名单计算。
本模块仅保留为可选能力（如后续需要"用户只给公式名称时按库补定义"），
评测与生产默认路径均不再调用 find_candidates。
"""
from typing import Dict, List, Optional

import psycopg2


class KnowledgeCards:
    """公式知识卡片（入库侧）的加载与检索。"""

    def __init__(self, database_url: str) -> None:
        self.database_url = database_url
        self.cards: List[Dict] = []

    def load(self) -> List[Dict]:
        """从 PG formula_cards 拉全部卡片。"""
        import json
        with psycopg2.connect(self.database_url, connect_timeout=10) as conn, conn.cursor() as cur:
            cur.execute("SELECT formula_id, name, latex, variables FROM formula_cards")
            self.cards = [
                {"id": r[0], "name": r[1], "expression": r[2],
                 "variables": (r[3] if isinstance(r[3], dict) else (json.loads(r[3]) if r[3] else {}))}
                for r in cur.fetchall()
            ]
        return self.cards

    def find_candidates(self, question: str, top_k: int = 5) -> List[Dict]:
        """按问题词与卡片名/变量名/表达式重叠取候选（粗匹配，需上层校验适用条件）。"""
        import re
        q_tokens = set(re.findall(r"[\u4e00-\u9fff]|[A-Za-z]{2,}", question.lower()))
        scored: List[Dict] = []
        for card in self.cards:
            card_text = " ".join([card.get("name", ""), card.get("expression", ""),
                                  " ".join((card.get("variables") or {}).keys())]).lower()
            overlap = 0
            for tok in q_tokens:
                if tok in card_text:
                    overlap += 1
            if overlap:
                scored.append({**card, "match_score": overlap})
        scored.sort(key=lambda c: -c["match_score"])
        return scored[:top_k]
