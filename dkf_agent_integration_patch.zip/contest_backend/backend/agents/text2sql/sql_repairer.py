"""只对可修复的技术错误进行一次修复，保留用户确认条件与真实结构证据。"""
import json
from backend.agents.text2sql.sql_generator import extract_sql
from backend.data_access.relational import parse_readonly


class SQLRepairer:
    def __init__(self, llm_client, ddl, joins, confirmed_slots=None, metric_hints=None,
                 granularity_warnings=None):
        self.llm, self.ddl, self.joins = llm_client, ddl, joins
        self.confirmed_slots = confirmed_slots or {}
        self.metric_hints = metric_hints or []
        self.warnings = granularity_warnings or []

    def try_fix(self, question, bad_sql, error):
        """错误文本已由执行层脱敏；安全/作用域、连接、权限和超时失败不修复。"""
        if any(code in error for code in ("sql_", "timeout", "permission_denied")):
            return None
        # 仅允许语法、表列和分组类型技术错误触发一次修复。
        if not any(code in error for code in ("42601", "42703", "42P01", "42803", "42804", "42883")):
            return None
        context = {"question": question, "bad_sql": bad_sql, "error": error,
            "confirmed_slots": self.confirmed_slots, "metric_hints": self.metric_hints,
            "joins": self.joins, "structural_warnings": self.warnings}
        messages = [{"role": "system", "content": "只输出修复后的单条PostgreSQL SELECT或WITH查询。保留原问题及全部已确认条件，不放宽过滤，不增加未授权表和自定义函数。"},
            {"role": "user", "content": "授权DDL：\n" + self.ddl + "\n输入数据：\n" + json.dumps(context, ensure_ascii=False)}]
        fixed = extract_sql(self.llm.chat(messages, temperature=0.0))
        try:
            parse_readonly(fixed)
        except Exception:
            return None
        return fixed
