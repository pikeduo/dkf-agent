"""生产采用无示例路径；CoSQL/BIRD测试标注及未经核验的人工SQL不进入提示。"""
EXAMPLES = []
