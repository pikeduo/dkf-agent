"""受控Text2SQL：显式业务库与模式，定位/DDL/执行共享来源；失败全程可审计。"""
from pathlib import Path
import httpx
import psycopg2

from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
from backend.agents.text2sql.ddl import build_ddl
from backend.agents.text2sql.sql_generator import SQLGenerator
from backend.agents.text2sql.sql_repairer import SQLRepairer
from backend.core.trace_logger import ExecutionTrace
from backend.data_access.registry import SourceRegistry


class Text2SQLPipeline:
    def __init__(self, llm_client, registry=None, index_dir=None):
        self.generator = SQLGenerator(llm_client)
        self.linker = SchemaLinker(index_dir)
        path = Path(__file__).resolve().parents[3] / "processed/knowledge_base/databases.json"
        # 结构化路径不初始化向量客户端，也不推测未注册库的连接串。
        self.registry = registry if registry is not None else SourceRegistry.load_from_json(
            str(path), use_siliconflow_embedding=False)

    def run(self, db_id, sub_db, question, confirmed_slots=None, top_k=6, *,
            schema_mode="pruned", unresolved_conditions=None):
        """父流程只有无未决用户条件时才能调用；full仍限定同一真实业务子库。"""
        trace = ExecutionTrace(question)
        self.last_trace = trace

        def stopped(stage, code, view=None):
            trace.log(module="Text2SQL", action="受控停止", output_data={"stage": stage, "code": code})
            return {"ok": False, "stage": stage, "error": code, "sql": None, "repaired": False,
                "tables": (view or {}).get("tables", []), "joins": (view or {}).get("bridges", []),
                "view": view or {}, "trace": trace}

        if unresolved_conditions:
            return stopped("needs_user", "unresolved_user_conditions")
        if schema_mode not in ("pruned", "full") or not isinstance(top_k, int) or not 1 <= top_k <= 15:
            return stopped("blocked", "invalid_execution_options")
        if not isinstance(question, str) or not question.strip() or len(question) > 12000:
            return stopped("blocked", "invalid_question")
        if confirmed_slots is not None and not isinstance(confirmed_slots, dict):
            return stopped("blocked", "invalid_confirmed_slots")
        source = self.registry.get_relational(db_id)
        if source is None:
            return stopped("blocked", "relational_source_not_registered")
        try:
            self.linker.load(db_id, sub_db)
            view = self.linker.link(question, None, top_k=top_k,
                full_baseline=schema_mode == "full", confirmed_slots=confirmed_slots)
        except (KeyError, ValueError, FileNotFoundError):
            return stopped("blocked", "source_scope_missing_or_invalid")
        trace.log(module="任务4-定位", action="本库候选与键闭包", output_data={"database": db_id,
            "sub_db": self.linker.index.current_db, "tables": view["tables"], "columns": view["columns"],
            "status": view["status"], "schema_mode": schema_mode},
            evidence={"citations": [{"kind": "schema_candidate", **c} for c in view["candidates"]]
                      + [{"kind": "fk_bridge", **c} for c in view["closure_evidence"]],
                      "negative_evidence": view["negative_evidence"]})
        if view["needs_clarification"]:
            return stopped("needs_user", "business_metric_ambiguous", view)
        if not view["tables"]:
            return stopped("blocked", "candidate_insufficient", view)
        schema = self.linker.index.schema_name
        scope = {schema: set(view["tables"])}
        if schema not in source.allowed_schemas:
            return stopped("blocked", "source_schema_not_registered", view)
        try:
            ddl = build_ddl(source.database_url, view["tables"], schema=schema)
        except (psycopg2.Error, ValueError):
            return stopped("error", "source_metadata_unavailable", view)
        trace.log(module="任务4-定位", action="同源DDL", output_data={"schema": schema,
            "tables": view["tables"], "schema_mode": schema_mode}, evidence={"citations": [
                {"kind": "pg_catalog", "source_id": db_id, "sub_db": self.linker.index.current_db,
                 "schema": schema, "table": table} for table in view["tables"]]})
        constraints = {"metric_hints": view["metric_hints"], "granularity_warnings": view["granularity_warnings"]}
        try:
            query = self.generator.generate(question, ddl, view["bridges"], confirmed_slots, **constraints)
        except (RuntimeError, httpx.HTTPError):
            return stopped("model_unavailable", "generation_unavailable", view)
        response = source.execute_sql(query, allowed_tables=scope, default_schema=schema)
        query = response.executed_sql or query
        repaired = False
        if not response.ok:
            repairer = SQLRepairer(self.generator.llm, ddl, view["bridges"], confirmed_slots, **constraints)
            try:
                fixed = repairer.try_fix(question, query, str(response.error))
            except (RuntimeError, httpx.HTTPError):
                fixed = None
            if fixed and fixed != query:
                query, response, repaired = fixed, source.execute_sql(fixed, allowed_tables=scope,
                                                                     default_schema=schema), True
        query = response.executed_sql or query
        stage = "executed" if response.ok else "blocked" if "sql_" in str(response.error) else "execute_failed"
        trace.log(module="Text2SQL", action="生成与只读执行", output_data={"sql": query,
            "ok": response.ok, "stage": stage, "repaired": repaired, "row_count": response.row_count,
            "truncated": response.truncated, "error": response.error},
            evidence={"confirmed_slots": confirmed_slots or {}, "metric_hints": view["metric_hints"]})
        return {"ok": response.ok, "stage": stage, "sql": query, "repaired": repaired,
            "columns": response.columns, "rows": response.rows, "row_count": response.row_count,
            "truncated": response.truncated, "error": response.error, "tables": view["tables"],
            "joins": view["bridges"], "view": view, "trace": trace}
