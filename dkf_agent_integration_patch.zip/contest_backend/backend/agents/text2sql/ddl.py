"""从同一授权连接读取真实DDL、主键和按序配对外键，候选缺表时拒绝继续。"""
import psycopg2


def quote_identifier(value):
    """目录标识统一加双引号，正确保留空格、点和大小写。"""
    return '"' + value.replace('"', '""') + '"'


def build_ddl(database_url, tables, schema=None):
    schema = schema or "public"
    tables = list(dict.fromkeys(tables or []))
    if not tables:
        raise ValueError("ddl_empty_scope")
    conn = None
    try:
        conn = psycopg2.connect(database_url, connect_timeout=10)
        conn.set_session(readonly=True, autocommit=False)
        with conn, conn.cursor() as cur:
            cur.execute("SET LOCAL statement_timeout TO 10000")
            cur.execute("""
                SELECT table_name, column_name, data_type, is_nullable
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = ANY(%s)
                ORDER BY table_name, ordinal_position
            """, (schema, tables))
            columns = {}
            for table, column, dtype, nullable in cur.fetchall():
                columns.setdefault(table, []).append((column, dtype, nullable))
            if set(columns) != set(tables):
                raise ValueError("ddl_catalog_mismatch")
            cur.execute("""
                SELECT tc.table_name, kcu.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                  ON tc.constraint_name = kcu.constraint_name
                 AND tc.constraint_schema = kcu.constraint_schema
                 AND tc.table_name = kcu.table_name
                WHERE tc.constraint_type = 'PRIMARY KEY'
                  AND tc.table_schema = %s AND tc.table_name = ANY(%s)
                ORDER BY tc.table_name, kcu.ordinal_position
            """, (schema, tables))
            primary = {}
            for table, column in cur.fetchall():
                primary.setdefault(table, []).append(column)
            # 同时展开conkey/confkey并保留序位，禁止复合外键列对笛卡尔积。
            cur.execute("""
                SELECT src.relname, c.conname, dstns.nspname, dst.relname,
                       sa.attname, da.attname, pair.ordinality
                FROM pg_catalog.pg_constraint c
                JOIN pg_catalog.pg_class src ON src.oid = c.conrelid
                JOIN pg_catalog.pg_namespace srcns ON srcns.oid = src.relnamespace
                JOIN pg_catalog.pg_class dst ON dst.oid = c.confrelid
                JOIN pg_catalog.pg_namespace dstns ON dstns.oid = dst.relnamespace
                CROSS JOIN LATERAL unnest(c.conkey, c.confkey) WITH ORDINALITY AS pair(srcnum, dstnum, ordinality)
                JOIN pg_catalog.pg_attribute sa ON sa.attrelid = src.oid AND sa.attnum = pair.srcnum
                JOIN pg_catalog.pg_attribute da ON da.attrelid = dst.oid AND da.attnum = pair.dstnum
                WHERE c.contype = 'f' AND srcns.nspname = %s AND src.relname = ANY(%s)
                ORDER BY src.relname, c.conname, pair.ordinality
            """, (schema, tables))
            foreign = {}
            for table, constraint, dstschema, target, fromcol, tocol, _ in cur.fetchall():
                if dstschema == schema and target in columns:
                    foreign.setdefault((table, constraint, target), []).append((fromcol, tocol))
        output = []
        for table in sorted(columns):
            definitions = [f"{quote_identifier(c)} {dtype.upper()}" + (" NOT NULL" if null == "NO" else "")
                           for c, dtype, null in columns[table]]
            if primary.get(table):
                definitions.append("PRIMARY KEY (" + ", ".join(quote_identifier(c) for c in primary[table]) + ")")
            for (source, constraint, target), pairs in foreign.items():
                if source == table:
                    definitions.append("CONSTRAINT " + quote_identifier(constraint) + " FOREIGN KEY ("
                        + ", ".join(quote_identifier(a) for a, _ in pairs) + ") REFERENCES "
                        + quote_identifier(schema) + "." + quote_identifier(target) + " ("
                        + ", ".join(quote_identifier(b) for _, b in pairs) + ")")
            output.append("CREATE TABLE " + quote_identifier(schema) + "." + quote_identifier(table)
                          + " (\n  " + ",\n  ".join(definitions) + "\n);")
        return "\n\n".join(output)
    finally:
        if conn is not None:
            conn.close()
