"""外部服务集成：国产大模型、OCR、Embedding。

模块结构：
    ocr_client.py — OCR 识别客户端（可选）
    embedder.py   — 硅基流动嵌入客户端（OpenAI 兼容 /v1/embeddings）
"""
from backend.integrations.embedder import SiliconFlowEmbedder
from backend.integrations.ocr_client import OcrClient

__all__ = [
    "SiliconFlowEmbedder",
    "OcrClient",
]
