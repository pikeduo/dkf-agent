"""
硅基流动嵌入客户端：OpenAI 兼容嵌入协议（/v1/embeddings）。

参照 RAG 项目的对接方式：
- 端点 https://api.siliconflow.cn/v1/embeddings
- 默认模型 BAAI/bge-m3，维度 1024
- 入库与检索必须使用相同模型与向量空间，密钥仅运行期内存持有。
"""
from typing import List

import httpx

from backend.config import get_settings


class SiliconFlowEmbedder:
    """硅基流动嵌入客户端。

    用法（作为 VectorSource 的 embedder 注入）：
        embedder = SiliconFlowEmbedder()
        vector_source = VectorSource("ohr_bench", embedder=embedder.embed)
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "",
        model: str = "",
        dim: int = 0,
        timeout: int = 120,
    ) -> None:
        """参数为空时从全局配置读取。"""
        settings = get_settings()
        if not api_key:
            api_key = settings.siliconflow_api_key
        if not base_url:
            base_url = settings.siliconflow_base_url
        if not model:
            model = settings.embedding_model
        if dim <= 0:
            dim = settings.embedding_dim

        if not api_key:
            raise ValueError(
                "硅基流动嵌入缺少 api_key，请在 .env 配置 SILICONFLOW_API_KEY"
            )

        self.api_key = api_key
        # 嵌入端点：{base_url}/embeddings（base_url 为 /v1 前缀）
        self.embed_url = f"{base_url.rstrip('/')}/embeddings"
        self.model = model
        self.dim = dim
        self._client = httpx.Client(timeout=timeout)

    @property
    def available(self) -> bool:
        """是否可用（已配置密钥）。"""
        return bool(self.api_key)

    def embed(self, text: str) -> List[float]:
        """单条文本嵌入，返回 dim 维浮点向量。"""
        results = self.embed_batch([text])
        if len(results) != 1:
            raise RuntimeError(f"嵌入返回数量异常：期望 1 条，实际 {len(results)}")
        return results[0]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """批量文本嵌入，返回与输入顺序一致的向量列表。"""
        payload = {"model": self.model, "input": texts}
        headers = {"Authorization": f"Bearer {self.api_key}"}

        resp = self._client.post(self.embed_url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

        # OpenAI 兼容协议：按 index 排序保证与输入顺序一致
        items = sorted(data["data"], key=lambda x: x.get("index", 0))
        vectors = [item["embedding"] for item in items]
        if len(vectors) != len(texts):
            raise RuntimeError(
                f"嵌入返回数量异常：期望 {len(texts)} 条，实际 {len(vectors)}"
            )
        return vectors

    def close(self) -> None:
        """关闭底层 HTTP 客户端。"""
        self._client.close()
