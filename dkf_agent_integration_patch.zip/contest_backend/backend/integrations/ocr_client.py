"""OCR 服务客户端封装（可选）。

用于扫描件/复杂表格/公式图片的识别。
具体厂商按部署环境替换；无密钥时降级为纯文本路径。
"""
import httpx
from backend.config import get_settings


class OcrClient:
    """OCR 客户端。未配置密钥时返回空结果，调用方走文本路径。"""

    def __init__(self) -> None:
        self.settings = get_settings()

    @property
    def available(self) -> bool:
        return bool(self.settings.ocr_api_key)

    def recognize(self, image_bytes: bytes) -> str:
        """识别图片，返回文本。未配置时抛错，由上层捕获降级。"""
        if not self.available:
            raise RuntimeError("未配置 OCR 服务密钥")
        # 具体实现按所选厂商 SDK 或 HTTP 接口填充
        raise NotImplementedError("请按部署环境实现 OCR 调用")
