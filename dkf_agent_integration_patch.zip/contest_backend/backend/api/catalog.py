"""Competition demo exposes only public dataset identifiers; no connection secrets."""
from pathlib import Path
import json
from fastapi import APIRouter, HTTPException

router = APIRouter()
_REGISTRY = Path(__file__).resolve().parents[2] / 'processed' / 'knowledge_base' / 'databases.json'


@router.get('/sources')
def sources():
    """Return only dataset IDs / labels (not DSNs, imported file paths, or secrets)."""
    try:
        data = json.loads(_REGISTRY.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        raise HTTPException(status_code=503, detail='数据库目录不可用') from None
    return {'items': [
        {'db_id': item['db_id'], 'name': item.get('db_name') or item['db_id'],
         'table_count_hint': item.get('table_count_hint')}
        for item in data.get('databases', [])
        if isinstance(item, dict) and isinstance(item.get('db_id'), str)
        and item['db_id'] != 'ohr_bench'
    ]}
