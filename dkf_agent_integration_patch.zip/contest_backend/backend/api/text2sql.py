"""API：Text2SQL 端点。

输入结构化问题与目标库，经「模块1 表定位 → DDL 裁剪 → SQL 生成 → 只读执行 → 一次修复」
返回 SQL、结果与可解释 trace。

边界：
- 不执行任务3 澄清（确认映射由调用方经 confirmed_slots 传入，来自 /api/clarification）。
- SQL 只走 RelationalSource 只读通道；失败时最多一次内部修复，不循环。
"""
import time
from typing import Dict, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from backend.agents.text2sql.pipeline import Text2SQLPipeline
from backend.api.trace import register_trace
from backend.core.llm_client import LLMClient

router = APIRouter()


class Text2SQLRequest(BaseModel):
    """Text2SQL 请求。db_id/sub_db 对应 databases.json 注册表。"""

    db_id: str = Field(description="数据源标识，如 chinook / bird / cosql")
    sub_db: Optional[str] = Field(default=None, description="子库 db_id，如 BIRD 的 california_schools")
    question: str = Field(min_length=1, max_length=12000)
    confirmed_slots: Optional[Dict] = Field(
        default=None, description="任务3 确认的业务口径映射；不进入任何全局状态")
    top_k: int = Field(default=6, ge=2, le=15)


class Text2SQLResponse(BaseModel):
    """Text2SQL 结果；ok 表示 SQL 成功执行，不代表答案充分。"""

    ok: bool
    stage: str
    sql: Optional[str] = None
    repaired: bool = False
    columns: list = Field(default_factory=list)
    rows: list = Field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    error: Optional[str] = None
    tables: list = Field(default_factory=list)
    joins: list = Field(default_factory=list)
    latency_s: float = 0.0
    trace_id: str = ""


def get_pipeline() -> Text2SQLPipeline:
    """每次请求构造流水线；LLMClient 复用全局配置（lru_cache）。"""
    return Text2SQLPipeline(LLMClient())


@router.post("/text2sql", response_model=Text2SQLResponse)
def text2sql(req: Text2SQLRequest,
              pipeline: Text2SQLPipeline = Depends(get_pipeline)):
    """执行一次 Text2SQL。"""
    t0 = time.perf_counter()
    import uuid
    result = pipeline.run(req.db_id, req.sub_db, req.question,
                          confirmed_slots=req.confirmed_slots, top_k=req.top_k)
    trace_id = uuid.uuid4().hex
    # 模块6：把流水线产出的 ExecutionTrace 登记到可解释接口
    trace = result.get("trace")
    if trace is not None:
        trace.trace_id = trace_id
        register_trace(trace)
    return Text2SQLResponse(
        ok=result.get("ok", False),
        stage=result.get("stage", "unknown"),
        sql=result.get("sql"),
        repaired=result.get("repaired", False),
        columns=result.get("columns", []),
        rows=result.get("rows", []),
        row_count=result.get("row_count", 0),
        truncated=result.get("truncated", False),
        error=result.get("error"),
        tables=result.get("tables", []),
        joins=result.get("joins", []),
        latency_s=round(time.perf_counter() - t0, 2),
        trace_id=trace_id,
    )
