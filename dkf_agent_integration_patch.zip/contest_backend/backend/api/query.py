"""查询入口：可选会话历史筛选后进行意图识别，不执行最终问答工具。"""
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field

from backend.api.sessions import SessionToken, get_session_store
from backend.config import get_settings
from backend.core.history.contracts import ConversationRequest
from backend.core.history.selector import HistorySelector
from backend.core.history.service import ConversationService
from backend.core.history.store import SessionError, SessionStore
from backend.core.intent import IntentResult, IntentService
from backend.core.intent.contracts import Identifier
from backend.core.workflow import WorkflowService
from backend.core.llm_client import LLMClient
from backend.integrations.history_ranker import ImajevHistoryRanker

router = APIRouter()


class QueryRequest(ConversationRequest):
    """继承无状态请求及显式会话控制字段。"""


class QueryResponse(BaseModel):
    """ok仅表示入口识别成功；会话令牌不会在此回显。"""

    ok: bool
    stage: Literal["intent_ready", "intent_failed"]
    intent: IntentResult
    answer: str | None = None
    sql: str | None = None
    calculation: dict | None = None
    citations: list = Field(default_factory=list)
    trace_id: str
    error: str | None = None
    session_id: str | None = None
    task_id: str | None = None
    revision: int | None = None
    user_message_id: str | None = None
    clarification_message_id: str | None = None
    history_selection: dict | None = None


def get_intent_service() -> IntentService:
    """不在服务导入时请求模型。"""
    return IntentService(LLMClient())


class RunQueryRequest(QueryRequest):
    """受控执行请求；业务子库由调用方明确指定，不将多个库混在一起。"""

    sub_db: Identifier | None = None


class RunQueryResponse(QueryResponse):
    """外层描述真实执行结果，内层意图结果仍只表示分析阶段。"""

    stage: str
    execution_performed: bool = False
    answer_ready: bool = False
    rows: list = Field(default_factory=list)
    columns: list = Field(default_factory=list)
    truncated: bool = False
    candidates: list[str] = Field(default_factory=list)
    evidence_ready: bool = False


def get_workflow_service(service: Annotated[IntentService, Depends(get_intent_service)]) -> WorkflowService:
    """执行组件按请求构造，复用本次识别的模型配置，可注入离线测试组件。"""
    return WorkflowService(service.client)


def get_history_selector() -> HistorySelector:
    settings = get_settings()
    ranker = None
    if settings.imajev_history_enabled:
        ranker = ImajevHistoryRanker(settings.imajev_history_endpoint,
                                    settings.imajev_history_api_key.get_secret_value(),
                                    settings.imajev_history_timeout_seconds)
    return HistorySelector(ranker=ranker, recent_turns=settings.history_recent_turns,
                           short_turns=settings.history_short_turns,
                           max_bytes=settings.history_max_context_bytes,
                           keep_threshold=settings.history_keep_threshold,
                           reject_threshold=settings.history_reject_threshold,
                           unknown_threshold=settings.history_unknown_threshold)


@router.post("/intent", response_model=QueryResponse)
@router.post("/", response_model=QueryResponse)
def query(req: QueryRequest, response: Response,
          service: Annotated[IntentService, Depends(get_intent_service)],
          store: Annotated[SessionStore, Depends(get_session_store)],
          selector: Annotated[HistorySelector, Depends(get_history_selector)],
          session_token: SessionToken = None):
    """无会话请求保持兼容；会话历史仅在令牌校验后读取。"""
    response.headers["Cache-Control"] = "no-store"
    metadata = {}
    if req.session_id:
        try:
            outcome = ConversationService(store, selector).analyze(req, session_token, service)
        except SessionError as exc:
            raise HTTPException(exc.status_code, str(exc)) from None
        result = outcome.intent
        metadata = {"session_id": outcome.session_id, "task_id": outcome.task_id,
                    "revision": outcome.revision, "user_message_id": outcome.user_message_id,
                    "clarification_message_id": outcome.clarification_message_id,
                    "history_selection": outcome.history}
    else:
        result = service.analyze(req.intent_request())
    return QueryResponse(ok=result.ok, stage=result.stage, intent=result,
                         trace_id=result.trace_id,
                         error=None if result.ok else result.decision.message, **metadata)


@router.post("/run", response_model=RunQueryResponse)
def run_query(req: RunQueryRequest, response: Response,
              service: Annotated[IntentService, Depends(get_intent_service)],
              store: Annotated[SessionStore, Depends(get_session_store)],
              selector: Annotated[HistorySelector, Depends(get_history_selector)],
              workflow: Annotated[WorkflowService, Depends(get_workflow_service)],
              session_token: SessionToken = None):
    """最小用户闭环：来源校验、必要澄清、受控执行及结果返回。"""
    analysis_req = QueryRequest.model_validate(req.model_dump(exclude={"sub_db"}, by_alias=True))
    if req.sub_db:
        try:
            if not req.database:
                raise ValueError("子库必须有数据集标识")
            workflow._scope(req.database, req.sub_db)
        except (KeyError, ValueError, OSError):
            raise HTTPException(422, "业务子库与数据集不匹配或目录不可用") from None
        # 意图层目录使用唯一业务子库，避免将整合数据集的表全部交给模型。
        analysis_req.database = req.sub_db
    base = query(analysis_req, response, service, store, selector, session_token)
    database, doc_id = analysis_req.database, analysis_req.doc_id
    if req.session_id and base.ok:
        try:
            with store.lease(req.session_id, session_token) as session:
                database, doc_id = session.database, session.doc_id
                session.discard = True
        except SessionError as exc:
            raise HTTPException(exc.status_code, str(exc)) from None
    outcome = workflow.run(base.intent, req.question, database=database, doc_id=doc_id)
    payload = {**base.model_dump(), **outcome}
    if outcome.get("stage") == "needs_user" and req.session_id and not base.clarification_message_id:
        # 执行层新发现的缺口也关联到当前回合，防止前端无法正确提交澄清回复。
        try:
            with store.lease(req.session_id, session_token) as session:
                if session.revision != base.revision:
                    raise SessionError("会话已更新，请重新提交当前请求", 409)
                message = session.append("assistant", outcome["answer"],
                                         "workflow_" + base.trace_id,
                                         tuple([base.user_message_id] if base.user_message_id else []))
                session.pending_id = message.id
                store.check_capacity(session)
                payload["clarification_message_id"] = message.id
                payload["revision"] = session.revision + 1
        except SessionError as exc:
            raise HTTPException(exc.status_code, str(exc)) from None
    return RunQueryResponse(**payload)
