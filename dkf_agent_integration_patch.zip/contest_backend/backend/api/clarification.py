"""独立任务3澄清接口；目录固定在当前会话，技术失败不伪装用户歧义。"""
import uuid
from functools import lru_cache
from typing import Dict, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from backend.agents.task3_clarification.dialog_manager import DialogManager
from backend.api.trace import register_trace
from backend.core.intent.contracts import IntentRequest, Contract, Identifier
from backend.core.intent.service import IntentService
from backend.core.llm_client import LLMClient

router = APIRouter()
_DIALOGS: Dict[str, DialogManager] = {}
_MAX_DIALOGS = 512


@lru_cache
def _intent_service() -> IntentService:
    """只缓存无会话服务，不缓存可变的SchemaIndex对象。"""
    return IntentService(LLMClient())


class ClarifyStart(Contract):
    """database为唯一原始子库标识；不默认猜测业务库。"""

    question: str = Field(min_length=1, max_length=12000)
    database: Identifier | None = None


class ClarifyStartResponse(BaseModel):
    ok: bool
    session_id: str
    status: str = "tool_error"
    need_clarify: bool = False
    clarify: Optional[dict] = None
    final_ready: bool = False
    reason: Optional[str] = None
    actual_turns: int = 0
    error: Optional[str] = None


class ClarifyReply(Contract):
    """用户回复允许选择与自由填写；操作文本不是实际参数值。"""

    reply: str = Field(min_length=1, max_length=400)


class ClarifyReplyResponse(ClarifyStartResponse):
    confirmed: dict = Field(default_factory=dict)


def _new_dialog(question: str, database: str | None):
    """先固定目录，再一次解释；失败保留错误码，不回显供应商信息。"""
    service = _intent_service()
    request = IntentRequest(question=question, database=database)
    context = service.schema_provider.resolve(database)
    result = service.analyze(request, schema_context=context)
    if not result.ok:
        return None, result.error_code or "intent_failed"
    if len(_DIALOGS) >= _MAX_DIALOGS:
        _DIALOGS.pop(next(iter(_DIALOGS)))
    sid = uuid.uuid4().hex
    dialog = DialogManager(sid, question, service.client, context.index,
                           interpretation=result.interpretation, schema_context=context.to_dict())
    _DIALOGS[sid] = dialog
    return dialog, None


@router.post("/", response_model=ClarifyStartResponse)
def start(req: ClarifyStart):
    """ready仅表示澄清条件齐备，未执行SQL或计算。"""
    dialog, error = _new_dialog(req.question, req.database)
    if dialog is None:
        return ClarifyStartResponse(ok=False, session_id="", status="tool_error", error=error,
                                    reason="technical_error")
    out = dialog.step(None)
    register_trace(dialog.trace)
    return ClarifyStartResponse(ok=True, session_id=dialog.state.session_id,
                               **{k: out[k] for k in ("status", "need_clarify", "clarify", "final_ready", "reason", "actual_turns")})


@router.post("/{session_id}/reply", response_model=ClarifyReplyResponse)
def reply(session_id: str, req: ClarifyReply):
    """未决、证据不足与预算耗尽均不是成功闭环。"""
    dialog = _DIALOGS.get(session_id)
    if dialog is None:
        return ClarifyReplyResponse(ok=False, session_id=session_id, error="unknown_session",
                                    reason="technical_error")
    out = dialog.step(req.reply)
    register_trace(dialog.trace)
    return ClarifyReplyResponse(ok=out["status"] != "tool_error", session_id=session_id,
                               **{k: out[k] for k in ("status", "need_clarify", "clarify", "confirmed", "final_ready", "reason", "actual_turns")},
                               error=out.get("error"))
