"""开发会话接口：随机能力令牌授权，不接受客户端自报用户身份。"""
from functools import lru_cache
from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, Response
from pydantic import BaseModel

from backend.config import get_settings
from backend.core.history.store import SessionError, SessionStore

router = APIRouter()
SessionToken = Annotated[str | None, Header(alias="X-Session-Token", max_length=256)]


@lru_cache
def get_session_store() -> SessionStore:
    settings = get_settings()
    return SessionStore(ttl_seconds=settings.history_session_ttl_seconds,
                        max_sessions=settings.history_max_sessions)


class SessionCreated(BaseModel):
    session_id: str
    session_token: str
    storage: str = "process_memory"


@router.post("/", response_model=SessionCreated, status_code=201)
def create_session(response: Response, store: Annotated[SessionStore, Depends(get_session_store)]):
    """令牌仅创建时返回，浏览器与代理不得缓存响应。"""
    response.headers["Cache-Control"] = "no-store"
    try:
        session_id, token = store.create()
    except SessionError as exc:
        raise HTTPException(exc.status_code, str(exc)) from None
    return SessionCreated(session_id=session_id, session_token=token)


@router.delete("/{session_id}", status_code=204)
def delete_session(session_id: str, store: Annotated[SessionStore, Depends(get_session_store)],
                   session_token: SessionToken = None):
    try:
        store.delete(session_id, session_token)
    except SessionError as exc:
        raise HTTPException(exc.status_code, str(exc)) from None
    return Response(status_code=204, headers={"Cache-Control": "no-store"})
