"""API：可解释性接口。

按 trace_id 拉取单次查询的全链路推理（模块、动作、证据、成本），
供前端「查看理解过程」可视化。存储为进程内 + JSON 落盘（与会话存储同约定，
重启失效；上线需对接共享存储）。
"""
import json
import re
import os
import threading
from functools import lru_cache
from typing import Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.core.trace_logger import ExecutionTrace

router = APIRouter()

# 进程内 trace 存储：trace_id → trace dict（有锁，限容量）
_TRACE_LOCK = threading.Lock()
_TRACES: Dict[str, dict] = {}
_MAX_TRACES = 512
_TRACE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                          "logs", "traces")


def register_trace(trace: ExecutionTrace) -> None:
    """各模块在关键路径完成后登记 trace；同一 trace_id 后写覆盖前写。"""
    with _TRACE_LOCK:
        if len(_TRACES) >= _MAX_TRACES:
            oldest = next(iter(_TRACES))
            _TRACES.pop(oldest, None)
        data = trace.to_dict()
        _TRACES[trace.trace_id] = data
        try:
            os.makedirs(_TRACE_DIR, exist_ok=True)
            with open(os.path.join(_TRACE_DIR, f"{trace.trace_id}.json"), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
        except OSError:
            pass  # 落盘失败不影响主流程


class TraceResponse(BaseModel):
    trace_id: str
    question: str = ""
    started_at: Optional[str] = None
    steps: list = []
    citations: list = []
    total_tokens: int = 0


@router.get("/{trace_id}", response_model=TraceResponse)
def get_trace(trace_id: str):
    """按 trace_id 拉取推理链路；未登记过的 id 返回 404（不伪造步骤）。"""
    if not re.fullmatch(r"[0-9a-fA-F-]{32,36}", trace_id):
        raise HTTPException(400, "trace_id 格式无效")
    with _TRACE_LOCK:
        data = _TRACES.get(trace_id)
    if data is None and os.path.exists(os.path.join(_TRACE_DIR, f"{trace_id}.json")):
        data = json.loads(open(os.path.join(_TRACE_DIR, f"{trace_id}.json"), encoding="utf-8").read())
    if data is None:
        raise HTTPException(404, f"trace {trace_id} 未找到（可能已过期或服务重启）")
    return TraceResponse(
        trace_id=trace_id,
        question=data.get("question", ""),
        started_at=data.get("started_at"),
        steps=data.get("steps", []),
        citations=data.get("citations", []),
        total_tokens=data.get("total_tokens", 0),
    )
