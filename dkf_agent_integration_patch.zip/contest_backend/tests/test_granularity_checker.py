# -*- coding: utf-8 -*-
"""粒度/fan-out 检查器单元测试：离线，只读 processed/task4_schema/fk_graph.json。"""
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task4_schema_linking.fk_graph_builder import FKGraphBuilder
from backend.agents.task4_schema_linking.granularity_checker import GranularityChecker


@pytest.fixture(scope="module")
def checker():
    fk = FKGraphBuilder()
    fk.load("chinook")
    return GranularityChecker(fk)


def test_single_table_no_warning(checker):
    assert checker.check(["invoice"]) == []


def test_self_join_detected(checker):
    # employee.reports_to 自引用外键
    warnings = checker.check(["employee"])
    assert any(w["type"] == "self_join" and w["table"] == "employee" for w in warnings)


def test_fanout_risk_on_fact_tables_via_bridge(checker):
    # invoice(事实, Total) + track(含 UnitPrice 列) 经 invoice_line 桥接（1:N）
    warnings = checker.check(
        ["invoice", "track", "invoice_line"],
        columns={"invoice": ["Total"], "track": ["UnitPrice"], "invoice_line": []},
    )
    assert any(w["type"] == "fanout_risk" and w["bridge_table"] == "invoice_line"
               for w in warnings)


def test_no_fact_columns_no_fanout_warning(checker):
    # 只有维度表、无金额/计数列 → 不报 fan-out（自连接除外）
    warnings = checker.check(["genre", "media_type"], columns={"genre": ["Name"], "media_type": ["Name"]})
    assert not any(w["type"] == "fanout_risk" for w in warnings)
