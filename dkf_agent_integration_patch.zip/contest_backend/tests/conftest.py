"""测试临时目录清理；只清理当前用例的 pytest 临时文件。"""
import shutil

import pytest


@pytest.fixture(autouse=True)
def remove_test_intermediates(request):
    """使用临时路径的用例结束后立即删除，不将中间文件留到后续运行。"""
    # 必须在 setup 阶段先取得 tmp_path 实例；teardown 时再请求会因 pytest 拆卸顺序报错。
    path = request.getfixturevalue("tmp_path") if "tmp_path" in request.fixturenames else None
    yield
    if path is not None and path.name.startswith("test_") and path.parent.name.startswith("pytest-"):
        shutil.rmtree(path, ignore_errors=True)
