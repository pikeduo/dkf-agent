"""任务3最小子集采样器验收测试；仅本地数据+无网络，不调真实模型。

验收点：样本确定性、整对话/中文20/每非空层至少一完整对话、选择与model hit无关、
清单篡改/源数据变更/选择器代码变更拒绝、分母=实际筛选数、dry-run无LLM、
Windows replace容错（前2次PermissionError后成功；永久失败不改旧report且清临时文件）、
旧优化报告hash在全部测试后不变。
"""
import hashlib
import json
import os
import shutil
from pathlib import Path
from types import SimpleNamespace

import pytest

import evaluation.eval_clarify as ev
import evaluation.task3_sampling as t3

HERE = Path(__file__).resolve().parents[1]
MANIFEST = HERE / "test_cases" / "task3_subset_manifest_v2.json"
REAL_TASK3_REPORT = HERE / "evaluation" / "reports" / "optimization_task3_20261010.json"


def _full_cases():
    """全量构建（与--create-subset-manifest同参数），用于子集断言。"""
    data = json.loads(ev.COSQL.read_text(encoding="utf-8"))
    zh = json.loads(ev.ZH_CASES.read_text(encoding="utf-8"))
    return ev.build_cosql_cases(data, all_turns=True) + ev.build_zh_cases(zh), data, zh


def _group_by_dialog(cases: list) -> dict:
    groups: dict[str, list] = {}
    for c in cases:
        if c.dataset == "cosql":
            groups.setdefault(c.case_id.rsplit(":", 1)[0], []).append(c)
    return groups


class _HitStub:
    """评分桩：把所有case的hit改写为False，验证选择结果与任何模型输出无关。"""

    @staticmethod
    def score(case, record):
        return False


@pytest.fixture(autouse=True)
def _guard_real_task3_report():
    """本模块测试前后校验正式task3报告字节hash不变（只校验，不顺手清理）。"""
    before = hashlib.sha256(REAL_TASK3_REPORT.read_bytes()).hexdigest() \
        if REAL_TASK3_REPORT.exists() else None
    yield
    assert hashlib.sha256(REAL_TASK3_REPORT.read_bytes()).hexdigest() == before, \
        "正式task3报告被测试污染，路径不变性破坏"


def _build_manifest_dict(tmp_path: Path) -> dict:
    cases, _, _ = _full_cases()
    sh = {"cosql": ev.digest(json.loads(ev.COSQL.read_text(encoding="utf-8"))),
          "zh": ev.digest(json.loads(ev.ZH_CASES.read_text(encoding="utf-8")))}
    manifest = t3.build_subset_manifest(all_cases=cases, source_hashes=sh,
                                        selector_code_hash=ev._selector_code_hash())
    path = tmp_path / "manifest.json"
    t3.write_manifest(path, manifest)
    return manifest


def test_sample_is_deterministic_and_registry_idempotent(tmp_path):
    """同一输入两次独立重抽逐字段一致；已有同清单时write幂等成功。"""
    m1 = _build_manifest_dict(tmp_path)
    path = tmp_path / "manifest.json"
    m2 = _build_manifest_dict(tmp_path)  # 幂等：与已存在清单一致，允许重写
    assert m1 == m2, "采样必须完全确定（种子ict-task3-subset-v1，与运行顺序无关）"
    assert hashlib.sha256(path.read_bytes()).hexdigest()
    # 全量注册表=9213有效轮且只存caseID+样本hash
    assert len(m1["full_registry"]) == 9213
    assert all(set(v) == set() or isinstance(v, str) for v in m1["full_registry"].values())


def test_whole_dialogs_kept_and_zh20_and_layer_coverage(tmp_path):
    """选中case所属对话必须在清单内完整成组；中文20条全保留；每非空层至少一完整对话。"""
    manifest = _build_manifest_dict(tmp_path)
    all_cases = _full_cases()[0]
    cosql_cases = [c for c in all_cases if c.dataset == "cosql"]
    full_by_dialog = _group_by_dialog(cosql_cases)
    picked_dialogs = {cid.rsplit(":", 1)[0] for cid in manifest["cases"]
                      if not cid.startswith("zh-")}
    # 整对话不截断：清单内每个对话的全部有效轮次都在
    for dialog in picked_dialogs:
        in_manifest = {cid for cid in manifest["cases"]
                       if cid.rsplit(":", 1)[0] == dialog}
        assert in_manifest == set(c.case_id for c in full_by_dialog[dialog]), \
            f"对话{dialog}被截断：清单{len(in_manifest)}轮，全量{len(full_by_dialog[dialog])}轮"
    # 中文20条全部保留
    zh_in_manifest = [cid for cid in manifest["cases"] if cid.startswith("zh-")]
    assert len(zh_in_manifest) == 20, "中文20条必须全部进入子集"
    # 每非空层至少一完整对话
    layer_total = {l: 0 for l in t3.LAYER_ORDER}
    layer_picked = {l: 0 for l in t3.LAYER_ORDER}
    for dialog, cs in full_by_dialog.items():
        layer = t3._dialog_layer(cs)
        layer_total[layer] += 1
        if dialog in picked_dialogs:
            layer_picked[layer] += 1
    for layer in t3.LAYER_ORDER:
        if layer_total[layer]:
            assert layer_picked[layer] >= 1, f"非空层{layer}必须至少保留一个完整对话"


def test_selection_is_independent_of_model_hits(tmp_path, monkeypatch):
    """把评分函数桩成永远False，选择结果与真实hit分布完全一致；不读旧run记录。"""
    monkeypatch.setattr(ev, "score_case", _HitStub.score)
    m1 = _build_manifest_dict(tmp_path)
    m2 = _build_manifest_dict(tmp_path)
    assert m1["cases"] == m2["cases"] and m1["manifest_hash"] == m2["manifest_hash"]
    # 明确不读取旧run的hit/records/SQL/evidence：清单内只允许指纹与元数据
    for key in ("hit", "records", "sql", "evidence"):
        assert key not in m1, f"清单不得携带模型结果字段{key}"


def _FullRef(v):  # 占位，保持类签名
    raise AssertionError("不应调用")


def test_tampered_manifest_rejected(tmp_path, monkeypatch):
    """清单case篡改/清单种子规则版本篡改/选择器代码hash变化/源数据hash变化均拒绝。"""
    manifest = _build_manifest_dict(tmp_path)
    cosql_cases = [c for c in _full_cases()[0] if c.dataset == "cosql"]
    sh = {"cosql": ev.digest(json.loads(ev.COSQL.read_text(encoding="utf-8"))),
          "zh": ev.digest(json.loads(ev.ZH_CASES.read_text(encoding="utf-8")))}
    sel = t3.filter_and_verify_cases(manifest, cosql_cases + [c for c in _full_cases()[0] if c.dataset == "zh"],
                                     sh, ev._selector_code_hash())
    assert len(sel) == len(manifest["cases"])
    # 篡改：从清单中删除一条case → 数量不符拒绝
    tampered = json.loads(json.dumps(manifest))
    del tampered["cases"][next(iter(tampered["cases"]))]
    with pytest.raises(ValueError):
        t3.filter_and_verify_cases(tampered, cosql_cases + [c for c in _full_cases()[0] if c.dataset == "zh"],
                                   sh, ev._selector_code_hash())
    # 篡改：种子/规则版本
    tampered2 = json.loads(json.dumps(manifest))
    tampered2["seed"] = "another-seed"
    with pytest.raises(ValueError):
        t3.filter_and_verify_cases(tampered2, cosql_cases + [c for c in _full_cases()[0] if c.dataset == "zh"],
                                   sh, ev._selector_code_hash())
    # 源数据hash变化
    tampered3 = json.loads(json.dumps(manifest))
    tampered3["source_hashes"]["cosql"] = "deadbeef"
    with pytest.raises(ValueError):
        t3.filter_and_verify_cases(tampered3, cosql_cases + [c for c in _full_cases()[0] if c.dataset == "zh"],
                                   sh, ev._selector_code_hash())
    # 选择器代码hash变化
    tampered4 = json.loads(json.dumps(manifest))
    tampered4["selector_code_hash"] = "changed-selector"
    with pytest.raises(ValueError):
        t3.filter_and_verify_cases(tampered4, cosql_cases + [c for c in _full_cases()[0] if c.dataset == "zh"],
                                   sh, ev._selector_code_hash())


def test_existing_manifest_rejects_non_deterministic_overwrite(tmp_path):
    """已有清单与重抽不一致时拒绝覆盖（确定性防护）；内容恢复一致后允许重写。"""
    manifest = _build_manifest_dict(tmp_path)
    path = tmp_path / "manifest.json"
    bad = json.loads(json.dumps(manifest))
    bad["cases"] = {"rogue:0": "ff" * 64}
    path.write_text(json.dumps(bad, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(ValueError):
        t3.write_manifest(path, manifest)
    # 恢复一致内容后重写允许
    path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
    t3.write_manifest(path, manifest)
    assert json.loads(path.read_text(encoding="utf-8")) == manifest


def test_bird_rejected_in_subset(monkeypatch):
    """BIRD未审核不选：含bird case时select_subset直接拒绝。"""
    cosql_cases, _zh, _ = _full_cases()
    bird_case = ev.EvalCase("bird:0:financial:137", "bird", "debug",
                             ev.EvalInput("q", "financial"), (), "COMPLETE_CONTROL", False)
    with pytest.raises(ValueError):
        t3.select_subset(cosql_cases + [bird_case])


def _FakeCase(cid, labels=("INFORM_SQL",)):
    """构造最小case桩：仅case_id/labels/dataset参与选择器；输入字段为最小合法stub。"""
    return ev.EvalCase(cid, "cosql", "debug", ev.EvalInput("q", "chinook"),
                       tuple(labels), ev._primary(tuple(labels)), None)


def test_v2_layer_orders_by_seed_rank_not_length(tmp_path, monkeypatch):
    """v2层内排序完全按种子hash，短组可以排到长组前：夹具中不总是总选最长组。

    通过固定_seed_rank的确定性重排（不改SEED字符串本身），构造短组hash先于长组，
    证明v2装入顺序由hash而非长度决定；同一夹具下v1规则仍先装最长组。
    """
    short = _FakeCase("dialA:0")
    longs = [_FakeCase(f"dialB:{i}") for i in range(6)]
    cases = [short] + longs
    # 固定_rank：短组dialA=100（先），长组dialB=200（后）；layer按_seed_rank排序
    monkeypatch.setattr(t3, "_seed_rank", lambda v: {"dialA": 100, "dialB": 200, "INFORM_SQL": 300}.get(v, 500))
    v2 = t3.select_subset(cases, target=2, rule_version=t3.RULE_VERSION)
    assert {c.case_id.rsplit(":", 1)[0] for c in v2} == {"dialA"}, \
        "v2必须按种子hash先装入短组dialA（hash顺序优先于长度）"
    # 同一夹具下v1回归规则先装最长组dialB（证明v2不是v1行为）
    v1 = t3.select_subset(cases, target=2, rule_version=t3.RULE_V1)
    assert {c.case_id.rsplit(":", 1)[0] for c in v1} == {"dialB"}, "v1回归规则仍偏长对话"


def test_v1_vs_v2_manifest_fields_distinguish_selected_from_total(tmp_path):
    """v2清单显式区分total_dialog_count与selected_dialog_count，剥除把全体说成选定的歧义。"""
    m1 = t3.build_subset_manifest(
        all_cases=[_FakeCase("x:0"), _FakeCase("x:1")],
        source_hashes={"cosql": "h"}, selector_code_hash="sel",
        rule_version=t3.RULE_VERSION)
    assert m1["rule_version"] == t3.RULE_VERSION
    assert m1["total_dialog_count"] == 1 and m1["selected_dialog_count"] == 1
    assert "dialog_count" not in m1, "旧歧义字段不得再出现"
    # v1清单仍可构建（回归集）
    m0 = t3.build_subset_manifest(
        all_cases=[_FakeCase("x:0"), _FakeCase("x:1")],
        source_hashes={"cosql": "h"}, selector_code_hash="sel",
        rule_version=t3.RULE_V1)
    assert m0["rule_version"] == t3.RULE_V1 and m0["manifest_hash"] != m1["manifest_hash"]


def test_v2_dry_run_same_manifest_deterministic(tmp_path, monkeypatch, capsys):
    """--dry-run两次引用同一v2清单，分母=清单实际数且无LLM、无写报告。"""
    manifest = _build_manifest_dict(tmp_path)
    mpath = tmp_path / "manifest_v2.json"
    t3.write_manifest(mpath, manifest)
    monkeypatch.setattr(ev, "REPORT", tmp_path / "no_report.json")
    for _ in range(2):
        rc = ev.main(["--datasets", "zh", "cosql", "--split", "all", "--all-turns",
                      "--subset-manifest", str(mpath), "--dry-run"])
        assert rc == 0
        out = capsys.readouterr().out
        assert "未调用模型" in out, "dry-run不得提示模型已运行"
    # 分母一致：两次筛选实际数=清单actual_count
    all_cases = _full_cases()[0]
    sh = {"cosql": ev.digest(json.loads(ev.COSQL.read_text(encoding="utf-8"))),
          "zh": ev.digest(json.loads(ev.ZH_CASES.read_text(encoding="utf-8")))}
    sel = t3.filter_and_verify_cases(manifest, all_cases, sh, ev._selector_code_hash())
    assert len(sel) == manifest["actual_count"] == len(manifest["cases"])
    assert not (tmp_path / "no_report.json").exists()


def test_unknown_rule_version_rejected(tmp_path):
    """非v1/v2规则版本拒绝，防止悄悄换规则。"""
    with pytest.raises(ValueError):
        t3.select_subset([_FakeCase("a:0")], target=1, rule_version="v3")
    bad = _build_manifest_dict(tmp_path)
    bad["rule_version"] = "v3"
    del bad["manifest_hash"]  # hash必须与篡改后内容重算一致才合法；此处校验完整性拒绝
    with pytest.raises(ValueError):
        t3.filter_and_verify_cases(bad, [_FakeCase("a:0")], {"cosql": "h"}, "sel")


def test_dry_run_subset_denominator_is_actual_count(tmp_path, monkeypatch, capsys):
    """dry-run子集模式：分母=清单实际数（非全量），不加载LLM、不写报告。"""
    manifest_path = MANIFEST  # 使用已存在的正式清单（只读）
    assert manifest_path.exists()
    report_path = tmp_path / "should_not_exist.json"
    monkeypatch.setattr(ev, "REPORT", report_path)
    rc = ev.main(["--datasets", "zh", "cosql", "--split", "all", "--all-turns",
                  "--subset-manifest", str(manifest_path)])
    assert rc == 0
    out = capsys.readouterr().out
    stats_line = next(l for l in out.splitlines() if l.startswith("{"))
    stats = json.loads(stats_line)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    # 分母=实际筛选数：可评分=清单实际数（中文20+cosql筛选数），排除未审核0
    assert stats["totals"]["built"] == manifest["actual_count"]
    assert stats["totals"]["runnable"] == manifest["actual_count"]
    assert "未调用模型" in out, "dry-run不得提示模型已运行"
    assert not report_path.exists(), "dry-run不得写任何报告"


def test_subset_conflicts_rejected(tmp_path, monkeypatch, capsys):
    """--limit非0/非all split/非all-turns/含BIRD 与子集模式互斥冲突即报错退出。"""
    manifest_path = MANIFEST
    monkeypatch.setattr(ev, "REPORT", tmp_path / "r.json")
    for argv in (
            ["--datasets", "zh", "cosql", "bird", "--split", "all", "--all-turns", "--subset-manifest", str(manifest_path)],
            ["--datasets", "zh", "cosql", "--split", "debug", "--all-turns", "--subset-manifest", str(manifest_path)],
            ["--datasets", "zh", "cosql", "--split", "all", "--subset-manifest", str(manifest_path)],
            ["--datasets", "zh", "cosql", "--split", "all", "--all-turns", "--limit", "10", "--subset-manifest", str(manifest_path)],
    ):
        with pytest.raises(SystemExit) as exc_info:
            ev.main(argv)
        assert exc_info.value.code == 2, f"冲突参数必须parser.error退出：{argv}"
    capsys.readouterr()


def test_report_flag_only_replaces_process_report(tmp_path, monkeypatch):
    """--report仅显式时替换本进程REPORT；默认（不传）时模块REPORT保持monkeypatch值。"""
    default_report = tmp_path / "default.json"
    monkeypatch.setattr(ev, "REPORT", default_report)
    # 不传--report：_run_model路径使用模块常量（此处只验证main在构建路径不改REPORT）
    rc = ev.main(["--datasets", "zh", "--split", "debug"])
    assert rc == 0
    assert ev.REPORT == default_report, "默认不得改动模块REPORT（monkeypatch契约）"
    # 显式--report（无run-model时不触发替换逻辑，保持默认）
    other = tmp_path / "other.json"
    rc = ev.main(["--datasets", "zh", "--split", "debug", "--report", str(other)])
    assert rc == 0
    # 构建路径不写报告；--report替换只在进入_run_model前生效，这里验证模块值未被构建路径改动
    assert not other.exists()


def test_win_permission_retry_then_success(tmp_path, monkeypatch):
    """replace前2次PermissionError(winerror=32)后成功；临时文件被清理；旧report未被改。"""
    report = tmp_path / "rep.json"
    report.write_text(json.dumps({"legacy": "old", "runs": {}}), encoding="utf-8")
    before = report.read_bytes()
    sleeps: list = []
    real_replace = os.replace
    calls = {"n": 0}

    def flaky_replace(src, dst):
        calls["n"] += 1
        if calls["n"] <= 2:
            err = PermissionError(32, "文件被占用")
            err.winerror = 32
            raise err
        real_replace(src, dst)

    monkeypatch.setattr(ev.os, "replace", flaky_replace)
    monkeypatch.setattr(ev.time, "sleep", sleeps.append)
    ev._save_run_unlocked(report, {"legacy": "old", "runs": {"new": {"x": 1}}})
    assert calls["n"] == 3, "前2次失败后第3次成功"
    assert sleeps[:2] == [0.05, 0.1], "短退避且重试复用同一临时文件"
    assert json.loads(report.read_text(encoding="utf-8"))["runs"]["new"]["x"] == 1
    assert not any(p.name.endswith(".tmp") for p in tmp_path.iterdir()), \
        "临时文件必须清理"


def test_win_permanent_failure_keeps_old_report_and_cleans_tmp(tmp_path, monkeypatch):
    """winerror=5永久失败：5次退避后抛出原PermissionError，旧report字节不变，临时文件已清理。"""
    import math
    report = tmp_path / "rep.json"
    report.write_text(json.dumps({"legacy": "frozen"}), encoding="utf-8")
    before = report.read_bytes()

    def always_fail(src, dst):
        err = PermissionError(5, "拒绝访问")
        err.winerror = 5
        raise err

    sleeps: list = []
    monkeypatch.setattr(ev.os, "replace", always_fail)
    monkeypatch.setattr(ev.time, "sleep", sleeps.append)
    with pytest.raises(PermissionError) as exc_info:
        ev._save_run_unlocked(report, {"new": 1})
    assert exc_info.value.winerror == 5, "原错误必须原样抛出（不被临时清理覆盖）"
    assert len(sleeps) == 5 and all(math.isclose(s, 0.05 * (i + 1)) for i, s in enumerate(sleeps)), \
        "最多5次短退避（0.05/0.1/.../0.25）"
    assert report.read_bytes() == before, "永久失败不得修改旧report"
    assert not any(p.name.endswith(".tmp") for p in tmp_path.iterdir()), "失败后临时文件仍须清理"


def test_non_lock_permission_error_raised_immediately(tmp_path, monkeypatch):
    """winerror不在{5,32,33}（如13）立即抛出，不做退避重试。"""
    report = tmp_path / "rep.json"
    report.write_text("{}", encoding="utf-8")
    sleeps: list = []

    def fail13(src, dst):
        err = PermissionError(13, "只读文件系统")
        err.winerror = 13
        raise err

    monkeypatch.setattr(ev.os, "replace", fail13)
    monkeypatch.setattr(ev.time, "sleep", sleeps.append)
    with pytest.raises(PermissionError) as exc_info:
        ev._save_run_unlocked(report, {"a": 1})
    assert exc_info.value.winerror == 13 and sleeps == [], "非锁类错误立即抛出且不退避"
