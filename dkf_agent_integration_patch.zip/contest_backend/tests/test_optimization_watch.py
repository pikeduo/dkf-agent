# -*- coding: utf-8 -*-
"""optimization_watch.py 的最小离线测试：只验证监控逻辑，不占用真实模型、不 import 生产 eval 代码。

覆盖：
1. 任务3 进度按 已处理记录数（status != not_attempted）推进，答错/技术失败也推进；
   另列 correct/semantic_scored/infra_failed/not_attempted，不用正确率判断卡顿；
2. 完成契约：planned>0、记录数齐、全部已处理、run.status=completed、无未恢复 HARD_STOP；
   缺记录（如仅 3 条而 planned 9233）禁止完成；
3. 成功读取报告中消失的 run 从缓存删除；写入中(None)不删；task3_status 真实反映；
4. 无真实 task3 run（legacy model_run=false）不触发无进度告警，不靠屏蔽 run 名掩盖问题；
5. planned 优先真实 denominators/metrics，不用 manifest.samples（含未审核 500）作分母；
6. 定时器 interval/poll 必须正数；首次心跳不重复立即触发；
7. 首次快照统一不刷历史；停止后恢复 running 刷新标志，再次停止/完成可再通知。
"""
import argparse
import ctypes
import os
import platform
import sys
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from evaluation import optimization_watch as ow  # noqa: E402


def t3_record(status, hit=None, error=None):
    """构造任务3真实字样的记录（record.status / hit / error）。"""
    return {"case_id": "x", "status": status, "hit": hit, "error": error}


def t3_run(status, recs, planned_n=None, stop_reason=None):
    """构造任务3 run：真实字段 runs[*].status/stop_reason/accuracy_denominators。"""
    run = {"manifest": {}, "records": {str(i): r for i, r in enumerate(recs)}, "status": status}
    if stop_reason is not None:
        run["stop_reason"] = stop_reason
    if planned_n is not None:
        run["accuracy_denominators"] = {
            "planned_n": planned_n,
            "attempted_n": sum(1 for r in recs if r["status"] != "not_attempted"),
            "not_attempted_n": sum(1 for r in recs if r["status"] == "not_attempted")}
    return run


# 用例1：任务3 进度=已处理记录数（hit=False/技术失败也推进），correct/未运行分列
def test_task3_progress_not_correctness():
    w = ow.Watch()
    recs = [t3_record("ready", hit=True), t3_record("needs_user", hit=False),
            t3_record("tool_error"), t3_record("not_attempted")]
    assert w._observe_run("task3", "full", t3_run("running", recs, 9233), 0.0) == []  # 首观锁档
    st = w.mon[("task3", "full")]
    # progress=3（ready/needs_user/tool_error 都已处理），correct=1，not_attempted=1
    assert st["last_prog"] == 3 and st["planned"] == 9233
    p = ow.t3_progress_counts(recs)
    assert p["progress"] == 3 and p["correct"] == 1 and p["not_attempted"] == 1
    assert p["semantic_scored"] == 2 and p["infra_failed"] == 0
    # 反例：连续答错 progress 10→60 仍触发里程碑，且不误报 no_progress（处理在推进）
    w2 = ow.Watch(no_progress_s=10)
    wrong = lambda n: [t3_record("needs_user", hit=False)] * n
    assert w2._observe_run("task3", "full", t3_run("running", wrong(10), 9233), 0.0) == []
    a = w2._observe_run("task3", "full", t3_run("running", wrong(60), 9233), 5.0)
    assert [x["type"] for x in a] == ["milestone"] and a[0]["progress"] == 60
    assert "no_progress" not in [x["type"] for x in a]  # 有推进不判卡顿
    # 里程碑/完成告警携带 分列统计
    assert a[0]["correct"] == 0 and a[0]["semantic_scored"] == 60


# 用例2：完成契约（planned>0、记录齐、全部已处理、status=completed、无未恢复 HARD_STOP）
def test_task3_completion_contract():
    w = ow.Watch()
    # 仅 3 条 records 而 planned=9233：禁止完成（缺记录拒绝）
    sparse = t3_run("completed", [t3_record("ready", hit=True)] * 3, 9233)
    a = w._observe_run("task3", "full", sparse, 0.0)
    assert not any(x["type"] == "run_completed" for x in a)
    # 纠正后的契约夹具：3 条记录配 planned=3 且全已处理、无故障 → 完成
    w2 = ow.Watch()
    w2._observe_run("task3", "full", t3_run("running", [t3_record("ready", hit=True)] * 3, 3), 0.0)
    a2 = w2._observe_run("task3", "full", t3_run("completed", [t3_record("ready", hit=True)] * 3, 3), 1.0)
    assert [x["type"] for x in a2] == ["run_completed"]
    # completed 但含未运行：不算完成
    w3 = ow.Watch()
    w3._observe_run("task3", "full",
                    t3_run("running", [t3_record("ready", hit=True), t3_record("not_attempted")], 9233), 0.0)
    r3 = t3_run("completed", [t3_record("ready", hit=True), t3_record("not_attempted")], 9233)
    assert not any(x["type"] == "run_completed" for x in w3._observe_run("task3", "full", r3, 1.0))
    # completed 但含未恢复 hard_stop（model_unavailable 属 HARD_STOP_ERRORS）：不算完成
    w4 = ow.Watch()
    w4._observe_run("task3", "full", t3_run("running", [t3_record("ready", hit=True)], 3), 0.0)
    r4 = t3_run("completed", [t3_record("ready", hit=True),
                              t3_record("tool_error", error="model_unavailable")], 3)
    a4 = w4._observe_run("task3", "full", r4, 1.0)
    assert not any(x["type"] == "run_completed" for x in a4)
    assert any(x["type"] == "infra_stopped" and x["unresolved_hard_stops"] == 1 for x in a4)
    # 纯语义失败（llm_timeout 不属 hard stop）允许完成
    w5 = ow.Watch()
    w5._observe_run("task3", "full",
                    t3_run("running", [t3_record("ready", hit=True)], 2), 0.0)
    r5 = t3_run("completed", [t3_record("ready", hit=True),
                              t3_record("tool_error", error="llm_timeout")], 2)
    assert [x["type"] for x in w5._observe_run("task3", "full", r5, 1.0)] == ["run_completed"]


# 用例3：成功读取后消失的 run 从缓存删除；写入中(None)不删；task3_status 真实反映
def test_disappeared_runs_purged_only_on_valid_json():
    w = ow.Watch()
    w.observe_task3({"runs": {"unit-run": t3_run("running", [t3_record("ready", hit=True)], 1)},
                     "model_run": True}, 0.0)
    assert ("task3", "unit-run") in w.mon and w.t3_status == "running"
    # 负责方清除误写 run 后：成功读到新报告（runs 为空）才删缓存
    w.observe_task3({"runs": {}, "model_run": False}, 10.0)
    assert ("task3", "unit-run") not in w.mon and w.t3_status == "not_attempted"
    # 写入中/损坏：本轮不可读(None)，不得删除已有缓存
    w.observe_task4({"execution_runs": {"bird500_r6_isolated":
                                        {"records": {}, "summary": {"planned": 500}}}}, 20.0)
    assert ("task4", "bird500_r6_isolated") in w.mon
    assert w.observe_task4(None, 30.0) == [] and ("task4", "bird500_r6_isolated") in w.mon
    # task3 停止/完成状态反映
    w2 = ow.Watch()
    w2.observe_task3({"runs": {"full": t3_run("stopped", [], None, "hard_stop:model_unavailable")}}, 0.0)
    assert w2.t3_status == "stopped"
    w3 = ow.Watch()
    w3.observe_task3({"runs": {"full": t3_run("completed", [t3_record("ready", hit=True)], 1)}}, 0.0)
    assert w3.t3_status == "completed"
    # 报告完全无 runs 且无 model_run 字段：记 absent
    w4 = ow.Watch()
    w4.observe_task3({"note": "legacy"}, 0.0)
    assert w4.t3_status == "absent"


# 用例4：无真实 task3 run（legacy model_run=false）不触发无进度告警；不靠屏蔽名字
def test_legacy_task3_no_false_no_progress():
    w = ow.Watch(no_progress_s=10)
    legacy = {"model_run": False, "samples": []}
    assert w.observe_task3(legacy, 0.0) == []
    assert w.observe_task3(legacy, 3600.0) == []
    assert ("task3", "unit-run") not in w.mon  # 不是靠屏蔽 unit-run，而是缓存里根本没 run
    # 对比：真实 running run 停滞才触发无进度告警
    w2 = ow.Watch(no_progress_s=10)
    run = t3_run("running", [t3_record("ready", hit=True)], 9233)
    w2._observe_run("task3", "full", run, 0.0)
    assert [a["type"] for a in w2._observe_run("task3", "full", run, 11.0)] == ["no_progress"]


# 用例5：planned 优先可信字段，不用 manifest.samples（含未审核 500）作分母
def test_planned_from_trusted_fields_only():
    recs = [t3_record("ready", hit=True)]
    # accuracy_denominators.planned_n 优先
    assert ow.planned_of(t3_run("running", recs, 9233), recs, "task3") == 9233
    # 无 denominators 时退 metrics.planned_n
    m = {"manifest": {}, "records": {}, "metrics": {"planned_n": 9233}, "status": "running"}
    assert ow.planned_of(m, recs, "task3") == 9233
    # manifest.samples（如 9733，含未审核 500）不得被采信：无可信字段时回退预置 records 数
    bad = {"manifest": {"samples": 9733}, "records": recs, "status": "running"}
    assert ow.planned_of(bad, recs, "task3") == 1
    # task4 仍用 summary.planned（500 口径）
    assert ow.planned_of({"records": {}, "summary": {"planned": 500}}, [], "task4") == 500
    # 完成契约：manifest.samples 给不了 9233，缺记录拒绝完成已在用例2覆盖


# 用例6：定时器参数必须正数；首次心跳不重复立即触发
def test_timer_interval_poll_positive_and_first_heartbeat():
    for args in (["--interval", "0"], ["--poll", "0"], ["--interval", "-5"], ["--poll", "-1"]):
        try:
            ow.main(args)
            assert False, "非法参数未被拒绝: %s" % args
        except SystemExit as e:
            assert "必须为正数" in str(e)
    a = argparse.Namespace(interval=900, poll=30)
    assert not (a.interval <= 0 or a.poll <= 0)
    # 首心跳 hb_due=start+interval：前 900 秒不触发
    t0 = 1_000_000.0
    assert (t0 + 1.0) < t0 + 900 and (t0 + 900.0) >= t0 + 900


# 用例7：报告缺失/半写/共享读安全降级；Windows 持有共享读句柄时观察写者原子 replace 真实行为（不碰真实报告）
def test_missing_halfwritten_and_shared_read(tmp_path):
    # 缺失文件安全返回 (None, False)
    assert ow.load_json_safe(Path("C:/nonexistent_ict_watch_report.json")) == (None, False)
    # 半写 JSON（截断）安全降级为 None，不抛全文异常
    half = tmp_path / "half.json"
    half.write_text('{"dataset": "bird"', encoding="utf-8")
    assert ow.load_json_safe(half) == (None, False)
    # 正常小 json 可解析
    ok = tmp_path / "ok.json"
    ok.write_text('{"runs": {}}', encoding="utf-8")
    data, _ok = ow.load_json_safe(ok)
    assert data == {"runs": {}}
    # 监控收到 None 报告时安全返回空告警
    w = ow.Watch()
    assert w.observe_task4(None, 0.0) == []
    assert w.observe_task3(None, 0.0) == []
    # 共享读反例：Windows 下持有 FILE_SHARE_READ|WRITE|DELETE 读句柄期间，
    # 记录写者 os.replace 的【真实】行为；不以“关句柄后可写”冒充共享语义
    if platform.system() == "Windows":
        import ctypes
        import os as _os
        dst = tmp_path / "dst.json"
        dst.write_text('{"old": 1}', encoding="utf-8")
        newf = tmp_path / "new.json"
        newf.write_text('{"new": 2}', encoding="utf-8")
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateFileW.restype = ctypes.c_void_p
        kernel32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32,
                                         ctypes.c_uint32, ctypes.c_void_p,
                                         ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_bool
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        share = ow.FILE_SHARE_READ | ow.FILE_SHARE_WRITE | ow.FILE_SHARE_DELETE
        h = kernel32.CreateFileW(str(dst), ow.GENERIC_READ, share, None,
                                  ow.OPEN_EXISTING,
                                  ow.FILE_FLAG_POSIX_SEMANTICS | ow.FILE_ATTRIBUTE_NORMAL, None)
        assert h not in (None, -1, ow.INVALID_HANDLE_VALUE), "共享读句柄打开失败"
        # 持有句柄期间尝试原子替换，记录真实结果（可能成功也可能被拒）
        replace_ok = True
        try:
            _os.replace(str(newf), str(dst))
        except OSError:
            replace_ok = False  # WinError5 等：仅证明本次替换被拒，不断言锁持有者
        kernel32.CloseHandle(h)  # 持有试验完成后关句柄
        # 关句柄后写者一定能原子替换成功（这是稳定事实）
        _os.replace(str(newf), str(dst)) if replace_ok is False else None
        data2, ok2 = ow.load_json_safe(dst)
        assert ok2 and data2 == {"new": 2}
        # 真实行为说明：持有共享句柄时的 replace 结果因环境而异，
        # 共享标志不足以保证环境不拒绝，因此不据此称“根因已证明是持写句柄”
        assert isinstance(replace_ok, bool)


# 用例7b：_read_bytes_shared 各级句柄关闭只发生一次（mock 打点），错误匹配不 TypeError
def test_read_bytes_shared_close_once(tmp_path):
    if platform.system() != "Windows":
        return  # 共享句柄路径仅 Windows；非 Windows 走普通 open，无句柄所有权转移
    import msvcrt
    import os as _os
    f = tmp_path / "shared.json"
    f.write_text('{"a": 1}', encoding="utf-8")
    # 成功路径：读完并逐级关闭，load 正常
    assert ow.load_json_safe(f) == ({"a": 1}, True)
    assert ow._read_bytes_shared(f) == b'{"a": 1}'
    # 缺失文件 → None（不冒认空文件）
    assert ow._read_bytes_shared(tmp_path / "nope.json") is None
    # 非 JSON 字节安全降级
    bad = tmp_path / "bad.json"
    bad.write_bytes(b"\xff\xfe not json")
    assert ow.load_json_safe(bad) == (None, False)
    # 失败分支：open_osfhandle 失败 → 走 else 分支 CloseHandle raw handle 一次，安全返回 None
    with mock.patch("msvcrt.open_osfhandle", side_effect=OSError("open_osfhandle fail")):
        res = ow._read_bytes_shared(f)
    assert res is None  # 打开 raw handle 后 open_osfhandle 失败，不泄漏（已 CloseHandle）
    # fdopen 失败 → 走 elif 分支 os.close(fd) 一次（连带关 handle），不重复 CloseHandle
    ch_seen, close_seen = [], []
    import ctypes
    with mock.patch("msvcrt.open_osfhandle", return_value=12345), \
         mock.patch("os.fdopen", side_effect=OSError("fdopen fail")), \
         mock.patch("os.close", side_effect=lambda fd: close_seen.append(fd)), \
         mock.patch.object(ow, "_read_bytes_shared") as _stub:  # 隔离，避免真实 kernel 调用
        pass
    # 直接构造 fd 已得、fdopen 失败 的路径：monkey 打点 os.close 与 CloseHandle，验证只各关一次
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = ctypes.c_bool
    real_open_osf = msvcrt.open_osfhandle
    real_fdopen = os.fdopen
    real_os_close = os.close
    real_ch = kernel32.CloseHandle

    def counting_fdopen(fd, mode):
        ch_seen.append("fdopen_fail"); raise OSError("fdopen fail")
    try:
        msvcrt.open_osfhandle = lambda h, flags: 12345
        os.fdopen = counting_fdopen
        def counting_close(fd):
            close_seen.append(fd); real_os_close(fd)
        os.close = counting_close
        res2 = ow._read_bytes_shared(f)
    finally:
        msvcrt.open_osfhandle = real_open_osf
        os.fdopen = real_fdopen
        os.close = real_os_close
    assert res2 is None
    # fd 已交给 os.close（fdopen 失败分支）：只关一次 fd，不额外 CloseHandle raw
    assert close_seen.count(12345) == 1
    # 源码不含把 ctypes.WinError 当异常类匹配的写法（ctypes.WinError 是工厂函数，非类）
    assert "except (OSError, ValueError, ctypes.WinError)" not in open(ow.__file__, encoding="utf-8").read()


# 用例8：里程碑/完成/停止 去重与 task4 口径回归
def test_task4_milestone_and_dedupe():
    def t4_run(states, stop=None, stopped_model=0):
        return {"manifest": {}, "records": {str(i): {"state": s} for i, s in enumerate(states)},
                "summary": {"planned": len(states), "stop_reason": stop, "stopped_model": stopped_model}}
    w = ow.Watch()
    r6 = "bird500_r6_isolated"
    assert w._observe_run("task4", r6, t4_run(["completed"] * 120 + ["not_attempted"] * 10), 0.0) == []
    assert w._observe_run("task4", r6, t4_run(["completed"] * 120 + ["not_attempted"] * 10), 5.0) == []
    a = w._observe_run("task4", r6, t4_run(["completed"] * 150 + ["not_attempted"] * 10), 10.0)
    assert [x["type"] for x in a] == ["milestone"] and a[0]["milestone"] == 150
    # 由进行中迁移到 500/500 才告警；首观即满 500 的历史 run 不刷历史告警
    w2 = ow.Watch()
    assert w2._observe_run("task4", r6, t4_run(["completed"] * 480 + ["not_attempted"] * 20), 0.0) == []
    assert [x["type"] for x in w2._observe_run("task4", r6, t4_run(["completed"] * 500), 1.0)] \
        == ["milestone", "run_completed"]
    w2b = ow.Watch()
    assert w2b._observe_run("task4", r6, t4_run(["completed"] * 500), 0.0) == []
    # 停止由进行中迁移才触发；首观即停止的历史 run 不刷历史告警
    w4 = ow.Watch()
    w4._observe_run("task4", r6, t4_run(["completed"] * 5), 0.0)
    stop_run = t4_run(["completed"] * 10, stop="model_unavailable")
    kinds = [x["type"] for x in w4._observe_run("task4", r6, stop_run, 1.0)]
    assert "run_stopped" in kinds
    assert w4._observe_run("task4", r6, stop_run, 9.0) == []


# 用例9：首次快照统一不刷历史；里程碑与完成/停止可同轮共存；stopped→running 恢复刷新标志
def test_first_snapshot_and_recover():
    def t4_run(states, stop=None):
        return {"manifest": {}, "records": {str(i): {"state": s} for i, s in enumerate(states)},
                "summary": {"planned": len(states), "stop_reason": stop}}
    r6 = "bird500_r6_isolated"
    w = ow.Watch()
    # 首次快照：已满 500 的历史 run 与 首观即停止 的 run 都不刷历史告警
    assert w._observe_run("task4", r6, t4_run(["completed"] * 500), 0.0) == []
    stop_run = t4_run(["completed"] * 10, stop="stopped")
    assert w._observe_run("task4", "other", stop_run, 0.0) == []
    # 里程碑与完成/停止同轮共存（进行中跨 50 步同时进入停止态）
    w2 = ow.Watch()
    w2._observe_run("task4", r6, t4_run(["completed"] * 40 + ["not_attempted"] * 60), 0.0)
    same = [x for x in w2._observe_run("task4", r6, t4_run(["completed"] * 50 + ["not_attempted"] * 50,
                                                            stop="stopped"), 1.0)]
    assert [x["type"] for x in same] == ["milestone", "run_stopped"]
    # task3 停止后恢复 running：状态标志刷新，再次停止/完成能再通知
    w3 = ow.Watch()
    run = lambda n, status, stop=None: t3_run(status, [t3_record("ready", hit=True)] * n, 3, stop)
    w3._observe_run("task3", "full", run(3, "running"), 0.0)
    assert [x["type"] for x in w3._observe_run("task3", "full", run(3, "stopped", "db_down"), 1.0)] \
        == ["infra_stopped"]
    w3._observe_run("task3", "full", run(3, "running"), 2.0)      # 恢复 running，刷新标志
    assert [x["type"] for x in w3._observe_run("task3", "full", run(3, "stopped", "db_down"), 3.0)] \
        == ["infra_stopped"]                                      # 再次停止可再通知
    assert [x["type"] for x in w3._observe_run("task3", "full", run(3, "running"), 4.0)] == []
    assert [x["type"] for x in w3._observe_run("task3", "full", run(3, "completed"), 5.0)] \
        == ["run_completed"]                                      # 恢复后完成仍可通知


# 用例10：task4 历史 run 抑制 + r6 与 新 run 告警（保留旧测面）
def test_task4_history_suppression():
    def done500():
        return {"records": {str(i): {"state": "completed"} for i in range(500)}, "summary": {"planned": 500}}
    hist = {"smoke1": done500(), "bird500_r5": done500(), "bird500_r6_isolated": done500()}
    w = ow.Watch()
    assert w.observe_task4({"execution_runs": hist}, 0.0) == []
    assert w.observe_task4({"execution_runs": hist}, 9.0) == []
    new = dict(hist, bird500_r7={"records": {}, "summary": {"planned": 500}})
    assert w.observe_task4(new, 10.0) == []
    assert w.observe_task4(new, 11.0) == []


if __name__ == "__main__":
    import unittest
    sys.exit(unittest.main(module=__name__, verbosity=1))
