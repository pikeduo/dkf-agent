"""固定调试分组复查后的通用回归夹具，不计入真实数据集成绩。"""
from decimal import Decimal
import json

import pytest

from backend.agents.task6_formula.formula_spec import spec_from_card, spec_from_user_formula
from backend.agents.task6_formula.numeric_units import quantity_from_raw
from backend.agents.task6_formula.param_finder import ParamFinder
from backend.agents.task6_formula.safe_calculator import SafeCalculator


@pytest.mark.parametrize("label", ["object's weight", "(Gas meter reading)", "汽车总质量"])
def test_opaque_placeholder_labels_do_not_become_executable_code(label):
    spec = spec_from_user_formula(f"[result]=[{label}]*2")
    assert spec.parse_status == "ok"
    assert SafeCalculator().compute_spec(spec, {label: 3})["result"] == 6


def test_symbol_map_identity_is_rechecked():
    spec = spec_from_user_formula("[y]=[x]+1")
    spec.symbol_map["x"] = "_v1"
    out = SafeCalculator().compute_spec(spec, {"x": 3})
    assert out["check_failed"] == "symbol_map_mismatch"


@pytest.mark.parametrize("unit,expected", [("dm³", .001), ("l", .001), ("kW•h", 3600000)])
def test_standard_linear_unit_alias_regressions(unit, expected):
    assert quantity_from_raw(1, unit).value == pytest.approx(expected)


@pytest.mark.parametrize("formula", ["[y]=[_v2]+1", "x=[0]", "x=[a,b]", "x=[__import__('os')]"])
def test_placeholder_name_injection_and_internal_collision_rejected(formula):
    assert spec_from_user_formula(formula).parse_status == "parse_error"


@pytest.mark.parametrize("formula", ["[y]=[x]+_ｖ2", "[y]=[_ｖ2]+1", "[y]=[x]+𝐱", "y=µ+μ"])
def test_compatibility_unicode_names_cannot_merge_symbols(formula):
    assert spec_from_user_formula(formula).parse_status == "parse_error"


def test_decimal_binding_contract_is_json_serializable():
    out = SafeCalculator().compute("x*2", {"x": {"raw_value": Decimal("0.125"), "source": {"quote": "x=0.125"}}})
    assert out["result"] == .25
    json.dumps(out, allow_nan=False)


@pytest.mark.parametrize("source", [object(), {"value": float("nan")}, "x" * 9000])
def test_invalid_source_returns_structured_failure(source):
    out = SafeCalculator().compute("x*2", {"x": {"raw_value": 1, "source": source}})
    assert out["check_failed"] == "invalid_binding"
    json.dumps(out, allow_nan=False)


def test_parameter_source_budget_never_truncates_or_calls_model():
    out = ParamFinder().bind("f", ["x"], "", "x" * 200001)[0]
    assert out["status"] == "missing" and out["error_code"] == "resource_limit"


@pytest.mark.parametrize("value", [float("nan"), True, None, complex(1, 1), {}])
def test_unused_binding_does_not_bypass_numeric_validation(value):
    out = SafeCalculator().compute("2+3", {"extra": value})
    assert out["ok"] is False and out["result"] is None
    json.dumps(out, allow_nan=False)


def test_pure_dictionary_spec_cannot_bypass_percentage_representation():
    # 仅验证旧字典接口，不连接或读取任何公式卡片库。
    spec = spec_from_card({"id": "unit_fixture", "expression": "y=x*100", "display": "percent"})
    out = SafeCalculator().compute_spec(spec, {"x": .2})
    assert out["check_failed"] == "ambiguous_representation"


@pytest.mark.parametrize("variables", [None, [None], [1], [""]])
def test_invalid_parameter_variable_list_is_structured(variables):
    out = ParamFinder().bind("f", variables, "", "")
    assert out[0]["status"] == "missing" and out[0]["error_code"] == "invalid_binding"


@pytest.mark.parametrize("source,code", [("x=20mystery", "unsupported_unit"),
    ("x=20 mystery", "unsupported_unit"), ("x=bad", "invalid_number")])
def test_parameter_found_but_invalid_is_not_missing_evidence(source, code):
    out = ParamFinder().bind("f", ["x"], source, "")[0]
    assert out["status"] == "missing" and out["error_code"] == code
    assert out["source"]["quote"] == source


@pytest.mark.parametrize("unit", ["%", "百分比"])
def test_requested_percent_unit_does_not_double_scale_formula(unit):
    spec = spec_from_user_formula("y=x*100")
    spec.expected_unit = unit
    bindings = {"x": {"raw_value": .2, "unit": "1"}}
    assert SafeCalculator().compute_spec(spec, bindings)["check_failed"] == "ambiguous_representation"
    spec.output_representation = "percent_number"
    out = SafeCalculator().compute_spec(spec, bindings)
    assert out["result"] == 20 and out["normalized_result"] == .2
