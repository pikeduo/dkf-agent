"""任务3评测运行器可靠性测试；仅本地数据与无网络桩客户端，不调真实模型。

覆盖父复核7项：故障停止外层提交、resume故障重试/语义不重跑、双分母口径、
跨进程报告锁、manifest含自评代码与resolved模型身份、checkpoint时机与线程、
真实2并发窗口验证。既有去泄漏与评分测试在test_eval_clarify.py不退化。
"""
import hashlib
import json
import threading
import time
import types
from pathlib import Path

import pytest

import evaluation.eval_clarify as ev
from tests.test_intent import StubClient

# 正式task3报告绝对路径：独立于ev.REPORT（后者会被隔离fixture改指tmp），用于污染防护校验
REAL_TASK3_REPORT = (Path(__file__).resolve().parents[1]
                     / "evaluation" / "reports" / "optimization_task3_20261010.json")

MOCK_IDENTITY = {"provider": "wb", "model_name": "mock-model",
                 "model_identifier": "mock16", "endpoint_identifier": "mock16",
                 "request_timeout_s": 60.0, "reasoning_effort": None,
                 "max_extra_http_retries": 2}


@pytest.fixture(autouse=True)
def _guard_real_task3_report():
    """会话级强制防护：记录正式task3报告字节hash，全部测试跑完断言未变。
    只校验、发现污染即测试失败，绝不顺手清理正式报告当作通过。"""
    before = hashlib.sha256(REAL_TASK3_REPORT.read_bytes()).hexdigest() \
        if REAL_TASK3_REPORT.exists() else None
    yield
    after = hashlib.sha256(REAL_TASK3_REPORT.read_bytes()).hexdigest() \
        if REAL_TASK3_REPORT.exists() else None
    assert before == after, "正式task3报告被测试污染，路径不变性破坏"


@pytest.fixture(autouse=True)
def report_path(tmp_path, monkeypatch):
    """强制隔离（autouse）：本模块全部测试的ev.REPORT指向tmp，model_identity用固定mock。
    任何调用_run_model/main只能写tmp_path，绝不写正式报告；按名请求也拿到同一tmp路径。"""
    path = tmp_path / "task3.json"
    monkeypatch.setattr(ev, "REPORT", path)
    monkeypatch.setattr(ev, "model_identity", lambda: dict(MOCK_IDENTITY))
    yield path


class ConcurrencyClient:
    """确定性按case故障：question文本内嵌序号标记，仅命中fail_markers的问题抛鉴权故障，
    其余成功。与调用顺序/并发无关，全量并发跑也稳定；可配Event网关驻留并发窗口。"""

    def __init__(self, fail_markers=frozenset()):
        self.fail_markers = frozenset(fail_markers)
        self.gateway = None
        self.calls = 0
        self.active = 0
        self.peak = 0
        self.peak_lock = threading.Lock()
        self.payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
                       "facts": [], "formulas": [], "requirements": []}

    def chat(self, messages, temperature=0.0, reasoning_effort="default"):
        with self.peak_lock:
            self.active += 1
            self.peak = max(self.peak, self.active)
            self.calls += 1
        try:
            if self.gateway is not None:
                self.gateway.wait(timeout=10)
            # 从user消息正文取嵌入的case标记，决定本条是否故障（确定性，与并发序无关）
            question = ""
            for m in reversed(messages):
                if m.get("role") == "user":
                    try:
                        question = json.loads(m["content"])["inputs"][0]["text"]
                    except Exception:
                        question = m.get("content", "")
                    break
            hit = next((mark for mark in self.fail_markers if f"CAS{mark}" in question), None)
            if hit is not None:
                raise RuntimeError("API 密钥未配置，无法调用供应商")
            return json.dumps(self.payload, ensure_ascii=False)
        finally:
            with self.peak_lock:
                self.active -= 1


def make_args(**overrides):
    base = dict(split="all", datasets=("zh", "cosql", "bird"), all_turns=False,
                limit=0, diagnose_first_option=False, bird_ids="", run_id="unit-run")
    base.update(overrides)
    return types.SimpleNamespace(**base)


def make_cases(n: int):
    """case正文内嵌"CASk"标记，故障客户端可据此确定性按case判定，不依赖调用顺序。"""
    from evaluation.eval_clarify import EvalCase, EvalInput
    return [EvalCase(f"unit:{i}", "zh", "debug",
                     EvalInput(f"查询 CAS{i}", "chinook"),
                     ("MANUAL_ZH",), "MANUAL_ZH", True) for i in range(n)]


def run_model_with(client, cases, **arg_over):
    """统一入口：patch LLMClient并运行_run_model，返回(rc, client, report_json)。"""
    import backend.core.llm_client as llm_module
    old = llm_module.LLMClient
    llm_module.LLMClient = lambda: client
    try:
        rc = ev._run_model(make_args(**arg_over), cases, cases, {"zh": "hash"})
    finally:
        llm_module.LLMClient = old
    report = json.loads(ev.REPORT.read_text(encoding="utf-8"))
    return rc, client, report["runs"]["unit-run"]


def test_dry_run_does_not_overwrite_existing_report(report_path, monkeypatch, capsys):
    legacy = {"model_run": False, "accuracy": None, "note": "冻结旧值"}
    report_path.write_text(json.dumps(legacy, ensure_ascii=False), encoding="utf-8")
    rc = ev.main(["--dry-run", "--datasets", "zh", "--split", "debug"])
    assert rc == 0
    assert json.loads(report_path.read_text(encoding="utf-8")) == legacy, "dry-run不得写报告"
    # 非模型构建路径同样不写报告；既有报告（含legacy与旧runs）原样保留
    rc = ev.main(["--datasets", "zh", "--split", "debug"])
    assert rc == 0
    assert json.loads(report_path.read_text(encoding="utf-8")) == legacy, "非模型构建不得写报告"


def test_hard_stop_stops_outer_loop_keeps_planned_denominator(report_path):
    """5题全部model_unavailable：外层提交必须停，calls<=2、attempted<=2、not_attempted>=3。"""
    client = ConcurrencyClient(fail_markers=frozenset({0, 1, 2, 3, 4}))
    rc, client, run = run_model_with(client, make_cases(5))
    assert rc == ev.EXIT_STOPPED
    assert client.calls <= 2, "故障后外层循环仍在烧队列"
    denom = run["accuracy_denominators"]
    assert denom["planned_n"] == 5
    assert denom["attempted_n"] <= 2 and denom["not_attempted_n"] >= 3
    assert run["status"] == "stopped" and "hard_stop" in run["stop_reason"]
    blob = json.dumps(run, ensure_ascii=False)
    assert "API 密钥未配置" not in blob and "unit-key" not in blob


def test_resume_retries_failed_keeps_history_and_still_nonzero(report_path):
    """resume：语义完成不重跑；故障与未运行case重试且保留前次故障分类；仍故障必须非0。"""
    cases = make_cases(3)
    # 第一次：仅CAS1故障 → 并发窗口内case0成功、case1故障、case2未提交
    client = ConcurrencyClient(fail_markers=frozenset({1}))
    rc1, _, run1 = run_model_with(client, cases)
    assert rc1 == ev.EXIT_STOPPED
    failed = [cid for cid, r in run1["records"].items()
              if r.get("error") in ev.HARD_STOP_ERRORS]
    pending_na = [cid for cid, r in run1["records"].items() if r["status"] == "not_attempted"]
    ok_cases = [cid for cid, r in run1["records"].items() if r.get("ok")]
    assert len(failed) == 1 and len(pending_na) == 1 and len(ok_cases) == 1
    # 第二次：故障case与未运行case仍故障，exit3；保留前一次故障分类/耗时
    client3 = ConcurrencyClient(fail_markers=frozenset({1, 2}))
    rc2, client3, run2 = run_model_with(client3, cases)
    assert rc2 == ev.EXIT_STOPPED
    assert client3.calls == len(failed) + len(pending_na), "只重试故障与未运行case"
    for cid in failed:
        rec = run2["records"][cid]
        assert rec.get("prior_error") in ev.HARD_STOP_ERRORS, "必须保留前一次故障分类"
        assert rec.get("retry_count") == 1 and rec.get("prior_latency_s") is not None
        assert rec["error"] in ev.HARD_STOP_ERRORS, "仍故障不得伪装成功"
    assert run2["status"] in {"stopped", "incomplete"}
    # 第三次：客户端恢复（无故障标记），同manifest续跑覆盖全部并completed
    client2 = ConcurrencyClient()
    rc3, client2, run3 = run_model_with(client2, cases)
    assert rc3 == 0 and run3["status"] == "completed"
    assert client2.calls == len(failed) + len(pending_na), "只补齐未成功case"
    for cid in failed:
        rec = run3["records"][cid]
        assert rec["ok"], "恢复后成功"
        assert rec.get("prior_error") in ev.HARD_STOP_ERRORS, "故障历史不被偷换"
        assert rec.get("retry_count") == 2
    for cid in ok_cases:
        assert "prior_error" not in run3["records"][cid], "成功case不得被重跑偷换"
    assert all(r["status"] != "not_attempted" for r in run3["records"].values())


def test_double_denominator_and_coverage(report_path):
    """双分母：correct_over_planned/accuracy_attempted/completion_rate与分组覆盖分列。"""
    client = ConcurrencyClient(fail_markers=frozenset({0, 1, 2, 3}))  # 全部故障
    rc, _, run = run_model_with(client, make_cases(4))
    assert rc == ev.EXIT_STOPPED
    denom = run["accuracy_denominators"]
    assert denom["planned_n"] == 4 and denom["attempted_n"] <= 2
    assert denom["not_attempted_n"] == 4 - denom["attempted_n"]
    assert "scope" in denom and "计划" in denom["scope"]
    m = run["metrics"]
    assert m["planned_n"] == 4 and m["not_attempted_n"] == 4 - m["attempted_n"]
    assert m["accuracy_attempted"] == 0.0  # 已评分全错
    assert m["correct_over_planned"] == 0.0
    assert 0 < m["completion_rate"] < 1
    cov = m["coverage"]["by_group"]["MANUAL_ZH"]
    assert cov["planned_n"] == 4 and cov["not_attempted_n"] == 4 - cov["attempted_n"]
    # 未运行题不伪造技术失败
    assert cov["technical_failed"] <= cov["attempted_n"]


def test_cross_process_lock_rejects_second_writer(report_path):
    """第二写者拒绝且不动旧legacy字段。"""
    client = ConcurrencyClient(fail_markers=frozenset({0, 1}))  # 全部故障→hard stop
    rc, _, _ = run_model_with(client, make_cases(2))
    assert rc == ev.EXIT_STOPPED
    legacy = json.loads(report_path.read_text(encoding="utf-8"))
    legacy["note"] = "冻结旧值"
    report_path.write_text(json.dumps(legacy, ensure_ascii=False), encoding="utf-8")
    # 模拟另一进程持锁
    ev.acquire_report_lock(report_path)
    try:
        rc2, _, _ = run_model_with(ConcurrencyClient(), make_cases(2), run_id="other")
        assert rc2 == ev.EXIT_CONFLICT
    finally:
        ev.release_report_lock(report_path)
    final = json.loads(report_path.read_text(encoding="utf-8"))
    assert final["note"] == "冻结旧值", "被拒绝的第二写者不得修改legacy"
    assert "other" not in final.get("runs", {})


def test_manifest_covers_eval_code_and_model_identity(report_path):
    """manifest必须含自评代码指纹与resolved模型身份；eval_clarify改动即拒绝旧run。"""
    client = ConcurrencyClient()
    rc, _, run = run_model_with(client, make_cases(2))
    manifest = run["manifest"]
    assert "self_code_hash" in manifest and manifest["self_code_hash"]
    assert manifest["prod_code_hashes"], "生产代码指纹缺失"
    assert manifest["model_provider"]["model_name"] == "mock-model"
    assert manifest["model_provider"]["max_extra_http_retries"] == 2
    assert "request_timeout_s" in manifest["model_provider"]
    # 模拟自评代码变更：self_code_hash不同即拒绝
    data = json.loads(report_path.read_text(encoding="utf-8"))
    data["runs"]["unit-run"]["manifest"]["self_code_hash"] = "changed"
    report_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    rc2, _, _ = run_model_with(ConcurrencyClient(), make_cases(2), run_id="unit-run")
    assert rc2 == ev.EXIT_CONFLICT


def test_records_validation_rejects_extra_or_mismatched(report_path, monkeypatch):
    """记录键/样本hash/db一致性校验：拒绝额外记录与串样本。"""
    client = ConcurrencyClient()
    rc, _, _ = run_model_with(client, make_cases(2))
    data = json.loads(report_path.read_text(encoding="utf-8"))
    run = data["runs"]["unit-run"]
    run["records"]["rogue:0"] = dict(run["records"]["unit:0"])
    report_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    rc2, _, _ = run_model_with(ConcurrencyClient(), make_cases(2), run_id="unit-run")
    assert rc2 == ev.EXIT_CONFLICT, "额外记录必须被拒绝"
    # 串样本：篡改某记录的dataset
    data = json.loads(report_path.read_text(encoding="utf-8"))
    run = data["runs"]["unit-run"]
    del run["records"]["rogue:0"]
    run["records"]["unit:0"]["dataset"] = "cosql"
    report_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    rc3, _, _ = run_model_with(ConcurrencyClient(), make_cases(2), run_id="unit-run")
    assert rc3 == ev.EXIT_CONFLICT


def test_checkpoint_timing_and_main_thread(report_path, monkeypatch):
    """patch保存函数记录线程ID与调用时机：启动占位先写、逐题在中途写、全部同一主线程。"""
    events = []
    original_unlock = ev._save_run_unlocked

    def spy_unlock(report, data):
        current = json.loads(json.dumps(data.get("runs", {}).get("unit-run", {}), ensure_ascii=False))
        events.append((threading.get_ident(), current.get("records", {})))
        original_unlock(report, data)

    client = ConcurrencyClient()
    client.gateway = threading.Event()  # 先不放行，让2个调用驻留在途
    import backend.core.llm_client as llm_module
    old_client, old_spy = llm_module.LLMClient, ev._save_run_unlocked
    llm_module.LLMClient = lambda: client
    ev._save_run_unlocked = spy_unlock
    cases = make_cases(2)
    # 运行线程充当_run_model的主线程；测试线程持Event门控在途窗口
    holder = {}
    def runner():
        holder["rc"] = ev._run_model(make_args(), cases, cases, {"zh": "hash"})
    worker = threading.Thread(target=runner, daemon=True)
    worker.start()
    time.sleep(0.5)  # 等2个调用真正驻留
    try:
        client.gateway.set()
        worker.join(timeout=60)
        assert not worker.is_alive(), "运行超时"
        rc = holder["rc"]
    finally:
        llm_module.LLMClient = old_client
        ev._save_run_unlocked = old_spy
        client.gateway.set()
    assert rc == 0
    assert events, "必须有多次保存"
    run_thread = events[0][0]
    assert all(tid == run_thread for tid, _ in events), "checkpoint必须只发生在同一主线程"
    # 第一次保存=启动占位（全not_attempted），在任何题目完成之前
    first_records = events[0][1]
    assert all(r["status"] == "not_attempted" for r in first_records.values()), "启动占位必须先写盘"
    # 中间保存：至少1题已在整批完成前落盘（存在恰好1题已完成的中间态）
    attempted_counts = [sum(1 for r in recs.values() if r["status"] != "not_attempted")
                        for _, recs in events[1:]]
    assert 1 in attempted_counts or len(set(attempted_counts)) >= 2, "逐结果checkpoint必须在中途发生"


def test_true_two_concurrent_window(report_path):
    """用Event门控让2个调用同时驻留，验证真正达到2并发而非峰值<=2立即返回。"""
    client = ConcurrencyClient()
    client.gateway = threading.Event()
    import backend.core.llm_client as llm_module
    old = llm_module.LLMClient
    llm_module.LLMClient = lambda: client
    try:
        rc_holder = {}
        def runner():
            rc_holder["rc"] = ev._run_model(make_args(), make_cases(2), make_cases(2), {"zh": "hash"})
        worker = threading.Thread(target=runner, daemon=True)
        worker.start()
        time.sleep(0.5)  # 等两个调用真正驻留在chat()内
        # 主线程放行：驻留中的两个调用完成后run才返回
        client.gateway.set()
        worker.join(timeout=60)
        assert worker.is_alive() is False, "运行超时"
        rc = rc_holder.get("rc")
        assert rc == 0
    finally:
        llm_module.LLMClient = old
        client.gateway.set()
    assert client.peak == 2, "必须真正维持2并发窗口（峰值=2且调用驻留）"
    assert client.calls == 2


def test_bird_duplicate_qid_rejected_and_full_id_unique():
    data = json.loads(ev.BIRD.read_text(encoding="utf-8"))
    with pytest.raises(ValueError):
        ev.build_bird_cases(data, "137")  # 裸qid歧义，拒绝静默选2题
    with pytest.raises(ValueError):
        ev.build_bird_cases(data, "9999")  # 不存在的ID
    cases = ev.build_bird_cases(data, "484:financial:137,487:financial:137")
    assert len({c.case_id for c in cases}) == len(cases), "唯一ID=序号:库:题号，不重复"
    selected = [c for c in cases if c.primary_label == "COMPLETE_CONTROL"]
    assert [c.case_id for c in selected] == ["bird:484:financial:137", "bird:487:financial:137"]
    assert all(c.expect_clarify is None for c in cases if c.primary_label == "UNADJUDICATED")


def test_first_turn_vs_all_turns_counts_are_built_not_guessed():
    data = json.loads(ev.COSQL.read_text(encoding="utf-8"))
    cases_ft, _, map_ft = ev._build_cases(types.SimpleNamespace(
        datasets=("cosql",), split="all", all_turns=False, limit=0,
        diagnose_first_option=False, bird_ids=""))
    cases_at, _, _ = ev._build_cases(types.SimpleNamespace(
        datasets=("cosql",), split="all", all_turns=True, limit=0,
        diagnose_first_option=False, bird_ids=""))
    assert len(cases_at) > len(cases_ft), "all-turns必须覆盖全部符合标签规则用户轮"
    stats_ft = ev.build_stats(map_ft, False, cases_ft)
    assert stats_ft["cosql"]["eligible_samples"] == len(cases_ft)
    runnable_ft = [c for c in cases_ft if c.primary_label != "UNADJUDICATED"]
    assert len(runnable_ft) == len(cases_ft)
