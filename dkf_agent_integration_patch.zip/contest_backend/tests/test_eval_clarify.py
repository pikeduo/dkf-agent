"""任务3评测构建、固定分区与去泄漏测试；只用本地数据和无网络客户端。"""
import copy
import json

from evaluation.eval_clarify import (
    BIRD, COSQL, ZH_CASES, EvalCase, EvalInput, build_bird_cases, build_cosql_cases,
    build_zh_cases, digest, run_case, summarize,
)
from tests.test_intent import StubClient


def test_real_cosql_build_preserves_native_labels_without_future_or_sql_leak():
    data = json.loads(COSQL.read_text(encoding="utf-8"))
    cases = build_cosql_cases(data, all_turns=True)
    assert cases and any("AMBIGUOUS" in c.labels for c in cases)
    assert any(c.primary_label == "CANNOT_ANSWER" for c in cases)
    assert any(c.system_clarify is True for c in cases)
    assert all(set(c.model_input.payload()) == {"question", "database", "history"} for c in cases)
    for case in cases:
        assert all(set(h) == {"id", "role", "text"} for h in case.model_input.history)
    # 用同一真实对话，改变所有目标答案字段，生产输入必须保持不变。
    key = next(iter(data))
    original = {key: data[key]}
    changed = copy.deepcopy(original)
    changed[key]["sql"] = "金标禁止泄漏"
    changed[key]["query_goal"] = "最终目标禁止泄漏"
    for turn in changed[key]["turns"]:
        if turn.get("isSql"):
            turn["text"] = "SQL结果禁止泄漏"
            turn["rawSql"] = "SQL答案禁止泄漏"
        elif not turn.get("isUser") and "CLARIFY" not in (turn.get("label") or []):
            turn["text"] = "答案回复禁止泄漏"
    before = build_cosql_cases(original, all_turns=True)
    after = build_cosql_cases(changed, all_turns=True)
    assert [c.model_input.payload() for c in before] == [c.model_input.payload() for c in after]


def test_real_cosql_dialogs_never_cross_fixed_partitions():
    data = json.loads(COSQL.read_text(encoding="utf-8"))
    first = build_cosql_cases(data, all_turns=True)
    second = build_cosql_cases(data, all_turns=True)
    assert [c.sample_hash() for c in first] == [c.sample_hash() for c in second]
    groups = {}
    for case in first:
        dialog = case.case_id.rsplit(":", 1)[0]
        groups.setdefault(dialog, set()).add(case.split)
    assert all(len(parts) == 1 for parts in groups.values())
    assert {c.split for c in first} == {"debug", "heldout"}


def test_real_zh_twenty_annotations_are_frozen_and_paired():
    raw = ZH_CASES.read_text(encoding="utf-8")
    data = json.loads(raw)
    before = digest(data)
    cases = build_zh_cases(data)
    assert len(cases) == 20 and sum(c.expect_clarify for c in cases) == 9
    assert digest(data) == before and ZH_CASES.read_text(encoding="utf-8") == raw
    for i in range(0, 20, 2):
        assert cases[i].split == cases[i + 1].split


def test_bird_official_evidence_and_sql_are_not_production_inputs():
    data = json.loads(BIRD.read_text(encoding="utf-8"))
    case_id = f"{0}:{data[0]['db_id']}:{data[0]['question_id']}"
    cases = build_bird_cases(data, complete_ids=case_id)
    assert sum(c.primary_label == "COMPLETE_CONTROL" for c in cases) == 1
    assert all(c.expect_clarify is None for c in cases if c.primary_label == "UNADJUDICATED")
    changed = copy.deepcopy(data)
    for item in changed:
        item["evidence"] = "官方解释禁止进入生产"
        item["SQL"] = "标准答案禁止进入生产"
    after = build_bird_cases(changed, complete_ids=case_id)
    assert [c.model_input.payload() for c in cases] == [c.model_input.payload() for c in after]


def test_unavailable_model_is_attempted_once_and_failure_stays_in_denominator():
    case = EvalCase("unit", "zh", "debug", EvalInput("查询", "chinook"), (), "MANUAL_ZH", False)
    client = StubClient(RuntimeError("不能回显的供应商正文"))
    record = run_case(case, client_factory=lambda: client)
    assert client.calls == 1 and record["hit"] is False and not record["ok"]
    assert "不能回显" not in json.dumps(record, ensure_ascii=False)
    summary = summarize([record])
    group = summary["groups"]["MANUAL_ZH"]
    assert group["n"] == group["scored_n"] == 1 and group["accuracy"] == 0
    assert record["latency_s"] >= 0 and record["http_attempts"] is None


def test_labels_and_target_clarification_never_enter_service_messages():
    case = EvalCase("native-label-id", "cosql", "heldout", EvalInput("查询客户数量", "chinook"),
                    ("AMBIGUOUS", "CANNOT_ANSWER"), "CANNOT_ANSWER", None, True)
    client = StubClient({"goals": [{"id": "g", "operation": "query", "description": "查询"}]})
    run_case(case, client_factory=lambda: client)
    payload = json.loads(client.messages[1]["content"])
    assert payload["inputs"] == [{"id": "question", "text": "查询客户数量"}]
    text = json.dumps(payload, ensure_ascii=False)
    assert "AMBIGUOUS" not in text and "CANNOT_ANSWER" not in text and "native-label-id" not in text


def test_undecided_is_neither_negative_success_nor_closed_loop_success():
    case = EvalCase("unit", "zh", "debug", EvalInput("查询", "chinook"), (), "MANUAL_ZH", False)
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
               "requirements": [{"id": "r", "goal_id": "g", "kind": "external_fact", "description": "不足证据",
                                 "status": "open", "resolver": "unknown", "gap_type": "insufficient_evidence"}]}
    record = run_case(case, client_factory=lambda: StubClient(payload), diagnose_first_option=True)
    assert record["status"] == "insufficient_evidence" and record["hit"] is False
    assert record["state_machine_diagnostic"] is None


def test_unanswerable_and_system_clarify_have_independent_metrics():
    records = [{"primary_label": "CANNOT_ANSWER", "hit": True, "ok": True,
                "system_clarify_gold": False, "need_clarify": False, "latency_s": 1},
               {"primary_label": "AMBIGUOUS", "hit": False, "ok": False,
                "system_clarify_gold": True, "need_clarify": None, "latency_s": 2}]
    summary = summarize(records)
    assert summary["groups"]["CANNOT_ANSWER"]["accuracy"] == 1
    assert summary["groups"]["AMBIGUOUS"]["accuracy"] == 0
    assert summary["system_CLARIFY"]["positive_n"] == 1
    assert summary["system_CLARIFY"]["recalled"] == 0
    assert summary["mean_latency_s"] == 1.5


def test_client_construction_failure_is_a_scored_record_not_a_lost_future():
    case = EvalCase("unit", "zh", "debug", EvalInput("查询", "chinook"), (), "MANUAL_ZH", False)
    def broken():
        raise RuntimeError("不可回显的客户端配置")
    record = run_case(case, client_factory=broken)
    assert record["hit"] is False and not record["ok"]
    assert record["error"] == "RuntimeError" and record["latency_s"] >= 0


def test_evaluation_does_not_multiply_common_client_http_retries(monkeypatch):
    import httpx
    from backend.core import llm_client as module
    from tests.test_llm_client import make_client
    real_client = httpx.Client
    calls, waits = [], []
    def handler(request):
        calls.append(request)
        return httpx.Response(503, text="不能回显的供应商错误正文")
    monkeypatch.setattr(module.httpx, "Client", lambda **kw: real_client(transport=httpx.MockTransport(handler), **kw))
    monkeypatch.setattr(module.time, "sleep", waits.append)
    client = make_client(monkeypatch, llm_provider="wb", wb_api_key="unit-key")
    case = EvalCase("unit", "zh", "debug", EvalInput("查询", "chinook"), (), "MANUAL_ZH", False)
    record = run_case(case, client_factory=lambda: client)
    assert len(calls) == 3 and waits == [2, 4]
    assert record["hit"] is False and record["error"] == "model_unavailable"
    assert "供应商错误正文" not in json.dumps(record, ensure_ascii=False)


def test_first_option_diagnosis_never_claims_semantic_correctness():
    case = EvalCase("unit", "zh", "debug", EvalInput("查询", "chinook"), (), "MANUAL_ZH", True)
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
               "requirements": [{"id": "r", "goal_id": "g", "kind": "parameter", "name": "p",
                                 "description": "参数", "status": "open", "resolver": "user",
                                 "candidates": ["由我提供"]}]}
    record = run_case(case, client_factory=lambda: StubClient(payload), diagnose_first_option=True)
    diagnostic = record["state_machine_diagnostic"]
    assert diagnostic["semantic_correctness"] is None
    assert not diagnostic["ready"] and diagnostic["status"] == "budget_exhausted"
    assert record["actual_turns"] == 3


def test_current_target_system_clarification_is_not_available_before_prediction():
    data = json.loads(COSQL.read_text(encoding="utf-8"))
    for key, item in data.items():
        built = build_cosql_cases({key: item})
        if built and built[0].system_clarify is True:
            break
    else:
        raise AssertionError("真实CoSQL应包含原生系统澄清样本")
    changed = copy.deepcopy(item)
    first = next(i for i, t in enumerate(changed["turns"]) if t.get("isUser"))
    for turn in changed["turns"][first + 1:]:
        if not turn.get("isUser"):
            turn["text"] = "当前或未来目标系统话语禁止泄漏"
    after = build_cosql_cases({key: changed})
    assert built[0].model_input.payload() == after[0].model_input.payload()
    assert "当前或未来目标系统话语" not in json.dumps(after[0].model_input.payload(), ensure_ascii=False)


def test_unannotated_system_turn_is_not_fabricated_as_negative_gold():
    data = json.loads(COSQL.read_text(encoding="utf-8"))
    for key, item in data.items():
        built = build_cosql_cases({key: item})
        if built and built[0].system_clarify is not None:
            break
    changed = copy.deepcopy(item)
    first = next(i for i, t in enumerate(changed["turns"]) if t.get("isUser"))
    system = next(t for t in changed["turns"][first + 1:] if not t.get("isSql"))
    assert not system.get("isUser")
    system["label"] = []
    case = build_cosql_cases({key: changed})[0]
    assert case.system_clarify is None
