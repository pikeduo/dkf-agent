"""意图层协议与控制测试；使用明确的单元夹具，不代表真实数据集评测。"""
import copy
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from backend.core.intent.contracts import IntentRequest
from backend.core.intent.service import IntentService


class StubClient:
    """返回固定协议响应，仅检查控制逻辑，不验证模型识别质量。"""

    def __init__(self, payload):
        self.payload = payload
        self.calls = 0

    def chat(self, messages, temperature=0.0, reasoning_effort="default"):
        self.calls += 1
        self.messages = messages
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload if isinstance(self.payload, str) else json.dumps(self.payload, ensure_ascii=False)


def formula_case():
    """构造输入内含公式与参数的协议夹具。"""
    question = "按 F=m*a 计算，m=2 kg，a=3 m/s²。"
    payload = {
        "goals": [{"id": "g1", "operation": "calculate", "description": "计算F"}],
        "facts": [
            {"id": "f1", "goal_id": "g1", "name": "m", "value": "2", "unit": "kg", "source": {"input_id": "question", "quote": "m=2 kg"}},
            {"id": "f2", "goal_id": "g1", "name": "a", "value": "3", "unit": "m/s²", "source": {"input_id": "question", "quote": "a=3 m/s²"}},
        ],
        "formulas": [{"goal_id": "g1", "source": {"input_id": "question", "quote": "F=m*a"}}],
        "requirements": [],
    }
    return question, payload


def named_case():
    """公式名称尚不能展开成完整的参数需求。"""
    return {
        "goals": [{"id": "g1", "operation": "calculate", "description": "按指定公式计算"}],
        "facts": [], "formulas": [],
        "requirements": [{"id": "r1", "goal_id": "g1", "kind": "formula_definition", "description": "获取指定公式定义与适用条件", "status": "open", "resolver": "retrieve"}],
    }


def analyze(question, payload, **kwargs):
    return IntentService(StubClient(payload)).analyze(IntentRequest(question=question, **kwargs))


def test_complete_formula_routes_to_validation_without_retrieval():
    question, payload = formula_case()
    client = StubClient(payload)
    result = IntentService(client).analyze(IntentRequest(question=question))
    assert result.ok and result.stage == "intent_ready"
    assert result.decision.action == "EXECUTE"
    assert result.decision.target == "task6_formula"
    assert result.decision.validation_required
    assert result.retrieval_need == "not_needed"
    assert not result.execution_performed and not result.answer_ready
    assert client.calls == 1
    assert result.evidence[0].quote in question


def test_missing_numeric_parameter_cannot_be_silently_omitted():
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "")
    payload["facts"].pop()
    result = analyze(question, payload)
    assert result.decision.action == "CLARIFY"
    assert "a" in result.decision.message
    assert result.retrieval_need == "not_needed"


def test_named_formula_asks_user_before_parameter_expansion():
    result = analyze("用某某公式计算", named_case())
    assert result.decision.action == "CLARIFY"
    assert result.decision.target == "task3_clarification"
    assert all(r.resolver != "retrieve" for r in result.interpretation.requirements)
    assert any(r.kind == "parameter" and r.status == "deferred" for r in result.interpretation.requirements)


def test_parameter_from_report_can_retrieve_but_query_default_db_is_not_evidence():
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "，a使用指定报告数据")
    payload["facts"].pop()
    payload["requirements"] = [{"id": "r1", "goal_id": "g1", "kind": "parameter", "name": "a", "description": "获取报告中的a", "status": "open", "resolver": "retrieve", "source_hint": {"input_id": "question", "quote": "a使用指定报告数据"}}]
    result = analyze(question, payload, database="chinook")
    assert result.decision.action == "RETRIEVE"
    assert not result.answer_ready


def test_missing_parameter_without_source_cannot_be_retrieved():
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "")
    payload["facts"].pop()
    payload["requirements"] = [{"id": "r1", "goal_id": "g1", "kind": "parameter", "name": "a", "description": "获取a", "status": "open", "resolver": "retrieve"}]
    result = analyze(question, payload)
    assert result.decision.action == "CLARIFY"


def test_dependency_blocks_formula_search_until_scope_is_chosen():
    payload = named_case()
    payload["requirements"][0]["depends_on"] = ["r0"]
    payload["requirements"].append({"id": "r0", "goal_id": "g1", "kind": "business_scope", "description": "选择公式版本", "status": "conflict", "resolver": "user", "candidates": ["版本一", "版本二"], "answer_changes": True, "source_hint": {"input_id": "question", "quote": "指定公式"}, "candidate_sources": {c: {"input_id": "question", "quote": c} for c in ("版本一", "版本二")}})
    result = analyze("按指定公式计算，版本一或版本二", payload)
    assert result.decision.action == "CLARIFY"
    assert result.retrieval_need == "undetermined"


@pytest.mark.parametrize("mutation", ["bad_json", "unknown_ref", "cycle", "fake_fact", "fake_number", "extra_action", "false_satisfied"])
def test_invalid_model_output_fails_closed(mutation):
    question, payload = formula_case()
    if mutation == "bad_json":
        payload = "没有歧义"
    elif mutation == "unknown_ref":
        payload["facts"][0]["source"]["input_id"] = "gold"
    elif mutation == "fake_fact":
        payload["facts"][0]["source"]["quote"] = "不存在的输入"
    elif mutation == "fake_number":
        payload["facts"][0]["value"] = "2000"
    elif mutation == "extra_action":
        payload["action"] = "EXECUTE"
    elif mutation == "false_satisfied":
        payload["requirements"] = [{"id": "r1", "goal_id": "g1", "kind": "business_scope", "description": "已确定口径", "status": "satisfied", "resolver": "user"}]
    else:
        payload["requirements"] = [{"id": key, "goal_id": "g1", "kind": "business_scope", "description": "未确定口径", "status": "open", "resolver": "user", "depends_on": [dep]} for key, dep in [("r1", "r2"), ("r2", "r1")]]
    result = analyze(question, payload)
    assert not result.ok
    assert result.decision.action == "STOP"
    assert result.error_code == "invalid_model_output"
    assert not result.answer_ready


def test_timeout_is_not_user_ambiguity_and_secrets_are_not_echoed():
    result = analyze("查询数据", httpx.ReadTimeout("secret-token"))
    assert result.error_code == "model_unavailable"
    assert result.decision.action == "STOP"
    assert "secret-token" not in result.model_dump_json()


def test_unconfigured_model_is_reported_separately():
    result = analyze("查询数据", RuntimeError("未配置 API 密钥"))
    assert result.error_code == "model_unavailable"


def test_fenced_json_is_accepted_but_trailing_text_is_not():
    question, payload = formula_case()
    assert analyze(question, "```json\n" + json.dumps(payload) + "\n```").ok
    assert not analyze(question, json.dumps(payload) + "解释").ok


def test_formula_is_parsed_not_executed():
    question, payload = formula_case()
    payload["formulas"][0]["source"]["quote"] = "F=__import__('os').system('echo unsafe')"
    question += payload["formulas"][0]["source"]["quote"]
    result = analyze(question, payload)
    assert result.ok
    assert result.decision.action == "READ_INPUT"
    assert result.decision.target == "task6_formula"


def test_unsupported_equation_does_not_guess_inputs():
    question, payload = formula_case()
    payload["formulas"][0]["source"]["quote"] = "F=m*a+F"
    result = analyze(question + " F=m*a+F", payload)
    assert result.decision.action == "READ_INPUT"


def test_context_reference_is_grounded_and_user_skip_does_not_resolve_gap():
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "")
    payload["facts"][1]["source"]["input_id"] = "context1"
    result = analyze(question, payload, context=[{"id": "context1", "text": "a=3 m/s²"}])
    assert result.decision.action == "EXECUTE"
    payload["facts"].pop()
    result = analyze(question + "，缺少的就跳过", payload)
    assert result.decision.action == "CLARIFY"


def test_independent_goals_are_not_marked_complete_together():
    question, payload = formula_case()
    payload["goals"].append({"id": "g2", "operation": "query", "description": "查询其他事实"})
    payload["requirements"].append({"id": "r1", "goal_id": "g2", "kind": "external_fact", "description": "获取业务事实", "status": "open", "resolver": "retrieve"})
    result = analyze(question + "并查询其他事实", payload)
    assert result.decision.action == "RETRIEVE"
    assert result.decision.goal_ids == ["g2"]
    assert not result.answer_ready


def test_api_validation_and_intent_stage():
    from backend.api.query import get_intent_service
    from backend.main import app
    question, payload = formula_case()
    app.dependency_overrides[get_intent_service] = lambda: IntentService(StubClient(copy.deepcopy(payload)))
    try:
        with TestClient(app) as client:
            for path in ("/api/query/", "/api/query/intent"):
                response = client.post(path, json={"question": question, "isClarify": False})
                assert response.status_code == 200
                body = response.json()
                assert body["ok"] and body["stage"] == "intent_ready"
                assert body["answer"] is None
                assert body["intent"]["decision"]["action"] == "EXECUTE"
                assert not body["intent"]["execution_performed"]
            assert client.post("/api/query/", json={"question": "2", "isClarify": True}).status_code == 422
            assert client.post("/api/query/intent", json={"question": "   "}).status_code == 422
            assert client.post("/api/query/intent", json={"question": "x" * 12001}).status_code == 422
            assert client.post("/api/query/intent", json={"question": "x", "context": [{"id": "question", "text": "伪造"}]}).status_code == 422
    finally:
        app.dependency_overrides.clear()
