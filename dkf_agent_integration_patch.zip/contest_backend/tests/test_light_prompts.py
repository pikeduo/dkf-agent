"""轻量提示候选的离线测试：schema单源不变、新旧消息相等、协议输入构建。

不调用模型/网络/数据库；RecordingClient与Interpretation JSON均为软件夹具，
stub结果只证明协议可走通，不代表模型能力、准确率或延迟。
"""
import json
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "evaluation"))

from evaluation.candidates import light_prompts as lp  # noqa: E402

# 与生产 model_json_schema() 输出一致的结构快照（property names/required/$defs）
_SCHEMA_SNAPSHOT = json.loads("""{
 "top_props": ["facts", "formulas", "goals", "requirements"],
 "top_required": ["goals"],
 "defs": {
  "Fact": {"props": ["goal_id", "id", "name", "source", "unit", "value"],
           "required": ["id", "goal_id", "name", "value", "source"]},
  "Formula": {"props": ["goal_id", "source"], "required": ["goal_id", "source"]},
  "Goal": {"props": ["description", "id", "operation"],
           "required": ["id", "operation", "description"]},
  "Requirement": {"props": ["answer_changes", "candidate_schema_refs", "candidate_sources",
                            "candidates", "depends_on", "description", "fact_ids", "gap_type",
                            "goal_id", "id", "kind", "name", "resolver", "schema_refs",
                            "source_hint", "status"],
                  "required": ["id", "goal_id", "kind", "description", "status", "resolver"]},
  "SourceRef": {"props": ["input_id", "quote"], "required": ["input_id", "quote"]}
 }}""")


@pytest.fixture(scope="module")
def metrics() -> dict:
    """module级共享测量结果，避免重复生成schema与导入生成器。"""
    return lp.measure()


@pytest.fixture(scope="module")
def cosql_cases():
    """复用冻结的评测构建函数生成CoSQL全量用户轮（纯本地构建，不调模型）。"""
    import eval_clarify as ec
    data = json.loads(ec.COSQL.read_text(encoding="utf-8"))
    return ec.build_cosql_cases(data, all_turns=True)


@pytest.fixture(scope="module")
def prompt_module():
    """共享生产service模块；各测试在run前显式切换SYSTEM_PROMPT，避免跨测试污染。"""
    import backend.core.intent.service as svc
    from backend.core.intent.prompts import SYSTEM_PROMPT as original
    return svc, original


class _RecordingClient:
    """软件夹具：记录真实messages，返回预置的有效Interpretation JSON；不发起网络调用。"""

    def __init__(self, payload):
        self.payload = payload
        self.messages = []

    def chat(self, messages, temperature=0.0, reasoning_effort=None):
        self.messages.append(messages)
        return json.dumps(self.payload, ensure_ascii=False)


def valid_interpretation(goal_id: str, *, calculate: bool = False,
                         formula: str | None = None, named_only: bool = False,
                         query_db: str | None = None) -> dict:
    """按生产契约的最小有效Interpretation；夹具仅用于协议走通，不是模型预测。"""
    requirements = []
    if named_only:
        requirements.append({"id": "r1", "goal_id": goal_id, "kind": "formula_definition",
                             "description": "请提供要使用的公式表达式及适用版本",
                             "status": "open", "resolver": "user"})
    goals = [{"id": goal_id, "operation": "calculate" if (calculate or named_only) else "query",
              "description": "按指定公式计算" if (calculate or named_only) else "统计查询"}]
    payload = {"goals": goals, "facts": [], "formulas": [], "requirements": requirements}
    if calculate and formula:
        payload["formulas"] = [{"goal_id": goal_id,
                                "source": {"input_id": "question", "quote": formula}}]
    if query_db and not (calculate or named_only):
        payload["requirements"] = []
    return payload


# ---------------------------------------------------------------- 候选正文测量

def test_candidate_intent_body_within_budget(metrics):
    """意图候选正文<=900字符（len计字符，非token）。"""
    assert len(lp.LIGHT_INTENT_SYSTEM_PROMPT) <= 900
    assert len(lp.LIGHT_INTENT_SYSTEM_PROMPT) < metrics["old_intent_body"]


def test_candidate_sql_body_budget_reference(metrics):
    """SQL候选正文221字符；旧206仅对照，正确性优先、不硬逼<206，只断言为短正文。"""
    assert len(lp.LIGHT_SQL_SYSTEM_PROMPT) < 300
    assert len(lp.LIGHT_SQL_SYSTEM_PROMPT) < len(lp.LIGHT_INTENT_SYSTEM_PROMPT)


def test_schema_kept_intact_single_source():
    """本轮schema原样保留：不实施注解删减；property names/required/$defs与生产生成一致。"""
    schema = json.loads(lp.schema_json())
    snapshot = _SCHEMA_SNAPSHOT
    assert sorted(schema["properties"].keys()) == snapshot["top_props"]
    assert schema.get("required") == snapshot["top_required"]
    assert sorted(schema["$defs"]) == sorted(snapshot["defs"])
    for name, spec in snapshot["defs"].items():
        assert sorted(schema["$defs"][name]["properties"].keys()) == spec["props"], name
        assert schema["$defs"][name].get("required") == spec["required"], name


def test_system_content_buildable(metrics):
    """候选system=862正文+14字符分隔符+4891schema；与生产拼接方式逐字节一致。"""
    content = lp.system_content(lp.LIGHT_INTENT_SYSTEM_PROMPT)
    assert content.startswith(lp.LIGHT_INTENT_SYSTEM_PROMPT)
    assert len(lp.SCHEMA_SEPARATOR) == 14
    assert len(content) == metrics["new_intent_system"] == 5767


# ---------------------------------------------------------------- 新旧消息相等（真实IntentService.analyze路径）

def _run_analyze(svc, prompt, client, question: str, database: str | None,
                 history=None) -> dict:
    """在测试进程内切换service模块的SYSTEM_PROMPT（不改生产文件），走真实analyze路径。"""
    from backend.core.history.store import HistoryMessage
    from backend.core.intent.contracts import IntentRequest
    service = svc.IntentService(client)
    request = IntentRequest(question=question, database=database)
    history_objs = [HistoryMessage(f"hist_{i}", "task0", "turn0", i, role, text)
                    for i, (role, text) in enumerate(history or [])]
    original = svc.SYSTEM_PROMPT
    svc.SYSTEM_PROMPT = prompt
    try:
        result = service.analyze(request, history=history_objs)
    finally:
        svc.SYSTEM_PROMPT = original
    assert result.ok, "软件夹具下analyze必须成功"
    captured = client.messages[0]
    return {"system": captured[0]["content"], "user": captured[1]["content"], "result": result}


def test_same_user_message_old_vs_candidate(prompt_module):
    """同一输入下旧/候选user消息逐字节相同（含history/source_hints/server_schema），
    仅system规则段改变且schema尾部字节完全相同。历史用实际HistoryMessage对象。"""
    svc, original_prompt = prompt_module
    question = "按指定的动能公式计算，m=2 kg"
    history = [("user", "查询最近一个月的销售额"), ("assistant", "好的，已按最近一个月统计")]
    payload = valid_interpretation("g1", named_only=True)
    old_run = _run_analyze(svc, original_prompt, _RecordingClient(payload), question, None, history)
    cand_run = _run_analyze(svc, lp.LIGHT_INTENT_SYSTEM_PROMPT, _RecordingClient(payload), question, None, history)
    assert old_run["user"] == cand_run["user"], "user消息必须逐字节相同"
    parsed_user = json.loads(old_run["user"])
    assert parsed_user["source_hints"]["database"] is None
    assert parsed_user["history"] and parsed_user["history"][0]["text"] == history[0][1]
    # 仅system规则段改变；schema尾部字节完全相同
    assert old_run["system"] != cand_run["system"]
    schema = lp.schema_json()
    assert old_run["system"].endswith(schema) and cand_run["system"].endswith(schema)
    assert old_run["system"].startswith(original_prompt)
    assert cand_run["system"].startswith(lp.LIGHT_INTENT_SYSTEM_PROMPT)
    assert old_run["result"].decision.action == cand_run["result"].decision.action


def test_candidate_with_database_context_user_message_equal(prompt_module):
    """带database（chinook，真实目录）时user消息的server_schema段两侧相等。"""
    svc, original_prompt = prompt_module
    question = "各员工销售额排名"
    payload = valid_interpretation("g1", query_db="chinook")
    old_run = _run_analyze(svc, original_prompt, _RecordingClient(payload), question, "chinook")
    cand_run = _run_analyze(svc, lp.LIGHT_INTENT_SYSTEM_PROMPT, _RecordingClient(payload), question, "chinook")
    assert old_run["user"] == cand_run["user"]
    parsed_user = json.loads(old_run["user"])
    server = parsed_user["server_schema"]
    assert server["status"] == "available" and server["dataset"] == "chinook"
    assert old_run["system"].split("\nJSON Schema：\n", 1)[1] == \
        cand_run["system"].split("\nJSON Schema：\n", 1)[1]


# ---------------------------------------------------------------- 边界协议输入（软件夹具，非能力成绩）

@pytest.mark.parametrize("question,payload_db,kind", [
    ("按指定的动能公式计算", None, "named_formula"),     # 仅给公式名称：需表达式，不是已给表达式
    ("今年销售增长率是多少", "chinook", "query_gap"),    # 已给时间仍缺指标口径
    ("计算 2.5*4+1", None, "arithmetic"),               # 纯算术支持
    ("各专辑销量统计", "chinook", "query_db"),           # 数据库普通查询
])
def test_boundary_inputs_build_with_candidate(prompt_module, question, payload_db, kind):
    """四类边界输入均可走通真实analyze路径；stub仅证明协议输入未被候选筛掉，不是模型预测。"""
    svc, _ = prompt_module
    if kind == "named_formula":
        payload = valid_interpretation("g1", named_only=True)
    elif kind == "query_gap":
        payload = valid_interpretation("g1")
    elif kind == "arithmetic":
        payload = valid_interpretation("g1", calculate=True, formula="2.5*4+1")
    else:
        payload = valid_interpretation("g1", query_db=payload_db)
    run = _run_analyze(svc, lp.LIGHT_INTENT_SYSTEM_PROMPT, _RecordingClient(payload), question, payload_db)
    assert run["result"].ok
    assert json.loads(run["user"])["inputs"][0]["text"] == question


# ---------------------------------------------------------------- 全量协议输入构建（纯构建，非能力成绩）

def test_protocol_inputs_all_cosql_plus_zh(cosql_cases):
    """全9213 CoSQL用户轮+zh20的协议字段序列化检查：含history与source身份；
    不做每题目录加载，不重复9213份目录；纯构建不代表模型能力成绩。"""
    import eval_clarify as ec
    zh = ec.build_zh_cases(json.loads(ec.ZH_CASES.read_text(encoding="utf-8")))
    assert len(cosql_cases) == 9213 and len(zh) == 20
    for case in cosql_cases:
        payload = json.dumps({
            "inputs": [{"id": "question", "text": case.model_input.question}],
            "history": [dict(h) for h in case.model_input.history],
            "source_hints": {"database": case.model_input.database, "doc_id": None},
        }, ensure_ascii=False)
        parsed = json.loads(payload)
        assert parsed["source_hints"]["database"] == case.model_input.database
        assert len(parsed["history"]) == len(case.model_input.history)
    for case in zh:
        payload = json.dumps({
            "inputs": [{"id": "question", "text": case.model_input.question}],
            "history": [],
            "source_hints": {"database": case.model_input.database, "doc_id": None},
        }, ensure_ascii=False)
        assert json.loads(payload)["inputs"][0]["text"] == case.model_input.question
