"""可选系统提示接口（--prompt-variant）与实例级失败阶段诊断测试。

覆盖：override=None时仍从当前模块常量读取（兼容monkeypatch）、
新实例override真2线程不同提示无串、不同实例不串统计、
invalid_model_output抄送受控stage且不泄模型原文、
manifest冻结variant/system文本hash/候选代码hash/schema内容hash且同ID混用拒绝。
仅本地数据与无网络桩客户端，不调真实模型。
"""
import json
import threading
from types import SimpleNamespace

import pytest

import evaluation.eval_clarify as ev
import evaluation.candidates.light_prompts as lp
import backend.core.intent.service as svc
from tests.test_intent import StubClient

VALID = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
         "facts": [], "formulas": [], "requirements": []}


class _RecordingClient:
    """记录真实messages并返回固定有效payload；不发网络调用。"""

    def __init__(self, payload=None):
        self.messages = []
        self.payload = payload or VALID

    def chat(self, messages, temperature=0.0, reasoning_effort=None):
        self.messages.append(messages)
        return json.dumps(self.payload, ensure_ascii=False)


def _request(question="各员工销售额", database="chinook"):
    from backend.core.intent import IntentRequest
    return IntentRequest(question=question, database=database)


def test_override_none_reads_module_constant_and_stays_monkeypatchable():
    """默认现行为不变：system_prompt=None时analyze从模块常量读取（monkeypatch兼容）。"""
    original = svc.SYSTEM_PROMPT
    svc.SYSTEM_PROMPT = "PROMPT-OVERRIDE-FOR-TEST"
    try:
        client = _RecordingClient()
        result = svc.IntentService(client).analyze(_request())
        assert result.ok
        assert client.messages[0][0]["content"].startswith("PROMPT-OVERRIDE-FOR-TEST"), \
            "override=None必须仍读当前模块常量"
    finally:
        svc.SYSTEM_PROMPT = original


def test_override_explicit_uses_given_prompt_ignoring_module_constant():
    """显式override：使用传入提示，且与模块常量变化无关（实例级隔离）。"""
    original = svc.SYSTEM_PROMPT
    svc.SYSTEM_PROMPT = "SHOULD-NOT-APPEAR"
    try:
        client = _RecordingClient()
        result = svc.IntentService(client, system_prompt=lp.LIGHT_INTENT_SYSTEM_PROMPT).analyze(_request())
        assert result.ok
        assert client.messages[0][0]["content"].startswith(lp.LIGHT_INTENT_SYSTEM_PROMPT)
        assert "SHOULD-NOT-APPEAR" not in client.messages[0][0]["content"]
    finally:
        svc.SYSTEM_PROMPT = original


def test_two_threads_different_override_no_crosstalk():
    """真2线程、各自独立实例、不同prompt override：互不串，模块常量不动。"""
    original = svc.SYSTEM_PROMPT
    results: dict = {}
    barrier = threading.Barrier(2)

    def worker(name, prompt, key):
        client = _RecordingClient()
        service = svc.IntentService(client, system_prompt=prompt)
        result = service.analyze(_request())
        barrier.wait()  # 两个线程真实同时驻留，强制并发窗口
        results[key] = {"ok": result.ok, "system": client.messages[0][0]["content"],
                        "stage": service.last_failure_stage}

    p1, p2 = "THREAD-PROMPT-A", "THREAD-PROMPT-B"
    t1 = threading.Thread(target=worker, args=(p1, p1, "a"))
    t2 = threading.Thread(target=worker, args=(p2, p2, "b"))
    t1.start(); t2.start(); t1.join(timeout=30); t2.join(timeout=30)
    assert not t1.is_alive() and not t2.is_alive()
    assert results["a"]["ok"] and results["b"]["ok"]
    assert results["a"]["system"].startswith(p1), "线程A不得看到线程B的提示"
    assert results["b"]["system"].startswith(p2), "线程B不得看到线程A的提示"
    assert svc.SYSTEM_PROMPT == original, "并发期间模块常量绝不被改动"


def test_failure_stage_isolated_across_instances_and_cleared_per_analyze():
    """不同实例不串统计；每次analyze开始清空本实例诊断。"""
    s1 = svc.IntentService(_RecordingClient())
    s2 = svc.IntentService(_RecordingClient())
    # 让s1先走一次失败（非法JSON→parse_contract）
    bad = svc.IntentService(_RecordingClient("完全不是JSON的正文"))
    res = bad.analyze(_request())
    assert res.ok is False and res.error_code == "invalid_model_output"
    assert bad.last_failure_stage == "parse_contract"
    # 成功实例与另一实例不串：s1/s2无诊断残留
    s1.analyze(_request()); s2.analyze(_request())
    assert s1.last_failure_stage is None and s2.last_failure_stage is None
    # 同一实例再次成功分析后清空
    res2 = bad.analyze(_request())  # 第二次仍失败
    assert res2.error_code == "invalid_model_output"
    assert bad.last_failure_stage in svc.IntentService._KNOWN_FAILURE_STAGES


def test_evidence_failure_stage_not_leak_model_text():
    """证据阶段失败抄送stage受控字符串；记录不保存模型原文/异常正文。"""
    # facts引用的来源片段不在用户输入中 → evidence阶段失败
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
               "facts": [{"id": "f", "goal_id": "g", "name": "x", "value": "1",
                          "source": {"input_id": "question", "quote": "输入里不存在的片段"}}],
               "formulas": [], "requirements": []}
    service = svc.IntentService(_RecordingClient(payload))
    result = service.analyze(_request())
    assert result.ok is False and result.error_code == "invalid_model_output"
    assert service.last_failure_stage == "evidence"
    blob = json.dumps(result.model_dump(), ensure_ascii=False)
    assert "输入里不存在的片段" not in blob, "失败结果不得携带模型原文"


def _make_args(**over):
    base = dict(split="all", datasets=("zh", "cosql"), all_turns=True, limit=0,
                diagnose_first_option=False, bird_ids="", run_id="pv-run",
                subset_manifest=None, prompt_variant="current")
    base.update(over)
    return SimpleNamespace(**base)


def test_manifest_freezes_prompt_variant_hashes(tmp_path, monkeypatch):
    """manifest冻结：实际system文本hash、variant、候选模块代码hash、完整schema内容hash。"""
    monkeypatch.setattr(ev, "model_identity", lambda: {"provider": "mock", "model_name": "m",
                                                       "model_identifier": "x",
                                                       "endpoint_identifier": "y",
                                                       "request_timeout_s": 1.0,
                                                       "reasoning_effort": None,
                                                       "max_extra_http_retries": 0})
    cases = [ev.EvalCase("pv:0", "zh", "debug", ev.EvalInput("各员工销售额", "chinook"),
                         ("MANUAL_ZH",), "MANUAL_ZH", True)]
    sh = {"zh": "h", "cosql": "h"}
    m_cur = ev.build_manifest(cases, args=_make_args(prompt_variant="current"),
                              source_hashes=sh, model_provider={"provider": "mock"})
    pv = m_cur["prompt_variant"]
    assert pv["variant"] == "current" and pv["candidate_code_hash"] is None
    assert pv["system_prompt_hash"] == ev.digest(svc.SYSTEM_PROMPT)
    assert pv["schema_content_hash"], "必须冻结完整Pydantic schema内容hash"
    # light：system文本hash=候选常量hash，候选模块代码hash=候选py文件内容指纹
    m_light = ev.build_manifest(cases, args=_make_args(prompt_variant="light"),
                                source_hashes=sh, model_provider={"provider": "mock"})
    pl = m_light["prompt_variant"]
    assert pl["variant"] == "light"
    assert pl["system_prompt_hash"] == ev.digest(lp.LIGHT_INTENT_SYSTEM_PROMPT)
    import pathlib
    assert pl["candidate_code_hash"] == ev.digest(pathlib.Path(lp.__file__).read_text(encoding="utf-8"))
    assert pl["schema_content_hash"] == pv["schema_content_hash"], "schema冻结同源"


def test_same_run_id_cannot_mix_prompt_variants(tmp_path, monkeypatch):
    """同ID混用不同variant：manifest指纹不同，attach_run拒绝（退出EXIT_CONFLICT）。"""
    monkeypatch.setattr(ev, "REPORT", tmp_path / "rep.json")
    monkeypatch.setattr(ev, "model_identity", lambda: {"provider": "mock", "model_name": "m",
                                                       "model_identifier": "x",
                                                       "endpoint_identifier": "y",
                                                       "request_timeout_s": 1.0,
                                                       "reasoning_effort": None,
                                                       "max_extra_http_retries": 0})
    cases = [ev.EvalCase("pv:0", "zh", "debug", ev.EvalInput("各员工销售额", "chinook"),
                          ("MANUAL_ZH",), "MANUAL_ZH", True)]
    import backend.core.llm_client as llm_module
    llm_module.LLMClient = lambda: _RecordingClient()
    try:
        rc1 = ev._run_model(_make_args(prompt_variant="current"), cases, cases, {"zh": "h"})
        assert rc1 == 0
        rc2 = ev._run_model(_make_args(prompt_variant="light"), cases, cases, {"zh": "h"})
        assert rc2 == ev.EXIT_CONFLICT, "同run-id换variant必须拒绝混用"
    finally:
        import importlib
        importlib.reload(llm_module)


def test_prompt_variant_rejects_free_user_text(tmp_path, monkeypatch):
    """variant配置只从可信候选常量取；未知值（用户自由提示渠道）直接报错。"""
    with pytest.raises(ValueError):
        ev._resolve_prompt_variant(_make_args(prompt_variant="my-custom-text"))
    # current/light取值只来自模块常量与候选模块，不接受argv之外的提示文本
    assert ev._resolve_prompt_variant(_make_args(prompt_variant="current"))[1] is None
    name, text = ev._resolve_prompt_variant(_make_args(prompt_variant="light"))
    assert name == "light" and text == lp.LIGHT_INTENT_SYSTEM_PROMPT


def test_run_case_copies_failure_stage_only_on_invalid(tmp_path):
    """eval记录仅invalid_model_output时抄stage；成功/模型不可用记录为None。"""
    from backend.core.intent import IntentRequest
    case = ev.EvalCase("pv:0", "zh", "debug", ev.EvalInput("各员工销售额", "chinook"),
                       ("MANUAL_ZH",), "MANUAL_ZH", True)
    # 成功：stage为None
    ok = ev.run_case(case, client_factory=lambda: _RecordingClient())
    assert ok["ok"] and ok.get("failure_stage") is None
    # 模型不可用（客户端抛错）：stage仍为None（非invalid_model_output不抄）
    from tests.test_intent import StubClient
    rec = ev.run_case(case, client_factory=lambda: StubClient(RuntimeError("接口故障")))
    assert rec["error"] == "model_unavailable" and rec.get("failure_stage") is None
    # invalid_model_output：抄送受控stage
    rec2 = ev.run_case(case, client_factory=lambda: _RecordingClient("不是JSON"))
    assert rec2["error"] == "invalid_model_output" and rec2["failure_stage"] == "parse_contract"
