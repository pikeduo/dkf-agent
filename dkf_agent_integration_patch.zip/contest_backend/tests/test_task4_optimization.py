"""任务4专用契约测试；mock只检查程序边界，真实评分仍使用原始BIRD500。"""
from decimal import Decimal
from pathlib import Path
from unittest import mock
import json
import sys

import psycopg2
import pytest
from sqlglot import exp

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from backend.data_access.relational import RelationalSource, parse_readonly, validate_sql
from backend.data_access.registry import SourceRegistry
from backend.data_access.protocol import DataResponse
from backend.agents.task4_schema_linking.schema_index import SchemaIndex
from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
from backend.agents.task4_schema_linking.table_matcher import TableMatcher, tokens
from backend.agents.task4_schema_linking.metric_catalog import MetricCatalog
from backend.agents.text2sql.pipeline import Text2SQLPipeline
from backend.agents.text2sql.sql_generator import SQLGenerator
from backend.agents.text2sql.sql_repairer import SQLRepairer
from evaluation.eval_text2sql import FullResult, compare_results, execute_full
from evaluation.eval_schema_link import candidate_connected, load_items, gold_tables


@pytest.mark.parametrize("query", ["", "SELECT 1; SELECT 2", "SELECT * INTO other FROM public.artist",
    "WITH x AS (DELETE FROM public.artist RETURNING *) SELECT * FROM x",
    "WITH x AS (UPDATE public.artist SET name='x' RETURNING *) SELECT * FROM x",
    "SELECT * FROM public.artist FOR UPDATE", "SELECT pg_sleep(1)",
    "SELECT set_config('search_path', 'public', true)", "SELECT pg_read_file('/etc/passwd')",
    "SELECT public.lower('x')", "SELECT pg_catalog.pg_read_file('/etc/passwd')",
    "SELECT dblink('host=external', 'SELECT 1')", "SELECT 'x'::public.external_type",
    "SELECT IF(true, 1, 0)"])
def test_unsafe_tree_rejected(query):
    with pytest.raises(Exception):
        parse_readonly(query)


@pytest.mark.parametrize("query", ["SELECT COUNT(*) FROM public.artist",
    "WITH a AS (SELECT * FROM public.artist) SELECT COUNT(*) FROM a",
    "WITH a AS (SELECT * FROM public.artist), b AS (SELECT * FROM a) SELECT name FROM b",
    "SELECT pg_catalog.lower(name) FROM public.artist",
    "SELECT name FROM public.artist UNION ALL SELECT name FROM public.artist",
    "SELECT CASE WHEN 1=1 AND 2=2 THEN 1 ELSE 0 END",
    "SELECT CASE WHEN 1=1 OR 2=2 THEN 1 ELSE 0 END",
    "SELECT EXISTS (SELECT 1 FROM public.artist)",
    "SELECT AGE(DATE '2020-01-01', DATE '2010-01-01')"])
def test_safe_cte_and_builtin_accepted(query):
    validate_sql(query, {"public": {"artist"}})


@pytest.mark.parametrize("query", ["SELECT * FROM bird_native.frpm", "SELECT * FROM pg_catalog.pg_class",
    "SELECT * FROM outside.public.artist", "SELECT * FROM public.invoice"])
def test_other_database_and_tables_rejected(query):
    with pytest.raises(Exception):
        validate_sql(query, {"public": {"artist"}})


def test_cte_name_does_not_override_real_table_permission():
    validate_sql("WITH invoice AS (SELECT * FROM public.artist) SELECT * FROM invoice", {"public": {"artist"}})
    with pytest.raises(Exception):
        validate_sql("WITH artist AS (SELECT * FROM public.invoice) SELECT * FROM artist", {"public": {"artist"}})


def fake_connection(rows=None):
    """连接mock不创建文件，也不连接真实库。"""
    cur = mock.MagicMock()
    cur.description = [("count",)]
    cur.fetchmany.return_value = rows or [(1,)]
    conn = mock.MagicMock()
    conn.__enter__.return_value = conn
    conn.cursor.return_value.__enter__.return_value = cur
    return conn, cur


def test_readonly_transaction_close_and_scope():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    conn, cur = fake_connection()
    with mock.patch.object(source, "_conn", return_value=conn):
        result = source.execute_sql("SELECT COUNT(*) FROM public.artist", allowed_tables={"public": {"artist"}})
    assert result.ok
    conn.set_session.assert_called_once_with(readonly=True, autocommit=False)
    conn.close.assert_called_once()
    assert any("search_path" in str(c.args[0]) for c in cur.execute.call_args_list)
    with mock.patch.object(source, "_conn") as connect:
        result = source.execute_sql("SELECT * FROM public.invoice", allowed_tables={"public": {"artist"}})
    assert not result.ok
    connect.assert_not_called()


def test_errors_are_redacted():
    source = RelationalSource("chinook", "postgresql://u:secret@invalid/db")
    with mock.patch.object(source, "_conn", side_effect=psycopg2.OperationalError("secret localhost original literal")):
        result = source.execute_sql("SELECT 1")
    assert not result.ok and "secret" not in result.error and "localhost" not in result.error
    with mock.patch("backend.data_access.relational.parse_readonly", side_effect=ValueError("secret literal")):
        result = source.execute_sql("SELECT 1")
    assert "secret" not in result.error


def test_full_result_tail_duplicates_null_decimal_and_order():
    reference = FullResult("OK", 1, tuple((n,) for n in range(501)))
    changed = FullResult("OK", 1, reference.rows[:-1] + ((999,),))
    assert compare_results(changed, reference) != "match"
    assert compare_results(FullResult("OK", 1, ((1,), (1,))), FullResult("OK", 1, ((1,), (2,)))) != "match"
    assert compare_results(FullResult("OK", 1, ((None,),)), FullResult("OK", 1, ((None,),))) == "match"
    assert compare_results(FullResult("OK", 1, ((Decimal("9007199254740993"),),)),
                           FullResult("OK", 1, ((Decimal("9007199254740992"),),))) != "match"
    assert compare_results(FullResult("OK", 1, ((Decimal("1.0"),),)), FullResult("OK", 1, ((1,),))) == "match"
    a, b = FullResult("OK", 1, ((1,), (2,))), FullResult("OK", 1, ((2,), (1,)))
    assert compare_results(a, b, ordered=False) == "match"
    assert compare_results(a, b, ordered=True) != "match"
    assert compare_results(FullResult("OK", 2, ()), FullResult("OK", 1, ())) == "different_shape"
    assert compare_results(FullResult("RESOURCE_LIMIT"), reference) == "candidate_resource_limit"


def test_full_reader_never_scores_truncated_prefix():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    conn, cur = fake_connection()
    cur.fetchmany.side_effect = [[(1,)] * 501, []]
    with mock.patch("evaluation.eval_text2sql.psycopg2.connect", return_value=conn):
        result = execute_full(source, "SELECT 1", {"public": {"artist"}}, "public", max_rows=500)
    assert result.status == "RESOURCE_LIMIT" and not result.rows
    conn.set_session.assert_called_once_with(readonly=True, autocommit=False)
    conn.close.assert_called_once()


def test_real_source_index_scope_and_native_identifier():
    index = SchemaIndex()
    index.load("cosql", "academic")
    assert {e["db_id"] for e in index.tables} == {"academic"}
    assert index.schema_name.startswith("cosql_academic_")
    index.load("bird", "california_schools")
    assert "cdscode" in index.get_table("frpm")["columns"]
    assert "Academic Year" in index.get_table("frpm")["columns"]
    assert "CDSCode" not in index.get_table("frpm")["columns"]
    with pytest.raises(KeyError):
        index.load("bird")
    assert index.tables == [] and index.aliases is None


def test_chinese_no_global_empty_match():
    linker = SchemaLinker()
    linker.load("chinook")
    assert TableMatcher(linker.index).match(["完全不存在的对象"]) == []
    view = linker.link("各艺人的专辑总数", None)
    assert {"artist", "album"} <= set(view["tables"])
    assert tokens("InvoiceDate") == {"invoice", "date"}
    assert tokens("countries") == {"country"}


def test_metrics_and_aliases_only_real_scope():
    linker = SchemaLinker()
    linker.load("bird", "financial")
    view = linker.link("total revenue sales 销售额", None)
    assert not view["metric_hints"] and not view["metric_ambiguous"]
    assert "invoice" not in view["tables"]
    assert linker.index.aliases.resolve("员工") == []
    linker.load("chinook")
    metric = MetricCatalog().resolve("曲目销售额", linker.index)
    assert metric.expression == "invoice_line.unit_price * invoice_line.quantity"
    ambiguous = linker.link("销售额", None)
    assert ambiguous["needs_clarification"]
    resolved = linker.link("销售额", None, confirmed_slots={"metric_id": "total_sales"})
    assert not resolved["needs_clarification"]
    assert all(c in linker.index.get_table(t)["columns"] for t, cols in resolved["columns"].items() for c in cols)


def test_bridge_table_and_keys_are_in_ddl_scope():
    linker = SchemaLinker()
    linker.load("chinook")
    view = linker.link("artist invoice", None, top_k=2)
    assert {"artist", "album", "track", "invoice_line", "invoice"} <= set(view["tables"])
    assert "artist_id" in view["columns"]["album"]
    assert "track_id" in view["columns"]["invoice_line"]
    assert candidate_connected({"artist", "invoice"}, set(view["tables"]), view["bridges"])
    assert not candidate_connected({"artist", "invoice"}, {"artist", "invoice"}, view["bridges"])


def test_graph_scope_native_keys_and_parallel_constraints():
    linker = SchemaLinker()
    linker.load("bird", "formula_1")
    assert not linker.fk.problems
    assert linker.fk.find_join_path("drivers", "races")
    linker.load("bird", "california_schools")
    assert set(linker.fk.graph.nodes) == {"frpm", "schools", "satscores"}
    assert not linker.fk.problems
    linker.load("bird", "european_football_2")
    alternatives = linker.fk.find_join_path("match", "player")[0]["alternatives"]
    assert len(alternatives) > 1


class RecordingLLM:
    def __init__(self, response="SELECT COUNT(*) FROM bird_native.frpm"):
        self.messages, self.response = [], response

    def chat(self, messages, **kwargs):
        self.messages.append(messages)
        return self.response


def test_pipeline_full_scope_routes_and_user_gate(monkeypatch):
    llm = RecordingLLM()
    source = RelationalSource("bird", "postgresql://scoped-route", allowed_schemas=["bird_native"])
    registry = SourceRegistry()
    registry.register_relational(source)
    calls = []

    def ddl(url, tables, schema):
        calls.append((url, tables, schema))
        return "CREATE TABLE bird_native.frpm (cdscode TEXT);"

    monkeypatch.setattr("backend.agents.text2sql.pipeline.build_ddl", ddl)
    monkeypatch.setattr(source, "execute_sql", lambda query, **kw: DataResponse(ok=True,
        source_type="relational", db_id="bird", columns=["count"], rows=[[1]], row_count=1))
    pipeline = Text2SQLPipeline(llm, registry=registry)
    assert pipeline.run("bird", "california_schools", "enrollment", unresolved_conditions=["time"])["stage"] == "needs_user"
    assert not llm.messages
    assert pipeline.run("bird", None, "enrollment")["stage"] == "blocked"
    result = pipeline.run("bird", "california_schools", "完全不存在对象", schema_mode="full")
    assert result["ok"] and set(result["tables"]) == {"frpm", "schools", "satscores"}
    assert calls[0][0] == source.database_url and calls[0][2] == "bird_native"
    assert "未核验SQL" not in str(llm.messages)
    assert result["trace"].steps
    assert result["trace"].collect_evidence()


def test_generator_examples_disabled_and_repair_constraints():
    llm = RecordingLLM("WITH x AS (SELECT 1) SELECT * FROM x")
    generator = SQLGenerator(llm)
    with pytest.raises(ValueError):
        generator.build_messages("q", "ddl", [], examples=[{"sql": "gold"}])
    repair = SQLRepairer(llm, "ddl", [], {"time": "2020"})
    assert repair.try_fix("q", "SELECT wrong", "SQLSTATE=42703").startswith("WITH")
    assert "2020" in llm.messages[-1][1]["content"]
    count = len(llm.messages)
    assert repair.try_fix("q", "SELECT wrong", "timeout") is None
    assert repair.try_fix("q", "SELECT wrong", "sql_table_outside_scope") is None
    assert len(llm.messages) == count


def test_real_bird500_identity_and_gold_cte_isolation():
    items, refs = load_items()
    assert len(items) == len(refs) == 500
    assert len({x["_sample_id"] for x in items}) == 500
    assert len({x["question_id"] for x in items}) < 500
    assert gold_tables("WITH invoice AS (SELECT * FROM artist) SELECT * FROM invoice") == {"artist"}


def test_default_schema_cannot_escape_authorized_source():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    with mock.patch.object(source, "_conn") as connect:
        result = source.execute_sql("SELECT 1", allowed_tables={"public": {"artist"}}, default_schema="outside")
    assert not result.ok and "sql_default_schema_outside_scope" in result.error
    connect.assert_not_called()


def test_full_reader_complete_rows_and_bytes_budget():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    conn, cur = fake_connection()
    cur.fetchmany.side_effect = [[(n,) for n in range(501)], []]
    with mock.patch("evaluation.eval_text2sql.psycopg2.connect", return_value=conn):
        result = execute_full(source, "SELECT 1", {"public": {"artist"}}, "public", max_rows=1000)
    assert result.status == "OK" and len(result.rows) == 501
    conn, cur = fake_connection()
    cur.fetchmany.side_effect = [[("large",)], []]
    with mock.patch("evaluation.eval_text2sql.psycopg2.connect", return_value=conn):
        result = execute_full(source, "SELECT 1", {"public": {"artist"}}, "public", max_bytes=1)
    assert result.status == "RESOURCE_LIMIT" and not result.rows


def test_ddl_composite_pairing_and_missing_table():
    """这里仅模拟两列键契约，不提供业务问题、答案或虚构评测数据。"""
    from backend.agents.text2sql.ddl import build_ddl
    conn, cur = fake_connection()
    cur.fetchall.side_effect = [
        [(t, c, "integer", "NO") for t in ("child", "parent") for c in ("first_id", "second_id")],
        [(t, c) for t in ("child", "parent") for c in ("first_id", "second_id")],
        [("child", "paired_key", "public", "parent", "first_id", "first_id", 1),
         ("child", "paired_key", "public", "parent", "second_id", "second_id", 2)]]
    with mock.patch("backend.agents.text2sql.ddl.psycopg2.connect", return_value=conn):
        ddl = build_ddl("postgresql://invalid", ["child", "parent"], "public")
    assert 'FOREIGN KEY ("first_id", "second_id") REFERENCES "public"."parent" ("first_id", "second_id")' in ddl
    assert any("unnest(c.conkey, c.confkey)" in str(call.args[0]) for call in cur.execute.call_args_list)
    conn, cur = fake_connection()
    cur.fetchall.return_value = []
    with mock.patch("backend.agents.text2sql.ddl.psycopg2.connect", return_value=conn):
        with pytest.raises(ValueError, match="ddl_catalog_mismatch"):
            build_ddl("postgresql://invalid", ["artist"], "public")


def test_executed_sql_is_actual_qualified_query():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    conn, cur = fake_connection()
    with mock.patch.object(source, "_conn", return_value=conn):
        result = source.execute_sql("SELECT name FROM artist", allowed_tables={"public": {"artist"}})
    assert result.ok and '"public"."artist"' in result.executed_sql
    assert cur.execute.call_args_list[-1].args[0] == result.executed_sql
    assert cur.execute.call_args_list[-2].args[0] == "SET LOCAL search_path TO pg_catalog"


def test_reference_sql_is_not_rewritten():
    source = RelationalSource("chinook", "postgresql://u:p@invalid/db")
    conn, cur = fake_connection()
    cur.fetchmany.side_effect = [[(2,)], []]
    original = "select 1 + 1 as total"
    with mock.patch("evaluation.eval_text2sql.psycopg2.connect", return_value=conn):
        result = execute_full(source, original, {"public": {"artist"}}, "public", trusted_reference=True)
    assert result.status == "OK" and cur.execute.call_args_list[-1].args[0] == original


