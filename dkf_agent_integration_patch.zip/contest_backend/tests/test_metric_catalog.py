# -*- coding: utf-8 -*-
"""指标口径库 MetricCatalog 单元测试：离线，不访问网络与数据库。"""
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task4_schema_linking.metric_catalog import MetricCatalog, MetricDef


@pytest.fixture(scope="module")
def catalog():
    return MetricCatalog()


def test_resolve_chinese_alias(catalog):
    m = catalog.resolve("销售额")
    assert m is not None
    assert m.metric_id == "total_sales"
    assert m.amount_column == "invoice.total"


def test_resolve_contained_entity(catalog):
    m = catalog.resolve("各国家销售额")
    assert m is not None and m.metric_id == "total_sales"


def test_resolve_unknown_entity_returns_none(catalog):
    assert catalog.resolve("不存在的指标xyz") is None
    assert catalog.resolve("") is None


def test_candidate_ambiguity_detected(catalog):
    # "销售额" 同时命中 total_sales 与 sales_by_track 的别名（包含匹配）
    found = catalog.candidates("销售额")
    ids = {m.metric_id for m in found}
    assert len(ids) >= 2, f"应能识别出多个口径候选，实际 {ids}"


def test_as_hint_shape(catalog):
    m = catalog.resolve("收入")
    hint = m.as_hint()
    for key in ("metric_id", "column", "aggregation", "time_column", "grain", "caveats"):
        assert key in hint


def test_verify_against_catalog_flags_missing_column():
    bad = [MetricDef("ghost", ("幽灵指标",), "ghost_table.ghost_col", "sum", None, "一行=未知")]
    cat = MetricCatalog(metrics=bad)

    class FakeIndex:
        def get_table(self, name):
            return None

    problems = cat.verify_against_catalog(FakeIndex())
    assert problems and "ghost_table.ghost_col" in str(problems)


def test_verify_passes_when_columns_present():
    ok = [MetricDef("m", ("指标x",), "t.c", "sum", None, "粒度")]

    class FakeIndex:
        def get_table(self, name):
            return {"table": "t", "columns": ["c"]}

    cat = MetricCatalog(metrics=ok)
    assert cat.verify_against_catalog(FakeIndex()) == {}
