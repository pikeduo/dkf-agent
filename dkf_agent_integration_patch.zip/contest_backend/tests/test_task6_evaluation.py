"""隔离评测控制流的单元夹具，不读取HoF文件，不计入真实413题成绩。"""
import pytest

from evaluation.eval_formula import (FIXED_N, _gold_argument, evaluate_item, fixed_group,
                                     isolated_numeric_expression, numbers_consistent, parse_number, summarize)
from backend.agents.task6_formula.numeric_units import FormulaError


def argument(name, number, unit=""):
    """仅构造评测逻辑的单元输入，不保存为数据集。"""
    return {"en_name": name, "zh_name": name, "en_symbol": name, "zh_symbol": name,
            "num": number, "unit": unit}


def item(lines, arguments, answer="irrelevant"):
    return {"id": "unit_fixture", "solution": {"en": lines}, "arguments": arguments, "answer": answer}


@pytest.mark.parametrize("text,expected", [("10x3600", 36000), ("10×3600", 36000),
    ("10^{3}+2", 1002), ("(10+2)*3", 36), ("10⁻³+1", 1.001)])
def test_numeric_answers_only_use_isolated_restricted_evaluation(text, expected):
    assert parse_number(text) is None
    assert isolated_numeric_expression(text) == pytest.approx(expected)


@pytest.mark.parametrize("text", ["10 cats", "x=10", "__import__('os')", "1;2", "sqrt(4)", "10xfoo", "2**1000"])
def test_numeric_answer_injection_and_ambiguity_rejected(text):
    with pytest.raises(FormulaError):
        isolated_numeric_expression(text)


def test_all_formula_lhs_matched_without_last_line_or_final_answer():
    record = evaluate_item(item(["[y]=[x]*2", "[z]=[x]+[y]"],
        [argument("x", 10, "m"), argument("y", 20, "m"), argument("z", 30, "m")], "999999"))
    assert record["ok"] and len(record["formulas"]) == 2
    assert record["final_answer_scored"] is False
    assert all(row["oracle_only_bindings"] for row in record["formulas"])


def test_no_numeric_ratio_fallback():
    record = evaluate_item(item(["[y]=[x]*2"], [argument("x", 1), argument("y", 200)]))
    assert record["formulas"][0]["status"] == "value_mismatch"
    assert record["formulas"][0]["comparable"] is True


def test_unique_alias_required_even_when_duplicate_values_equal():
    record = evaluate_item(item(["[y]=[x]*2"], [argument("x", 1), argument("y", 2), argument("y", 2)]))
    assert record["formulas"][0]["status"] == "annotation_conflict"
    unmatched = evaluate_item(item(["[output]=[x]*2"], [argument("x", 1), argument("y", 2)]))
    assert unmatched["formulas"][0]["status"] == "missing_target_annotation"


def test_gold_unsupported_unit_stays_unit_failure():
    # 词典外单位及裸摄氏温标（歧义温标）均走 unsupported_unit 拒绝契约；
    # 用词典外单位和裸℃直接验证"单位失败不伪装数值失败"的契约，不绕过旧测试。
    for unit in ("mystery_unit", "℃"):
        with pytest.raises(FormulaError) as exc:
            _gold_argument(argument("temperature", 20, unit), 0)
        assert exc.value.code == "unsupported_unit"
    # 显式温差标记的复合单位可通过同一路径解析（契约边界）
    from backend.agents.task6_formula.numeric_units import quantity_from_raw
    assert quantity_from_raw(4186, "J/(kg·Δ℃)").value == 4186


def test_argument_numeric_expression_marked_oracle_only():
    quantity, binding, mode = _gold_argument(argument("time", "10x3600", "s"), 0)
    assert quantity.value == 36000 and binding["raw_value"] == 36000
    assert mode == "isolated_numeric_expression"
    assert binding["source"]["kind"] == "HoF_arguments_oracle_only"


def test_failures_remain_in_fixed_denominator_and_group_is_stable():
    passed = evaluate_item(item(["[y]=[x]*2"], [argument("x", 1), argument("y", 2)]))
    failed = evaluate_item(item(["[z]=[x]*2"], [argument("x", 1), argument("y", 2)]))
    summary = summarize([passed, failed], FIXED_N)
    assert summary["all_formulas_consistent_item_rate"] == 1 / 413
    assert summary["evaluated_items"] == 2
    assert summary["formula_status_counts"]["missing_target_annotation"] == 1
    assert fixed_group("unit_fixture") == fixed_group("unit_fixture")


@pytest.mark.parametrize("actual,expected,ok", [(2e-20, 1e-20, False), (1.005e-20, 1e-20, True),
    (1e-13, 0, True), (1e-10, 0, False)])
def test_small_nonzero_values_cannot_hide_ratio_errors(actual, expected, ok):
    assert numbers_consistent(actual, expected) is ok
