"""
任务6 公式结构化（FormulaSpec + SafeCalculator）离线单元测试：不访问网络与数据库。
覆盖：LaTeX/表达式解析、白名单校验、计算前硬性检查、分母为零、展示分离、参数回配。
"""
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task6_formula.formula_spec import FormulaSpec, parse_formula, spec_from_card, spec_from_user_formula
from backend.agents.task6_formula.safe_calculator import SafeCalculator
from backend.agents.task6_formula.param_finder import ParamFinder


def test_parse_ok_growth_rate():
    status, tree, err = parse_formula("增长率=(本期-基期)/基期")
    assert status == "ok" and tree is not None and err is None


def test_parse_rejects_non_whitelist_struct():
    # 下标/属性访问等越界结构必须解析失败，不猜表达式
    status, tree, err = parse_formula("a[0].x")
    assert status == "parse_error" and tree is None


def test_spec_from_card_parses_and_lists_inputs():
    card = {"id": "f1", "expression": "(c - b) / b", "variables": {"c": {"zh_name": "本期"}, "b": {"zh_name": "基期"}}}
    spec = spec_from_card(card)
    assert spec.parse_status == "ok"
    assert sorted(spec.input_symbols) == ["b", "c"]
    assert spec.formula_id == "f1"


def test_unverified_spec_blocked_from_compute():
    spec = FormulaSpec(formula_id="bad", expression="a[0]", parse_status="parse_error")
    out = SafeCalculator().compute_spec(spec, {"a": 1})
    assert out["ok"] is False and out.get("check_failed") == "parse_status"


def test_missing_bindings_blocked():
    spec = spec_from_card({"id": "f", "expression": "(c - b) / b"})
    out = SafeCalculator().compute_spec(spec, {"c": 1.2, "b": 1.0, "x": 5})
    # x 不是必要输入，缺 b/c 才会触发；这里 c/b 齐全 → 应成功
    assert out["ok"] is True and abs(out["result"] - 0.2) < 1e-9


def test_divide_by_zero_blocked():
    spec = spec_from_card({"id": "f", "expression": "(c - b) / b"})
    out = SafeCalculator().compute_spec(spec, {"c": 1.0, "b": 0.0})
    assert out["ok"] is False and out.get("check_failed") == "divide_by_zero"


def test_user_formula_bracket_placeholders():
    # 用户原文公式（占位符式）：目标量=左侧占位符，参数=右侧占位符
    spec = spec_from_user_formula("[热量]=[热值]*[质量]")
    assert spec.parse_status == "ok"
    assert spec.target_symbol == "_v1"
    # AST 变量只来自右式：目标是待求量，不计入必要输入
    assert sorted(spec.input_symbols) == ["_v2", "_v3"]
    # 绑定参数（_v1 是待求目标，不需要）
    out = SafeCalculator().compute_spec(spec, {"_v2": 8.0e7, "_v3": 0.21})
    assert out["ok"] is True
    assert abs(out["result"] - 1.68e7) < 1e-6


def test_user_formula_direct_substitution():
    # 普通代入式 "F=m*a"（无占位符）
    spec = spec_from_user_formula("F=m*a")
    assert spec.parse_status == "ok" and spec.target_symbol == "F"
    out = SafeCalculator().compute_spec(spec, {"m": 2, "a": 3})
    assert out["ok"] is True and out["result"] == 6


def test_user_formula_unicode_ops_and_power():
    # Unicode 运算符 × 与幂 ^ 归一化后可算
    spec = spec_from_user_formula("[效率]=[吸收热量]/[放出热量]")
    assert spec.parse_status == "ok"
    out = SafeCalculator().compute_spec(spec, {"_v2": 5.04e5, "_v3": 1.4e6})
    assert out["ok"] and abs(out["result"] - 0.36) < 1e-9
    spec2 = spec_from_user_formula("[电压²]=[功率]*[电阻]")
    assert spec2.parse_status == "ok"


def test_user_formula_parse_error_blocks_compute():
    # 越界结构（属性访问）必须解析失败并拒绝执行
    spec = spec_from_user_formula("[F]=m.x")
    assert spec.parse_status == "parse_error"
    out = SafeCalculator().compute_spec(spec, {"_v2": 1})
    assert out["ok"] is False and out["check_failed"] == "parse_status"


def test_user_formula_missing_param_blocked():
    # 参数缺失不猜值
    spec = spec_from_user_formula("[热量]=[热值]*[质量]")
    out = SafeCalculator().compute_spec(spec, {"_v2": 8.0e7})
    assert out["ok"] is False and out["check_failed"] == "missing_bindings"


def test_user_formula_bad_lhs_rejected():
    # 等号左侧不是单一目标量（多目标/表达式）→ 解析失败
    spec = spec_from_user_formula("[a]+[b]=[c]")
    assert spec.parse_status == "parse_error"
    spec = spec_from_user_formula("[X]")
    assert spec.parse_status == "parse_error"


def test_percent_display_keeps_ratio_value():
    spec = spec_from_card({"id": "g", "expression": "(1200 - 1000) / 1000"})
    spec.display = "percent"
    out = SafeCalculator().compute_spec(spec, {})
    # 恒等式无变量输入：应正常返回数值 0.2，展示值 20%
    assert out["ok"] is True and abs(out["result"] - 0.2) < 1e-9
    assert out.get("display_value") == "20%"


class EchoLLM:
    """离线 LLM 桩：固定返回构造好的 JSON 文本。"""
    def __init__(self, payload):
        self.payload = payload
        self.calls = 0

    def chat(self, messages, temperature=0.0, reasoning_effort="default"):
        self.calls += 1
        return self.payload


def test_param_finder_requires_value_in_source():
    # 批量抽值：模型给的键是变量符号 x，值 42 不在原文 → 回配失败视为未绑定
    llm = EchoLLM('{"x": {"raw_value": 42, "normalized_value": 42}}')
    out = ParamFinder(llm).bind("f", ["x"], "问题", "基期为 10 万", None)
    assert out[0]["status"] == "missing"
    assert llm.calls == 1  # 一次调用批量抽全部变量，不逐变量调


def test_param_finder_batch_single_call():
    # 明确的多变量赋值由确定性解析直接读取，不需要模型调用。
    llm = EchoLLM('{"t_理论": {"raw_value": 98}, "t_初": {"raw_value": 20}}')
    out = ParamFinder(llm).bind("f", ["t_理论", "t_初"], "问题", "t_理论=98, t_初=20", None)
    assert {b["symbol"] for b in out if b["status"] == "bound"} == {"t_理论", "t_初"}
    assert llm.calls == 0


def test_param_finder_accepts_value_present_in_source():
    # 数值与变量有明确对应才绑定，单纯数字出现不算来源证据。
    llm = EchoLLM('{"x": {"raw_value": 10, "normalized_value": 999}}')
    out = ParamFinder(llm).bind("f", ["x"], "问题", "x=10", None)
    assert out[0]["status"] == "bound"
    assert out[0].get("reverified") is True


def test_param_finder_user_input_without_document():
    llm = EchoLLM('{"x": {"raw_value": 7}}')
    out = ParamFinder(llm).bind("f", ["x"], "x=7", "", None)
    # 用户原文的明确赋值仍需回配，不因没有文档而接受模型编造。
    assert out[0]["status"] == "bound"
    assert out[0].get("reverified") is True
    assert out[0]["source"]["kind"] == "user_input"
    assert out[0]["normalized_value"] == 7
    assert llm.calls == 0
