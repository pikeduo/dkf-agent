"""历史筛选与会话隔离的离线单元测试，不请求实际模型。"""
from types import SimpleNamespace

import pytest

from backend.core.history.selector import HistorySelector, byte_size
from backend.core.history.store import HistoryMessage, SessionStore, SessionError


def message(index, *, role="user", turn=None, depends=(), text=None):
    return HistoryMessage(f"history_{index}", "task1", turn or f"turn{index}", index,
                          role, text or f"消息{index}", tuple(depends))


class StubRanker:
    def __init__(self, scores=None, failure=False):
        self.scores = scores or {}
        self.failure = failure
        self.calls = 0

    def score(self, question, candidates):
        self.calls += 1
        self.last = candidates
        if self.failure:
            raise RuntimeError("不得回显的错误")
        return {c["id"]: SimpleNamespace(score=self.scores.get(c["id"], (0.05, 0))[0],
                                         unknown=self.scores.get(c["id"], (0.05, 0))[1]) for c in candidates}


def test_short_history_skips_ranker():
    ranker = StubRanker()
    history = [message(i) for i in range(3)]
    selected = HistorySelector(ranker).select("问题", history, {"history_0"})
    assert selected.mode == "short"
    assert selected.messages == history
    assert ranker.calls == 0


def test_low_scores_do_not_drop_required_old_root_or_recent_turn():
    ranker = StubRanker()
    result = HistorySelector(ranker, recent_turns=3, short_turns=0).select("q", [message(i) for i in range(8)], {"history_0"})
    assert {m.id for m in result.messages} == {"history_0", "history_7"}
    assert {c["id"] for c in ranker.last} == {"turn0", "turn5", "turn6", "turn7"}


def test_selected_answer_brings_question_and_original_request():
    history = [message(0), message(1, role="assistant", turn="turn0", depends=["history_0"]),
               message(2, depends=["history_1"]), message(3), message(4)]
    ranker = StubRanker({"turn2": (0.95, 0)})
    result = HistorySelector(ranker, short_turns=0).select("继续", history, set())
    assert {m.id for m in result.messages} == {"history_0", "history_1", "history_2", "history_4"}


def test_unknown_and_gray_area_retained_without_treating_scores_as_single_choice():
    ranker = StubRanker({"turn1": (0.1, 0.9), "turn2": (0.5, 0), "turn3": (0.2, 0)})
    result = HistorySelector(ranker, short_turns=0).select("q", [message(i) for i in range(5)], {"history_0"})
    assert {m.id for m in result.messages} == {"history_0", "history_1", "history_2", "history_4"}


def test_failure_reverts_to_whole_recent_turns_and_preserves_old_required():
    result = HistorySelector(StubRanker(failure=True), recent_turns=2, short_turns=0).select("q", [message(i) for i in range(6)], {"history_0"})
    assert result.mode == "fallback"
    assert {m.id for m in result.messages} == {"history_0", "history_4", "history_5"}
    assert "不得回显" not in str(result.summary())


def test_budget_does_not_cut_mandatory_history():
    history = [message(0, text="原始问题" * 100), message(1)]
    with pytest.raises(SessionError) as exc:
        HistorySelector(max_bytes=256).select("q", history, {"history_0"})
    assert exc.value.status_code == 413
    optional = [message(0), message(1, text="无关历史" * 100), message(2)]
    cap = byte_size([optional[0], optional[2]])
    result = HistorySelector(max_bytes=max(256, cap)).select("q", optional, {"history_0"})
    assert result.budget_omitted
    assert result.after_bytes <= max(256, cap)
    assert "history_1" not in {m.id for m in result.messages}


def test_broken_dependency_and_cross_task_are_rejected():
    with pytest.raises(SessionError):
        HistorySelector().select("q", [], {"missing"})
    with pytest.raises(SessionError):
        HistorySelector().select("q", [message(1, depends=["unknown"])], set())
    with pytest.raises(SessionError):
        HistorySelector().select("q", [message(1)], {"history_missing"})
    with pytest.raises(SessionError):
        HistorySelector().select("q", [message(1), HistoryMessage("x", "other", "turn1", 2, "user", "x")], set())


def test_store_token_isolation_busy_and_rollback():
    store = SessionStore()
    session_id, token = store.create()
    other_id, other_token = store.create()
    with pytest.raises(SessionError):
        with store.lease(session_id, other_token):
            pass
    with pytest.raises(RuntimeError):
        with store.lease(session_id, token) as session:
            session.append("user", "不会提交", "turn1")
            with pytest.raises(SessionError) as busy:
                with store.lease(session_id, token):
                    pass
            assert busy.value.status_code == 409
            raise RuntimeError("模拟事务失败")
    with store.lease(session_id, token) as session:
        assert not session.messages
        assert session.token_digest != token
    store.delete(session_id, token)
    with pytest.raises(SessionError):
        with store.lease(session_id, token):
            pass


def test_condition_replacement_preserves_original_and_formula():
    store = SessionStore()
    sid, token = store.create()
    with store.lease(sid, token) as session:
        old = session.append("user", "F=m*a，m=2 kg", "turn1")
        session.update_condition("mass", "m=2 kg", old)
        new = session.append("user", "改为m=4 kg", "turn2")
        session.update_condition("mass", "m=4 kg", new)
        view = session.model_view()
        assert "m=2 kg" not in view[0].text
        assert "F=m*a" in view[0].text
        assert "m=2 kg" in session.messages[0].text
        session.start_task()
        assert session.model_view() == [] and not session.conditions
        assert len(session.messages) == 2


def test_session_expiration_capacity_and_explicit_quote_validation(monkeypatch):
    clock = [1.0]
    monkeypatch.setattr("backend.core.history.store.time.monotonic", lambda: clock[0])
    store = SessionStore(ttl_seconds=10, max_sessions=1)
    sid, token = store.create()
    with pytest.raises(SessionError):
        store.create()
    with store.lease(sid, token) as session:
        m = session.append("user", "条件", "turn1")
        with pytest.raises(SessionError):
            session.update_condition("x", "不存在", m)
    clock[0] = 20.0
    with pytest.raises(SessionError):
        with store.lease(sid, token):
            pass
    store.create()


def test_overlapping_condition_quotes_are_rejected():
    store = SessionStore()
    sid, token = store.create()
    with store.lease(sid, token) as session:
        item = session.append("user", "abcdef", "turn")
        session.update_condition("x", "abcd", item)
        with pytest.raises(SessionError):
            session.update_condition("y", "cdef", item)


def test_invalid_score_falls_back_without_dropping_history():
    ranker = StubRanker({"turn1": (float("nan"), 0)})
    result = HistorySelector(ranker, short_turns=0).select("q", [message(i) for i in range(3)], set())
    assert result.mode == "fallback" and len(result.messages) == 3


def test_more_than_32_candidates_never_calls_ranker():
    ranker = StubRanker()
    history = [message(i) for i in range(33)]
    result = HistorySelector(ranker, recent_turns=32, short_turns=0).select("q", history, {"history_0"})
    assert result.mode == "fallback" and ranker.calls == 0
    assert len(result.messages) == 33


def test_storage_limit_rolls_back_update():
    store = SessionStore(max_messages=1)
    sid, token = store.create()
    with pytest.raises(SessionError) as exc:
        with store.lease(sid, token) as session:
            session.append("user", "一", "t1")
            session.append("user", "二", "t2")
    assert exc.value.status_code == 413
    with store.lease(sid, token) as session:
        assert session.messages == []
