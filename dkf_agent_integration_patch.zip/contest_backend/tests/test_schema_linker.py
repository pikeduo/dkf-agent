"""任务4 表定位组件单元测试：静态索引/FK 桥接/实体抽取，不访问网络与数据库。"""
import json
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task4_schema_linking.fk_graph_builder import FKGraphBuilder
from backend.agents.task4_schema_linking.schema_index import SchemaIndex
from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
from backend.agents.task4_schema_linking.question_entities import extract_question_entities


@pytest.fixture(scope="module")
def linker():
    s = SchemaLinker()
    s.load("chinook")
    return s


def test_chinook_load_and_link(linker):
    view = linker.link("各艺人的专辑总数", None, top_k=6)
    assert "album" in view["tables"] and "artist" in view["tables"]
    # 证据来源必须可解释
    assert any(ev["source_type"] in ("表名", "列名", "注释") or ev["source_type"].startswith("别名(")
               for c in view["candidates"] for ev in c["evidence"])
    assert view["status"] == "ok"


def test_fk_bridge_artist_to_invoice(linker):
    bridges = linker.fk.bridge_tables(["artist", "invoice"])
    assert any(h["is_bridge"] or (h["from_table"], h["to_table"]) in {("artist", "album"), ("album", "invoice")}
               for h in bridges) or len(bridges) > 0
    # 路径不超 3 跳
    assert all(len(h["between"]) == 2 for h in bridges)


def test_no_path_returns_empty():
    fk = FKGraphBuilder()
    fk.load("chinook")
    # artist 与 genre 在真实外键图中隔着多跳；人为设 1 跳上限验证截断
    hops = fk.find_join_path("artist", "genre", max_hops=1)
    assert hops == []  # 中间隔着 album/track，1 跳内无路径


def test_full_baseline_kept_for_comparison(linker):
    view = linker.link("每个国家的销售金额", None, top_k=6, full_baseline=True)
    # RSL-SQL 完整 schema 基线：chinook 全部 11 表
    assert len(view["baseline_tables"]) == 11
    assert view["tables"]  # 裁剪候选与基线共存


def test_bird_subdb_load():
    s = SchemaLinker()
    s.load("bird", sub_db="california_schools")
    view = s.link("What is the enrollment for each school?", None, top_k=6)
    assert "frpm" in view["tables"]


def test_pruned_one_hop_neighbor_table_closure():
    """一跳外键邻表闭包：裁剪模式须把与选表直接相连的桥表补入，不丢金标表。"""
    s = SchemaLinker()
    s.load("bird", sub_db="california_schools")
    view = s.link("Please list the codes of the schools with a total enrollment of over 500.", None, top_k=6)
    # satscores 经 schools.cdscode 一跳可达，必须保留；闭包证据须可解释。
    assert "satscores" in view["tables"]
    assert any(c["source"] == "一跳外键邻表" for c in view["closure_evidence"])


def test_full_baseline_unchanged_by_neighbor_closure():
    """full 模式取全库基线，邻表闭包不得重复或越界。"""
    s = SchemaLinker()
    s.load("bird", sub_db="california_schools")
    view = s.link("任意问题", None, top_k=6, full_baseline=True)
    assert len(view["tables"]) == 3 and len(set(view["tables"])) == 3


def test_bird_missing_subdb_raises():
    s = SchemaLinker()
    with pytest.raises(KeyError):
        s.load("bird", sub_db="not_a_db")


def test_question_entities_extracts_quotes_and_zh():
    ents = extract_question_entities('What is the venue of "1994 FIFA World cup"? 增长率是多少')
    assert "1994 FIFA World cup" in ents
    assert any("增长率" in e for e in ents)
    # 停用词被过滤
    assert "the" not in [e.lower() for e in ents]


def test_insufficient_candidates_marked(linker):
    view = linker.link("qqqqxxxx 是什么", None, top_k=6)
    # 无任何目录命中属于检索不足，不自动变成用户业务歧义。
    assert view["tables"] == []
    assert view["status"] == "candidate_insufficient"
    assert view["needs_clarification"] is False
