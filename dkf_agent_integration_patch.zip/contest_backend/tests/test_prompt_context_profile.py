"""提示上下文序列化探针专用测试：无损roundtrip、前缀字节不变、零LLM、门槛逻辑。

只测探针自身的编码/解码与度量逻辑（含固定夹具DDL），不连PG、不读BIRD全量、
不触碰任务3文件；完整全量探针由父agent单独调度。
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from backend.agents.text2sql.sql_generator import SQLGenerator
from evaluation.profile_prompt_context import (
    LLMStub, compact_json, encode_registry, decode_registry, measure_variants,
    percentile, GATE_MEAN_SAVE_PER_CALL, GATE_TOTAL_INPUT_REDUCTION,
    FIXTURE_DDL, FIXTURE_BRIDGE, FIXTURE_MULTI_BRIDGE)


def _context(bridges):
    """按build_messages相同字段构造输入数据上下文，供编码测量。"""
    return {"question": "曲目“北京”的歌手？", "confirmed_slots": {"专辑": "精选“2009”"},
            "authorized_join_evidence": bridges,
            "verified_metric_hints": [], "structural_warnings": ["跨schema同名表已按限定标识区分"]}


def test_fixture_ddl_bytes_unchanged_in_all_variants():
    """DDL段与system规则字节不变：变体只允许动输入数据JSON部分。"""
    stub = LLMStub()
    generator = SQLGenerator(stub)
    context = _context(FIXTURE_MULTI_BRIDGE)
    # examples位置参数恒为None（生产禁用示例），确认槽位走keyword。
    message = generator.build_messages(context["question"], FIXTURE_DDL,
                                       FIXTURE_MULTI_BRIDGE,
                                       confirmed_slots=context["confirmed_slots"])
    m = measure_variants(message, context, FIXTURE_DDL)
    prefix = "授权DDL：\n" + FIXTURE_DDL + "\n输入数据：\n"
    assert message[1]["content"].startswith(prefix)
    assert m["prod_chars"] >= m["compact_chars"] >= 0
    # 前缀字符数必须一致计入（前缀长度显式加回），不靠DDL引用唯一性证明无损。
    assert m["compact_chars"] >= len(prefix)
    assert m["registry_roundtrip_ok"]
    assert stub.calls == 0  # 构造消息路径零模型调用


def test_registry_roundtrip_identity_multi_bridge():
    """多桥接共享note/between/alternatives后，独立解码必须逐字段（含类型）相等。"""
    context = _context(FIXTURE_MULTI_BRIDGE)
    encoded = encode_registry(context)
    assert "shared_registry" in encoded
    assert decode_registry(encoded) == context
    # 原文中的键一个都不能丢。
    assert set(context["authorized_join_evidence"][0]) == set(encoded["authorized_join_evidence"][0])
    assert "alternatives" in encoded["authorized_join_evidence"][0]
    assert "note" in encoded["authorized_join_evidence"][0]
    assert "between" in encoded["authorized_join_evidence"][0]


def test_registry_noop_single_bridge_keeps_fields():
    """单桥接不共享（避免引用开销超过节约），字段完整保留且roundtrip恒等。"""
    context = _context(FIXTURE_BRIDGE)
    encoded = encode_registry(context)
    m = measure_variants(
        SQLGenerator(LLMStub()).build_messages(context["question"], FIXTURE_DDL,
                                               FIXTURE_BRIDGE,
                                               confirmed_slots=context["confirmed_slots"]),
        context, FIXTURE_DDL)
    assert m["registry_noop"]
    assert decode_registry(encoded) == context


def test_composite_pk_and_selfref_ddl_present():
    """复合主键与自引用外键必须出现在真实DDL夹具中（不丢约束信息）。"""
    assert 'PRIMARY KEY ("item_id", "batch_id")' in FIXTURE_DDL
    assert 'FOREIGN KEY ("parent_id") REFERENCES "beta"."item" ("item_id")' in FIXTURE_DDL


def test_empty_joins_compact_save_nonnegative():
    """空join场景：紧凑分隔符只能省不增，roundtrip恒等。"""
    import json
    context = _context([])
    encoded = encode_registry(context)
    assert "shared_registry" not in encoded
    assert decode_registry(encoded) == context
    compact = compact_json(context)
    assert len(compact) <= len(json.dumps(context, ensure_ascii=False))


def test_unicode_confirmed_slots_survive_roundtrip():
    """Unicode引号/确认条件逐字节保留，编码解码不改变值。"""
    context = _context(FIXTURE_MULTI_BRIDGE)
    assert decode_registry(encode_registry(context))["confirmed_slots"] == context["confirmed_slots"]
    assert "“北京”" in compact_json(context)  # ensure_ascii=False保留原文


def test_llm_stub_forbidden():
    """LLMStub任何调用必须立即抛异常，保证探针零模型请求。"""
    import pytest
    stub = LLMStub()
    with pytest.raises(RuntimeError):
        stub.chat([{"role": "user", "content": "x"}])
    assert stub.calls == 1


def test_percentile_and_gate_thresholds():
    """门槛常量与百分位函数：空集None、单值稳定、阈值语义固定。"""
    assert percentile([], 50) is None
    assert percentile([7], 95) == 7
    assert percentile([1, 2, 3, 4], 50) == 2
    assert GATE_MEAN_SAVE_PER_CALL == 800
    assert GATE_TOTAL_INPUT_REDUCTION == 0.10
