"""LLMClient 供应商选择测试：不访问网络，请求经 MockTransport 截获。"""
import json

import httpx
import pytest

from backend.config import Settings
from backend.core import llm_client as llm_module
from backend.core.llm_client import LLMClient

# 显式清空所有密钥，避免本机环境变量或 .env 影响结果
EMPTY_KEYS = dict(zhipu_api_key="", siliconflow_api_key="", qwen_api_key="", anna_api_key="", wb_api_key="")


def make_client(monkeypatch, **overrides) -> LLMClient:
    settings = Settings(_env_file=None, **{**EMPTY_KEYS, **overrides})
    monkeypatch.setattr(llm_module, "get_settings", lambda: settings)
    return LLMClient()


def test_explicit_anna_uses_anna_endpoint_and_model(monkeypatch):
    client = make_client(monkeypatch, llm_provider="anna", anna_api_key="anna-key",
                         siliconflow_api_key="sf-key", anna_base_url="https://ai.anna.tf/v1/")
    provider = client._select_provider()
    assert provider["name"] == "anna"
    # 结尾斜杠被去掉，防止拼出 //chat/completions
    assert provider["base_url"] == "https://ai.anna.tf/v1"
    assert provider["model"] == "DeepSeek-V4.1-Flash"
    assert provider["api_key"] == "anna-key"


def test_explicit_provider_without_key_does_not_fall_back(monkeypatch):
    client = make_client(monkeypatch, llm_provider="anna", siliconflow_api_key="sf-key")
    with pytest.raises(RuntimeError) as exc:
        client._select_provider()
    assert "anna" in str(exc.value)
    assert "sf-key" not in str(exc.value)


def test_auto_keeps_previous_order(monkeypatch):
    # 只配了硅基流动和 Anna 时，auto 仍选硅基流动，Anna 必须显式指定
    client = make_client(monkeypatch, siliconflow_api_key="sf-key", anna_api_key="anna-key")
    provider = client._select_provider()
    assert provider["name"] == "siliconflow"
    assert provider["model"] == "Qwen/Qwen2.5-72B-Instruct"


def test_auto_without_any_key_raises(monkeypatch):
    client = make_client(monkeypatch)
    with pytest.raises(RuntimeError):
        client._select_provider()


def test_unknown_provider_rejected_by_settings():
    with pytest.raises(ValueError):
        Settings(_env_file=None, llm_provider="deepseek")


def test_chat_sends_anna_request(monkeypatch):
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["auth"] = request.headers["Authorization"]
        seen["body"] = json.loads(request.content)
        # 模拟 Anna 响应：推理在 reasoning_content，正文在 content
        return httpx.Response(200, json={"choices": [{"message": {
            "role": "assistant", "content": "{\"ok\": true}", "reasoning_content": "思考过程"}}]})

    real_client = httpx.Client
    monkeypatch.setattr(llm_module.httpx, "Client",
                        lambda **kw: real_client(transport=httpx.MockTransport(handler), **kw))
    client = make_client(monkeypatch, llm_provider="anna", anna_api_key="anna-key")
    text = client.chat([{"role": "user", "content": "hi"}], temperature=0.0)

    assert text == "{\"ok\": true}"
    assert seen["url"] == "https://ai.anna.tf/v1/chat/completions"
    assert seen["auth"] == "Bearer anna-key"
    assert seen["body"]["model"] == "DeepSeek-V4.1-Flash"
    assert seen["body"]["temperature"] == 0.0
