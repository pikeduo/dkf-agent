"""公共运行配置与有界模型重试测试；仅使用离线响应夹具。"""
from pathlib import Path

import httpx
import pytest

from backend.config import Settings
from backend.core import llm_client as module
from tests.test_llm_client import make_client


def install_transport(monkeypatch, handler):
    """注入离线传输并记录等待时间，不真正等待或联网。"""
    real_client = httpx.Client
    waits = []
    monkeypatch.setattr(module.httpx, "Client", lambda **kw: real_client(transport=httpx.MockTransport(handler), **kw))
    monkeypatch.setattr(module.time, "sleep", waits.append)
    return waits


def test_503_retries_twice_and_recovers(monkeypatch):
    calls = []
    def handler(request):
        calls.append(request)
        if len(calls) < 3:
            return httpx.Response(503)
        return httpx.Response(200, json={"choices": [{"message": {"content": "ok"}}]})
    waits = install_transport(monkeypatch, handler)
    client = make_client(monkeypatch, llm_provider="wb", wb_api_key="unit-key")
    assert client.chat([{"role": "user", "content": "test"}]) == "ok"
    assert len(calls) == 3 and waits == [2, 4]
    assert str(calls[-1].url).endswith("/v1/chat/completions")


@pytest.mark.parametrize("status", [400, 401, 403, 404])
def test_permanent_http_errors_do_not_retry(monkeypatch, status):
    calls = []
    def handler(request):
        calls.append(request)
        return httpx.Response(status)
    waits = install_transport(monkeypatch, handler)
    client = make_client(monkeypatch, llm_provider="wb", wb_api_key="unit-key")
    with pytest.raises(httpx.HTTPStatusError):
        client.chat([{"role": "user", "content": "test"}])
    assert len(calls) == 1 and not waits


@pytest.mark.parametrize("status", [429, 502, 503])
def test_transient_errors_have_fixed_total_attempts(monkeypatch, status):
    calls = []
    def handler(request):
        calls.append(request)
        return httpx.Response(status, text="private-vendor-secret")
    waits = install_transport(monkeypatch, handler)
    client = make_client(monkeypatch, llm_provider="wb", wb_api_key="unit-key")
    with pytest.raises(RuntimeError) as exc:
        client.chat([{"role": "user", "content": "test"}])
    assert len(calls) == 3 and waits == [2, 4]
    assert "private-vendor-secret" not in str(exc.value)
    assert "unit-key" not in str(exc.value)
    assert "://" not in str(exc.value)


def test_retry_budget_cannot_exceed_user_limit(monkeypatch):
    client = make_client(monkeypatch, llm_provider="wb", wb_api_key="unit-key")
    with pytest.raises(ValueError):
        client.chat([], max_retries=3)
    with pytest.raises(ValueError):
        Settings(_env_file=None, llm_max_retries=3)


def test_configuration_paths_are_independent_of_working_directory():
    env_file = Path(Settings.model_config["env_file"])
    registry = Path(Settings(_env_file=None).data_registry_path)
    assert env_file.is_absolute() and env_file.parent.name == "agent"
    assert registry.is_absolute() and registry.name == "databases.json"
