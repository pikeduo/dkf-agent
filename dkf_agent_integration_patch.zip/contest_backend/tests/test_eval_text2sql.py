"""BIRD执行评测并发隔离、manifest与安全契约的无网络测试；mock只验证程序边界，不冒充真实数据集成绩。"""
import json
import sys
import threading
import time
from pathlib import Path
from unittest import mock

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import evaluation.eval_text2sql as ev
from evaluation.eval_text2sql import FullResult, RunAbortedError


def make_items(n=3, dbs=None):
    """构造评测条目与金标SQL映射；金标只在本脚本内，永不进pipeline。"""
    dbs = dbs or [f"db{i}" for i in range(n)]
    items, refs = [], {}
    for i, db in enumerate(dbs):
        sid = f"{i:03d}:{db}:q{i}"
        items.append({"_sample_id": sid, "db_id": db, "question_id": f"q{i}", "question": "enrollment"})
        refs[sid] = {"sql": "SELECT 1"}
    return items, refs


class FakePipeline:
    """只实现评测用到的pipeline表面接口；linker用真实当前子库判定串库。"""
    class _Index:
        def __init__(self):
            self.current_db = None
            self.allowed_tables = {"bird_native": {"frpm", "schools"}}
            self.schema_name = "bird_native"

    class _Linker:
        def __init__(self):
            self.index = FakePipeline._Index()

        def load(self, db, sub_db=None, verify_metrics=True):
            self.index.current_db = sub_db

    class _Registry:
        def get_relational(self, name):
            class _Src:
                allowed_schemas = ["bird_native"]
                database_url = "postgresql://u@invalid/bird"
            return _Src()

    def __init__(self, tag, factory_state=None):
        self.tag = tag
        self.linker = FakePipeline._Linker()
        self.registry = FakePipeline._Registry()
        self.factory_state = factory_state

    def run(self, db_id, sub_db, question, confirmed_slots=None, top_k=6, *,
            schema_mode="pruned", unresolved_conditions=None):
        # 与生产pipeline一致：执行前linker切到本题子库，串库快照才有真实判定依据。
        self.linker.load(db_id, sub_db)
        if self.factory_state is not None:
            response = self.factory_state(self, db_id, sub_db, schema_mode)
            if response is not None:
                return response
        return {"ok": True, "stage": "executed", "sql": "SELECT 1", "repaired": False,
                "tables": ["frpm"], "joins": [], "row_count": 1, "rows": [[1]],
                "columns": ["x"], "truncated": False, "error": None, "view": {}, "trace": None}


def make_pool_factory(pipe_cls):
    """构造与默认工厂同构的测试工厂：每线程独立pipeline+独立LLM监视器（threading.local惰性）。"""
    def factory():
        thread_local = threading.local()
        monitors = {}

        def _thread_pipeline():
            monitor = getattr(thread_local, "monitor", None)
            if monitor is None:
                monitor = ev.LLMMonitor()
                thread_local.monitor = monitor
                thread_local.pipeline = pipe_cls(tag=str(len(monitors)))
                monitors[threading.get_ident()] = monitor
            return thread_local.pipeline

        class _Pool:
            def created(self):
                return len(monitors)

        pool = _Pool()
        pool._thread_pipeline = _thread_pipeline
        pool._monitors = monitors
        return pool

    return factory


def fake_execute(sql, trusted=False, scope=None, schema=None):
    """参考与候选共用同一可评结果；不连接真实数据库，不走网络。"""
    return FullResult("OK", 1, ((1,),))


# 并发观测器：记录同时在途线程数、见过的独立pipeline实例。
_thread_state = {"cur": set(), "lock": threading.Lock(), "max_conc": 0,
                 "threads": set(), "pipes": set()}


def _conc_hook(pipe, db_id, sub_db, mode):
    cur, lock = _thread_state["cur"], _thread_state["lock"]
    ident = threading.get_ident()
    with lock:
        cur.add(ident)
        _thread_state["max_conc"] = max(_thread_state["max_conc"], len(cur))
        _thread_state["threads"].add(ident)
        _thread_state["pipes"].add(id(pipe))
    time.sleep(0.05)  # 保持占位制造真实并发窗口
    with lock:
        cur.discard(ident)


@pytest.fixture(autouse=True)
def _reset_observers():
    _thread_state.update(cur=set(), max_conc=0, threads=set(), pipes=set())
    yield


def test_two_threads_simultaneous_independent_pipelines_and_monitors():
    """两个线程同时运行，pipeline与LLM监视器各自独立，混库无共享可变状态。"""
    items, refs = make_items(4)
    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=_conc_hook))()
    run = {"manifest": {}, "records": {
        x["_sample_id"]: {"sample_id": x["_sample_id"], "state": "not_attempted"} for x in items}}
    ev.run_parallel(items, refs, workers=2, run=run, report=None,
                    execute=fake_execute, factory=pool)
    assert _thread_state["max_conc"] >= 2, "必须有两个线程同时在途"
    assert len(_thread_state["threads"]) == 2, "必须真的跑在两个线程"
    assert len(_thread_state["pipes"]) == 2, "两线程各持独立pipeline实例"
    assert pool.created() == 2, "惰性构造实例数（含各自monitor）必须等于线程数"
    assert all(r["state"] == "completed" for r in run["records"].values())


def test_same_thread_reuses_pipeline_across_three_cases():
    """workers=1时至少3题在同一线程复用同一pipeline与monitor实例，不新建。"""
    items, refs = make_items(3)
    factory = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=None))
    pool = factory()
    run = {"manifest": {}, "records": {
        x["_sample_id"]: {"sample_id": x["_sample_id"], "state": "not_attempted"} for x in items}}
    ev.run_parallel(items, refs, workers=1, run=run, report=None,
                    execute=fake_execute, factory=pool)
    assert pool.created() == 1, "单线程3题必须复用同一pipeline与其独立monitor实例"


def test_blocked_result_never_reexecutes_candidate_sql():
    """res.ok=False（携带SQL的blocked）绝不触发候选execute；参考execute可以发生。"""
    items, refs = make_items(1)
    calls = []

    def execute(sql, trusted=False, scope=None, schema=None):
        calls.append((sql, trusted, scope))
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        return {"ok": False, "stage": "blocked", "sql": "SELECT 9 FROM bird_native.schools",
                "error": "sql_table_outside_scope", "repaired": False,
                "tables": ["schools"], "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                    execute=execute, factory=pool)
    # 仅参考SQL（trusted=True）被执行；候选blocked携带的SQL绝不执行。
    assert len(calls) == 1 and calls[0][1] is True, "参考执行可发生，候选blocked不得重执"
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "completed"
    assert rec["modes"]["full"]["ex"] is False
    assert rec["modes"]["full"]["error_class"] == "sql_safety"


def test_isolation_never_executes_candidate_sql():
    """串库快照命中立即阻断，候选execute绝不被调用；记录isolation_error并终止后续模式。"""
    items, refs = make_items(1)
    calls = []

    def execute(sql, trusted=False, scope=None, schema=None):
        calls.append(sql)
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        pipe.linker.index.current_db = "some_other_subdb"  # 模拟共享目录被切到别的子库
        return {"ok": True, "stage": "executed", "sql": "SELECT 1", "repaired": False,
                "tables": ["frpm"], "row_count": 1, "rows": [[1]], "columns": ["x"],
                "truncated": False, "error": None, "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    with pytest.raises(RunAbortedError):
        ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                        execute=execute, factory=pool)
    # 仅参考SQL进入execute；候选SQL在串库检查后绝不被执行。
    assert calls == ["SELECT 1"] and len(calls) == 1
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "isolation_error"
    assert rec["modes"]["full"]["executed"] is False
    assert rec["modes"]["pruned"]["state"] == "not_attempted", "串库后pruned不再调用"


def test_full_model_unavailable_does_not_call_pruned():
    """full模式模型故障后pruned不再调用模型，pruned显式标not_attempted；整题pending。"""
    items, refs = make_items(1)
    calls = []

    def execute(sql, trusted=False, scope=None, schema=None):
        calls.append((sql, trusted))
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        calls.append(mode)
        return {"ok": False, "stage": "model_unavailable", "error": "generation_unavailable",
                "sql": None, "repaired": False, "tables": [], "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    with pytest.raises(RunAbortedError):
        ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                        execute=execute, factory=pool)
    assert "pruned" not in calls, "full模型故障后pruned不得再调模型"
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "pending"
    assert rec["modes"]["pruned"]["state"] == "not_attempted"
    # 未尝试的占位标stopped_model；已尝试的pending题不改写。
    assert run["records"][items[0]["_sample_id"]]["state"] == "pending"


def test_candidate_scope_is_res_tables_intersect_scope():
    """候选execute允许表=生产res.tables与本题scope交集，绝不用全库scope绕过生产拒绝。"""
    items, refs = make_items(1)
    seen = []

    def execute(sql, trusted=False, scope=None, schema=None):
        seen.append(scope)
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        # 生成器只返回一张授权表schools（在scope内），候选允许集合必须等于它。
        return {"ok": True, "stage": "executed", "sql": "SELECT 1", "repaired": False,
                "tables": ["schools"], "row_count": 1, "rows": [[1]], "columns": ["x"],
                "truncated": False, "error": None, "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                    execute=execute, factory=pool)
    # 参考用全scope；候选两次（full/pruned）都用res.tables交集={"schools"}，缩小而非全库。
    assert seen[0] == {"bird_native": {"frpm", "schools"}}, "参考执行保持全库scope"
    assert seen[1] == {"bird_native": {"schools"}}, "候选full必须受res.tables约束"
    assert seen[2] == {"bird_native": {"schools"}}, "候选pruned必须受res.tables约束"


def test_thread_monitors_do_not_cross_count():
    """两线程monitor完全隔离：不同调用数/不同prompt长度，精确断言无互串。"""
    m1, m2 = ev.LLMMonitor(), ev.LLMMonitor()
    m1.start_case()
    s1 = m1.new_call()
    s1.prompt_chars = 10
    m1.finish(s1, response_chars=3)
    m2.start_case()
    s2 = m2.new_call()
    s2.prompt_chars = 40
    m2.finish(s2, response_chars=7)
    s3 = m2.new_call()
    s3.prompt_chars = 5
    m2.finish(s3, response_chars=2)
    t1 = m1.case_totals()
    t2 = m2.case_totals()
    assert t1 == {"llm_calls": 1, "llm_total_s": t1["llm_total_s"], "prompt_chars": 10,
                  "response_chars": 3, "usage_supported": False,
                  "usage_source": "null_no_vendor_usage",
                  "note": t1["note"]}, "线程A计数不得混入线程B"
    assert t2["llm_calls"] == 2 and t2["prompt_chars"] == 45, "线程B精确计两题窗口"
    # 题边界：新case必须重置窗口，不继承旧题calls。
    m2.start_case()
    s4 = m2.new_call()
    s4.prompt_chars = 1
    m2.finish(s4, response_chars=1)
    assert m2.case_totals()["llm_calls"] == 1, "新题窗口只含本题调用"


def test_checkpoint_written_before_last_task_finishes():
    """checkpoint由主线程在最后一个任务完成之前逐题写入，掉线不丢已完成预算。"""
    items, refs = make_items(3)
    writes = []
    report = {"execution_runs": {}}
    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=None))()
    run = {"manifest": {}, "records": {
        x["_sample_id"]: {"sample_id": x["_sample_id"], "state": "not_attempted"} for x in items}}

    def execute(sql, trusted=False, scope=None, schema=None):
        return FullResult("OK", 1, ((1,),))

    # 拦截报告原子写：只计数不真正落盘，避免污染真实报告。
    with mock.patch.object(ev, "atomic_write_json", side_effect=lambda p, o: writes.append(o)):
        ev.run_parallel(items, refs, workers=2, run=run, report=report, execute=execute,
                       factory=pool)
    # 提交前占位写1次 + 每题完成后各写1次（共3题）>= 4次；证明不是整轮结束才写一次。
    assert len(writes) >= 4, "每个future完成后主线程立即checkpoint，不等到整轮结束"


def test_at_most_workers_futures_in_flight():
    """真正只提交<=workers个future在途：4题workers=2时峰值在途绝不超过2。"""
    items, refs = make_items(4)
    inflight = {"cur": 0, "max": 0, "lock": threading.Lock()}

    def hook(pipe, db_id, sub_db, mode):
        with inflight["lock"]:
            inflight["cur"] += 1
            inflight["max"] = max(inflight["max"], inflight["cur"])
        time.sleep(0.04)
        with inflight["lock"]:
            inflight["cur"] -= 1

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {
        x["_sample_id"]: {"sample_id": x["_sample_id"], "state": "not_attempted"} for x in items}}
    ev.run_parallel(items, refs, workers=2, run=run, report=None,
                    execute=fake_execute, factory=pool)
    assert inflight["max"] <= 2, "任意时刻在途future绝不超过workers=2"
    assert inflight["max"] >= 2, "2个worker确实在途并行"


def test_manifest_every_semantic_field_change_rejected():
    """manifest任一语义字段（样本顺序/max_bytes/python/sqlglot/指纹files/模型标识）变化即拒绝。"""
    items, _ = make_items(2)
    base = ev.build_manifest(items, {"provider": "wb", "model": "m"}, True, False, 2)
    run = {"manifest": json.loads(json.dumps(base)), "records": {}}
    assert ev.check_manifest(base, run, items) is True, "完全一致放行"
    changed = dict(base); changed["samples"] = list(reversed(base["samples"]))
    assert ev.check_manifest(changed, run, items) is False, "样本顺序变化必须拒绝"
    for field in ("fingerprint", "fingerprint_files", "python", "sqlglot",
                  "sub_db_counts", "selection", "ordered", "max_rows", "max_bytes"):
        mutated = dict(base); mutated[field] = "x"
        assert ev.check_manifest(mutated, run, items) is False, f"字段{field}变化必须拒绝"
    # records键越出选题集：分母膨胀必须拒绝。
    inflated = dict(run)
    inflated["records"] = {"000:db0:q0": {"db_id": "db0", "state": "completed"},
                            "999:outside:zz": {"db_id": "outside", "state": "completed"}}
    assert ev.check_manifest(base, inflated, items) is False, "records越出选题集必须拒绝"
    wrong_db = dict(run)
    wrong_db["records"] = {"000:db0:q0": {"db_id": "db1", "state": "completed"}}
    assert ev.check_manifest(base, wrong_db, items) is False, "record.db_id与选题不符必须拒绝"


def test_task_error_keeps_denominator_and_aborts_nonzero(tmp_path, capsys):
    """任务异常记task_error保留分母，终止后raise RunAbortedError（main转非0退出），不回显正文。"""
    items, refs = make_items(2)

    def hook(pipe, db_id, sub_db, mode):
        raise RuntimeError("模拟供应商故障：细节不外传")

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {
        x["_sample_id"]: {"sample_id": x["_sample_id"], "state": "not_attempted"} for x in items}}
    with pytest.raises(RunAbortedError) as excinfo:
        ev.run_parallel(items, refs, workers=1, run=run, report=None,
                        execute=fake_execute, factory=pool)
    assert "模拟供应商故障" not in str(excinfo.value), "终止原因不得回显异常正文"
    states = {k: v["state"] for k, v in run["records"].items()}
    assert "task_error" in states.values(), "已尝试失败题必须记task_error而非not_attempted"
    summary = run["summary"]
    assert summary["task_error"] == 1
    assert summary["planned"] == 2, "固定分母保留"
    # main的退出码路径：RunAbortedError被main捕获后sys.exit(1)。
    out = capsys.readouterr().out
    assert "模拟供应商故障" not in out


def test_frozen_provider_same_identifier_for_all_workers():
    """model_identifier由一次性resolve的冻结快照生成，多worker共用同一标识（端点仅去用户信息散列）。"""
    fake_provider = {"name": "wb", "base_url": "http://1.2.3.4:7863/v1",
                     "api_key": "secret-key", "model": "global:test-model"}
    with mock.patch("backend.core.llm_client.LLMClient._select_provider",
                    return_value=dict(fake_provider)):
        provider, settings = ev.resolve_llm_snapshot()
        cfg1 = ev.model_identifier(provider, settings)
        cfg2 = ev.model_identifier(provider, settings)
    assert cfg1 == cfg2, "同一冻结快照下标识必须稳定"
    assert cfg1["frozen"] is True
    assert cfg1["provider"] == "wb" and cfg1["model"] == "global:test-model"
    blob = json.dumps(cfg1)
    assert "secret-key" not in blob and "1.2.3.4" not in blob, "标识绝不含密钥与完整地址"
    assert len(cfg1["endpoint_sha256_16"]) == 16


def test_two_modes_snapshot_windows_are_disjoint():
    """同一题full与pruned各1次LLM调用（不同字符数）：每mode以开始快照切窗，pruned不重含full。"""
    monitor = ev.LLMMonitor()
    monitor.start_case()
    full_base = monitor.snapshot()  # full模式开始前快照=0
    assert full_base == 0
    s1 = monitor.new_call(); s1.prompt_chars = 10; monitor.finish(s1, response_chars=3)
    # full结束：相对其开始快照的窗口恰好=1次（仅full）。
    full_s, full_calls = monitor.case_s(full_base)
    assert full_calls == 1, "full窗口相对其开始快照必须只含full的1次"
    pruned_base = monitor.snapshot()  # full结束后快照=1；pruned窗口从1起算
    assert pruned_base == 1
    s2 = monitor.new_call(); s2.prompt_chars = 40; monitor.finish(s2, response_chars=7)
    pruned_s, pruned_calls = monitor.case_s(pruned_base)
    assert pruned_calls == 1, "pruned窗口相对其开始快照必须只含pruned的1次，不能=2"
    assert full_s >= 0.0 and pruned_s >= 0.0
    # 单题totals仍完整覆盖两模式共2次，不丢失。
    total = monitor.case_totals()
    assert total["llm_calls"] == 2
    assert total["prompt_chars"] == 50


def test_reference_ok_candidate_db_disconnect_not_capability_error():
    """参考执行成功后候选DB断连：记candidate_db_unavailable且ex=None（不当能力错计False）。"""
    items, refs = make_items(1)

    def execute(sql, trusted=False, scope=None, schema=None):
        # 参考(trusted)成功；候选执行返回库级连接故障。
        if trusted:
            return FullResult("OK", 1, ((1,),))
        return FullResult("ERROR", 0, (), "connection_or_query")

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=None))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    with pytest.raises(ev.RunAbortedError):
        ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                        execute=execute, factory=pool)
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "pending", "库级故障必须转pending，不当能力错"
    assert rec["modes"]["full"]["ex"] is None
    assert rec["modes"]["full"]["error_class"] == "candidate_db_unavailable"
    assert run["summary"]["stop_reason"] == "candidate_db_unavailable"


def test_sqlsyntax_failure_is_not_db_unavailable():
    """参考SQL语法失败（如42601）记reference_error而非库级故障，不误停整库。"""
    items, refs = make_items(1)

    def execute(sql, trusted=False, scope=None, schema=None):
        if trusted:
            return FullResult("ERROR", 0, (), "42601")
        return FullResult("OK", 1, ((1,),))

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=None))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    # 语法错误是reference_error，不触发RunAbortedError，调度正常结束。
    ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                    execute=execute, factory=pool)
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "reference_error"
    assert rec["reference_error_code"] == "42601"
    assert ev.is_db_unavailable("42601") is False


def test_isolation_requires_schema_and_subset_not_just_intersection():
    """scope检查：res.tables越出原scope立即isolation不重执，而非交集后静默忽略。"""
    items, refs = make_items(1)
    calls = []

    def execute(sql, trusted=False, scope=None, schema=None):
        calls.append((sql, scope))
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        # 生成器返回越出scope的表（outside_table不在本题scope内）。
        return {"ok": True, "stage": "executed", "sql": "SELECT 1", "repaired": False,
                "tables": ["frpm", "outside_table"], "row_count": 1, "rows": [[1]],
                "columns": ["x"], "truncated": False, "error": None, "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    with pytest.raises(ev.RunAbortedError):
        ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                        execute=execute, factory=pool)
    # 仅参考SQL进入execute；候选越界题在res.ok判断前即isolation，绝不重执。
    assert len(calls) == 1 and calls[0][0] == "SELECT 1"
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["state"] == "isolation_error"
    assert rec["modes"]["full"]["isolated"] is True
    assert rec["modes"]["full"]["executed"] is False


def test_sql_block_still_blocks_even_with_ok_false():
    """安全/权限类blocked保持阻断语义：ex=False且不触发候选execute。"""
    items, refs = make_items(1)
    calls = []

    def execute(sql, trusted=False, scope=None, schema=None):
        calls.append(sql)
        return FullResult("OK", 1, ((1,),))

    def hook(pipe, db_id, sub_db, mode):
        return {"ok": False, "stage": "blocked", "sql": "SELECT 1",
                "error": "sql_read_only", "repaired": False, "tables": [],
                "view": {}, "trace": None}

    pool = make_pool_factory(lambda tag: FakePipeline(tag, factory_state=hook))()
    run = {"manifest": {}, "records": {items[0]["_sample_id"]: {"state": "not_attempted"}}}
    ev.run_parallel([items[0]], refs, workers=1, run=run, report=None,
                    execute=execute, factory=pool)
    assert len(calls) == 1, "仅参考SQL执行；安全阻断的候选SQL绝不重执"
    rec = run["records"][items[0]["_sample_id"]]
    assert rec["modes"]["full"]["state"] == "candidate_blocked"
    assert rec["modes"]["full"]["error_class"] == "sql_safety"


def test_per_db_must_be_positive():
    """per-db正值校验：0或负数直接拒绝，避免静默退化到全量。"""
    items, _ = make_items(2)
    with pytest.raises(ValueError):
        ev.select_samples(items, per_db=0, all_samples=False)
    with pytest.raises(ValueError):
        ev.select_samples(items, per_db=-1, all_samples=False)


def test_manifest_missing_but_records_present_rejected():
    """缺manifest但已有records：严格校验直接拒绝，禁止跨版本补盖混跑。"""
    items, _ = make_items(2)
    manifest = ev.build_manifest(items, {"provider": "wb"}, True, True, 2)
    assert ev.check_manifest(manifest, {"records": {"a": 1}}) is False, "缺manifest含records必须拒绝"
    assert ev.check_manifest(manifest, {"records": {}}) is True, "新建无records放行"


def test_full_selection_500_unique_and_11_subdbs():
    """--all全量选择必须恰好500、sample_id唯一、11个子库；不用per-db估算。"""
    items = []
    dbs = [f"subdb_{i}" for i in range(11)]
    for i in range(500):
        db = dbs[i % len(dbs)]
        items.append({"_sample_id": f"{i:03d}:{db}:q{i}", "db_id": db,
                      "question_id": f"q{i}", "question": "x"})
    counts = ev.verify_full_selection(items)
    assert len(items) == 500 and len(counts) == 11
    with pytest.raises(ValueError):
        ev.verify_full_selection(items[:499])
    dup = list(items)
    dup[-1] = dict(dup[0])
    with pytest.raises(ValueError):
        ev.verify_full_selection(dup)


def test_atomic_write_leaves_no_temp_file(tmp_path):
    """原子写：正常替换后无临时文件残留；replace失败时finally也清理temp。"""
    target = tmp_path / "report.json"
    ev.atomic_write_json(target, {"a": 1})
    assert target.exists() and json.loads(target.read_text(encoding="utf-8")) == {"a": 1}
    assert list(tmp_path.glob("report.json.tmp-*")) == [], "replace后必须清理临时文件"
    with mock.patch.object(Path, "replace", side_effect=OSError("disk full")):
        with pytest.raises(OSError):
            ev.atomic_write_json(target, {"a": 2})
    assert list(tmp_path.glob("report.json.tmp-*")) == [], "异常也必须删除temp"


def test_report_write_lock_rejects_second_writer(tmp_path):
    """同一报告同一时间只允许一个评测运行；第二个写者被拒绝退出。"""
    report = tmp_path / "rep.json"
    ev.acquire_report_write_lock(report)
    with pytest.raises(SystemExit):
        ev.acquire_report_write_lock(report)
    ev.release_report_write_lock(report)
    ev.acquire_report_write_lock(report)
    ev.release_report_write_lock(report)


def test_summary_reports_fixed_and_paired_denominators_separately():
    """固定计划分母与可评配对分母必须显式分开；未完成不声称全量验收。"""
    records = {
        "a": {"state": "completed", "modes": {"full": {"ex": True}, "pruned": {"ex": True}}},
        "b": {"state": "completed", "modes": {"full": {"ex": False}, "pruned": {"ex": True}}},
        "c": {"state": "not_attempted", "modes": {}},
        "d": {"state": "stopped_model", "modes": {}},
        "e": {"state": "reference_error", "modes": {}},
        "f": {"state": "task_error", "modes": {}},
    }
    summary = ev.summary_counts(records)
    assert summary["planned"] == 6
    assert summary["full_correct"] == 1 and summary["pruned_correct"] == 2
    assert summary["full_correct_over_planned"] == 1 / 6
    assert summary["pruned_correct_over_planned"] == 2 / 6
    assert summary["paired_completed"] == 2
    assert summary["full_ex_completed"] == 0.5 and summary["pruned_ex_completed"] == 1.0
    assert summary["not_attempted"] == 1 and summary["stopped_model"] == 1
    assert summary["reference_error"] == 1 and summary["task_error"] == 1


def test_http_error_classification_by_status_code():
    """HTTPStatusError按响应码分类auth/config/transient，绝不靠正文猜测。"""
    import httpx
    req = httpx.Request("POST", "http://invalid/none")

    def status(code):
        return httpx.HTTPStatusError(
            f"HTTP {code}", request=req, response=httpx.Response(code, request=req))
    assert ev.classify_http_error(status(401)) == "auth_error"
    assert ev.classify_http_error(status(403)) == "auth_error"
    assert ev.classify_http_error(status(400)) == "config_error"
    assert ev.classify_http_error(status(422)) == "config_error"
    assert ev.classify_http_error(status(404)) == "config_error"
    assert ev.classify_http_error(status(429)) == "transient_rate_limited"
    assert ev.classify_http_error(status(503)) == "transient_server_error"
    assert ev.classify_http_error(status(500)) == "transient_server_error"


def test_db_unavailable_classification():
    """库级故障=SQLSTATE 08xx/28xx/42501及无pgcode连接失败；参考语法失败不算库故障。"""
    assert ev.is_db_unavailable("08001") is True
    assert ev.is_db_unavailable("08006") is True
    assert ev.is_db_unavailable("28000") is True
    assert ev.is_db_unavailable("42501") is True
    assert ev.is_db_unavailable("connection_or_query") is True
    assert ev.is_db_unavailable("source_metadata_unavailable") is True
    assert ev.is_db_unavailable("42601") is False, "参考SQL语法错误不得当整个库故障"
    assert ev.is_db_unavailable("result_budget") is False
