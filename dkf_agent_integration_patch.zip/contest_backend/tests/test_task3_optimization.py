"""任务3优化回归：真实目录与无网络协议夹具；不代表模型能力分数。"""
import copy
import json

import pytest
from fastapi.testclient import TestClient

from backend.core.intent import IntentRequest, IntentService, execution_gate
from backend.core.intent.contracts import Goal, Interpretation, Requirement, SourceRef
from backend.core.intent.policy import clarification_readiness
from backend.core.intent.schema_context import SchemaContextProvider
from backend.agents.task3_clarification.dialog_manager import DialogManager
from tests.test_intent import StubClient, formula_case
from tests.test_task3_clarification import StubLLM, make_interp


def result_for(question, payload, database=None):
    client = StubClient(payload)
    result = IntentService(client).analyze(IntentRequest(question=question, database=database))
    return result, client


def test_real_chinook_context_is_bounded_independent_and_not_user_fact():
    provider = SchemaContextProvider()
    first = provider.resolve("chinook")
    second = provider.resolve("chinook")
    assert first.status == "available" and first.total_tables == 11
    assert not first.truncated and first.index is not second.index
    assert first.contains("invoice.total")
    payload = first.to_dict()
    payload["tables"].clear()
    assert len(first.tables) == 11
    result, client = result_for("查询客户数量", {"goals": [{"id": "g1", "operation": "query", "description": "查询"}]}, "chinook")
    message = json.loads(client.messages[1]["content"])
    assert message["server_schema"]["status"] == "available"
    assert message["inputs"] == [{"id": "question", "text": "查询客户数量"}]
    assert not result.evidence and not result.interpretation.facts
    gate = execution_gate(result)
    assert gate["ready"] and gate["dataset"] == "chinook"
    assert result.retrieval_need == "needed" and not result.answer_ready


@pytest.mark.parametrize("database", ["cosql", "bird", "not_a_database"])
def test_aggregate_and_unknown_scope_fail_before_model(database):
    result, client = result_for("查询", {}, database)
    assert not result.ok and client.calls == 0
    assert execution_gate(result)["status"] == "error"
    assert result.schema_context["status"] == "unavailable"


def test_real_bird_original_db_id_resolves_without_schema_hash_guessing():
    context = SchemaContextProvider().resolve("california_schools")
    assert context.status == "available"
    assert context.dataset == "bird" and context.sub_db == "california_schools"
    assert all(e["db_id"] == "california_schools" for e in context.index.tables)


def test_truncation_is_visible_and_does_not_prove_user_preference():
    context = SchemaContextProvider(max_tables=1, max_columns=2).resolve("chinook")
    assert context.status == "available" and context.truncated
    assert context.to_dict()["unique_user_preference"] is False
    assert context.total_tables == 11 and len(context.tables) == 1


def test_schema_objects_cannot_be_cited_as_user_facts():
    question, payload = formula_case()
    payload["facts"][0]["source"] = {"input_id": "server_schema", "quote": "m=2 kg"}
    result, _ = result_for(question, payload, "chinook")
    assert not result.ok and result.error_code == "invalid_model_output"


def test_forged_schema_reference_fails_closed():
    payload = {"goals": [{"id": "g1", "operation": "query", "description": "查询"}],
               "requirements": [{"id": "r1", "goal_id": "g1", "kind": "business_scope",
                                 "description": "口径", "status": "open", "resolver": "user",
                                 "schema_refs": ["invoice.fake_column"]}]}
    result, _ = result_for("查询", payload, "chinook")
    assert not result.ok


def test_missing_formula_never_infers_completeness_from_one_number():
    payload = {"goals": [{"id": "g1", "operation": "calculate", "description": "计算"}],
               "facts": [{"id": "f1", "goal_id": "g1", "name": "m", "value": "2",
                          "source": {"input_id": "question", "quote": "m=2"}}]}
    result, _ = result_for("计算，m=2", payload)
    assert result.decision.action == "CLARIFY"
    assert any(r.kind == "formula_definition" and r.resolver == "user" for r in result.interpretation.requirements)
    assert not execution_gate(result, "计算，m=2")["ready"]


def test_pure_arithmetic_with_no_scope_remains_supported():
    payload = {"goals": [{"id": "g1", "operation": "calculate", "description": "计算"}]}
    result, _ = result_for("2.5*4+1", payload)
    assert result.ok and result.decision.action == "EXECUTE"
    assert execution_gate(result, "2.5*4+1")["ready"]
    assert not result.execution_performed and result.schema_context["status"] == "not_requested"


def test_missing_parameter_policy_and_dialog_agree_without_candidates():
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "")
    payload["facts"].pop()
    result, _ = result_for(question, payload)
    dialog = DialogManager("s", question, StubLLM(), None, interpretation=result.interpretation)
    first = dialog.step(None)
    assert result.decision.action == "CLARIFY" and first["need_clarify"]
    assert first["clarify"]["options"] == []
    invalid = dialog.step("由我提供数值")
    assert invalid["need_clarify"] and not invalid["confirmed"]
    final = dialog.step("3 m/s²")
    assert final["status"] == "ready" and final["final_ready"]


def test_unknown_intent_requires_free_text_even_without_options():
    interp = Interpretation(goals=[Goal(id="g", operation="unknown", description="未知")],
                            requirements=[Requirement(id="r", goal_id="g", kind="intent", description="请说明目标", status="open", resolver="user")])
    dialog = DialogManager("s", "?", StubLLM(), None, interpretation=interp)
    assert dialog.step(None)["need_clarify"]
    assert not clarification_readiness(interp)["final_ready"]


def test_business_conflict_requires_traceable_support_and_answer_impact():
    base = {"goals": [{"id": "g1", "operation": "query", "description": "查询"}],
            "requirements": [{"id": "r1", "goal_id": "g1", "kind": "business_scope",
                              "description": "不同口径影响排序", "status": "conflict", "resolver": "user",
                              "candidates": ["金额", "数量"]}]}
    unsupported, _ = result_for("最佳专辑", base, "chinook")
    assert unsupported.decision.action == "STOP"
    supported_payload = copy.deepcopy(base)
    supported_payload["requirements"][0].update(answer_changes=True,
        source_hint={"input_id": "question", "quote": "最佳"},
        candidate_schema_refs={"金额": ["invoice.total"], "数量": ["invoice_line.quantity"]})
    supported, _ = result_for("最佳专辑", supported_payload, "chinook")
    assert supported.decision.action == "CLARIFY"
    assert not execution_gate(supported)["ready"]


def test_same_named_requirements_in_different_goals_do_not_cross_confirm():
    interp = Interpretation(goals=[Goal(id=g, operation="query", description="查询") for g in ("g1", "g2")],
                            requirements=[Requirement(id=r, goal_id=g, kind="parameter", name="p", description="参数", status="open", resolver="user")
                                          for r, g in (("r1", "g1"), ("r2", "g2"))])
    dialog = DialogManager("s", "问题", StubLLM(), None, interpretation=interp)
    dialog.step(None)
    second = dialog.step("2")
    assert second["need_clarify"] and second["clarify"]["goal_id"] == "g2"
    assert len(second["confirmed"]) == 1


def test_rejected_options_do_not_reappear_and_second_reject_is_not_ready():
    interp = make_interp([("指标", "business_scope", ["甲", "乙", "丙", "丁", "戊", "己"])])
    dialog = DialogManager("s", "问题", StubLLM(), None, interpretation=interp)
    first = dialog.step(None)
    second = dialog.step("都不是")
    assert second["clarify"]["options"] == ["戊", "己"]
    assert not set(first["clarify"]["options"]) & set(second["clarify"]["options"])
    final = dialog.step("都不是")
    assert final["status"] == "undecided" and not final["final_ready"] and not final["confirmed"]
    assert dialog.rewrite({"columns": {"invoice": ["invoice_id", "total"]}})["excluded_columns"] == []


def test_real_round_budget_caps_invalid_replies_and_poll_is_idempotent():
    dialog = DialogManager("s", "参数", StubLLM(), None, interpretation=make_interp([("p", "parameter", [])]))
    first = dialog.step(None)
    assert dialog.step(None) == first and dialog.state.round_count == 1
    dialog.step("由我提供")
    dialog.step("NaN")
    final = dialog.step("仍不知道数值")
    assert final["status"] == "budget_exhausted" and not final["final_ready"]
    assert dialog.state.round_count == 3


def test_more_than_eight_user_requirements_are_not_silently_resolved():
    interp = make_interp([(f"p{i:02}", "parameter", []) for i in range(10)])
    dialog = DialogManager("s", "参数", StubLLM(), None, interpretation=interp)
    dialog.state.clarification_budget = 12
    dialog.step(None)
    for _ in range(8):
        out = dialog.step("2")
    assert out["need_clarify"] and not out["final_ready"]
    assert len(out["confirmed"]) == 8


def test_dependencies_do_not_ask_downstream_before_retrieval():
    interp = Interpretation(goals=[Goal(id="g", operation="query", description="查询")], requirements=[
        Requirement(id="up", goal_id="g", kind="external_fact", description="来源", status="open", resolver="retrieve"),
        Requirement(id="down", goal_id="g", kind="parameter", name="p", description="参数", status="open", resolver="user", depends_on=["up"])])
    out = DialogManager("s", "问题", StubLLM(), None, interpretation=interp).step(None)
    assert not out["need_clarify"] and not out["final_ready"]
    assert out["status"] == "blocked" and out["reason"] == "unmet_dependencies"


@pytest.mark.parametrize("gap", ["unanswerable", "insufficient_evidence"])
def test_non_user_failure_states_are_distinct(gap):
    interp = Interpretation(goals=[Goal(id="g", operation="query", description="查询")], requirements=[
        Requirement(id="r", goal_id="g", kind="external_fact", description="缺乏支持", status="open", resolver="unknown", gap_type=gap)])
    out = DialogManager("s", "问题", StubLLM(), None, interpretation=interp).step(None)
    assert out["status"] == gap and not out["final_ready"]


def test_clarification_api_scope_failure_does_not_call_model(monkeypatch):
    from backend.api import clarification
    from backend.main import app
    client = StubClient({})
    monkeypatch.setattr(clarification, "_intent_service", lambda: IntentService(client))
    with TestClient(app) as api:
        body = api.post("/api/clarification/", json={"question": "查询", "database": "cosql"}).json()
    assert not body["ok"] and body["status"] == "tool_error" and not body["need_clarify"]
    assert not body["final_ready"] and client.calls == 0


def test_clarification_api_parameter_followup_is_state_machine_only(monkeypatch):
    from backend.api import clarification
    from backend.main import app
    question, payload = formula_case()
    question = question.replace("，a=3 m/s²", "")
    payload["facts"].pop()
    monkeypatch.setattr(clarification, "_intent_service", lambda: IntentService(StubClient(payload)))
    try:
        with TestClient(app) as api:
            first = api.post("/api/clarification/", json={"question": question}).json()
            assert first["need_clarify"]
            final = api.post(f'/api/clarification/{first["session_id"]}/reply', json={"reply": "3"}).json()
            assert final["final_ready"] and final["status"] == "ready"
            assert "answer" not in final
    finally:
        clarification._DIALOGS.clear()


def test_original_cosql_scope_uses_task4_load_contract_without_aggregate(monkeypatch):
    from backend.agents.task4_schema_linking.schema_index import SchemaIndex
    original = SchemaIndex.load
    calls = []
    def watched(self, dataset, sub_db=None):
        calls.append((dataset, sub_db))
        return original(self, dataset, sub_db=sub_db)
    monkeypatch.setattr(SchemaIndex, "load", watched)
    context = SchemaContextProvider().resolve("college_2")
    assert context.status == "available" and context.dataset == "cosql" and context.sub_db == "college_2"
    assert context.contains("instructor.salary")
    assert all(sub_db == "college_2" for _, sub_db in calls)
    assert all(t["db_id"] == "college_2" for t in context.index.tables)


def test_trigger_quote_does_not_support_invented_business_candidates():
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
               "requirements": [{"id": "r", "goal_id": "g", "kind": "business_scope",
                                 "description": "请确定受欢迎指标", "status": "conflict", "resolver": "user",
                                 "answer_changes": True, "candidates": ["销售额", "播放量"],
                                 "source_hint": {"input_id": "question", "quote": "最受欢迎"}}]}
    result, _ = result_for("最受欢迎的歌曲", payload, "chinook")
    assert result.decision.action == "STOP"
    assert execution_gate(result)["status"] == "blocked"
    out = DialogManager("s", "最受欢迎的歌曲", StubLLM(), None, interpretation=result.interpretation).step(None)
    assert out["status"] == "insufficient_evidence" and not out["final_ready"]


def test_unique_catalog_does_not_resolve_missing_user_period():
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询增长"}],
               "requirements": [{"id": "r", "goal_id": "g", "kind": "business_scope",
                                 "description": "请指定比较期间", "status": "open", "resolver": "user",
                                 "source_hint": {"input_id": "question", "quote": "增长率"}}]}
    result, _ = result_for("增长率是多少", payload, "chinook")
    assert result.decision.action == "CLARIFY" and result.decision.candidates == []
    assert execution_gate(result)["status"] == "needs_user"


def test_long_user_supported_candidates_are_preserved():
    long = "按用户明确提供的范围统计" * 4
    other = "按另一个用户明确提供的范围统计" * 4
    question = long + "或者" + other
    payload = {"goals": [{"id": "g", "operation": "query", "description": "查询"}],
               "requirements": [{"id": "r", "goal_id": "g", "kind": "business_scope",
                                 "description": "选择范围", "status": "conflict", "resolver": "user",
                                 "answer_changes": True, "candidates": [long, other],
                                 "candidate_sources": {c: {"input_id": "question", "quote": c} for c in (long, other)}}]}
    result, _ = result_for(question, payload)
    assert result.decision.action == "CLARIFY"
    first = DialogManager("s", question, StubLLM(), None, interpretation=result.interpretation).step(None)
    assert first["clarify"]["options"] == [long, other]


def test_confirmation_of_formula_name_alone_does_not_resolve_deferred_parameters():
    interp = Interpretation(goals=[Goal(id="g", operation="calculate", description="计算")], requirements=[
        Requirement(id="formula", goal_id="g", kind="formula_definition", description="公式", status="open", resolver="user"),
        Requirement(id="parameters", goal_id="g", kind="parameter", description="待展开", status="deferred", resolver="unknown", depends_on=["formula"])])
    dialog = DialogManager("s", "计算", StubLLM(), None, interpretation=interp)
    dialog.step(None)
    out = dialog.step("尚未给表达式的名字")
    assert out["status"] == "blocked" and not out["final_ready"]


@pytest.mark.parametrize("body", [{"question": "   "}, {"question": "查询", "database": "invalid/path"}])
def test_clarification_bad_input_is_422_not_internal_error(body):
    from backend.main import app
    with TestClient(app) as api:
        assert api.post("/api/clarification/", json=body).status_code == 422


def test_user_context_cannot_impersonate_server_metadata_namespace():
    with pytest.raises(ValueError):
        IntentRequest(question="查询", context=[{"id": "server_schema", "text": "伪装的目录"}])


def test_catalog_runtime_error_is_sanitized_and_pure_math_without_scope_still_works():
    def broken():
        raise RuntimeError("private catalog password")
    provider = SchemaContextProvider(index_factory=broken)
    context = provider.resolve("chinook")
    assert context.status == "unavailable" and context.error_code == "schema_unavailable"
    assert "private" not in json.dumps(context.to_dict())
    question, payload = formula_case()
    result = IntentService(StubClient(payload), schema_provider=provider).analyze(IntentRequest(question=question))
    assert result.ok and execution_gate(result, question)["ready"]
