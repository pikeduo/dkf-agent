"""补充意图层原文取值与依赖关系的协议回归测试。"""
import copy

from tests.test_intent import analyze, formula_case


def test_adjacent_chinese_text_and_units_preserve_raw_numbers():
    question, payload = formula_case()
    payload["facts"][0]["source"]["quote"] = "质量为2kg"
    payload["facts"][1]["source"]["quote"] = "加速度为3m/s²"
    result = analyze("F=m*a，质量为2kg，加速度为3m/s²", payload)
    assert result.ok
    assert result.decision.action == "EXECUTE"


def test_fact_cannot_satisfy_another_goal_requirement():
    question, payload = formula_case()
    payload["goals"].append({"id": "g2", "operation": "query", "description": "另一个目标"})
    payload["requirements"].append({"id": "r1", "goal_id": "g2", "kind": "external_fact", "description": "其他事实", "status": "satisfied", "resolver": "user", "fact_ids": ["f1"]})
    assert not analyze(question, payload).ok


def test_implicit_multiplication_is_not_mistaken_for_missing_ma():
    question, payload = formula_case()
    question = question.replace("m*a", "ma")
    payload["formulas"][0]["source"]["quote"] = "F=ma"
    result = analyze(question, payload)
    assert result.decision.action == "READ_INPUT"


def test_explicit_binding_cannot_be_renamed_by_model():
    question, payload = formula_case()
    payload["facts"][1]["source"] = payload["facts"][0]["source"]
    payload["facts"][1]["value"] = "2"
    payload["facts"][1]["unit"] = "kg"
    result = analyze(question, payload)
    assert not result.ok


def test_conflicting_values_remain_unresolved():
    question, payload = formula_case()
    second = copy.deepcopy(payload["facts"][0])
    second.update(id="f3", value="4", source={"input_id": "question", "quote": "m=4 kg"})
    payload["facts"].append(second)
    result = analyze(question + "另一个m=4 kg", payload)
    assert result.decision.action == "CLARIFY"
    assert "多个值" in result.decision.message


def test_missing_model_requirement_is_resolved_by_verified_input_binding():
    question, payload = formula_case()
    payload["requirements"] = [{"id": "r1", "goal_id": "g1", "kind": "parameter", "name": "a", "description": "需要a", "status": "open", "resolver": "user"}]
    assert analyze(question, payload).decision.action == "EXECUTE"


def test_duplicate_json_key_is_rejected():
    assert not analyze("计算", '{"goals": [], "goals": []}').ok


def test_masked_superseded_condition_cannot_be_cited():
    from backend.core.history.store import MASK_TEXT, HistoryMessage
    from backend.core.intent.contracts import IntentRequest
    from backend.core.intent.service import IntentService
    from tests.test_intent import StubClient
    question, payload = formula_case()
    old = HistoryMessage("history_old", "task", "turn", 0, "user", f"F=m*a，{MASK_TEXT}")
    payload["facts"][0]["source"] = {"input_id": "history_old", "quote": MASK_TEXT}
    result = IntentService(StubClient(payload)).analyze(IntentRequest(question=question), history=[old])
    assert not result.ok and result.error_code == "invalid_model_output"


def test_formula_fragment_cannot_drop_an_addend():
    question, payload = formula_case()
    assert not analyze(question.replace("F=m*a", "F=m*a+b"), payload).ok


def test_explicit_binding_cannot_take_another_value_from_same_quote():
    question, payload = formula_case()
    payload["facts"][0]["source"]["quote"] = "m=2 kg，a=3 m/s²"
    payload["facts"][0]["value"] = "3"
    assert not analyze(question, payload).ok


def test_satisfied_downstream_with_open_dependency_is_rejected():
    question, payload = formula_case()
    payload["requirements"] = [
        {"id": "r1", "goal_id": "g1", "kind": "business_scope", "description": "未定", "status": "open", "resolver": "user"},
        {"id": "r2", "goal_id": "g1", "kind": "parameter", "name": "m", "description": "已定", "status": "satisfied", "resolver": "user", "depends_on": ["r1"], "fact_ids": ["f1"]},
    ]
    assert not analyze(question, payload).ok
