"""Integration overlay: local, no database, LLM or paid HTTP calls."""
import json
from pathlib import Path
import pytest
from fastapi import HTTPException
from backend.api.catalog import sources
from backend.api.trace import get_trace, register_trace
from backend.core.trace_logger import ExecutionTrace


def test_catalog_exposes_only_safe_identifiers():
    content = sources()
    assert content['items']
    assert 'chinook' in {item['db_id'] for item in content['items']}
    for item in content['items']:
        assert set(item) == {'db_id','name','table_count_hint'}
        assert 'password' not in json.dumps(item).lower()
        assert 'postgresql://' not in json.dumps(item)


def test_trace_endpoint_rejects_path_traversal():
    with pytest.raises(HTTPException) as exc:
        get_trace('../../other_secret')
    assert exc.value.status_code == 400


def test_trace_endpoint_returns_real_record(monkeypatch, tmp_path):
    import backend.api.trace as trace_api
    monkeypatch.setattr(trace_api, '_TRACE_DIR', str(tmp_path))
    record = ExecutionTrace('demo question')
    record.log('SQL', 'validated', output_data={'ok':True})
    register_trace(record)
    restored = get_trace(record.trace_id)
    assert restored.steps[0]['module'] == 'SQL'
    assert restored.trace_id == record.trace_id
    assert (tmp_path / (record.trace_id + '.json')).exists()
