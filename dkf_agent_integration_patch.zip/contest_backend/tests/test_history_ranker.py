"""协议夹具测试，不属于真实数据集或中文能力评测。"""
import json

import httpx
import pytest

from backend.integrations.history_ranker import ImajevHistoryRanker, HistoryRankingError


def candidates():
    return [{"id": "turn1", "messages": [{"id": "m1", "role": "user", "text": "公式与参数"}]},
            {"id": "turn2", "messages": [{"id": "m2", "role": "assistant", "text": "澄清问题"}]}]


def answer():
    return {"answers": {"history": {"type": "multi", "probabilities": {"turn1": 0.8, "turn2": 0.7},
                                    "unknown_probabilities": {"turn1": 0.1, "turn2": 0.2}, "abstained": False}}}


def test_multi_uses_stable_ids_and_independent_scores():
    def handler(request):
        payload = json.loads(request.content)
        assert payload["questions"]["history"]["type"] == "multi"
        assert set(payload["questions"]["history"]["criteria"]) == {"turn1", "turn2"}
        assert payload["state"]["current_question"] == "开始计算"
        assert request.headers["authorization"] == "Bearer local-secret"
        return httpx.Response(200, json=answer())
    ranker = ImajevHistoryRanker(api_key="local-secret", transport=httpx.MockTransport(handler))
    scores = ranker.score("开始计算", candidates())
    assert scores["turn1"].score == 0.8
    assert sum(s.score for s in scores.values()) > 1


@pytest.mark.parametrize("kind", ["missing", "unknown_id", "boolean", "nan", "type", "http", "redirect", "json", "timeout", "too_large"])
def test_bad_responses_raise_sanitized_error(kind):
    def handler(request):
        data = answer()
        if kind == "missing":
            del data["answers"]["history"]["unknown_probabilities"]["turn1"]
        elif kind == "unknown_id":
            data["answers"]["history"]["probabilities"]["evil"] = 0.9
        elif kind == "boolean":
            data["answers"]["history"]["probabilities"]["turn1"] = True
        elif kind == "nan":
            return httpx.Response(200, content=json.dumps(data).replace("0.8", "NaN"))
        elif kind == "type":
            data["answers"]["history"]["type"] = "choice"
        elif kind == "http":
            return httpx.Response(500, text="private-message")
        elif kind == "redirect":
            return httpx.Response(302, headers={"location": "http://other.invalid"})
        elif kind == "json":
            return httpx.Response(200, text="private-message")
        elif kind == "timeout":
            raise httpx.ReadTimeout("private-message")
        elif kind == "too_large":
            return httpx.Response(200, content=b"x" * (1024 * 1024 + 1))
        return httpx.Response(200, json=data)
    with pytest.raises(HistoryRankingError) as exc:
        ImajevHistoryRanker(transport=httpx.MockTransport(handler)).score("test", candidates())
    assert "private-message" not in str(exc.value)


def test_abstention_keeps_all_unknown_and_input_limit_prevents_network():
    calls = []
    def handler(request):
        calls.append(1)
        data = answer()
        data["answers"]["history"]["abstained"] = True
        return httpx.Response(200, json=data)
    ranker = ImajevHistoryRanker(transport=httpx.MockTransport(handler))
    assert all(s.unknown == 1 for s in ranker.score("q", candidates()).values())
    with pytest.raises(HistoryRankingError):
        ranker.score("x" * 65000, candidates())
    with pytest.raises(HistoryRankingError):
        ranker.score("q", candidates() * 17)
    assert len(calls) == 1


@pytest.mark.parametrize("url", ["file:///a", "http://a:b@host/x", "https://host/x?token=secret", "https://host/x#fragment"])
def test_bad_endpoint_is_rejected(url):
    with pytest.raises(ValueError):
        ImajevHistoryRanker(url)
