"""任务3 澄清闭环离线测试：不访问网络与数据库。
检测器以固定意图解释为输入，候选选项走启发式兜底，验证状态机与去重规则。
"""
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task3_clarification.dialog_manager import DialogManager
from backend.core.intent.contracts import Goal, Interpretation, Requirement, SourceRef


class StubLLM:
    """离线用：记录调用；fill_options 走启发式兜底，不真正调模型。"""

    def __init__(self):
        self.calls = 0

    def chat(self, messages, temperature=0.0, reasoning_effort="default"):
        self.calls += 1
        return "[]"  # 让 fill_options 落到启发式兜底，选项可离线断言


def make_interp(user_reqs=(), conflict=False):
    reqs = []
    for i, (name, kind, candidates) in enumerate(user_reqs):
        reqs.append(Requirement(
            id=f"r{i}", goal_id="g1", kind=kind, name=name,
            description=f"缺少 {name}", status="conflict" if conflict else "open",
            resolver="user", candidates=list(candidates),
            source_hint=SourceRef(input_id="question", quote="协议夹具口径"),
            candidate_sources={c: SourceRef(input_id="question", quote=c) for c in candidates},
            answer_changes=conflict))
    return Interpretation(goals=[Goal(id="g1", operation="query", description="查询")],
                          requirements=reqs)


def test_ready_when_no_user_requirements():
    d = DialogManager("s1", "各国家的顾客数量", StubLLM(), None, interpretation=make_interp())
    out = d.step(None)
    assert out["need_clarify"] is False
    assert out["final_ready"] is True
    assert out["status"] == "ready"


def test_clarify_when_user_requirement_open():
    interp = make_interp(user_reqs=[("时间范围", "business_scope", ["2008年", "2009年", "全部"])])
    d = DialogManager("s2", "销售额增长率是多少？", StubLLM(), None, interpretation=interp)
    out = d.step(None)
    assert out["need_clarify"] is True
    assert out["clarify"]["dimension"] == "时间范围"
    assert "2008年" in out["clarify"]["options"]
    # 选第一项后登记确认，闭环到 ready
    out2 = d.step(out["clarify"]["options"][0])
    assert out2["need_clarify"] is False
    assert out2["final_ready"] is True
    assert out2["confirmed"], "确认值必须写回 confirmed_slots"


def test_conflict_dim_ranked_first():
    interp = make_interp(user_reqs=[("时间范围", "business_scope", ["A", "B"]),
                                    ("指标口径", "business_scope", ["销售额", "数量"])])
    # 把第二个需求置为冲突，必须排到最前
    interp.requirements[1].status = "conflict"
    interp.requirements[1].answer_changes = True
    d = DialogManager("s3", "增长率", StubLLM(), None, interpretation=interp)
    out = d.step(None)
    assert out["clarify"]["dimension"] == "指标口径"


def test_reject_once_triggers_revision_then_undecided():
    interp = make_interp(user_reqs=[("指标口径", "business_scope", ["销售额", "数量"])])
    d = DialogManager("s4", "最佳员工是谁？", StubLLM(), None, interpretation=interp)
    first = d.step(None)
    # 第一次「都不是」：触发一次候选修正，仍开放该维度
    out = d.step("都不是")
    assert out["need_clarify"] is True, "一次全拒绝后应重新给候选再问"
    # 再次全拒绝：进未决状态，不当作已解决
    out2 = d.step("都不是")
    assert out2["need_clarify"] is False
    assert out2["final_ready"] is False
    assert out2["status"] in ("undecided", "budget_exhausted")


def test_no_default_on_full_reject():
    """全拒绝后不得默认第一个候选为确认值（CLEAR 反馈规则）。"""
    interp = make_interp(user_reqs=[("指标口径", "business_scope", ["销售额", "数量"])])
    d = DialogManager("s5", "最佳员工是谁？", StubLLM(), None, interpretation=interp)
    d.step(None)
    out = d.step("都不是")
    out2 = d.step("都不是")
    # 两次拒绝后：该维度没有落任何确认值
    assert not any(s.get("dimension") == "指标口径" for s in out2["confirmed"].values())


def test_free_text_reply_confirmed():
    interp = make_interp(user_reqs=[("时间范围", "business_scope", ["2008年", "2009年"])])
    d = DialogManager("s6", "增长率", StubLLM(), None, interpretation=interp)
    out = d.step(None)
    out2 = d.step("2007 到 2008")  # 自由填写，不在选项里
    assert out2["final_ready"] is True
    slot = list(out2["confirmed"].values())[0]
    assert slot["free_text"] is True and slot["value"] == "2007 到 2008"


def test_budget_exhausted_reported_not_ready():
    interp = make_interp(user_reqs=[(f"d{i}", "business_scope", ["A", "B"]) for i in range(4)])
    d = DialogManager("s7", "多重口径", StubLLM(), None, interpretation=interp)
    # 预算 3 轮：依次答完 3 个维度后第 4 个无法再问
    for i in range(3):
        out = d.step(None if i == 0 else "A")
        assert out["need_clarify"]
    out = d.step("A")
    assert out["need_clarify"] is False
    assert out["final_ready"] is False
    assert out["status"] == "budget_exhausted"
