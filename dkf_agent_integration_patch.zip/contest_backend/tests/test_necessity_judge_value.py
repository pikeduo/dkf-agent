# -*- coding: utf-8 -*-
"""NecessityJudge 价值评分（INTENT-SIM 确定性近似）离线测试。"""
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

from backend.agents.task3_clarification.necessity_judge import NecessityJudge
from backend.core.state_manager import DialogState


@pytest.fixture
def judge():
    return NecessityJudge(DialogState(session_id="s", original_question="q"))


def test_conflict_ranks_higher_than_column_ambiguity(judge):
    conflict = {"kind": "business_scope", "status": "conflict", "dimension": "口径", "supported": True,
                "answer_changes": True,
                "candidates": ["含税", "不含税"], "source": "intent"}
    col = {"kind": "column_ambiguity", "dimension": "金额",
           "candidates": ["a", "b"], "source": "schema"}
    out = judge.rank([col, conflict])
    assert out[0]["dimension"] == "口径", "conflict 结果影响更大，应排前"
    assert len(out) == 1, "裸schema多命中不构成已支持歧义"
    assert out[0]["value_score"] > judge.value_score(col)


def test_more_candidates_raise_value(judge):
    few = {"kind": "parameter", "dimension": "d", "candidates": ["1", "2"]}
    many = {"kind": "parameter", "dimension": "d2",
            "candidates": ["1", "2", "3", "4", "5"]}
    assert judge.value_score(many) > judge.value_score(few)


def test_rank_is_deterministic(judge):
    dims = [{"kind": "parameter", "dimension": "z", "candidates": ["a", "b"]},
            {"kind": "parameter", "dimension": "a", "candidates": ["c", "d"]}]
    r1 = [d["dimension"] for d in judge.rank(list(dims))]
    r2 = [d["dimension"] for d in judge.rank(list(dims))]
    assert r1 == r2


def test_confirmed_dimension_not_asked(judge):
    dim = {"kind": "parameter", "dimension": "t", "candidates": ["x", "y"], "source": ""}
    # 去重键 = dimension:source，与该维度键一致时确认即生效
    judge.state.confirm("t:", {"dimension": "t", "value": "1", "confirmed": True})
    assert judge.should_clarify(dim) is False
