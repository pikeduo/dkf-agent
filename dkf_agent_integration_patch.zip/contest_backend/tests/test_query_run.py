"""受控执行入口的离线集成测试；协议夹具不代表真实数据集成绩。"""
import copy

import pytest
from fastapi.testclient import TestClient

from backend.api.query import get_intent_service, get_workflow_service, get_history_selector
from backend.core.history.selector import HistorySelector
from backend.core.intent.service import IntentService
from backend.core.workflow import WorkflowService
from backend.main import app
from tests.test_intent import formula_case, StubClient


@pytest.fixture
def api():
    question, payload = formula_case()
    model = StubClient(copy.deepcopy(payload))
    app.dependency_overrides[get_intent_service] = lambda: IntentService(model)
    app.dependency_overrides[get_workflow_service] = lambda: WorkflowService(model)
    app.dependency_overrides[get_history_selector] = lambda: HistorySelector()
    try:
        with TestClient(app) as client:
            yield client, model, question, payload
    finally:
        app.dependency_overrides.clear()


def test_execution_does_not_change_intent_only_contract(api):
    client, model, question, _ = api
    old = client.post("/api/query/intent", json={"question": question}).json()
    assert old["stage"] == "intent_ready" and old["answer"] is None
    executed = client.post("/api/query/run", json={"question": question}).json()
    assert executed["ok"] and executed["stage"] == "answered"
    assert executed["execution_performed"] and executed["answer_ready"]
    assert executed["calculation"]["result"] == 6
    assert not executed["intent"]["execution_performed"]
    assert executed["citations"] and "6" in executed["answer"]
    assert model.calls == 2


def test_missing_parameter_never_executes(api):
    client, model, question, payload = api
    question = question.replace("，a=3 m/s²", "")
    model.payload = copy.deepcopy(payload)
    model.payload["facts"].pop()
    result = client.post("/api/query/run", json={"question": question}).json()
    assert result["ok"] and result["stage"] == "needs_user"
    assert not result["execution_performed"] and not result["answer_ready"]
    assert "a" in result["answer"]


def test_unsupported_formula_is_blocked_not_executed(api):
    client, model, _, payload = api
    formula = "F=__import__('os').system('never-run')"
    model.payload = copy.deepcopy(payload)
    model.payload["formulas"][0]["source"]["quote"] = formula
    model.payload["facts"] = []
    result = client.post("/api/query/run", json={"question": formula}).json()
    assert result["stage"] == "blocked"
    assert not result["execution_performed"] and not result["answer_ready"]


def test_multiple_goals_are_not_claimed_as_complete(api):
    client, model, question, payload = api
    model.payload = copy.deepcopy(payload)
    model.payload["goals"].append({"id": "g2", "operation": "query", "description": "查询客户"})
    result = client.post("/api/query/run", json={"question": question + "，再查询客户。"}).json()
    assert result["stage"] == "blocked" and not result["answer_ready"]


def test_sql_results_return_through_same_answer_endpoint(api):
    client, model, _, _ = api
    model.payload = {"goals": [{"id": "g1", "operation": "query", "description": "查询客户数量"}],
                     "facts": [], "formulas": [], "requirements": []}
    calls = []
    class Pipeline:
        def run(self, database, sub_db, question):
            calls.append((database, sub_db, question))
            return {"ok": True, "stage": "executed", "sql": "SELECT COUNT(*) FROM customer",
                    "columns": ["count"], "rows": [[59]], "tables": ["customer"]}
    app.dependency_overrides[get_workflow_service] = lambda: WorkflowService(model, pipeline_factory=Pipeline)
    result = client.post("/api/query/run", json={"question": "客户数量是多少？", "database": "chinook"}).json()
    assert result["stage"] == "answered" and result["rows"] == [[59]]
    assert "59" in result["answer"] and len(calls) == 1
    assert calls[0][:2] == ("chinook", None)


def test_unresolved_user_condition_blocks_retrieval_execution():
    from backend.core.intent.contracts import Interpretation, IntentResult, Decision
    draft = Interpretation.model_validate({
        "goals": [{"id": "g1", "operation": "query", "description": "查询"}],
        "requirements": [{"id": "r1", "goal_id": "g1", "kind": "business_scope",
                          "description": "请确认统计口径", "status": "conflict", "resolver": "user",
                          "candidates": ["数量", "金额"]}]
    })
    intent = IntentResult(ok=True, stage="intent_ready", trace_id="unit", interpretation=draft,
                          decision=Decision(action="RETRIEVE", target="source_discovery", message="获取数据"))
    def forbidden():
        raise AssertionError("未确认口径不允许构造执行器")
    result = WorkflowService(None, pipeline_factory=forbidden).run(intent, "查询", database="chinook")
    assert result["stage"] == "needs_user" and not result["execution_performed"]


def test_missing_document_evidence_cannot_be_answer_ready(api):
    client, model, _, _ = api
    model.payload = {"goals": [{"id": "g1", "operation": "explain", "description": "解释条款"}],
                     "facts": [], "formulas": [], "requirements": []}
    class Retriever:
        def retrieve(self, *args, **kwargs):
            return []
    app.dependency_overrides[get_workflow_service] = lambda: WorkflowService(model, retriever_factory=Retriever)
    result = client.post("/api/query/run", json={"question": "解释条款", "doc_id": "unit_doc"}).json()
    assert result["stage"] == "blocked" and not result["answer_ready"]


def test_technical_error_is_structured_and_desensitized(api):
    client, model, _, _ = api
    model.payload = {"goals": [{"id": "g1", "operation": "query", "description": "查询客户"}],
                     "facts": [], "formulas": [], "requirements": []}
    def broken():
        raise RuntimeError("private-password http://private-provider")
    app.dependency_overrides[get_workflow_service] = lambda: WorkflowService(model, pipeline_factory=broken)
    response = client.post("/api/query/run", json={"question": "查询客户", "database": "chinook"})
    assert response.status_code == 200
    assert not response.json()["ok"] and response.json()["stage"] == "execution_failed"
    assert "private-password" not in response.text and "private-provider" not in response.text
