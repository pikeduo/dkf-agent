"""
数据接入协议层单元测试。

不依赖运行中的 PostgreSQL：
- 关系型：mock _conn 返回假连接/游标，验证路由与校验逻辑
- 向量  ：mock 嵌入函数与 _conn，验证检索链路
- 注册表：临时 JSON 文件（pytest tmp_path，跑完自动清理）
"""
import json
from unittest import mock

import pytest

from backend.data_access.protocol import DataQuery, DataResponse
from backend.data_access.relational import RelationalSource
from backend.data_access.vector import VectorSource
from backend.data_access.registry import SourceRegistry
from backend.data_access.manager import DataAccessManager


# ---------------------------------------------------------------------------
# DataQuery 协议测试
# ---------------------------------------------------------------------------
class TestDataQuery:
    def test_structured_mode(self):
        q = DataQuery(sql="SELECT 1")
        assert q.is_structured()
        assert not q.is_vector()

    def test_vector_mode(self):
        q = DataQuery(query_text="合同违约金")
        assert q.is_vector()
        assert not q.is_structured()

    def test_neither_mode(self):
        q = DataQuery()
        assert not q.is_structured()
        assert not q.is_vector()


# ---------------------------------------------------------------------------
# RelationalSource 测试
# ---------------------------------------------------------------------------
class TestRelationalSource:
    def test_validate_select_only_accepts_select(self):
        assert RelationalSource._validate_select_only("SELECT * FROM album")
        assert RelationalSource._validate_select_only(
            "SELECT COUNT(*) FROM invoice WHERE Total > 100"
        )

    def test_validate_rejects_dml(self):
        assert not RelationalSource._validate_select_only("DELETE FROM album")
        assert not RelationalSource._validate_select_only("DROP TABLE album")
        assert not RelationalSource._validate_select_only("UPDATE employee SET name='x'")

    def test_execute_rejects_non_select(self):
        src = RelationalSource(source_id="chinook", database_url="postgresql://u:p@h/db")
        resp = src.execute_sql("DELETE FROM album")
        assert not resp.ok
        assert "非只读" in resp.error
        assert resp.source_type == "relational"
        assert resp.db_id == "chinook"

    def test_execute_sql_success_path(self):
        """mock 连接与游标，验证成功路径返回结构化结果。"""
        src = RelationalSource(source_id="chinook", database_url="postgresql://u:p@h/db")
        fake_cur = mock.MagicMock()
        fake_cur.description = [("ArtistId", None), ("Title", None)]
        fake_cur.fetchall.return_value = []
        fake_cur.fetchmany.return_value = [(1, "Nevermind")]
        fake_conn = mock.MagicMock()
        fake_conn.cursor.return_value.__enter__.return_value = fake_cur
        fake_conn.__enter__.return_value = fake_conn

        with mock.patch.object(src, "_conn", return_value=fake_conn):
            resp = src.execute_sql("SELECT ArtistId, Title FROM album LIMIT 1")
        assert resp.ok
        assert resp.columns == ["ArtistId", "Title"]
        assert resp.rows == [[1, "Nevermind"]]
        assert resp.row_count == 1
        assert not resp.truncated
        # 执行前会把裸表名显式限定为 schema-qualified 形式（prepare_sql 行为）。
        assert '"public"."album"' in resp.executed_sql
        assert resp.executed_sql.startswith("SELECT ArtistId, Title FROM")

    def test_execute_db_error_returns_failure(self):
        src = RelationalSource(source_id="chinook", database_url="postgresql://u:p@h/db")
        import psycopg2

        fake_conn = mock.MagicMock()
        cur_cm = mock.MagicMock()
        cur_cm.__enter__.side_effect = psycopg2.OperationalError("connection refused")
        fake_conn.cursor.return_value = cur_cm
        fake_conn.__enter__.return_value = fake_conn

        with mock.patch.object(src, "_conn", return_value=fake_conn):
            resp = src.execute_sql("SELECT 1")
        assert not resp.ok
        assert "SQL 执行失败" in resp.error


# ---------------------------------------------------------------------------
# VectorSource 测试
# ---------------------------------------------------------------------------
class TestVectorSource:
    @staticmethod
    def _fake_embedder(text: str):
        """确定性假嵌入：取文本长度作为向量各分量。"""
        return [len(text)] * 4

    def test_search_without_embedder_fails(self):
        src = VectorSource(source_id="ohr_bench", embedder=None,
                           database_url="postgresql://u:p@h/db")
        resp = src.search("合同违约金")
        assert not resp.ok
        assert "embedder" in resp.error

    def test_search_success_path(self):
        src = VectorSource(source_id="ohr_bench", embedder=self._fake_embedder,
                           database_url="postgresql://u:p@h/db")
        fake_row = {
            "doc_id": "law_agreement_001",
            "physical_page": 3,
            "text": "违约金按合同金额 10% 计算",
            "source_bbox": None,
            "distance": 0.12,
        }
        fake_cur = mock.MagicMock()
        fake_cur.fetchall.return_value = [fake_row]
        fake_conn = mock.MagicMock()
        fake_conn.cursor.return_value.__enter__.return_value = fake_cur
        fake_conn.__enter__.return_value = fake_conn

        with mock.patch.object(src, "_conn", return_value=fake_conn):
            resp = src.search("违约金怎么算", top_k=3, doc_id=None)
        assert resp.ok
        assert resp.source_type == "vector"
        assert len(resp.hits) == 1
        assert resp.hits[0]["doc_id"] == "law_agreement_001"
        assert resp.hits[0]["distance"] == 0.12

    def test_citation_for_vector(self):
        resp = DataResponse(
            ok=True,
            source_type="vector",
            db_id="ohr_bench",
            hits=[{"doc_id": "a"}, {"doc_id": "b"}],
        )
        cite = resp.to_citation()
        assert cite["type"] == "vector"
        assert cite["doc_ids"] == ["a", "b"]

    def test_citation_for_sql(self):
        resp = DataResponse(
            ok=True,
            source_type="relational",
            db_id="chinook",
            executed_sql="SELECT 1",
            row_count=1,
        )
        cite = resp.to_citation()
        assert cite["type"] == "sql"
        assert cite["db_id"] == "chinook"


# ---------------------------------------------------------------------------
# SourceRegistry 测试
# ---------------------------------------------------------------------------
class TestSourceRegistry:
    def test_load_from_json(self, tmp_path):
        """临时注册表 JSON，验证关系型数据源批量创建。"""
        reg_file = tmp_path / "databases.json"
        reg_file.write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "databases": [
                        {
                            "db_id": "chinook",
                            "engine": "postgresql",
                            "database_url": "postgresql://u:p@h/chinook",
                        },
                        {
                            "db_id": "bird",
                            "engine": "postgresql",
                            "database_url": "postgresql://u:p@h/bird",
                        },
                        {"db_id": "no_url", "engine": "postgresql"},
                    ],
                }
            ),
            encoding="utf-8",
        )
        reg = SourceRegistry.load_from_json(str(reg_file))
        assert "chinook" in reg.source_ids
        assert "bird" in reg.source_ids
        # 无 database_url 的条目应被跳过
        assert "no_url" not in reg.source_ids
        assert reg.get_relational("chinook") is not None
        assert reg.get_vector("chinook") is None


# ---------------------------------------------------------------------------
# DataAccessManager 测试
# ---------------------------------------------------------------------------
class TestManagerRouting:
    @staticmethod
    def _make_manager() -> DataAccessManager:
        """构造含假数据源的 Manager，验证路由逻辑（不碰真实数据库）。"""
        reg = SourceRegistry()

        class _FakeRel:
            source_id = "chinook"
            source_type = "relational"

            def execute_sql(self, sql):
                return DataResponse(
                    ok=True, source_type="relational", db_id="chinook",
                    executed_sql=sql,
                )

            def ping(self):
                return True

            def close(self):
                pass

        reg.register_relational(_FakeRel())  # type: ignore[arg-type]

        class _FakeVec:
            source_id = "ohr_bench"
            source_type = "vector"

            def search(self, query_text, top_k=5, doc_id=None):
                return DataResponse(ok=True, source_type="vector", db_id="ohr_bench")

            def ping(self):
                return True

            def close(self):
                pass

        reg.register_vector(_FakeVec())  # type: ignore[arg-type]
        return DataAccessManager(reg, primary_relational="chinook", primary_vector="ohr_bench")

    def test_structured_routes_to_relational(self):
        m = self._make_manager()
        resp = m.query(DataQuery(sql="SELECT 1"))
        assert resp.ok
        assert resp.source_type == "relational"

    def test_vector_routes_to_vector_source(self):
        m = self._make_manager()
        resp = m.query(DataQuery(query_text="销售额"))
        assert resp.ok
        assert resp.source_type == "vector"

    def test_unknown_relational_target_errors(self):
        m = self._make_manager()
        resp = m.query(DataQuery(sql="SELECT 1", target="not_registered"))
        assert not resp.ok
        assert "未注册" in resp.error

    def test_empty_query_errors(self):
        m = self._make_manager()
        resp = m.query(DataQuery())
        assert not resp.ok
        assert "必须提供" in resp.error
