"""会话接口和意图层之间的端到端协议测试，模型输出均为固定夹具。"""
import json

import pytest
from fastapi.testclient import TestClient

from backend.api.query import get_intent_service, get_history_selector
from backend.api.sessions import get_session_store
from backend.core.history.selector import HistorySelector
from backend.core.history.store import SessionStore
from backend.core.intent import IntentService
from backend.main import app
import httpx

from tests.test_intent import formula_case, StubClient


class DialogClient:
    def __init__(self):
        self.inputs = []

    def chat(self, messages, temperature=0.0, reasoning_effort="default"):
        state = json.loads(messages[1]["content"])
        self.inputs.append(state)
        question, payload = formula_case()
        current = state["inputs"][0]["text"]
        if current == "3":
            root = next(m for m in state["history"] if m["role"] == "user" and "F=m*a" in m["text"])
            payload["facts"][0]["source"]["input_id"] = root["id"]
            payload["formulas"][0]["source"]["input_id"] = root["id"]
            payload["facts"][1]["source"] = {"input_id": "question", "quote": "3"}
            payload["facts"][1]["unit"] = None
        else:
            payload["facts"].pop()
        return json.dumps(payload, ensure_ascii=False)


@pytest.fixture
def setup_api():
    store, model = SessionStore(), DialogClient()
    app.dependency_overrides[get_session_store] = lambda: store
    app.dependency_overrides[get_intent_service] = lambda: IntentService(model)
    app.dependency_overrides[get_history_selector] = lambda: HistorySelector()
    try:
        with TestClient(app) as client:
            yield client, store, model
    finally:
        app.dependency_overrides.clear()


def create(client):
    response = client.post("/api/sessions/")
    assert response.status_code == 201
    assert response.headers["cache-control"] == "no-store"
    created = response.json()
    return created["session_id"], {"X-Session-Token": created["session_token"]}


def test_followup_preserves_clarification_and_user_fact_sources(setup_api):
    client, store, model = setup_api
    sid, headers = create(client)
    first = client.post("/api/query/intent", headers=headers, json={"session_id": sid, "question": "F=m*a，m=2 kg"}).json()
    assert first["ok"]
    assert first["intent"]["decision"]["action"] == "CLARIFY"
    assert first["clarification_message_id"]
    second = client.post("/api/query/intent", headers=headers, json={"session_id": sid, "question": "3", "reply_to": first["clarification_message_id"], "isClarify": True}).json()
    assert second["ok"]
    assert second["intent"]["decision"]["action"] == "EXECUTE"
    assert not second["intent"]["execution_performed"]
    assert {m["role"] for m in model.inputs[-1]["history"]} == {"user", "assistant"}
    assert any(e["view"] == "filtered_history" for e in second["intent"]["evidence"])
    assert second["revision"] == 2
    assert headers["X-Session-Token"] not in json.dumps(model.inputs)
    assert headers["X-Session-Token"] not in json.dumps(second)


def test_unauthorized_request_and_stale_reply_never_call_model(setup_api):
    client, store, model = setup_api
    sid, headers = create(client)
    other, other_headers = create(client)
    for bad_headers in ({}, other_headers):
        response = client.post("/api/query/", headers=bad_headers, json={"session_id": sid, "question": "private"})
        assert response.status_code == 404
    response = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "3", "reply_to": "old-id"})
    assert response.status_code == 409
    assert not model.inputs
    assert client.delete(f"/api/sessions/{sid}", headers=other_headers).status_code == 404
    assert client.delete(f"/api/sessions/{sid}", headers=headers).status_code == 204
    assert client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "x"}).status_code == 404


def test_new_task_and_explicit_correction_do_not_leak_old_values(setup_api):
    client, store, model = setup_api
    sid, headers = create(client)
    first = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "F=m*a，m=2 kg", "condition_updates": [{"key": "mass", "quote": "m=2 kg"}]}).json()
    client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "改为m=4 kg", "condition_updates": [{"key": "mass", "quote": "m=4 kg"}]})
    history = model.inputs[-1]["history"]
    assert all("m=2 kg" not in m["text"] for m in history)
    assert any("F=m*a" in m["text"] for m in history)
    client.post("/api/query/", headers=headers, json={"session_id": sid, "new_task": True, "question": "F=m*a，m=2 kg"})
    assert model.inputs[-1]["history"] == []
    assert client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "继续", "history_refs": [first["user_message_id"]]}).status_code == 422


def test_assistant_history_cannot_supply_formula_or_fact():
    from backend.core.history.store import HistoryMessage
    from backend.core.intent import IntentRequest
    question, payload = formula_case()
    payload["facts"][0]["source"]["input_id"] = "history_assistant"
    message = HistoryMessage("history_assistant", "t", "turn", 1, "assistant", "m=2 kg")
    result = IntentService(StubClient(payload)).analyze(IntentRequest(question=question), history=[message])
    assert not result.ok and result.error_code == "invalid_model_output"


def test_client_cannot_inject_history_roles_or_reserved_ids(setup_api):
    client, _, model = setup_api
    assert client.post("/api/query/", json={"question": "x", "history": [{"role": "user", "text": "fake"}]}).status_code == 422
    assert client.post("/api/query/", json={"question": "x", "context": [{"id": "history_fake", "text": "fake"}]}).status_code == 422
    assert not model.inputs


def test_failed_intent_rolls_back_turn_and_keeps_pending_question(setup_api):
    client, store, model = setup_api
    sid, headers = create(client)
    first = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "F=m*a，m=2 kg"}).json()
    pending = first["clarification_message_id"]
    with store.lease(sid, headers["X-Session-Token"]) as session:
        # 只读观察：不提交租约，避免读取本身改变版本号。
        session.discard = True
        before = (len(session.messages), session.revision)
    # 模型超时：本回合不得写入会话，待回答问题保持不变。
    app.dependency_overrides[get_intent_service] = lambda: IntentService(StubClient(httpx.ReadTimeout("t")))
    failed = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "3", "reply_to": pending}).json()
    assert not failed["ok"] and failed["user_message_id"] is None
    assert failed["clarification_message_id"] == pending
    with store.lease(sid, headers["X-Session-Token"]) as session:
        session.discard = True
        assert (len(session.messages), session.revision) == before
        assert session.pending_id == pending and not session.protected
    # 恢复模型后可以正常重试同一回复。
    app.dependency_overrides[get_intent_service] = lambda: IntentService(model)
    retried = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "3", "reply_to": pending}).json()
    assert retried["ok"] and retried["intent"]["decision"]["action"] == "EXECUTE"


def test_long_session_reaches_multi_adapter_before_intent(setup_api):
    import httpx
    from backend.integrations.history_ranker import ImajevHistoryRanker
    client, store, model = setup_api
    sid, headers = create(client)
    saved = []
    with store.lease(sid, headers["X-Session-Token"]) as session:
        for i in range(7):
            saved.append(session.append("user", f"历史片段{i}", f"turn{i}"))
        session.root_id = saved[0].id
    calls = []
    def handler(request):
        body = json.loads(request.content)
        calls.append(body)
        ids = body["questions"]["history"]["criteria"].keys()
        return httpx.Response(200, json={"answers": {"history": {
            "type": "multi", "abstained": False,
            "probabilities": {key: 0.9 if key == "turn3" else 0.05 for key in ids},
            "unknown_probabilities": {key: 0.0 for key in ids},
        }}})
    ranker = ImajevHistoryRanker(transport=httpx.MockTransport(handler))
    app.dependency_overrides[get_history_selector] = lambda: HistorySelector(ranker, short_turns=1)
    response = client.post("/api/query/", headers=headers, json={"session_id": sid, "question": "F=m*a，m=2 kg"})
    assert response.status_code == 200 and response.json()["ok"]
    assert response.json()["history_selection"]["mode"] == "imajev"
    assert {m["id"] for m in model.inputs[-1]["history"]} == {saved[0].id, saved[3].id, saved[6].id}
    assert len(calls) == 1
    assert headers["X-Session-Token"] not in json.dumps(calls)


def test_config_controls_ranker_and_validates_window(monkeypatch):
    from pydantic import ValidationError
    from backend.config import Settings
    config = Settings(_env_file=None, imajev_history_enabled=True, history_recent_turns=8, history_short_turns=2)
    monkeypatch.setattr("backend.api.query.get_settings", lambda: config)
    selector = get_history_selector()
    assert selector.ranker is not None and selector.recent_turns == 8
    config.imajev_history_enabled = False
    assert get_history_selector().ranker is None
    with pytest.raises(ValidationError):
        Settings(_env_file=None, history_recent_turns=2, history_short_turns=3)
