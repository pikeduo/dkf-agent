"""任务6安全单元夹具，不属于真实数据集成绩；全程无网络、模型和文件输出。"""
import ast
import json
import math

import pytest

from backend.agents.task6_formula.formula_spec import FormulaSpec, parse_formula, spec_from_user_formula
from backend.agents.task6_formula.numeric_units import FormulaError, parse_real, parse_unit, quantity_from_raw
from backend.agents.task6_formula.param_finder import ParamFinder
from backend.agents.task6_formula.safe_calculator import SafeCalculator


@pytest.mark.parametrize("text,expected", [("1.68×10²³", 1.68e23), ("10⁻³", .001),
    ("8.0*10^{7}", 8e7), ("-.5", -.5), ("1,234.56", 1234.56), ("1e-3", .001)])
def test_complete_scientific_number(text, expected):
    assert parse_real(text) == pytest.approx(expected)


@pytest.mark.parametrize("value", [True, False, None, complex(1, 1), float("nan"), float("inf"),
    "NaN", "inf", "10x3600", "10*3600", "1,2", "10 apples", "约10", "1e101", "1e-1000", "9" * 200])
def test_invalid_number_rejected(value):
    with pytest.raises(FormulaError):
        parse_real(value)


@pytest.mark.parametrize("formula", ["y=m[0]+1", "x=x+1", "[x]=[x]+1", "x=y=1", "[y]=[x]+_v2",
    "x=1±2", "x≈2", "x=m.x", "x=__import__('os')", "x=(lambda:1)()", "x=[1,2]",
    "x=abs(-1, bogus=2)", "x=sum(1,2)", "x=sqrt(1,2)", "x=1;2", "x=True", "x=1e309",
    "x=2**1000", "x=" + "(" * 80 + "1" + ")" * 80 + "+" + "+1" * 300])
def test_unified_parser_rejects_unsupported(formula):
    assert spec_from_user_formula(formula).parse_status == "parse_error"
    assert parse_formula(formula)[0] == "parse_error"


def test_repeated_placeholder_and_named_binding():
    spec = spec_from_user_formula("[y]=[x]+[x]")
    assert spec.input_symbols == ["_v2"]
    assert spec.resolve_symbol("x") == spec.resolve_symbol("_v2")
    assert SafeCalculator().compute_spec(spec, {"x": 3})["result"] == 6
    mixed = spec_from_user_formula("[y]=[x]+x")
    assert SafeCalculator().compute_spec(mixed, {"x": 3})["result"] == 6


def test_conflicting_aliases_and_binding_structure():
    spec = spec_from_user_formula("[y]=[x]+1")
    assert SafeCalculator().compute_spec(spec, {"x": 1, "_v2": 2})["check_failed"] == "ambiguous_binding"
    for bindings in (None, [], {1: 3}):
        assert SafeCalculator().compute_spec(spec, bindings)["check_failed"] == "invalid_binding"


def test_forged_or_mutated_ast_rechecked():
    forged = FormulaSpec("bad", "1", parse_status="ok", ast_tree=ast.Constant(value="text"))
    assert SafeCalculator().compute_spec(forged, {})["ok"] is False
    mutated = spec_from_user_formula("y=1+2")
    mutated.ast_tree = ast.Constant(value=7)
    assert SafeCalculator().compute_spec(mutated, {})["check_failed"] == "ast_mismatch"


@pytest.mark.parametrize("bindings", [{"a": True}, {"a": "nan"}, {"a": "inf"}, {"a": "bad"},
    {"a": {"raw_value": None}}, {"a": {"normalized_value": 1}}, {"a": complex(1, 1)}])
def test_binding_failures_are_structured(bindings):
    out = SafeCalculator().compute("a+1", bindings)
    assert out["ok"] is False and out["result"] is None and out["check_failed"]
    json.dumps(out, allow_nan=False)


def test_none_normalized_falls_back_to_raw():
    out = SafeCalculator().compute("a+1", {"a": {"raw_value": 2, "normalized_value": None}})
    assert out["ok"] and out["result"] == 3


def test_constant_expression_actual_denominator_floor_and_mod():
    calculator = SafeCalculator()
    assert calculator.compute("2+3", {})["result"] == 5
    assert calculator.compute("a/(b-c)", {"a": 2, "b": 0, "c": 1})["result"] == -2
    assert calculator.compute("a/(b-c)", {"a": 2, "b": 1, "c": 1})["check_failed"] == "divide_by_zero"
    assert calculator.compute("a//b", {"a": 5, "b": 2})["result"] == 2
    assert calculator.compute("a%b", {"a": 5, "b": 2})["result"] == 1


@pytest.mark.parametrize("formula,code", [("2**(10**9)", "resource_limit"),
    ("(-1)**.5", "domain_error"), ("sqrt(-1)", "domain_error"),
    ("0**-1", "divide_by_zero"), ("round(1,2.5)", "domain_error"),
    ("1e100*1e100", "resource_limit")])
def test_execution_budgets_and_domains(formula, code):
    assert SafeCalculator().compute(formula, {})["check_failed"] == code


def test_derived_dimensions_and_requested_conversion():
    calculator = SafeCalculator()
    force = calculator.compute("F=m*a", {"m": {"raw_value": 2, "unit": "kg"},
        "a": {"raw_value": 3, "unit": "m/s²"}}, "N")
    assert force["ok"] and force["result"] == 6 and force["unit"] == "N"
    speed = calculator.compute("v", {"v": {"raw_value": 72, "unit": "km/h"}}, "m/s")
    assert speed["result"] == 20
    energy = calculator.compute("q*m", {"q": {"raw_value": 8e7, "unit": "J/kg"},
        "m": {"raw_value": .21, "unit": "kg"}}, "J")
    assert energy["result"] == pytest.approx(1.68e7)
    assert energy["trace"][0]["operation"] == "Mult"


def test_unit_addition_missing_incompatible_unknown_and_currency():
    calculator = SafeCalculator()
    assert calculator.compute("a+b", {"a": {"raw_value": 1, "unit": "m"},
        "b": {"raw_value": 100, "unit": "cm"}}, "m")["result"] == 2
    assert calculator.compute("a+1", {"a": {"raw_value": 2, "unit": "kg"}}, "m")["check_failed"] == "unit_mismatch"
    assert calculator.compute("a*b", {"a": {"raw_value": 2, "unit": "m"}, "b": 3})["check_failed"] == "missing_unit"
    assert calculator.compute("a", {"a": {"raw_value": 2, "unit": "mystery"}})["check_failed"] == "unsupported_unit"
    assert calculator.compute("a+b", {"a": {"raw_value": 2, "unit": "CNY"},
        "b": {"raw_value": 3, "unit": "USD"}})["check_failed"] == "unit_mismatch"
    assert calculator.compute("3", {}, "m")["check_failed"] == "unit_mismatch"


def test_percent_display_and_explicit_scaled_formula():
    spec = spec_from_user_formula("(1200-1000)/1000")
    spec.display = "percent"
    out = SafeCalculator().compute_spec(spec, {})
    assert out["result"] == pytest.approx(.2) and out["display_value"] == "20%"
    spec = spec_from_user_formula("(1200-1000)/1000*100")
    spec.display = "percent"
    assert SafeCalculator().compute_spec(spec, {})["check_failed"] == "ambiguous_representation"
    spec.output_representation = "percent_number"
    out = SafeCalculator().compute_spec(spec, {})
    assert out["result"] == pytest.approx(.2) and out["display_value"] == "20%"
    assert quantity_from_raw(36, "%").value == pytest.approx(.36)


def test_bare_celsius_fahrenheit_rejected_as_ambiguous_temperature():
    # 裸摄氏/华氏温标（含中文别名）默认含糊，一律拒绝，不按温差默认处理。
    calculator = SafeCalculator()
    for unit in ("℃", "°C", "℉", "°F", "摄氏", "华氏"):
        out = calculator.compute("a", {"a": {"raw_value": 20, "unit": unit}})
        assert out["ok"] is False and out["check_failed"] == "unsupported_unit", unit
    # 绝对温度换算到 K 无参考零点，走拒绝路径而不是 293.15
    with pytest.raises(FormulaError) as exc:
        parse_unit("℃")
    assert exc.value.code == "unsupported_unit"
    # 摄氏/华氏混合无论是否授权温差仍拒绝
    with pytest.raises(FormulaError):
        parse_unit("Δ°C/Δ°F")
    # 转数单位 r 本轮整体不支持（词典与期望输出边界均拒绝）
    with pytest.raises(FormulaError) as exc2:
        parse_unit("r")
    assert exc2.value.code == "unsupported_unit"
    out = calculator.compute("a*b", {"a": {"raw_value": 2, "unit": "rad/s"}, "b": {"raw_value": 6, "unit": "s"}}, "r")
    assert out["ok"] is False and out["check_failed"] == "unsupported_unit"


def test_explicit_temperature_difference_is_parsed_as_kelvin():
    # 显式温差记号（Δ/delta 前缀）或 quantity_kind='temperature_difference' 才允许按 K 规范。
    assert parse_unit("Δ°C").dimensions == parse_unit("K").dimensions
    assert parse_unit("delta°F").dimensions == parse_unit("K").dimensions
    assert parse_unit("J/(kg·Δ°C)").dimensions == parse_unit("J/(kg·K)").dimensions
    assert quantity_from_raw(18, "°F", "temperature_difference").value == pytest.approx(10)
    assert quantity_from_raw(18, "Δ°F").value == pytest.approx(10)
    # 复合温差单位仅在裸温标均获显式授权时支持，复合乘号别名（·/⋅/•）可解析
    assert quantity_from_raw(4, "J/(kg⋅Δ℃)").dimensions == parse_unit("J/(kg·K)").dimensions


def test_bad_temperature_prefix_still_rejected():
    # 近似前缀（xΔ°C、deltafoo°C 等）不能借温差标记绕过歧义拒绝
    for unit in ("xΔ°C", "deltafoo°C", "5Δ°C", "kgΔ°C"):
        with pytest.raises(FormulaError):
            parse_unit(unit)
    # 内部温差 token 不接受用户直接提供，防止绕过歧义检查
    with pytest.raises(FormulaError) as exc:
        parse_unit("tdC")
    assert exc.value.code == "unsupported_unit"


def test_temperature_prefix_and_kind_may_combine():
    # 显式Δ/delta前缀与quantity_kind='temperature_difference'可单独使用，也可并用；
    # 并用时先识别并去掉合法前缀，kind仅作兜底，坏前缀仍拒绝。
    assert parse_unit("Δ°C", "temperature_difference").scale == 1.0
    assert parse_unit("J/(kg·Δ°C)", "temperature_difference").dimensions == parse_unit("J/(kg·K)").dimensions
    assert quantity_from_raw(18, "Δ°F", "temperature_difference").value == pytest.approx(10)
    for bad in ("xΔ°C", "5Δ°C"):
        with pytest.raises(FormulaError):
            parse_unit(bad, "temperature_difference")


def test_compatibility_private_unit_tokens_rejected():
    # 全角等 NFKC 兼容写法不能归一到私有内部token绕过歧义检查；成功映射仅来自原文真实温标+显式授权。
    for unit in ("tdC", "tdF", "ｔｄＣ", "ｔｄＦ"):
        with pytest.raises(FormulaError) as exc:
            parse_unit(unit)
        assert exc.value.code == "unsupported_unit"
    # 合法Δ表达式中夹带ASCII或全角兼容私有占位符（_tp数字/_t_数字）一律整体拒绝；
    # 嵌套复合单位内夹带同样拒绝。全角 ＿ｔｐ０ 经 NFKC 归一为 _tp0 后命中保留命名空间。
    fw_tp0 = "".join(chr(c) for c in (0xFF3F, 0xFF54, 0xFF70, 0xFF10))  # ＿ｔｐ０全角写法
    for unit in ("Δ°C*_tp0", "Δ°C*" + fw_tp0, "Δ°C/" + fw_tp0,
                 "J/(kg·Δ℃*_tp0)", "J/(kg·Δ℃/_t_1)"):
        with pytest.raises(FormulaError) as exc:
            parse_unit(unit)
        assert exc.value.code == "unsupported_unit", unit
    # 夹带私有token不影响合法温差通道的成功：前缀+kind并用、C/F尺度与复合温差仍成立
    assert parse_unit("Δ°C", "temperature_difference").scale == 1.0
    assert parse_unit("Δ°F").scale == pytest.approx(5 / 9)
    assert parse_unit("J/(kg·Δ°C)").dimensions == parse_unit("J/(kg·K)").dimensions


def test_non_string_expected_unit_is_structured_failure():
    # 非字符串期望单位必须走结构化受控失败，不允许裸异常漏出；转数边界继续拒绝。
    for bad in (123, ["m"]):
        out = SafeCalculator().compute("2+3", {}, bad)
        assert out["ok"] is False and out["check_failed"], bad
    for unit in ("r", "r/min", "rev", "rpm"):
        out = SafeCalculator().compute("2+3", {}, unit)
        assert out["ok"] is False and out["check_failed"] == "unsupported_unit", unit


def test_source_boundary_recomputed_normalization_and_conflict():
    finder = ParamFinder()
    assert finder.bind("f", ["x"], "", "x=142")[0]["normalized_value"] == 142
    assert finder.bind("f", ["x"], "", "y=42")[0]["status"] == "missing"
    bound = finder.bind("f", ["x"], "x=72 km/h", "")[0]
    assert bound["normalized_value"] == 20 and bound["unit"] == "km/h"
    assert bound["source"]["quote"] == "x=72 km/h"
    assert finder.bind("f", ["x"], "x=1", "x=2")[0]["status"] == "conflict"


class ProposalStub:
    """只用于离线验证候选拒绝，不调用付费模型。"""
    def __init__(self, payload):
        self.payload = json.dumps(payload)
    def chat(self, *args, **kwargs):
        return self.payload


def test_model_cannot_invent_values_units_aliases_or_sources():
    for payload, source in [({"x": {"raw_value": 42}}, "x=142"),
        ({"x": {"raw_value": 7}}, "没有数据"),
        ({"x1": {"raw_value": 7}}, "x1=7"),
        ({"x": {"raw_value": 10, "unit": "kg", "source_quote": "x=10"}}, "x=10")]:
        out = ParamFinder(ProposalStub(payload)).bind("f", ["x"], "", source)[0]
        if source == "x=142":
            assert out["normalized_value"] == 142
        elif source == "x=10":
            assert out["unit"] is None
        else:
            assert out["status"] == "missing"
    out = ParamFinder(ProposalStub({"x": {"raw_value": 999}})).bind("f", ["x"], "问题", "")[0]
    assert out["status"] == "missing"
