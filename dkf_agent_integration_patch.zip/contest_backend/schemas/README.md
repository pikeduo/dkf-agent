# schemas/ 目录说明

真实 schema 结构件（只读，未执行 DB）：

- schema_index.json：任务 4 Schema 索引（1348 条表记录：chinook 11 / cosql 873 / bird 75 / dr_spider 1289，含 source_name、rows、columns）
- fk_graph.json：外键关系图（表节点 + 主外键边）
- databases.json：数据源注册表（db_id / 库名 / 引擎 / 导入文件 / schema 清单）
- *_database_mapping.json：PG 导入逐表映射（source_sha256、row_count_match）

表字段/关系的人类可读说明见 support/schema_reference.md。
数据库获取与导入（不随包提供 16GB 数据）：

| 库 | 获取 | 导入 |
| --- | --- | --- |
| chinook | data/raw/chinook（官方 PG 脚本，586KB，KB 级可自取） | psql -U $USER -d chinook -f Chinook_PostgreSql.sql |
| ict_bird（bird_native，75 表） | BIRD 作者原生 PG 包（data/raw/bird，修订 f65faf4a…；包体约 782MB） | psql -d ict_bird -f data/postgresql/bird/import_native.sql（约 1GB） |
| ict_cosql（166 schema） | CoSQL 公开镜像（约 104MB zip） | psql -d ict_cosql -f data/postgresql/cosql/import_all.sql |
| ict_adventureworks（68 表，仅决赛可选） | Microsoft 原 CSV + 第三方 PG 移植 | data/postgresql/adventureworks/import.sql |

行数核对与全量值一致性结论：见 data/postgresql/ 验证报告（本包不带）。
