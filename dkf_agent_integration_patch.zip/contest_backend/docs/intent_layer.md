# 意图层与任务3：有来源的缺口门控

## 输入与模型边界

`IntentRequest`的输入字段保持不变：`question/context/database/doc_id/trace_id`。没有增加`sub_db`，因此本轮不要求修改历史请求转发或会话持久字段。`database`可使用唯一的原始子库标识，例如`college_2`、`california_schools`；`chinook`保留单库兼容。`cosql`或`bird`聚合标识不能冒充一套业务库，目录无法唯一解析时在模型调用前失败闭合。

`SchemaContextProvider.resolve(database)`逐一使用任务4的`SchemaIndex.load(dataset, sub_db=原始标识)`查找唯一作用域，不解析schema哈希、不先加载整合873张表，也不修改静态索引。显式作用域调用方可用`load_scope(dataset, sub_db)`，然后把返回的可信对象通过`IntentService.analyze(..., schema_context=context)`交入；该参数只对服务器代码开放，不是客户端可写字段。

模型用户消息中的`server_schema`与`inputs/history`分区。目录只包含真实表列、作用域、版本、预算及`truncated`；没有业务别名、QA答案或SQL。`Fact.source`仍只能引用用户原文。目录被裁剪时不能证明唯一解释，也不能据此证明请求不可回答。唯一字段不能替用户决定最佳指标、比较期间或异常阈值。

`IntentResult`增加服务端生成的`schema_context`元数据，仍固定`execution_performed=false`与`answer_ready=false`。模型异常继续使用`intent_failed/STOP`；目录错误使用`schema_scope_required/schema_scope_not_unique/schema_unavailable`等错误码，不回显路径或供应商正文。

## 统一需求分类

`policy.requirement_gap(requirement)`供意图层和任务3共同使用：

- 必要参数、未知目标、缺公式：`user_missing`，没有候选也追问。
- 有支持且会改变答案的冲突：`user_ambiguity`。
- 口径没有支持：`unsupported_ambiguity`，停止或明确证据不足，不能制造候选。
- 外部事实：`retrieve`；未读取输入：`read_input`；未知依赖：`deferred/unknown`。
- 已标明的不可满足请求与证据不足：`unanswerable/insufficient_evidence`，独立于技术失败。

`Requirement`新增可选解释字段：`gap_type/schema_refs/answer_changes/candidate_schema_refs/candidate_sources`。业务候选逐项绑定真实目录对象或包含该候选的用户原文；只引用“最佳”等触发词不足以支持任意生成的指标。模型引用的目录及用户来源由服务端再次验证。`satisfied`仍必须有真实用户事实绑定。

缺公式或只提供公式名称时询问用户提供表达式，不再创建公式卡片检索需求。只有原题本身是无变量的完整算术表达式，才能跳过缺公式追问；不能凭题面出现一个数字推断公式和参数齐全。

## 主流程的接入契约

统一导出入口：`from backend.core.intent import execution_gate, clarification_readiness, requirement_gap`。

1. 用`IntentService.analyze`获得解释。带会话时沿用现有受保护历史机制；本轮没有接入imajev。
2. 受控执行前调用`execution_gate(intent_result, question=当前原文)`。
3. 返回`ready=false`时按`status`处理：`needs_user`表示可询问的必要用户条件；`blocked`表示未解析、无证据、未知作用域或不支持；`error`表示技术失败。
4. 返回`ready=true`仅代表可以交接执行器。返回字段含`target/goal_id`，SQL路径还含真实`dataset/sub_db`。调用方继续执行SQL只读、目录授权、结果完整性或公式解析、单位与数值校验。
5. 外部`retrieval_need=needed`不能被当作SQL已经完成；执行成功、证据充分及答案准备好必须由外层工作流独立记录。

辅助函数`clarification_readiness(draft, confirmed_ids=())`返回`status/final_ready/pending_user_ids/unresolved_ids/retrieval_pending`。它的`final_ready`仅指澄清条件齐备，仍可能存在待查询的外部事实；最终执行资格必须用`execution_gate`，不能直接看`final_ready`。未支持多目标、未知目标和缺公式均不能通过执行门控。

如果`/run`显式接收数据集与子库而`/intent`仍只接收`database`，有状态后续回复应保存唯一原始子库标识，而不是只保存聚合的`bird/cosql`。否则必须由主流程为每轮重新提供相同可信`schema_context`；本轮没有改动history来隐式持久化新的字段。

## 独立澄清接口

`POST /api/clarification/`不再默认猜Chinook。省略`database`可以做文本/公式缺口澄清，但不获得SQL授权；指定`bird/cosql`却没有唯一子库时返回`ok=false/status=tool_error`，不调用模型。

每个会话持有独立目录对象和快照，稳定保存`goal_id/requirement_id/depends_on`。同名不同目标不交叉确认。缺参直接自由填写，“由我提供数值”等操作选项不成为参数值。第一次全拒绝使用尚未被否决的受支持候选，若没有新证据则转自由填写；第二次全拒绝进入`undecided`。跳过或不知道直接保留未决。

预算按真正生成的追问轮数计。重复读取同一待答问题不再次消耗轮数；无效回答再次询问会消耗轮数。默认最多3轮。`undecided/budget_exhausted/blocked/insufficient_evidence/unanswerable/tool_error`均不返回`final_ready=true`。

`rewrite`只附加结构化用户确认，不替换原问题、不删除目录列或主外键。自由填写的业务含义仍需要下一次意图分析或下游语义校验；澄清接口本身不执行计算或SQL。

## 离线测试与固定评测

全部离线测试用当前conda环境，不联网、不运行付费模型、不产生pytest缓存或字节码：

`conda run --no-capture-output -n agent python -B -m pytest -q -p no:cacheprovider tests/test_intent.py tests/test_intent_boundaries.py tests/test_task3_clarification.py tests/test_necessity_judge_value.py tests/test_task3_optimization.py tests/test_eval_clarify.py`

默认评测只构建真实样本并写指定报告，不调用模型：

`conda run --no-capture-output -n agent python -B evaluation/eval_clarify.py --split all --datasets zh cosql bird`

报告固定为`evaluation/reports/optimization_task3_20261010.json`。未调用模型时准确率、配置模型均为`null`，并标记`model_run=false`。报告包含源内容hash、样本hash、固定分区标识和样本ID；每次新运行覆盖报告，不断点混合不同提示或目录版本。

固定分区为自定义`task3-dialog-hash-v1`，不是未经验证的官方dev/test分区。debug占约20%，heldout占约80%；CoSQL同一对话不会跨分区，中文相邻成对用例也不拆分。中文原有20条标注冻结不改。

父流程明确允许真实模型调用后，分别运行下列命令，并在复核前记录报告，避免后续覆盖丢失：

- 中文debug：上述评测命令加`--datasets zh --split debug --run-model`。
- 中文heldout：加`--datasets zh --split heldout --run-model`；最终20条回归可用`--split all`。
- CoSQLdebug：加`--datasets cosql --split debug --limit 20 --run-model`。
- CoSQLheldout：加`--datasets cosql --split heldout --limit 20 --run-model`。
- CoSQL后续轮：额外加`--all-turns`；生产历史只取先前用户原文与先前澄清话语，不包括SQL、结果确认或未来回复。
- BIRD完整题对照：先由评测方审核并固定题号，再用`--datasets bird --bird-ids 题号列表 --split debug`或`heldout`；只有显式`--run-model`才调用模型。没有审核的题只参与构建统计，不被默认作为负例，也不消耗模型预算。

用户轮`AMBIGUOUS`、用户轮`CANNOT_ANSWER`与下一系统轮`CLARIFY`分别计分。多标签优先级在报告中写明，完整原生标签仍保留。所有技术失败留在主指标分母；延迟包括模型内部重试、意图解释和追问生成。HTTP额外重试完全由公共LLMClient承担，最多2次，评测不增加外层重试；客户端没有暴露实际HTTP次数时记录null，不猜次数。

`--diagnose-first-option`只诊断自动选择首项后的状态机推进；仅`ready`可算诊断收敛，`semantic_correctness`始终为null，不把该模拟器当真实用户或答案正确性评测。英语标签成绩不作中文能力证明；首轮状态匹配也不是SQL/计算答案正确率。
