# 任务4最小优化与父流程集成契约

## 范围与真实反馈

本轮只改任务4、Text2SQL、关系型安全执行及对应评测/测试。未修改意图核心、任务3/6、公共配置、模型客户端、API主流程或前端；未调用付费模型，未安装依赖。

唯一评测输出为 `evaluation/reports/optimization_task4_20261010.json`，保留修改前、首轮、通用修复后的500题配对。原始问答、参考SQL、mapping、导入文件与旧processed索引均保持不变。报告的严格覆盖是表集合包含关系，不是SQL EX。414为多表题，407为显式JOIN题；原始question_id存在重复，因此身份使用原始行号、db_id和question_id。

调试库在基线前固定为debit_card_specializing、student_club、california_schools、formula_1、financial（206题）；其余294题仅用于冻结后验证。这是回归分组，不声称过去从未观察过该数据集。

首轮严格覆盖从56.6%增至70.2%，越库候选和失效列各从21题降至0，但候选内桥接率从37.20%降至29.47%。只分析固定调试分组后发现：原SQLite字段大小写被误当作PG字段；只读核验真实PG目录证实native导入中的普通标识符已折小写。通用修复仅从既有import_native.sql的CREATE TABLE读实际列，遇COPY即停止，保留原始字段名用于词形检索。未向生产加入gold词典。

通用修复后最终严格覆盖73.4%（367/500），初选覆盖67.6%（338/500）；最终F1为0.614127，原实现为0.577829；初选F1为0.623894。最终候选平均3.932表，原实现2.95表。候选内桥接率55.80%；相对基线严格覆盖改对93题、改坏9题。7题仍无候选。第二轮比首轮覆盖增加16题，但平均F1略降，固定调试组最终F1也低于基线；额外桥表有精确率代价，不能据覆盖提高宣称全指标改善。

旧84.3%桥接数是整个FK图可达性，与本报告候选内路径指标不可直接比较。75张跨业务表没有用于完整业务库基线。无声明外键的子库仍缺真实连接证据；尚未验证真实模型SQL EX。

## 推荐父流程调用

1. 意图分析与用户澄清由父流程负责。保留原IntentResult含义，不把执行成功写回意图标志。
2. 父流程确定明确的数据集、真实子库与来源后，构造 `Text2SQLPipeline(llm_client, registry=registry)`；生产默认只加载关系源，不初始化向量客户端。
3. 推荐调用 `run(db_id, sub_db, question, confirmed_slots=confirmed, top_k=6, schema_mode="pruned", unresolved_conditions=pending)`。
4. `db_id="bird"`必须给11个真实业务子库中的一个sub_db；`db_id="cosql"`必须给原始子库名（如academic）；Chinook使用sub_db=None。禁止用bird,None代表完整业务库。
5. `schema_mode="full"`仅表示同一sub_db不裁剪结构，仍受相同来源、表、函数与事务限制；它不会取消真实用户口径歧义。
6. pending非空时直接返回needs_user，模型和数据库都不调用。检索不足、来源缺失、作用域错误返回blocked；技术不可用返回error/model_unavailable/execute_failed。executed且ok仅表示SQL成功执行，父流程仍按来源与业务条件决定是否输出answered。
7. 具体指标确认可传 `{"metric_id": "total_sales"}` 或合法精确字段引用；确认口径参与定位并保留在一次技术修复中。任意其他确认字符串不被当作结构标识。
8. 明确缺公式、缺参数来源、不支持的复合来源请求由父流程在调用前停止；本模块不接公式检索或猜测默认库。

## 给任务3的共享目录边界

`SchemaIndex.load(dataset, sub_db)`为原兼容接口。多库缺sub_db时抛KeyError；加载失败清空当前作用域，不保留上一个库的表。CoSQL子库身份从既有mapping源路径恢复，schema_name提供实际独立schema。目录是有状态对象，父流程应每会话单独持有，不能共享一个可变实例在不同会话间切库。别名与find_ambiguous_matches只返回当前目录真实标识；多表结构命中本身不能证明业务歧义。

## 执行安全

关系执行使用PostgreSQL解析、恰好一条非空查询、全树拒绝写入/锁/外部函数/自定义类型，真实readonly事务、超时、受限schema和表允许集合。安全函数只允许明确内置无副作用计算；显式业务schema同名函数被拒绝。真实表显式限定schema，函数search_path仅保留pg_catalog。BIRD/CoSQL不能通过无作用域默认调用访问全部子库。

生产最多展示500行，并标truncated。只有可修复SQLSTATE允许一次修复；安全/权限/连接/超时失败不修复，合法空结果不放宽条件。异常仅返回分类和SQLSTATE，不返回连接串、原始数据库报错或字面值。输入查询经PG方言规范化并把真实表显式加schema；函数search_path仅为pg_catalog，避免业务schema同名函数重载。executed_sql及pipeline.sql返回实际规范化后执行的SQL，旧公共测试若要求与未限定输入字符串逐字相同，需要由其负责人更新断言。

DDL通过同一registry来源读取，候选缺表即停止；真实主键与复合外键按对应序位配对。结构检索保桥表、PK/FK列及多条真实外键备选；最短链与粒度风险都不是业务正确性证明。原始PK元数据用于保列，生成阶段真实PG约束以实时DDL为准。

## 评测隔离和预算

生产不读取BIRD的SQL/evidence/参考结果，不读取CoSQL对话标注。生产示例全部关闭。完整结果比较器只存在于评测脚本，检查列数、行数、NULL、Decimal精度、多重集重复和显式排序规则。资源超限是独立状态，不按前500行计正确。

`eval_text2sql.py`默认不调用模型；显式--run-models及独立--run-id才运行，父流程统一控制2并发与预算。每个并发工作单独构造pipeline，不能共享可变SchemaLinker。完整与裁剪都跑，不能按gold结果决定补跑或选择答案。默认顶层ORDER BY按序比较；--unordered必须显式声明，不能混报官方口径。参考错误与模型不可用独立记录，共同完成配对分母与计划题数分开。

首个真实执行冒烟推荐每库2题，共22题；这只验证接点，不用于声称显著准确率提升。续跑必须相同代码、输入、题目集合和比较规则指纹。结果只更新上述指定JSON，不创建jsonl/log/tmp。

## 测试与复测

使用conda agent环境，所有Python命令加-B，pytest加-p no:cacheprovider。专用测试不写临时注册文件，mock仅验证契约，不参与数据集评分。

离线运行 `python -B evaluation/eval_schema_link.py --label baseline/first/final`；已有baseline/first禁止覆盖。最终版重测必须显式--replace-final，旧版概要保留在报告中。相同题目配对保持原始行序，不能只按重复question_id合并。

## 并发执行复核段（2026-10-11 第二轮独立复核修订）

独立只读复核确认原执行层缺陷并已修订：旧线程号余数pipeline池、任务锁外写报告、缺manifest补盖混跑、候选SQL在res.ok=False时仍用全库scope重执绕过生产安全拒绝、LLM全局monitor跨题跨线程串计量、model_identifier宣称frozen但未真正冻结worker配置。本节只陈述实做，不宣称尚未实现的功能；旧run-r3c/r4/r5日志仅作历史结果待复核，不作为可信优化结论。

1. **候选SQL重执恢复旧契约**：`evaluate_case.run_mode`只有`res.ok`为真且串库检查通过才调用`execute`；候选允许表=`res.tables`与本题scope交集（`{schema: res.tables ∩ scope[schema]}`），`blocked`携带的SQL绝不用全库scope绕过生产拒绝；串库快照命中立即返回`isolation_error`并在执行前阻断；full模式`model_unavailable`后不再调用pruned，pruned显式标`not_attempted`。金标参考执行照常发生。
2. **主线程逐批checkpoint**：`run_parallel`用`wait(FIRST_COMPLETED)`批式消费，最多`workers`(1或2)个future在途，绝不一口气submit全500；每个future完成后主线程立即合并记录、原子写报告并flush进度；main提交任务前先预置全部占位并落盘；任务异常转`task_error`记录（保留题号/异常类型/耗时，不回显正文）后停止新增调度，已尝试失败题不再回退为`not_attempted`；终止时main以非0退出。
3. **每线程独立LLM计量**：删除全局`_tls/build_pipeline/reset_thread_state`；每线程惰性构造独立pipeline并配独立`LLMMonitor`，`start_case()`在每题开始时重置窗口基线，`case_totals()`只统计本题calls后重置，绝不跨题/跨线程累计；主线程在checkpoint锁内按各record.llm逐题汇总，不共享可变计量。无模型`--dry-run`验证完整500、唯一sample_id、11子库，不写或覆盖报告。
4. **manifest全字段等值校验**：`check_manifest`对`fingerprint`/`fingerprint_files`/`python`/`sqlglot`/`samples`(顺序)/`sub_db_counts`/`selection`/`model_identifier`/`ordered`/`max_rows`/`max_bytes`逐一等值；已有records的键必须严格属于选题集且逐条`sample_id`/`db_id`一致，防分母膨胀；缺manifest含records直接拒绝，禁止补盖。`build_manifest`保存完整`fingerprint.files`清单供审计，不止总sha。
5. **真正的frozen LLM客户端**：`build_frozen_llm_client`评测only覆盖`_select_provider`为启动时resolved provider的私有深拷贝（密钥仅内存，不序列化进manifest/报告），全部worker共用同一快照；`model_identifier`端点身份仅散列去除用户信息的服务地址（16位摘要），严禁输出凭据；.env只经Settings正常加载，不直接读/回显。
6. **受控故障分类**：HTTPStatusError按响应码分auth(401/403)/config(400/404/422)/transient(429及5xx)，不靠正文猜测；pipeline吞异常时仍从monitor的`last_error_class`取分类。库级故障=SQLSTATE 08xx/28xx/42501及无pgcode的`connection_or_query`/`source_metadata_unavailable`，参考SQL语法失败记`reference_error`而非整个库故障。
6b. **库级故障不当能力错**（第三轮小修）：参考执行成功后DB断连时，`res.ok=False`且error为`source_metadata_unavailable`/库级SQLSTATE/`connection_or_query`（无法区分时保守停）→ 候选记`candidate_db_unavailable`、`ex=None`未评分pending，阻断后续mode与新增调度；`execute_full`候选执行同规则；monitor记有repair模型故障且非SQL安全阻断 → `repair_model_fault`、`ex=None`。普通SQLSTATE(如42703)仍按`candidate_blocked`计`ex=False`。保留错误类别供排查。
7. **worker只回记录、主线程消费**（第三轮小修）：worker不再写`record_queue`，仅`return` record；主线程`consume()`在每future完成时append/checkpoint；`summary.llm`从本run全部records聚合，另单列`segment_metrics`（本次吞吐/cases_finished），不混历史run；`finally`收尾未消费future，防Ctrl-C丢已完成。
7b. **每mode独立LLM快照**（第三轮小修）：`LLMMonitor.snapshot()`在每mode开始取当前calls长度，pruned窗口相对full结束快照只含pruned调用（不重含full），单题`case_totals()`仍完整覆盖两模式；`resolve_llm_snapshot()`在main启动时一次resolve provider+settings深拷贝，`model_identifier`与两个worker共用同一快照，不再每worker`_select_provider`；`--dry-run`不加载密钥。
8. **scope严格校验**（第三轮小修）：`run_mode`在`res.ok`判断前校验`current_db==db`且schema一致且`res.tables⊆原scope`，越界（含`current_db=None`）立即`isolation_error`不重执行，非仅交集后静默忽略。
9. **无网络回归测试**：`tests/test_eval_text2sql.py`覆盖blocked/isolation不重执SQL、参考OK但候选DB断连不当能力错、两模式LLM快照窗口不重复计数、任一manifest字段变更拒绝、task_error保留分母与非0退出、frozen provider同一标识、越界表isolation、SQL阻断仍阻断；夹具只用fake pipeline/mock，不冒充真实数据集。

验收：`conda run --no-capture-output -n agent python -B -m pytest tests -p no:cacheprovider -q`全量396项通过，`--all --dry-run`显式验证500/唯一ID/11子库且不写报告后，方可发起真实模型500题评测；本阶段未调用真实模型、未发付费请求。


