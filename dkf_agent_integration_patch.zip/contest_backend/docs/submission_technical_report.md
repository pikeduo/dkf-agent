# 提交技术报告（初稿）

> 状态：初稿，供提交前继续完善。本文只引用实际已存在的代码、保留报告与真实数据集；
> 候选方案明确标注"未部署/未验证"，不以中途或组件级数字包装为端到端成绩。
> 文中路径均不含密钥与连接串。

## 1. 项目目标与任务边界

针对高校 ICT 产教融合创新大赛赛题八（当前资料未逐字核实的官方全称一律用此泛称），
聚焦中级任务 3（智能语义校验与澄清）、任务 4（精准表定位 SchemaLinking）、
任务 6（文档公式识别与计算），构建一套多模态、可解释、可溯源的精准问数/问答智能体。

| 任务 | 边界 | 主要真实数据源 |
| ---- | ---- | ---- |
| 任务 3 | 意图结构化 + 缺口门控：该追问时追问、信息完整时直答；澄清后由执行门控放行 SQL/计算 | CoSQL（原生 AMBIGUOUS/CLARIFY 标注）、BIRD 信息完整题作对照、20 条 Chinook 真实表手工中文标注（`agent/test_cases/task3_zh.json`） |
| 任务 4 | 真实业务库子库作用域内的表字段定位 + 只读 SQL 生成与执行，多表关联桥接 | Chinook（11 表）、BIRD Mini-Dev（11 个真实业务子库、共 500 题 PostgreSQL 版） |
| 任务 6 | 用户/文档提供公式的受限解析、参数绑定与安全计算；OHR 文档证据检索 | FormulaReasoning（272 公式库按设计允许作为知识源加载，当前受控链路不自动检索公式卡片；HoF_test 413 题仅评测隔离使用）、OHR-Bench 文档 |

基础任务（单表 NL2SQL、单文档 RAG）采用赛题官方推荐的 Chinook 与 OHR-Bench 作为数据基础。

## 2. 当前真实运行链路

请求从 `backend/main.py`（FastAPI）进入。以下为实际调用关系，"模块存在"与"已接入主路径"分开说明。

1. **会话验证**：`backend/api/sessions.py` 会话令牌校验；受保护历史仅
   `backend/core/history/` 在令牌有效时供用，用户回复必须关联当前追问。
2. **意图结构化 / 缺口控制**：`/api/query` 只做**意图分析**（`IntentService` 的
   `prepare` 后 `choose_action`，见 `core/intent/service.py`）；只有
   `/api/query/run` 才在意图结果之上调用 `WorkflowService.run`（`core/workflow.py`）
   **自行判断 gaps/STOP** 并路由到 `_query/_calculate/_retrieve`。
   `clarification_readiness`/`requirement_gap` 参与澄清控制，由
   `task3_clarification/dialog_manager.py` 调用；**`execution_gate` 当前无生产调用**，
   仅作为统一门控的候选（§6）。意图层与执行层目前存在两套缺口判断（重复门控），
   是待改接点，未美化成单一控制器。
   模型只判目标、原文事实、真正影响答案的缺口；目录由服务端
   `SchemaContextProvider` 提供（`server_schema` 与 `inputs/history` 分区，无业务别名/答案/SQL）。
   任务 3 澄清接口 `backend/api/clarification.py` 按会话独立目录、预算最多 3 轮。
3. **SQL / 安全计算 / 文档证据**：
   - SQL：`text2sql/pipeline.py` 定位（`task4_schema_linking/schema_linker.py`）
     → 生成（`sql_generator.py`）→ 受限修复（`sql_repairer.py`），执行**直接经
     `registry.get_relational(db_id)` 返回的 `RelationalSource.execute_sql`**
     （`data_access/relational.py`）；`core/sql_executor.py` 当前**无生产引用**，
     不在每次执行路径上。
   - 公式：主路径是 `workflow._calculate` 用意图层已验证 `facts` 做精确符号绑定，
     交 `task6_formula/safe_calculator.py` 白名单计算；
     `task6_formula/param_finder.py` 是**独立组件，不在此主路径**，
     仅用于离线/文档抽参场景。
   - 文档：`agents/rag_retriever.py` 返回证据摘录；`doc evidence_ready`
     不冒充"已得最终答案"。
4. **结果**：`/api/query/run` 受控执行入口返回真实答案、计算步骤与来源；
   理解成功、执行成功、答案完成三者独立标记；追踪写 `logs/traces/`。

## 3. 数据隔离约束（5 真实源 + 手工中文标注）

- **入库/向量化（知识源）**：Chinook 数据库、OHR-Bench 文档（1261 PDF）。
  FormulaReasoning `formulas.json`（272 公式）按设计**允许**作为知识源加载，
  但当前受控链路**不自动检索公式卡片**（缺公式时按 §2 走用户原文），
  本轮无物理入库完成的证明，不写成已完成部署。原数据在 `data/raw`，
  预处理产物在 `agent/processed/`，数据库映射在 `data/postgresql/*`。
- **不入库（测试集，仅评测脚本读取）**：`agent/test_cases/`（含 20 条中文标注）、
  BIRD dev、OHR-Bench 8498 条问答（完整集在 `data/raw/ohr_bench/qas_and_code/data/qas_v2.json`）、
  CoSQL 对话、FormulaReasoning `HoF_test.json`（413 题的 `solution/arguments/ground_truth`
  不进入可检索知识库或生产提示词，评测隔离）。
- **BIRD 口径**：Mini-Dev 是 **11 个真实业务子库、共 500 题**（不是每库 500），
  414 多表题、407 显式 JOIN 题；不得把 11 库 75 张表相加冒充一套业务库。
- **OHR 口径**：文档文本是知识来源，其问答标注不是；10 个 textbook 文档
  （`textbook_needrop_en_*` 与 `jiaocai_needrop_en_*` 前缀一一对应）；
  1223 条 formula 证据支撑任务 6 评测；10 个纯扫描图 PDF 无文本层（记录在
  `evaluation/reports/doc_index_uncovered.json`），未伪造切片，需 OCR 补充。
- 官方 evidence / 金标 SQL 不进生产 RAG，也不进停止判断。

## 4. 安全执行边界

- **只读 SQL**：PostgreSQL 解析，恰好一条非空查询，全树拒绝写入/锁/外部函数/自定义类型；
  真实 readonly 事务、超时、受限 schema 与表允许集合；普通标识符限定真实 schema，
  函数 search_path 仅 `pg_catalog`；最多展示 500 行并标 truncated；
  仅可修复 SQLSTATE 允许一次修复（白名单），安全/权限/连接/超时失败不放宽；
  异常只返回分类与 SQLSTATE，不回显连接串或数据库原始报错。
- **受限 AST 计算**：公式 2048 字符、256 节点、32 层深度、幂指数 ≤100、
  实数 ≤1e100；白名单函数 abs/round/min/max/sqrt（sum 拒绝）；
  自引用、多等号、属性访问、任意调用、列表/推导式全部拒绝；
  计算器对绑定重新解析防规格篡改。
- **温差与单位**：摄氏/华氏温标默认歧义一律拒绝；显式 Δ/delta 紧邻标记或
  `quantity_kind="temperature_difference"` 授权后按开尔文温差
  （1℃温差=1K，1℉温差=5/9K）规范化；**转数单位 r 本轮不支持**（文档限定，不换算 rad）。
- **来源校验**：`Fact.source` 只引用用户原文；目录被裁剪不得据此证明请求不可回答；
  来源可 JSON 序列化且 ≤8192 字符；不得编造页码、坐标、证据编号。

## 5. 可信指标与口径声明

评测并发：真实 API 最高 2 并发（每评测线程独立 pipeline 与 LLM 计量，互不串账），
故障分类用受控枚举 + SQLSTATE，技术失败保留在固定分母内。

### 任务 4（`evaluation/reports/optimization_task4_20261010.json`，r6 隔离轮，可信）

- BIRD 500 全量完成 500/500 配对：full **170/500 = 34%**、pruned **162/500 = 32.4%**，
  双分母口径（固定计划分母与可评配对分母分开标明），wall **6304.432s**，
  平均单题延迟 25.03s；**参考级异常 0、隔离级异常 0、任务级异常 0、未尝试 0**
  （指上述三类故障计数，并非所有 SQL 都成功——仍有执行前被安全阻断的 blocked 题）。
- 历史对照（早期离线 `final` 轮，非 r6 当前代码成绩，仅作趋势参考）：
  严格覆盖 73.4%（367/500）、初选 67.6%、候选内桥接率 55.8%。
  r6 的表覆盖若作为结论需独立计数，**本轮不开展**。
- 旧 run r3c/r4/r5 分数仅作历史结果复核记录，r6 前已在新契约下重跑。

### 任务 6（`evaluation/reports/optimization_task6_20261010.json`）

- HoF 413 题**金标公式+参数组件一致性**（oracle 口径，非端到端）：
  **232/413 = 56.17%** 全式一致；可比较覆盖 241/413；
  该诊断不经过工作流门控，不能证明或否定 gate/绑定重构。
- **旧 93.2% 因单位错误已撤回**，不得再引用。
- 最终回答准确率、生产原文抽参、PDF 识别能力本轮未评测。

### 任务 3（`evaluation/reports/optimization_task3_20261010.json` + `task3_subset_20261013.json`）

- 全 9233 题运行 `task3_full_20261012_v1` 因 `model_unavailable` 硬停止于 5454 题，
  属**历史部分运行**，不当最终成绩：attempted 准确率 0.828 仅覆盖已尝试 5454 题，
  固定计划分母口径 0.489（3779 题未尝试）。
- **v1 长对话偏重回归集（`task3_subset_20261013.json`，已完整 607 条）**：
  实际分母 607（CoSQL 587 + 中文 20），**correct_over_planned 528/607 = 86.99%**，
  completed 607/607、技术失败 14（均为 `invalid_model_output`，已保留在分母）：
  - CoSQL AMBIGUOUS 召回 **6/51（11.8%）**；INFORM_SQL complete_ready 499/528；
    不必要追问 17/528；CANNOT_ANSWER 2/7；CANNOT_UNDERSTAND 1/1。
  - 中文 20 条 **20/20**（必要澄清 9/9、不必要追问 0/11、complete_ready 11/11）。
  - 分区：debug 84 / heldout 523。
  - **采样限制（必须声明）**：该 v1 清单由 rule_version `task3-subset-v1` 生成，
    层内按 (-对话轮数, 固定种子hash) 装入，**长对话系统性偏重，不是代表性随机抽样**；
    仅作"长对话偏重回归集"使用，不得宣称随机代表性。已修复为 v2。
- **v2 代表性固定哈希抽样（`task3_subset_v2_20261013.json`，新清单
  `test_cases/task3_subset_manifest_v2.json`，清单一次冻结后所有 baseline/light
  共用同一 ID/hash 分母）：新结果待测，本文不预写分数、不填空表、不造 0；
  完成后按"v2 固定子集成绩，不代表原 9233 全量"口径写入 §5。
- 47/278 系统 CLARIFY 召回只是中途证据，不作合格门槛。

### 其它保留证据

- `prompt_context_probe_20261011.json`：提示长度探针（0 模型调用），
  BIRD 场景压缩/注册表候选收益约 3%（字符），未过资源门控（阈值 10%），
  不推荐下一轮加模型预算。
- `closed_loop_reviews_*_20261010.json`：复核记录（review_unavailable + 金标不可见）。
- `doc_index_uncovered.json`：10 个纯图片 PDF 未覆盖清单。

## 6. 候选架构（未实现，不得当已实现）

`docs/lightweight_architecture.md` + `evaluation/candidates/light_prompts.py`：
单一不可变来源上下文 SourceScope、统一语义门控重构、短提示候选
（意图正文 862 / system 合计 5767 / SQL 正文 221，**均为字符数不是 token**）。
截至本文撰写，候选**尚未部署、尚未模型验证**，生产提示词与 schema 原样保留；
`light_prompts.py` 不被任何生产模块 import。

## 7. 已知局限

1. OHR 公式场景：PDF 公式文本提取质量与"最终回答"本轮未评测；
   10 个纯扫描图 PDF 需 OCR 后才能覆盖。
2. 计算：绝对温标不做仿射换算（无参考零点）；转数单位 r 不支持。
3. CoSQL：跨源 `formula_1` 同名目录碰撞（61 轮/17 对话）是评测目录解析与
   API 丢 source 两处独立缺陷的交集，已单列为技术修复项（阶段 A 范围）。
4. BIRD 严格覆盖与 SQL EX 是两层不同指标，报告分别标明，不混用。
5. 任务 3 固定子集成绩（v1 长对话偏重回归集 607 条已完成、v2 代表性固定哈希
   抽样新结果待测）仅代表各自子集，不替代原 9233 全量结论；v1 层内先长后短的
   装入顺序已修复为 v2 纯固定哈希序（不搜索种子、不改样本调分），清单一次冻结
   后 current/light 两轮共用同一 ID 与 hash。

## 8. 测试与复现命令（仅引用实际存在的 CLI）

```powershell
# 全部使用 conda agent 环境；pytest 不产生缓存
conda run --no-capture-output -n agent python -B -m pytest tests -p no:cacheprovider -q

# 任务 3 离线构建（不写模型成绩，不调用模型）
conda run --no-capture-output -n agent python -B evaluation/eval_clarify.py --split all --datasets zh cosql bird

# 任务 3 真实模型（父流程批准后按 --datasets zh --split debug --run-model 等执行）
# 新子集（task3_subset_20261013.json）对应的评测命令由并行实现任务最终补充，本文不猜测其参数

# 任务 4 离线表定位（eval_schema_link.py）：查看可用参数与输出管理说明（不覆盖历史基线/final）：
conda run --no-capture-output -n agent python -B evaluation/eval_schema_link.py --help
# 离线重跑/新 label 的输出管理（是否覆盖 baseline/final、命名）另行指定，本文不默认覆盖历史 final。

# 任务 4 真实模型 500 题：--all 仅作范围核查（配 --dry-run 时不写报告、不调模型）；
#   发起真实 500 题须显式 --run-models + 唯一 --run-id + 2 并发（--workers 2）。
#   范围核查（不发起真实调用）：
conda run --no-capture-output -n agent python -B evaluation/eval_text2sql.py --all --dry-run
# 真实 500 题（父流程批准并发与预算后；注意：此命令会发起真实 API 调用，产生费用）：
#   使用前请把 "r6_submit_example" 换成实际唯一 run-id：
conda run --no-capture-output -n agent python -B evaluation/eval_text2sql.py --all --run-models --workers 2 --run-id "r6_submit_example"

# 任务 6 HoF 组件诊断（可复现，含测试）
conda run --no-capture-output -n agent python -B evaluation/eval_formula.py --round verification --with-tests
```

## 9. 演示输入（建议演示输入/软件夹具；本轮未真实调用，不宣称端到端已验证）

以下仅为建议演示输入。`/api/query/run` 使用 `database` 参数（可选 `sub_db`），
**不使用 `db_id`**（`RunQueryRequest`，见 `backend/api/query.py`）。

- Chinook 单表：`database="chinook"`，例："查询客户总数"。
- BIRD 多表：`database="bird"` + `sub_db="california_schools"` 等 11 个真实子库之一，
  不得用 `bird` 不带 `sub_db`。
- 公式计算：用户原文给出完整公式与参数，例 `F=m*a, m=2 kg, a=3 m/s²`
  （软件夹具走受限解析→绑定→白名单计算，不经过公式卡片检索）。
- 澄清：`POST /api/clarification/`，省略 database 可做文本/公式缺口澄清
  （无 SQL 授权）；指定 bird/cosql 需唯一子库。

已知边界：CoSQL/BIRD 存在同名目录（如跨源 `formula_1`）时，当前 API 丢源缺陷**未修复**，
受控逻辑会**拒绝而非默认选择第一个库**；调用方给出唯一原始子库标识可定位到已给定的库，
但**不能解决同名冲突本身**，`SourceScope` 修复（§6）仍待实现。

## 10. 提交前检查清单

- [ ] 任务 3 子集重建完成并得到新成绩（当前"待评测"），填入 §5。
- [ ] 全 pytest 由主实现任务统一跑一遍并留记录（本清理任务不跑全量）。
- [ ] 确认 `evaluation/reports/` 无新增临时 jsonl/log；`_tmp_*` 诊断文件已清。
- [ ] 确认无 `.env` 内容、连接串、密钥进入文档与报告。
- [ ] 复核 §6 候选描述与代码现状一致（候选仍未部署）。
- [ ] OHR 10 个纯图片 PDF 的 OCR 补充边界写入答辩口径。
- [ ] 新子集 manifest/report 命名落地后，确认本文"待评测"项已替换。

## 附：保留证据文件（不得改动）

| 文件 | 说明 |
| ---- | ---- |
| `evaluation/reports/optimization_task3_20261010.json` | 全量 9233 硬停于 5454 的历史部分运行 + 固定分区样本 |
| `evaluation/reports/optimization_task4_20261010.json` | 含 r6 可信全 500（full 34% / pruned 32.4%，wall 6304.432s） |
| `evaluation/reports/optimization_task6_20261010.json` | 金标公式参数组件 232/413 = 56.17% + 历史轮 |
| `evaluation/reports/prompt_context_probe_20261011.json` | 提示长度探针（0 模型调用） |
| `evaluation/reports/doc_index_uncovered.json` | 10 个纯图片 PDF 未覆盖清单 |
| `evaluation/reports/closed_loop_reviews_*_20261010.json` | 复核记录 |
| `test_cases/task3_zh.json` | 20 条中文手工标注（Chinook 真实表） |
| `processed/`、`data/raw`、`data/postgresql` | 预处理产物与原始数据/数据库 |
| `docs/*.md` | 既有架构与契约文档 |
