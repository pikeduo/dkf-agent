"""任务3最小子集采样器：从CoSQL全量有效轮按整对话分层抽约600轮+中文20条。

硬约束：
- 仅基于dialog_id+固定种子哈希排序，选择与任何模型结果/旧run记录无关；
- 整对话不截断：某对话被选中则其全部有效轮次一并入选，总量容许轻微浮动；
- 中文20条全部保留；BIRD未审核一律不选；
- 采样前不读旧run的hit/records/SQL/evidence，清单不复制答案到知识源。
"""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

SEED = "ict-task3-subset-v1"        # 固定seed，v1/v2沿用，不搜索seed
RULE_VERSION = "task3-subset-v2"    # 现行规则版本：v2（层内仅按固定种子hash排序，不偏长）
RULE_V1 = "task3-subset-v1"         # 旧规则版本：层内(-轮数,种子hash)，长对话偏重，仅作回归集
VALID_RULES = (RULE_V1, RULE_VERSION)
DEFAULT_TARGET = 600           # 约600个CoSQL有效轮（整对话不截断，实际量容许轻微浮动）
LAYER_ORDER = ("CANNOT_ANSWER", "CANNOT_UNDERSTAND", "AMBIGUOUS", "INFORM_SQL")


def _seed_rank(value: str) -> int:
    """固定种子+内容排序键；同一输入永远同一排名，与模型输出无关。"""
    return int(hashlib.sha256(f"{SEED}:{value}".encode()).hexdigest(), 16)


def _dialog_layer(cases) -> str:
    """对话级分层优先级：含CANNOT_ANSWER优先，其次CANNOT_UNDERSTAND、AMBIGUOUS，
    其余归INFORM_SQL。"""
    for layer in LAYER_ORDER:
        if any(c.primary_label == layer for c in cases):
            return layer
    return "INFORM_SQL"


def _allocate_targets(counts: dict, total: int, target: int) -> dict:
    """按各层有效轮数占总体的比例分配目标轮数；余数按小数部分降序补齐。"""
    alloc: dict[str, int] = {}
    for layer in LAYER_ORDER:
        if counts.get(layer):
            alloc[layer] = min(int(round(target * counts[layer] / total)), counts[layer])
    remaining = target - sum(alloc.values())
    ordered = sorted(alloc, key=lambda l: (-(target * counts[l] / total -
                                              int(target * counts[l] / total)), _seed_rank(l)))
    for layer in ordered:
        if remaining <= 0:
            break
        step = min(counts[layer] - alloc[layer], remaining)
        alloc[layer] += step
        remaining -= step
    return alloc


def select_subset(cases: list, target: int = 600,
                  rule_version: str = RULE_VERSION) -> list:
    """从全量有效轮（须为all_turns构建结果）选整对话子集；返回选中的case列表。

    选择与模型结果无关：只读case_id/primary_label/dataset，装入量完全由
    固定种子哈希顺序决定，不截断对话，总量容许轻微浮动。
    - v2（现行）：每层内只按_seed_rank(dialog_id)排序选完整对话，保证代表性
      （短/长对话同权，不偏长）；每非空层按总体有效轮数比例分配目标轮数。
    - v1（旧回归集）：层内(-轮数,种子hash)排序，先长后短，长对话偏重；
      仅旧清单/旧报告沿用，不得宣称随机代表性。
    """
    if rule_version not in VALID_RULES:
        raise ValueError(f"未知采样规则版本{rule_version}；仅支持{'/'.join(VALID_RULES)}")
    cosql = [c for c in cases if c.dataset == "cosql"]
    if any(c.dataset not in ("cosql", "zh") for c in cases):
        raise ValueError("子集仅覆盖cosql与zh数据集；BIRD未审核不得进入")
    # 按dialog_id完整分组，不截断对话
    groups: dict[str, list] = defaultdict(list)
    for c in cosql:
        groups[c.case_id.rsplit(":", 1)[0]].append(c)
    turns_per_layer = {layer: sum(len(cs) for cs in groups.values() if _dialog_layer(cs) == layer)
                       for layer in LAYER_ORDER}
    total_turns = sum(turns_per_layer.values())
    # 先按比例分配；再保证每非空层至少一完整对话（最小占用）
    alloc = dict(_allocate_targets(turns_per_layer, total_turns, target))
    for layer in LAYER_ORDER:
        if turns_per_layer[layer] > 0:
            alloc[layer] = max(alloc.get(layer, 0), 1)
    picked: dict[str, int] = {}
    for layer in LAYER_ORDER:
        wanted = alloc.get(layer, 0)
        if wanted <= 0:
            continue
        if rule_version == RULE_V1:
            # 旧v1：轮次多的对话先装（长对话偏重），仅保留供回归集使用
            ranked = sorted((g for g, cs in groups.items() if _dialog_layer(cs) == layer),
                            key=lambda g: (-len(groups[g]), _seed_rank(g)))
        else:
            # v2：层内只按固定种子hash排序，短/长对话同权，代表性抽样
            ranked = sorted((g for g, cs in groups.items() if _dialog_layer(cs) == layer),
                            key=lambda g: _seed_rank(g))
        running = 0
        for g in ranked:
            if running + len(groups[g]) > wanted and running > 0:
                break  # 至少已装入一完整对话（非空层最小覆盖），不截断对话
            picked[g] = len(groups[g])
            running += len(groups[g])
    selected = [c for c in cosql if c.case_id.rsplit(":", 1)[0] in picked]
    selected.extend(c for c in cases if c.dataset == "zh")
    return selected


def build_subset_manifest(*, all_cases: list, source_hashes: dict,
                          selector_code_hash: str, target: int = 600,
                          rule_version: str = RULE_VERSION) -> dict:
    """构建清单：caseID+样本hash、源hash、种子/规则版/实际数/分布；实际选定子集落盘。

    all_cases=zh+cosql全量有效轮；选择器只读caseID/标签，不复制答案/SQL/evidence。
    字段显式区分：selected_dialog_count=选定完整对话数，total_dialog_count=全体有效
    对话数（禁止把全体数说成选定数）。
    """
    chosen = select_subset(all_cases, target, rule_version=rule_version)
    case_map = {c.case_id: c.sample_hash() for c in chosen}
    cosql_cases = [c for c in all_cases if c.dataset == "cosql"]
    # 全量有效轮注册表（只存caseID+样本hash，不复制答案/SQL/evidence）
    full_registry = {c.case_id: c.sample_hash() for c in
                     sorted(cosql_cases, key=lambda c: c.case_id)}
    dist: dict[str, int] = {}
    for c in chosen:
        key = c.primary_label if c.dataset == "cosql" else "MANUAL_ZH"
        dist[key] = dist.get(key, 0) + 1
    selected_cosql = [c for c in chosen if c.dataset == "cosql"]
    # 选定对话id集合；db覆盖=选定轮次涉及的数据库集合；原debug/heldout分组计数
    selected_dialogs = sorted({c.case_id.rsplit(":", 1)[0] for c in selected_cosql})
    db_coverage: dict[str, int] = {}
    for c in selected_cosql:
        db_coverage[c.model_input.database] = db_coverage.get(c.model_input.database, 0) + 1
    partition_counts: dict[str, int] = {}
    for c in chosen:
        partition_counts[c.split] = partition_counts.get(c.split, 0) + 1
    fields = {
        "seed": SEED, "rule_version": rule_version, "target": target,
        "selector_code_hash": selector_code_hash, "source_hashes": source_hashes,
        "total_valid_turns": len(cosql_cases),
        "total_dialog_count": len({c.case_id.rsplit(":", 1)[0] for c in cosql_cases}),
        "selected_dialog_count": len(selected_dialogs),
        "selected_databases": dict(sorted(db_coverage.items())),
        "partition_counts": dict(sorted(partition_counts.items())),
        "actual_count": len(case_map), "label_distribution": dict(sorted(dist.items())),
        "selected_dialogs": selected_dialogs,
        "cases": dict(sorted(case_map.items())),
        "full_registry": dict(sorted(full_registry.items())),
    }
    manifest = dict(fields)
    manifest["manifest_hash"] = hashlib.sha256(json.dumps(fields, ensure_ascii=False,
                                                          sort_keys=True,
                                                          separators=(",", ":")).encode()).hexdigest()
    return manifest


def filter_and_verify_cases(manifest: dict, cases: list, source_hashes: dict,
                            selector_code_hash: str) -> list:
    """只读校验+筛选：先整manifest_hash完整性（任何篡改即拒绝），再按清单caseID
    过滤出子集并逐case校验样本hash与实际数量。返回筛选后的case列表。"""
    _verify_manifest_integrity(manifest)
    if manifest.get("seed") != SEED or manifest.get("rule_version") not in VALID_RULES:
        raise ValueError("清单种子或规则版本不符，拒绝使用")
    if manifest.get("selector_code_hash") != selector_code_hash:
        raise ValueError("选择器代码hash变化，须重新构建清单")
    if manifest.get("source_hashes") != source_hashes:
        raise ValueError("源数据hash变化，清单与数据不一致，拒绝使用")
    recorded_cases = manifest.get("cases", {})
    # 筛选：只保留清单内case（顺序保持稳定，由case_id排序保证）
    selected = [c for c in cases if c.case_id in recorded_cases]
    for case in selected:
        if recorded_cases[case.case_id] != case.sample_hash():
            raise ValueError(f"{case.case_id}样本hash与清单不一致，疑似数据或构建被改动")
    if len(selected) != len(recorded_cases):
        raise ValueError(f"清单{len(recorded_cases)}条与实际筛选{len(selected)}条数量不符")
    return selected


def _verify_manifest_integrity(manifest: dict) -> None:
    """按manifest内全部字段重算sha256；任何caseID/样本hash/源hash被篡改即拒绝。"""
    fields = {k: v for k, v in manifest.items() if k != "manifest_hash"}
    expected = manifest.get("manifest_hash")
    recomputed = hashlib.sha256(json.dumps(fields, ensure_ascii=False,
                                           sort_keys=True,
                                           separators=(",", ":")).encode()).hexdigest()
    if expected != recomputed:
        raise ValueError("清单manifest_hash与内容不符，清单被篡改，拒绝使用")


def write_manifest(path: Path, manifest: dict) -> None:
    """清单落盘；同路径重抽必须与原清单逐字段一致（确定性），否则拒绝覆盖。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        if old != manifest:
            raise ValueError("清单已存在且与本次重抽结果不一致（非确定性），拒绝覆盖，请人工核对")
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
