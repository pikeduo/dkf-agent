"""闭环优化的独立只读评审：工程代码与方案可见，测试金标及密钥不可见。

使用现有模型接口，不安装依赖。评审只给意见，不执行模型生成的程序。
输出为指定的闭环评审报告；失败会保留错误类型，不伪装成评审通过。
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

PLANS = {
    "task3": {
        "files": ["backend/core/intent/service.py", "backend/core/intent/prompts.py", "backend/core/intent/policy.py", "backend/agents/task3_clarification/necessity_judge.py", "backend/agents/task3_clarification/dialog_manager.py"],
        "proposal": [
            "使用服务端真实且限定子库的元数据补问题解释，只提供表字段与定义，不提供答案；测试不能加载不到索引后静默丢掉schema。",
            "把模型不清楚字段和用户真正缺失意图分开：可查定义先读取元数据，用户必要参数/指标口径缺失应追问，不要求缺参必须有两个候选。",
            "撤销一刀切的只允许数据已证明歧义才提需求的提示；候选解释必须有原文或真实目录支持，模型不能替用户选择指标/时间。",
            "缺失、冲突、不可回答、技术失败分开，排序权重不当判定阈值；全拒绝、预算耗尽不能成为ready。",
            "修复评测仅首问及CANNOT_ANSWER合并歧义问题，按dialog稳定划分调试/留出集，输入仅之前对话和schema，无金标/未来回复。",
            "共用流程增加显式受控执行入口，保留原/intent兼容；会话内执行保持串行租约，追问可恢复，失败回合不提交；模型候选不是已确认事实。"
        ]
    },
    "task4": {
        "files": ["backend/agents/task4_schema_linking/schema_index.py", "backend/agents/task4_schema_linking/table_matcher.py", "backend/agents/task4_schema_linking/fk_graph_builder.py", "backend/agents/task4_schema_linking/schema_linker.py", "backend/data_access/relational.py", "backend/agents/text2sql/pipeline.py"],
        "proposal": [
            "从已有原始数据库映射恢复cosql原始子库id，按真实schema隔离；bird仍限定原始11子库之一，不用75张无关表集合作真实业务库。",
            "修复中文normalize空字符串匹配所有字段、英文token字符串子串误命中；使用非空token证据、库内IDF和表/字段互补召回。",
            "固定范围和数据集上缓存元数据；去除当前子库目录不存在的指标和列引用，补齐真实外键路径中间表及PK/FK列，不臆造关联。",
            "执行使用只读事务、单条Query、完整AST拒绝写入和危险函数、受限schema/search_path与scope表白名单；模型失败或schema不足不执行。",
            "SQL修复仅一次且只对可修复语法/字段错误，权限/超时/安全拒绝不修复；响应与trace不暴露DSN/密钥。",
            "BIRD金标SQL/evidence仅评测层读，EX不截断比较、不剔除失败抬分，不沿用跨库完整catalog对照。",
            "共用配置改绝对.env路径，503/429按瞬时故障最多2次重试，默认同端点最多2并发，不另套外层重试。"
        ]
    },
    "task6": {
        "files": ["backend/agents/task6_formula/formula_spec.py", "backend/agents/task6_formula/safe_calculator.py", "backend/agents/task6_formula/param_finder.py", "evaluation/eval_formula.py"],
        "proposal": [
            "主链路只解析用户提供公式，不连接或测试公式卡片检索。统一受限AST，保留原文，同一方括号名称复用同一符号；下标/属性/自引用/多等号/歧义±必须拒绝。",
            "有限实数和复杂度预算，禁止eval/exec；科学计数含上标和花括号按位正确解析，不从字符串截取第一个数字冒充完整数值。",
            "求值真正的分母表达式而非检查所有出现在分母的变量，处理复合除数/非法域/过大幂/非有限中间结果/白名单函数参数。",
            "不用新依赖，实现有限单位词典及维度运算；参数保留原单位，换算按单位标注而非答案数字比例，百分数内部比率与展示分离；未知或不兼容单位拒绝。温度绝对值/温差有边界说明，不静默抹单位。",
            "参数符号只做明确映射，值必须逐字有原文来源；无法唯一绑定追问，不用双向包含把多个变量绑到相同候选。",
            "HoF solution/arguments/answer仅离线评测读，标明给定公式与标注输入的组件一致性诊断，不称生产抽参端到端准确率；移除任意数字比例因子，失败/数据不一致不硬算正确。",
            "计算接口输出原公式、必要符号、参数/单位/步骤和结构化失败；真实自然题面测试与oracle输入诊断分开报告，暂不宣称PDF视觉识别完整实现。"
        ]
    }
}


def review(task, round_name, client):
    plan = PLANS[task]
    snapshots = []
    for relative in plan["files"]:
        path = HERE / relative
        text = path.read_text(encoding="utf-8")
        import ast
        excerpts = []
        if relative.endswith("prompts.py"):
            excerpts = [text[:4200]]
        else:
            tree = ast.parse(text)
            important = {"analyze", "should_clarify", "rank", "load", "match", "link", "execute_sql", "run", "compute_spec", "parse_formula", "spec_from_user_formula"}
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in important:
                    excerpts.append((ast.get_source_segment(text, node) or "")[:2400])
        # 只审阅计划与关键接点摘录，完整源码哈希用于后续代码复核。
        snapshots.append({"path": relative, "sha256": hashlib.sha256(text.encode()).hexdigest(), "code_excerpts": excerpts[:2]})
    payload = {"task": task, "phase": round_name, "proposal": plan["proposal"], "sources": snapshots}
    prompt = (
        "你是独立的只读工程评审，不执行优化、不改代码。依据给定真实代码评估方案是否能实施。"
        "工程目标为安全的语义澄清、精确子库表定位和用户公式确定性计算，不连接imajev或公式卡片。"
        "只能使用既有Chinook/OHR/CoSQL/BIRD/FormulaReasoning；金标不可进生产提示。"
        "不能保证最佳性能或用测试集反复调到过拟合。不要复述方案为通过证据。"
        "找出真实反例、阻断风险和最小可测试修复；当前代码缺陷允许通过修复方案解决，"
        "但若方案本身有安全/评测泄露错误必须requires_revision。"
        "返回严格JSON：{status: approve_with_conditions或requires_revision, findings:[{severity,location,reason}],"
        "mandatory_conditions:[字符串], tests:[字符串], avoid:[字符串]}。中文内容。\n"
        + json.dumps(payload, ensure_ascii=False)
    )
    started = time.perf_counter()
    raw = client.chat([{"role": "user", "content": prompt}], temperature=0.0, reasoning_effort=None, max_retries=0)
    text = raw.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    result = json.loads(text)
    if result.get("status") not in ("approve_with_conditions", "requires_revision"):
        raise ValueError("评审未返回合法状态")
    return {"task": task, "phase": round_name, "review": result, "elapsed_s": round(time.perf_counter()-started, 3),
            "source_hashes": {s["path"]: s["sha256"] for s in snapshots}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--round", default="plan")
    ap.add_argument("--tasks", nargs="+", choices=list(PLANS), default=list(PLANS))
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    from backend.core.llm_client import LLMClient
    client = LLMClient()
    # 工程评审使用短预算，不叠加重试或改动实际环境配置。
    client.settings = client.settings.model_copy(update={"llm_request_timeout": 25.0, "llm_max_retries": 0})
    rows = []
    path = Path(args.output).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    for task in args.tasks:
        print(f"review_started {task} {args.round}", flush=True)
        try:
            row = review(task, args.round, client)
        except Exception as exc:
            row = {"task": task, "phase": args.round, "status": "review_unavailable", "error_type": type(exc).__name__}
        rows.append(row)
        path.write_text(json.dumps({"reviews": rows, "gold_visible": False}, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"review_finished {task} {row.get('review',{}).get('status',row.get('status'))}", flush=True)
    if any(r.get("status") == "review_unavailable" for r in rows):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
