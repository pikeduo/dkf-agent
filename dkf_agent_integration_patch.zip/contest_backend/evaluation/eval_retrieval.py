"""任务4 向量检索评测：OHR-Bench 证据段落命中率。

抽样 qas_v2.json（8498 题）300 题（固定种子），对每题：
- 检索：SiliconFlowEmbedder 嵌入问题 → doc_chunks top-k（限定该题 doc_name）
- 判定：top-k 切片中是否有与 evidence_context 高度重叠的切片
  （token 重叠率 ≥ 0.5 判命中；evidence_context 仅本脚本读取，评测隔离）
- 分层：按 evidence_source（formula/table/text/...）分别报告
指标：Recall@5 / Recall@10（重叠口径），公式类单独报。
结果落 evaluation/reports/retrieval_ohr_YYYYMMDD.json。

用法：python -B evaluation/eval_retrieval.py [--n 300] [--seed 7]
"""
import argparse
import datetime as dt
import json
import random
import re
import sys
import time
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

QAS = HERE.parent / "data" / "raw" / "ohr_bench" / "qas_and_code" / "data" / "qas_v2.json"
REPORT_DIR = HERE / "evaluation" / "reports"
OVERLAP_THRESHOLD = 0.5  # 证据词重叠率阈值（distinct 非停用词）


def content_tokens(text: str) -> set:
    """证据词：数字、LaTeX 公式符号保留，英文词 ≥2 字，去标点。"""
    if not text:
        return set()
    toks = set(re.findall(r"[A-Za-z]{2,}|\d+(?:\.\d+)?", text.lower()))
    return toks


def overlap_rate(evidence: set, chunk_text: str) -> float:
    if not evidence:
        return 1.0
    chunk_toks = content_tokens(chunk_text)
    hit = evidence & chunk_toks
    return len(hit) / len(evidence)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--skip-images", action="store_true",
                    help="自动跳过无文本层的纯扫描图文档")
    args = ap.parse_args()

    from backend.agents.rag_retriever import RAGRetriever
    from backend.data_access.registry import SourceRegistry
    from backend.config import get_settings
    from backend.integrations.embedder import SiliconFlowEmbedder

    settings = get_settings()
    embedder = SiliconFlowEmbedder()
    registry = SourceRegistry.load_from_json(
        str(HERE / "processed" / "knowledge_base" / "databases.json"))
    vs = registry.get_vector("ohr_bench")
    assert vs is not None, "ohr_bench 向量源未注册"
    rag = RAGRetriever(vs)

    qas = json.loads(QAS.read_text(encoding="utf-8"))
    uncovered = set()
    try:
        unc = json.loads((REPORT_DIR / "doc_index_uncovered.json").read_text(encoding="utf-8"))
        uncovered = set(unc.get("image_only_no_text_layer", []))
    except FileNotFoundError:
        pass
    pool = [q for q in qas if q.get("doc_name") not in uncovered]
    if args.skip_images:
        pool = [q for q in qas if q.get("doc_name") not in uncovered]
    rng = random.Random(args.seed)
    sample = rng.sample(pool, min(args.n, len(pool)))

    stats = {"n": 0, "r5": 0, "r10": 0, "no_doc": 0,
             "per_source": {}, "failure_samples": []}
    t_loop = time.perf_counter()
    for i, q in enumerate(sample):
        case_t0 = time.perf_counter()
        doc = q.get("doc_name")
        ev = content_tokens(str(q.get("evidence_context") or ""))
        try:
            hits5 = rag.retrieve(q.get("questions") or "", doc_id=doc, top_k=5)
        except RuntimeError:
            continue
        # top-10 需要另取一次（VectorSource.search 按 top_k 取）
        try:
            hits10 = rag.retrieve(q.get("questions") or "", doc_id=doc, top_k=10)
        except RuntimeError:
            hits10 = []
        r5 = any(overlap_rate(ev, h["text"]) >= OVERLAP_THRESHOLD for h in hits5)
        r10 = any(overlap_rate(ev, h["text"]) >= OVERLAP_THRESHOLD for h in hits10)
        src = q.get("evidence_source") or "unknown"
        st = stats["per_source"].setdefault(src, {"n": 0, "r5": 0, "r10": 0})
        stats["n"] += 1
        st["n"] += 1
        stats["r5"] += int(r5)
        stats["r10"] += int(r10)
        st["r5"] += int(r5)
        st["r10"] += int(r10)
        if not r10 and len(stats["failure_samples"]) < 20:
            stats["failure_samples"].append({
                "id": q.get("ID"), "doc": doc, "source": src,
                "question": (q.get("questions") or "")[:80],
                "evidence": str(q.get("evidence_context"))[:120]})
        if (i + 1) % 10 == 0:
            print(f"[{i + 1}/{len(sample)}] 题{q.get('ID')}  本题{time.perf_counter() - case_t0:.2f}s", flush=True)

    n = stats["n"]
    print(f"评测完成：{n}题有效（跳过{len(sample) - n}题），共{time.perf_counter() - t_loop:.1f}s", flush=True)
    report = {
        "dataset": "ohr_bench_qas_v2",
        "n": n,
        "overlap_threshold": OVERLAP_THRESHOLD,
        "recall_at_5": round(stats["r5"] / n, 4) if n else None,
        "recall_at_10": round(stats["r10"] / n, 4) if n else None,
        "per_source": {k: {"n": v["n"],
                           "r5": round(v["r5"] / v["n"], 4) if v["n"] else None,
                           "r10": round(v["r10"] / v["n"], 4) if v["n"] else None}
                       for k, v in sorted(stats["per_source"].items())},
        "uncovered_image_docs": len(uncovered),
        "failure_samples": stats["failure_samples"],
        "note": "命中=证据词与top-k切片distinct-token重叠≥阈值；evidence_context仅评测脚本读取",
    }
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    out = REPORT_DIR / f"retrieval_ohr_{dt.date.today():%Y%m%d}.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "failure_samples"},
                     ensure_ascii=False, indent=2))
    print("报告:", out)


if __name__ == "__main__":
    main()
