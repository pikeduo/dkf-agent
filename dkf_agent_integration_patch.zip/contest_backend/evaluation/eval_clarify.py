"""任务3固定分区评测；默认只构建样本，显式--run-model才调用真实模型。

标签、SQL、官方evidence和目标系统回复只供评分，不进入生产输入。
CoSQL原生用户标签与下一系统轮CLARIFY分别统计；首选项模拟只作状态机诊断。

报告可靠性契约：
- 纯构建与--dry-run只打印摘要，不写任何文件、不加载LLM/config；
- 模型运行按--run-id存于REPORT的runs[run-id]：manifest冻结输入/标签/参数/源hash/
  生产代码hash/模型安全身份与预算；逐结果原子checkpoint（临时文件+替换，单写者锁）；
- 旧顶层legacy字段保留不被新run覆盖；同run-id指纹不一致拒绝混用；
- 起跑前预置全部计划ID为not_attempted；鉴权/参数或模型重试耗尽即停止新增提交，
  已在途结果收尾保存；technical_error保留在分母；未运行与已失败分列；
- Windows原子replace容错：_save_run_unlocked仅对PermissionError(winerror 5/32/33)
  最多5次短退避后重试，重用同一序列化临时文件；其它错误立即抛出且不覆盖原错误。

最小子集模式（evaluation/task3_sampling.py，模块级import避免循环）：
- --create-subset-manifest [PATH]：纯构建子集清单（默认test_cases/task3_subset_manifest_v1.json），
  不发任何模型调用；已有清单且重抽不一致时拒绝覆盖；
- --subset-manifest PATH：只读校验+筛选（源hash/选择器代码/逐样本hash/数量），
  与--limit非0、非all split、非all-turns、BIRD数据集互斥冲突即报错退出；
- --report PATH：仅显式指定时替换本进程REPORT，默认保持模块常量不动。
"""
import argparse
import hashlib
import json
import os
import sys
import threading
import time
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
ROOT = HERE.parent
COSQL = ROOT / "data/raw/cosql/original/cosql_dataset/cosql_all_info_dialogs.json"
ZH_CASES = HERE / "test_cases/task3_zh.json"
BIRD = ROOT / "data/raw/bird/original/minidev/MINIDEV/mini_dev_postgresql.json"
REPORT = HERE / "evaluation/reports/optimization_task3_20261010.json"
SPLIT_VERSION = "task3-dialog-hash-v1"
WORKERS = 2            # 真实API并发固定为2；队列只允许最多2个future在途
EXIT_STOPPED = 3       # 运行中止（鉴权/模型故障/键盘中断）
EXIT_CONFLICT = 2      # manifest冲突或参数错误
# 参与生产行为的关键代码；任一文件变更必须开新run-id（manifest拒绝混用）
PROD_CODE_PATHS = [
    "backend/core/intent/prompts.py",
    "backend/core/intent/service.py",
    "backend/core/intent/policy.py",
    "backend/core/intent/contracts.py",
    "backend/core/intent/schema_context.py",
    "backend/core/llm_client.py",
    "backend/config.py",
    "backend/agents/task3_clarification/dialog_manager.py",
    "backend/agents/task3_clarification/ambiguity_detector.py",
    "backend/agents/task3_clarification/necessity_judge.py",
]

_report_lock = threading.Lock()  # 报告单写者锁


def digest(value) -> str:
    """按完整规范化内容计算指纹；指纹仅进报告，不进模型提示。"""
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def fixed_split(dataset: str, group: str) -> str:
    """按对话分组固定划分；不使用金标、题型或模型输出挑选分区。"""
    key = hashlib.sha256(f"{SPLIT_VERSION}:{dataset}:{group}".encode()).hexdigest()
    return "debug" if int(key[:8], 16) % 5 == 0 else "heldout"


@dataclass(frozen=True)
class EvalInput:
    """生产侧白名单输入；不持有评分字段或目标回复。"""

    question: str
    database: str
    history: tuple = ()

    def payload(self) -> dict:
        return {"question": self.question, "database": self.database,
                "history": [dict(h) for h in self.history]}


@dataclass(frozen=True)
class EvalCase:
    """评测侧标签与生产输入分离；case_id不传给模型。"""

    case_id: str
    dataset: str
    split: str
    model_input: EvalInput
    labels: tuple
    primary_label: str
    expect_clarify: bool | None
    system_clarify: bool | None = None
    history_truncated: bool = False

    def sample_hash(self) -> str:
        return digest({"id": self.case_id, "input": self.model_input.payload(),
                       "labels": self.labels, "system_clarify": self.system_clarify})


def _primary(labels) -> str | None:
    """多标签策略固定：不可回答优先，随后歧义、完整请求；保留全部原生标签。"""
    for label in ("CANNOT_ANSWER", "AMBIGUOUS", "INFORM_SQL", "CANNOT_UNDERSTAND"):
        if label in labels:
            return label
    return None


def _history(turns: list, stop: int) -> tuple:
    """只取先前用户原文与先前澄清话语，排除SQL、结果确认和未来系统回复。"""
    prior = []
    for i, turn in enumerate(turns[:stop]):
        text = (turn.get("text") or "").strip()
        if not text or turn.get("isSql"):
            continue
        if turn.get("isUser"):
            role = "user"
        elif "CLARIFY" in (turn.get("label") or []):
            role = "assistant"
        else:
            continue
        prior.append({"id": f"history_eval_{i}", "role": role, "text": text})
    # 只使用固定预算，不用金标推测哪些历史最重要。
    selected = prior[-8:]
    while sum(len(h["text"]) for h in selected) > 16000:
        selected.pop(0)
    return tuple(selected), len(selected) != len(prior)


def build_cosql_cases(data: dict, *, all_turns: bool = False) -> list:
    """从all_info的原生轮次构建样本，不从query_goal或SQL重写问题。"""
    cases = []
    for dialog_key, item in sorted(data.items()):
        turns = item.get("turns") or []
        users = [i for i, t in enumerate(turns) if t.get("isUser")]
        for i in users if all_turns else users[:1]:
            turn = turns[i]
            question = (turn.get("text") or "").strip()
            labels = tuple(sorted(set(turn.get("label") or [])))
            primary = _primary(labels)
            if not question or primary is None:
                continue
            system = next((t for t in turns[i + 1:] if not t.get("isSql")), None)
            response_label = None if system is None or system.get("isUser") or not system.get("label") else (
                "CLARIFY" in system["label"])
            prior, truncated = _history(turns, i)
            cases.append(EvalCase(
                f"cosql:{dialog_key}:{i}", "cosql", fixed_split("cosql", dialog_key),
                EvalInput(question, item["db_id"], prior), labels, primary,
                True if primary == "AMBIGUOUS" else False if primary == "INFORM_SQL" else None,
                response_label, truncated))
    return cases


def build_zh_cases(data: list) -> list:
    """原有20条标注原样冻结；近邻对照题按标识成对放入同一分区。"""
    cases = []
    for item in data:
        number = int(item["id"].rsplit("-", 1)[1])
        group = str((number + 1) // 2)
        cases.append(EvalCase(item["id"], "zh", fixed_split("zh", group),
                              EvalInput(item["question"], item.get("database", "chinook")),
                              ("MANUAL_ZH",), "MANUAL_ZH", item["expect_clarify"]))
    return cases


def build_bird_cases(data: list, complete_ids=()) -> list:
    """评测唯一ID=序号:库:题号；500中重复的题号（如137/138）禁止裸qid静默选2题。

    complete_ids接受无歧义裸qid或完整case_id（序号:库:题号）；未审核题只计构建覆盖。
    """
    entries = ([s.strip() for s in complete_ids.split(",") if s.strip()]
               if isinstance(complete_ids, str) else [str(x) for x in complete_ids])
    full_keys = {(str(i), str(it["db_id"]), str(it["question_id"])) for i, it in enumerate(data)}
    qid_map: dict[str, list] = {}
    for i, it in enumerate(data):
        qid_map.setdefault(str(it["question_id"]), []).append(i)
    resolved, not_found, ambiguous = set(), [], []
    for entry in entries:
        if entry.count(":") == 2:
            # 完整case_id=序号:库:题号
            key = tuple(entry.split(":"))
            if key not in full_keys:
                not_found.append(entry)
            else:
                resolved.add(key)
        elif ":" in entry:
            not_found.append(entry)
        else:
            idxs = qid_map.get(entry, [])
            if not idxs:
                not_found.append(entry)
            elif len(idxs) > 1:
                ambiguous.append(entry)
            else:
                resolved.add((str(idxs[0]), str(data[idxs[0]]["db_id"]), entry))
    if not_found:
        raise ValueError(f"指定的BIRD ID不存在于数据：{sorted(not_found)}")
    if ambiguous:
        raise ValueError(f"BIRD题号{sorted(ambiguous)}在数据中重复且裸qid有歧义；"
                         f"请改用完整ID（序号:库:题号），不得静默任选其一")
    cases = []
    for i, item in enumerate(data):
        key = (str(i), str(item["db_id"]), str(item["question_id"]))
        selected = key in resolved
        cases.append(EvalCase(f"bird:{key[0]}:{key[1]}:{key[2]}", "bird",
                              fixed_split("bird", key[2]),
                              EvalInput(item["question"], item["db_id"]), (),
                              "COMPLETE_CONTROL" if selected else "UNADJUDICATED",
                              False if selected else None))
    return cases


def score_case(case: EvalCase, record: dict) -> bool | None:
    """主指标包含失败；未审核题不造标签或准确率。"""
    if case.primary_label == "UNADJUDICATED":
        return None
    if not record["ok"]:
        return False
    if case.primary_label == "CANNOT_ANSWER":
        return record["status"] == "unanswerable"
    if case.primary_label == "CANNOT_UNDERSTAND":
        return record["status"] in {"needs_user", "undecided"}
    if case.expect_clarify:
        return record["need_clarify"] is True
    return record["need_clarify"] is False and record["status"] == "ready"


def run_case(case: EvalCase, *, client_factory=None, diagnose_first_option=False,
             prior_record: dict | None = None, system_prompt: str | None = None) -> dict:
    """每case独立IntentService与SchemaContext；HTTP重试完全由公共客户端负责，不套外层。

    prior_record=同run前一次基础设施故障记录：保留其首次故障分类与耗时历史，
    本次结果不偷换故障事实；语义评分已完成的记录由调度层跳过，不进这里。
    system_prompt=可选显式提示覆盖（评测候选对照用）；None=模块常量现行为不变。
    failure_stage仅在invalid_model_output时从本case实例的私有诊断抄送，不外泄模型原文。
    """
    from backend.core.history.store import HistoryMessage
    from backend.core.intent import IntentRequest, IntentService
    from backend.core.llm_client import LLMClient
    from backend.agents.task3_clarification.dialog_manager import DialogManager

    t0 = time.perf_counter()
    record = {"case_id": case.case_id, "dataset": case.dataset, "split": case.split,
              "sample_hash": case.sample_hash(), "primary_label": case.primary_label,
              "native_labels": list(case.labels), "system_clarify_gold": case.system_clarify,
              "expect_clarify": case.expect_clarify,
              "ok": False, "status": "tool_error", "need_clarify": None,
              "actual_turns": 0, "reason": "technical_error", "error": None,
              "failure_stage": None,
              "state_machine_diagnostic": None, "http_attempts": None,
              "history_truncated": case.history_truncated}
    if prior_record:
        # 保留前一次基础设施故障的分类与耗时历史，续跑结果叠加而不是覆盖
        record["prior_error"] = prior_record.get("error")
        record["prior_latency_s"] = prior_record.get("latency_s")
        record["retry_count"] = int(prior_record.get("retry_count", 0)) + 1
    try:
        client = (client_factory or LLMClient)()
        # 评分字段永不进入构造请求、历史或生产服务的调用参数。
        payload = case.model_input.payload()
        history = [HistoryMessage(h["id"], "eval", "prior", i, h["role"], h["text"])
                   for i, h in enumerate(payload["history"])]
        request = IntentRequest(question=payload["question"], database=payload["database"])
        # 每case独立IntentService；system_prompt覆盖显式传入（None=模块常量现行为）
        service = IntentService(client, system_prompt=system_prompt)
        context = service.schema_provider.resolve(request.database)
        result = service.analyze(request, history=history, schema_context=context)
        record["schema_version"] = context.version
        record["schema_truncated"] = context.truncated
        if result.ok:
            dialog = DialogManager(case.case_id, request.question, client, context.index,
                                   interpretation=result.interpretation, schema_context=context.to_dict())
            out = dialog.step(None)
            record.update({"ok": out["status"] != "tool_error", "status": out["status"],
                           "need_clarify": out["need_clarify"], "actual_turns": out["actual_turns"],
                           "reason": out["reason"]})
            record["trigger"] = {key: out["clarify"][key] for key in ("kind", "dimension", "goal_id", "requirement_id")} if out.get("clarify") else None
            if diagnose_first_option and out["need_clarify"]:
                diagnosis = out
                while diagnosis["need_clarify"]:
                    options = (diagnosis.get("clarify") or {}).get("options") or []
                    if not options:
                        break
                    diagnosis = dialog.step(options[0])
                record["actual_turns"] = diagnosis["actual_turns"]
                record["state_machine_diagnostic"] = {
                    "status": diagnosis["status"], "actual_turns": diagnosis["actual_turns"],
                    "ready": diagnosis["status"] == "ready" and diagnosis["final_ready"],
                    "semantic_correctness": None}
        else:
            record["error"] = result.error_code
            # 仅invalid_model_output时抄送本实例私有失败阶段（受控字符串，不泄模型原文）
            if result.error_code == "invalid_model_output":
                record["failure_stage"] = service.last_failure_stage
    except Exception as exc:
        # 只记录异常类型，避免模型正文、连接信息或密钥写入报告；鉴权/配置故障显式标记。
        message = str(exc)
        record["error"] = "auth_or_config" if ("API 密钥" in message or "未配置" in message) \
            else type(exc).__name__
    record["latency_s"] = round(time.perf_counter() - t0, 6)
    record["hit"] = score_case(case, record)
    return record


def summarize(records: list) -> dict:
    """原生用户标签分组及系统澄清行为分开计分；技术失败保留在分母。

    not_attempted占位不进任何准确率分母；未运行与已失败在planned_n/attempted_n分列。
    双分母：correct_over_planned用固定计划分母，accuracy_attempted用已评分分母，
    旧accuracy键仅等于accuracy_attempted，禁止当作全量成绩。
    """
    live = [r for r in records if r.get("status") != "not_attempted"]
    groups = {}
    for label in sorted({r["primary_label"] for r in live}):
        subset = [r for r in live if r["primary_label"] == label]
        scored = [r for r in subset if r["hit"] is not None]
        groups[label] = {"n": len(subset), "scored_n": len(scored),
                         "correct": sum(r["hit"] is True for r in scored),
                         "accuracy": sum(r["hit"] is True for r in scored) / len(scored) if scored else None,
                         "technical_failed": sum(not r["ok"] for r in subset)}
    dataset_metrics = {}
    for dataset in sorted({r.get("dataset", "unknown") for r in live}):
        subset = [r for r in live if r.get("dataset", "unknown") == dataset]
        positive = [r for r in subset if r.get("expect_clarify") is True]
        negative = [r for r in subset if r.get("expect_clarify") is False]
        dataset_metrics[dataset] = {
            "n": len(subset), "technical_failed": sum(not r["ok"] for r in subset),
            "necessary_n": len(positive), "necessary_recalled": sum(r["ok"] and r["need_clarify"] is True for r in positive),
            "complete_n": len(negative), "unnecessary_questions": sum(r["need_clarify"] is True for r in negative),
            "complete_ready": sum(r["ok"] and r["status"] == "ready" for r in negative),
        }
    partitions = {}
    for part in sorted({r.get("split", "unknown") for r in records}):
        subset_all = [r for r in records if r.get("split") == part]
        subset_live = [r for r in live if r.get("split") == part]
        partitions[part] = {"planned_n": len(subset_all), "attempted_n": len(subset_live),
                            "not_attempted_n": len(subset_all) - len(subset_live),
                            "technical_failed": sum(not r["ok"] for r in subset_live)}
    system = [r for r in live if r.get("system_clarify_gold") is not None]
    positive = [r for r in system if r["system_clarify_gold"]]
    negative = [r for r in system if not r["system_clarify_gold"]]
    not_attempted_n = len(records) - len(live)
    planned_n = len(records)
    scored = [r for r in live if r["hit"] is not None]
    correct = sum(r["hit"] is True for r in scored)
    return {"groups": groups, "by_dataset": dataset_metrics, "partitions": partitions,
            "coverage": coverage(records),
            "system_CLARIFY": {
                "positive_n": len(positive), "recalled": sum(r["ok"] and r["need_clarify"] is True for r in positive),
                "negative_n": len(negative), "unnecessary": sum(r["need_clarify"] is True for r in negative),
                "technical_failed": sum(not r["ok"] for r in system)},
            "mean_latency_s": sum(r["latency_s"] for r in live) / len(live) if live else None,
            "planned_n": planned_n, "attempted_n": len(live),
            "not_attempted_n": not_attempted_n,
            "correct_over_planned": correct / planned_n if planned_n else None,
            "accuracy_attempted": correct / len(scored) if scored else None,
            "accuracy_scope": "accuracy_attempted只覆盖已评分题，不是固定计划分母的全量成绩",
            "completion_rate": len(live) / planned_n if planned_n else None,
            "state_machine_diagnostics_are_semantic_scores": False}


# ---------------------------------------------------------------- 报告可靠性

def prod_code_hashes() -> dict:
    """关键生产代码内容指纹；身份变更必须开新run-id。"""
    return {rel: digest((HERE / rel).read_text(encoding="utf-8")) for rel in PROD_CODE_PATHS}


def _selector_code_hash() -> str:
    """采样器模块自身代码指纹；采样器代码变更必须重建清单（经--subset-manifest校验）。"""
    return digest((HERE / "evaluation" / "task3_sampling.py").read_text(encoding="utf-8"))


def _check_subset_conflicts(args, parser) -> None:
    """子集模式硬冲突检查：BIRD未审核不选、必须all-turns、split all、禁止limit截断。"""
    conflicts = []
    if set(args.datasets) != {"zh", "cosql"}:
        conflicts.append("子集模式仅支持--datasets zh cosql（BIRD未审核不选）")
    if args.split != "all":
        conflicts.append("子集模式要求--split all")
    if not args.all_turns:
        conflicts.append("子集模式要求--all-turns（清单基于全部有效轮构建）")
    if args.limit != 0:
        conflicts.append("子集模式禁止非零--limit截断（清单已按整对话定分母）")
    if conflicts:
        parser.error("子集清单冲突：" + "；".join(conflicts))


def _resolve_prompt_variant(args) -> tuple[str, str | None]:
    """--prompt-variant仅从可信候选常量取提示，不接受用户自由文本。

    返回(variant_name, system_prompt)：current=None（模块常量现行为），
    light=light_prompts候选常量。候选模块代码hash随manifest冻结。
    """
    variant = getattr(args, "prompt_variant", "current")
    if variant == "current":
        return "current", None
    if variant == "light":
        import evaluation.candidates.light_prompts as lp
        return "light", lp.LIGHT_INTENT_SYSTEM_PROMPT
    raise ValueError(f"未知prompt-variant{variant}；仅支持current/light可信候选常量")


def _prompt_variant_hashes(variant: str, system_prompt: str | None) -> dict:
    """冻结实际system文本hash、variant名、候选模块代码hash与完整Pydantic schema内容hash。

    current的实际system文本=生产模块常量SYSTEM_PROMPT（哈希时读取，冻结该时刻文本）；
    light=可信候选常量；候选模块代码hash=候选py文件内容指纹（同ID混用即拒绝）。
    """
    from backend.core.intent.contracts import Interpretation
    import backend.core.intent.service as svc
    schema_hash = digest(json.dumps(Interpretation.model_json_schema(), ensure_ascii=False,
                                    sort_keys=True))
    candidate_code_hash = None
    if system_prompt is not None:
        import evaluation.candidates.light_prompts as lp
        # 候选模块代码hash：候选py源文件内容指纹（非提示常量）
        candidate_code_hash = digest(Path(lp.__file__).read_text(encoding="utf-8"))
        body = system_prompt
    else:
        body = svc.SYSTEM_PROMPT
    return {"variant": variant, "system_prompt_hash": digest(body),
            "candidate_code_hash": candidate_code_hash, "schema_content_hash": schema_hash}


def build_manifest(cases: list, *, args, source_hashes: dict, model_provider: dict) -> dict:
    """冻结本run全部可变要素；resume续跑指纹必须逐字段一致，禁止跨版本迁移。

    自评代码指纹一并纳入：改评分/构建函数即改指纹，旧run不可续跑。
    """
    bird_ids = [s.strip() for s in args.bird_ids.split(",") if s.strip()]
    subset_info = None
    if getattr(args, "subset_manifest", None):
        # 新run的manifest额外冻结：子集清单文件内容hash、选择器代码hash与实际cases数
        manifest_path = Path(args.subset_manifest).resolve()
        content = json.loads(manifest_path.read_text(encoding="utf-8"))
        subset_info = {"path": str(manifest_path), "file_hash": digest(content),
                       "selector_code_hash": _selector_code_hash(),
                       "subset_case_count": len(content.get("cases", {})),
                       "subset_manifest_hash": content.get("manifest_hash")}
    fields = {
        "split": args.split, "datasets": list(args.datasets), "all_turns": args.all_turns,
        "limit": args.limit, "diagnose_first_option": args.diagnose_first_option,
        "bird_ids": sorted(bird_ids),
        "subset_manifest": subset_info,
        "prompt_variant": _prompt_variant_hashes(*_resolve_prompt_variant(args)),
        "source_hashes": source_hashes, "prod_code_hashes": prod_code_hashes(),
        # 评分与构建函数自身代码指纹；改eval_clarify即换新run-id
        "self_code_hash": digest(Path(__file__).read_text(encoding="utf-8")),
        "model_provider": model_provider,
        "samples": [c.sample_hash() for c in cases],
    }
    manifest = dict(fields)
    manifest["manifest_hash"] = digest(fields)
    return manifest


def model_identity() -> dict:
    """启动时冻结的模型身份：真正resolved的provider/model（auto必落具体供应商），
    端点仅存16位摘要、密钥不写不hash；含超时/思考配置与重试预算。仅经Settings加载。"""
    from backend.config import get_settings
    settings = get_settings()

    def table(name: str) -> dict:
        rows = {"zhipu": (settings.zhipu_base_url, settings.default_model),
                "siliconflow": (settings.siliconflow_base_url, settings.siliconflow_chat_model),
                "qwen": (settings.qwen_base_url, settings.default_model),
                "anna": (settings.anna_base_url, settings.anna_chat_model),
                "wb": (settings.wb_base_url, settings.wb_chat_model)}
        base_url = rows[name][0].rstrip("/")
        if name == "wb" and not base_url.endswith("/v1"):
            base_url += "/v1"
        key = {"zhipu": settings.zhipu_api_key, "siliconflow": settings.siliconflow_api_key,
               "qwen": settings.qwen_api_key, "anna": settings.anna_api_key,
               "wb": settings.wb_api_key}[name]
        return {"name": name, "base_url": base_url, "model": rows[name][1], "api_key": key}

    if settings.llm_provider != "auto":
        provider = table(settings.llm_provider)
        if not provider["api_key"]:
            raise ValueError(f"已指定供应商 {provider['name']} 但未配置密钥")
    else:
        # auto：按密钥可用性选择具体供应商，manifest不允许存None模型
        provider = next((table(n) for n in ("zhipu", "siliconflow", "qwen") if table(n)["api_key"]),
                        None)
        if provider is None:
            raise ValueError("auto供应商未配置任何密钥，无法冻结模型身份")
    return {"provider": provider["name"],
            "model_name": provider["model"],
            "model_identifier": hashlib.sha256(str(provider["model"]).encode()).hexdigest()[:16],
            "endpoint_identifier": hashlib.sha256(provider["base_url"].encode()).hexdigest()[:16],
            "request_timeout_s": settings.llm_request_timeout,
            "reasoning_effort": settings.anna_reasoning_effort if provider["name"] == "anna" else None,
            "max_extra_http_retries": settings.llm_max_retries}


# 基础设施故障类别；语义评分完成（ok或invalid_model_output）不在此列
HARD_STOP_ERRORS = {"model_unavailable", "auth_or_config"}


def load_report(report: Path) -> dict:
    if not report.exists():
        return {"runs": {}}
    data = json.loads(report.read_text(encoding="utf-8"))
    data.setdefault("runs", {})
    return data


def preseed_records(cases: list) -> dict:
    """起跑前预置全部计划ID为not_attempted；未运行与已失败分列，留分母不消失。"""
    return {c.case_id: {"case_id": c.case_id, "dataset": c.dataset, "split": c.split,
                       "primary_label": c.primary_label, "sample_hash": c.sample_hash(),
                       "expect_clarify": c.expect_clarify, "system_clarify_gold": c.system_clarify,
                       "status": "not_attempted", "ok": False, "hit": None,
                       "need_clarify": None, "actual_turns": 0, "reason": "not_attempted",
                       "error": None, "http_attempts": None,
                       "history_truncated": c.history_truncated, "latency_s": 0}
            for c in cases}


def validate_records(records: dict, preseed: dict) -> None:
    """记录键、样本hash、数据集/分区一致性校验；拒绝额外记录与串样本。"""
    extra = set(records) - set(preseed)
    if extra:
        raise ValueError(f"报告出现计划外记录，拒绝分母膨胀：{sorted(extra)[:3]}")
    for cid, base in preseed.items():
        rec = records.get(cid)
        if rec is None:
            raise ValueError(f"计划记录{cid}缺失")
        if rec.get("sample_hash") != base["sample_hash"]:
            raise ValueError(f"{cid}样本hash不一致，疑似串样本")
        if (rec.get("dataset"), rec.get("split")) != (base["dataset"], base["split"]):
            raise ValueError(f"{cid}数据集或分区与预置不一致")
        required = {"case_id", "status", "ok", "hit", "need_clarify", "primary_label", "error", "latency_s"}
        missing = required - set(rec)
        if missing:
            raise ValueError(f"{cid}记录缺少键{sorted(missing)}")


def attach_run(report_data: dict, run_id: str, manifest: dict, preseed: dict) -> dict:
    """同run-id指纹不一致拒绝；旧无manifest且带records的run拒绝续跑。"""
    run = report_data["runs"].get(run_id)
    if run is None:
        run = {"manifest": manifest, "records": dict(preseed), "status": "running"}
        report_data["runs"][run_id] = run
        return run
    if "manifest" not in run:
        if run.get("records"):
            raise ValueError(f"run {run_id} 为旧版无manifest记录，拒绝追加，请换新run-id")
        run["manifest"] = manifest
    elif run["manifest"] != manifest:
        raise ValueError(f"run {run_id} 的manifest指纹与本次不一致；禁止跨版本迁移已完成记录，请换新run-id")
    for cid, rec in preseed.items():
        run["records"].setdefault(cid, rec)
    return run


def acquire_report_lock(report: Path) -> Path:
    """跨进程独占报告锁：O_EXCL原子创建，整个run持有、结束时释放；第二写者拒绝，不动旧legacy。"""
    lock = report.with_suffix(".lock")
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(f"{os.getpid()}\n")
    return lock


def release_report_lock(report: Path) -> None:
    lock = report.with_suffix(".lock")
    try:
        lock.unlink()
    except FileNotFoundError:
        pass


def checkpoint_report(report: Path, run_id: str, manifest: dict, preseed: dict,
                      record: dict, progress: str = "") -> None:
    """主线程逐结果保存并刷新进度；即使整批未完成，已完成记录与分母均已落盘。"""
    with _report_lock:
        data = load_report(report)
        run = attach_run(data, run_id, manifest, preseed)
        if record is not None:
            run["records"][record["case_id"]] = record
        _save_run_unlocked(report, data)
        if progress:
            print(progress, flush=True)


_WIN_LOCK_ERRORS = {5, 32, 33}   # 拒绝访问/文件被占用/共享冲突；仅对此类做短退避


def _replace_report_file(tmp: Path, report: Path, payload: str) -> None:
    """Windows原子replace容错：仅对PermissionError(winerror 5/32/33)最多5次短退避，
    每次重试前重写同一份序列化payload；其它错误立即原样抛出。"""
    attempts = 0
    while True:
        tmp.write_text(payload, encoding="utf-8")
        try:
            os.replace(tmp, report)
            return
        except PermissionError as exc:
            if getattr(exc, "winerror", None) not in _WIN_LOCK_ERRORS or attempts >= 5:
                raise
            attempts += 1
            time.sleep(0.05 * attempts)


def _save_run_unlocked(report: Path, data: dict) -> None:
    """锁内原子写：临时文件名含本进程PID（每进程独立、互不覆盖），替换后清自身临时文件。

    临时文件清理失败（OSError）绝不覆盖主流程原错误；清理成功与否不影响结果。
    """
    tmp = report.with_name(f"{report.name}.{os.getpid()}.tmp")
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    try:
        _replace_report_file(tmp, report, payload)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                # 残留临时文件由run收尾清理兜底；此处清理失败不得吞掉/覆盖原错误
                pass


def is_hard_stop(record: dict) -> bool:
    """鉴权/配置或模型重试耗尽立即停；纯invalid_model_output是语义格式错，不中止全量。"""
    return record.get("error") in HARD_STOP_ERRORS


def _submit_batch(pool, queue: list, in_flight: dict, client_factory, diagnose: bool,
                  prior: dict, system_prompt: str | None = None) -> None:
    """最多WORKERS个future在途：只从队列提交到上限，队列本身不消耗模型预算。"""
    while queue and len(in_flight) < WORKERS:
        case = queue.pop(0)
        in_flight[pool.submit(run_case, case, client_factory=client_factory,
                              diagnose_first_option=diagnose,
                              prior_record=prior.get(case.case_id),
                              system_prompt=system_prompt)] = case


def coverage(records) -> dict:
    """计划分母覆盖率：各组同时给planned/attempted/not_attempted与失败计数；
    未运行题不伪造技术失败或准确率，但不出现在覆盖分母之外。"""
    if not isinstance(records, dict):
        records = {i: r for i, r in enumerate(records)}

    def section(keyfn) -> dict:
        acc: dict = {}
        for rec in records.values():
            bucket = acc.setdefault(keyfn(rec), {"planned_n": 0, "attempted_n": 0, "not_attempted_n": 0,
                                                 "technical_failed": 0, "missed_necessary_clarify": 0,
                                                 "unnecessary_questions": 0})
            bucket["planned_n"] += 1
            if rec.get("status") == "not_attempted":
                bucket["not_attempted_n"] += 1
                continue
            bucket["attempted_n"] += 1
            if not rec["ok"]:
                bucket["technical_failed"] += 1
            if rec.get("expect_clarify") is True and rec.get("need_clarify") is not True:
                bucket["missed_necessary_clarify"] += 1
            if rec.get("expect_clarify") is False and rec.get("need_clarify") is True:
                bucket["unnecessary_questions"] += 1
        return acc
    return {"by_group": section(lambda r: r["primary_label"]),
            "by_dataset": section(lambda r: r.get("dataset", "unknown")),
            "by_partition": section(lambda r: r.get("split", "unknown"))}


# ---------------------------------------------------------------- 构建统计

def build_stats(data_map: dict, all_turns: bool, cases: list) -> dict:
    """无模型构建即输出原对话/用户轮/有效样本/按原生标签排除统计，不许靠过滤削分母。"""
    stats: dict = {}
    if "cosql" in data_map:
        raw = data_map["cosql"]
        eligible = excluded_reasons = 0
        for item in raw.values():
            users = [i for i, t in enumerate(item.get("turns") or []) if t.get("isUser")]
            for i in users if all_turns else users[:1]:
                turn = item["turns"][i]
                primary = _primary(tuple(sorted(set(turn.get("label") or []))))
                if (turn.get("text") or "").strip() and primary is not None:
                    eligible += 1
                else:
                    excluded_reasons += 1
        users_total = sum(len([i for i, t in enumerate(item.get("turns") or []) if t.get("isUser")])
                          for item in raw.values())
        stats["cosql"] = {"dialogs_total": len(raw),
                          "dialogs_with_valid_sample": len({c.case_id.rsplit(":", 1)[0] for c in cases if c.dataset == "cosql"}),
                          "user_turns_in_scope": sum(1 for c in cases if c.dataset == "cosql"),
                          "user_turns_all": users_total,
                          "eligible_samples": eligible,
                          "excluded_by_native_rule": excluded_reasons}
    if "bird" in data_map:
        bird = [c for c in cases if c.dataset == "bird"]
        stats["bird"] = {"cases_total": len(bird),
                         "unadjudicated": sum(c.primary_label == "UNADJUDICATED" for c in bird),
                         "complete_control": sum(c.primary_label == "COMPLETE_CONTROL" for c in bird)}
    runnable = [c for c in cases if c.primary_label != "UNADJUDICATED"]
    stats["totals"] = {"built": len(cases), "runnable": len(runnable),
                       "excluded_unadjudicated": len(cases) - len(runnable)}
    return stats


def _build_cases(args):
    """构建三数据集案例；返回(cases, source_hashes, data_map)，纯本地无网络。"""
    cases, source_hashes, data_map = [], {}, {}
    for dataset in args.datasets:
        path = {"zh": ZH_CASES, "cosql": COSQL, "bird": BIRD}[dataset]
        data = json.loads(path.read_text(encoding="utf-8"))
        source_hashes[dataset] = digest(data)
        data_map[dataset] = data
        if dataset == "zh":
            cases.extend(build_zh_cases(data))
        elif dataset == "cosql":
            cases.extend(build_cosql_cases(data, all_turns=args.all_turns))
        else:
            cases.extend(build_bird_cases(
                data, ",".join(sorted(set(s.strip() for s in args.bird_ids.split(",") if s.strip())))))
    cases = sorted((c for c in cases if args.split == "all" or c.split == args.split),
                   key=lambda c: c.case_id)
    return cases, source_hashes, data_map


def _print_summary(cases: list, stats: dict, source_hashes: dict) -> None:
    totals = stats["totals"]
    print(f"构建：{totals['built']}条，可评分{totals['runnable']}条，"
          f"排除未审核{totals['excluded_unadjudicated']}条（仅计构建覆盖不计准确率）")
    if "cosql" in stats:
        cs = stats["cosql"]
        print(f"CoSQL：对话{cs['dialogs_total']}个（有效样本覆盖{cs['dialogs_with_valid_sample']}），"
              f"范围内用户轮{cs['user_turns_in_scope']}（全部对话用户轮{cs['user_turns_all']}），"
              f"有效样本{cs['eligible_samples']}，按原生标签规则排除{cs['excluded_by_native_rule']}")
        print("原生用户标签分布：" + json.dumps(
            dict(Counter(label for c in cases if c.dataset == "cosql" for label in c.labels)),
            ensure_ascii=False))
    if "bird" in stats:
        bs = stats["bird"]
        print(f"BIRD：{bs['cases_total']}题，未审核{bs['unadjudicated']}（不作负例成绩），"
              f"已审核负例{bs['complete_control']}")
    print("中文20例为人工冻结标注；英文成绩不作中文能力证明")
    print("源数据hash：" + json.dumps(source_hashes, ensure_ascii=False))


def _pending_cases(saved: dict, runnable: list) -> tuple[list, dict]:
    """resume规则：语义评分已完成（ok或非故障类别）不重跑；
    仅基础设施故障（HARD_STOP_ERRORS）或not_attempted的case在续跑时重试，
    并把前一次故障记录作为prior传入以保留分类与耗时历史，不偷换故障事实。"""
    pending, prior = [], {}
    for c in runnable:
        rec = saved.get(c.case_id) or {}
        status = rec.get("status")
        if status == "not_attempted" or rec.get("error") in HARD_STOP_ERRORS:
            pending.append(c)
            if status != "not_attempted":
                prior[c.case_id] = rec
    return pending, prior


def _run_model(args, cases: list, runnable: list, source_hashes: dict) -> int:
    """模型运行：跨进程独占报告锁→预置计划ID→最多2在途→主线程逐结果原子checkpoint
    →故障设stop_requested明确停止外层提交，收尾仅已提交的在途结果；仍故障必须非0。"""
    manifest = build_manifest(cases, args=args, source_hashes=source_hashes,
                              model_provider=model_identity())
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    preseed = preseed_records(runnable)
    try:
        acquire_report_lock(REPORT)
    except FileExistsError:
        print(f"报告锁被另一进程持有：{REPORT.with_suffix('.lock')}；拒绝第二写者，请等待其结束")
        return EXIT_CONFLICT
    exit_code = 0
    try:
        # 先内存校验manifest与记录一致性；冲突不写盘（启动占位写在校验之后）
        data = load_report(REPORT)
        try:
            attach_run(data, args.run_id, manifest, preseed)
            validate_records(data["runs"][args.run_id]["records"], preseed)
        except ValueError as exc:
            print(f"manifest或记录校验冲突：{exc}")
            return EXIT_CONFLICT
        # 启动占位先写盘：预置全部计划ID为not_attempted
        checkpoint_report(REPORT, args.run_id, manifest, preseed, None)
        saved = load_report(REPORT)["runs"][args.run_id]["records"]
        pending, prior = _pending_cases(saved, runnable)
        resume_n = len(prior)
        print(f"run {args.run_id}：计划{len(runnable)}题，本次待完成{len(pending)}题"
              f"（含{resume_n}题基础设施故障重试；语义已完成题按manifest跳过）")

        def default_factory():
            from backend.core.llm_client import LLMClient
            return LLMClient()

        queue, in_flight = list(pending), {}
        stop_requested = False
        stop_reason = None
        started = time.perf_counter()
        variant_name, variant_prompt = _resolve_prompt_variant(args)
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            try:
                while queue or in_flight:
                    if not stop_requested:
                        _submit_batch(pool, queue, in_flight, default_factory,
                                      args.diagnose_first_option, prior,
                                      system_prompt=variant_prompt)
                    if not in_flight:
                        break
                    done, _ = wait(list(in_flight), return_when=FIRST_COMPLETED)
                    for fut in done:
                        case = in_flight.pop(fut)
                        record = fut.result()  # run_case内部已兜底全部异常
                        checkpoint_report(REPORT, args.run_id, manifest, preseed, record,
                                          progress=f"[{case.case_id}] 状态={record['status']} "
                                                   f"判定={'对' if record['hit'] is True else '错' if record['hit'] is False else '—'}")
                        if is_hard_stop(record):
                            # 鉴权/参数或模型重试耗尽：明确停止外层新增提交；
                            # 队列中未提交题保持not_attempted，仅已在途结果收尾保存
                            stop_requested = True
                            stop_reason = f"hard_stop:{record['error']}"
                            break
            except KeyboardInterrupt:
                stop_requested = True
                stop_reason = "keyboard_interrupt"
            finally:
                # 收尾：仅已提交的在途结果等待并逐条保存；收尾再遇故障同样保持非0
                for fut in list(in_flight):
                    case = in_flight.pop(fut)
                    record = fut.result()
                    checkpoint_report(REPORT, args.run_id, manifest, preseed, record)
                    if is_hard_stop(record):
                        stop_requested = True
                        stop_reason = stop_reason or f"hard_stop:{record['error']}"
                data = load_report(REPORT)
                run = data["runs"][args.run_id]
                validate_records(run["records"], preseed)
                all_records = [run["records"][c.case_id] for c in runnable]
                pending_n = sum(r.get("status") == "not_attempted" for r in all_records)
                unresolved_hard = any(
                    r.get("error") in HARD_STOP_ERRORS for r in all_records
                    if r.get("status") != "not_attempted")
                if pending_n or unresolved_hard:
                    # 未运行或仍有未恢复的基础故障：禁止completed，仍故障必须非0
                    run["status"] = "stopped" if (stop_requested or unresolved_hard) else "incomplete"
                    run["stop_reason"] = stop_reason or ("pending_cases" if pending_n else "unresolved_hard_stop")
                    exit_code = EXIT_STOPPED
                else:
                    run["status"] = "completed"
                    run["stop_reason"] = None
                run["metrics"] = summarize(all_records)
                scored = [r for r in all_records if r["hit"] is not None]
                attempted = [r for r in all_records if r.get("status") != "not_attempted"]
                # 双分母口径：correct_over_planned固定计划分母；accuracy_attempted仅已评分
                correct = sum(r["hit"] is True for r in scored)
                run["accuracy_attempted"] = correct / len(scored) if scored else None
                run["correct_over_planned"] = correct / len(all_records) if all_records else None
                run["completion_rate"] = len(attempted) / len(all_records) if all_records else None
                run["accuracy_denominators"] = {"planned_n": len(all_records), "scored_n": len(scored),
                                                 "attempted_n": len(attempted),
                                                 "not_attempted_n": len(all_records) - len(attempted),
                                                 "scope": "accuracy_attempted只覆盖已评分题；correct_over_planned才是固定计划分母"}
                _save_run_unlocked(REPORT, data)
                m = run["metrics"]
                elapsed = time.perf_counter() - started
                acc = run["accuracy_attempted"]
                print(f"\n结果：计划{len(all_records)}，已尝试{len(attempted)}，"
                      f"技术失败{sum(not r['ok'] for r in attempted)}，"
                      f"未运行{m['not_attempted_n']}，"
                      f"correct_over_planned={'null' if run['correct_over_planned'] is None else round(run['correct_over_planned'], 4)}，"
                      f"accuracy_attempted={'null' if acc is None else round(acc, 4)}（仅限已评分范围）")
                for part, p in m["partitions"].items():
                    print(f"分区{part}：计划{p['planned_n']}，已尝试{p['attempted_n']}，"
                          f"未运行{p['not_attempted_n']}，技术失败{p['technical_failed']}")
                print(f"墙钟{elapsed:.1f}s；报告runs[{args.run_id}]：{REPORT}")
                if exit_code:
                    print(f"中止原因：{run['stop_reason']}；本run存在未运行或未恢复故障，"
                          f"不作为全量验收；恢复后同manifest续跑补齐")
    finally:
        release_report_lock(REPORT)
        # 清理本进程残留临时文件
        leftover = REPORT.with_name(f"{REPORT.name}.{os.getpid()}.tmp")
        if leftover.exists():
            leftover.unlink()
    return exit_code


def main(argv: list | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datasets", nargs="+", choices=("zh", "cosql", "bird"), default=["zh", "cosql", "bird"])
    parser.add_argument("--split", choices=("debug", "heldout", "all"), default="debug")
    parser.add_argument("--all-turns", action="store_true", help="CoSQL包含后续用户轮；同对话仍在同一分区")
    parser.add_argument("--bird-ids", default="", help="审核BIRD题号（无歧义qid或完整 序号:库:题号），逗号分隔")
    parser.add_argument("--limit", type=int, default=0, help="按稳定ID排序截取；不按标签挑选；0=不截断")
    parser.add_argument("--run-model", action="store_true", help="明确同意调用当前配置的付费模型")
    parser.add_argument("--diagnose-first-option", action="store_true")
    parser.add_argument("--run-id", default="", help="模型运行ID；同ID指纹必须一致，禁止跨版本迁移")
    parser.add_argument("--dry-run", action="store_true", help="纯构建打印统计，不加载LLM配置、不写任何报告")
    parser.add_argument("--create-subset-manifest", nargs="?", const=str(HERE / "test_cases/task3_subset_manifest_v2.json"),
                        default=None, metavar="PATH",
                        help="纯构建任务3最小子集清单（不发模型调用）；缺省写到test_cases/task3_subset_manifest_v2.json")
    parser.add_argument("--subset-manifest", default=None, metavar="PATH",
                        help="只读校验并按清单筛选；与--limit非0/非all split/非all-turns/BIRD互斥冲突即报错")
    parser.add_argument("--report", default=None, metavar="PATH",
                        help="仅显式指定时替换本进程报告路径；默认保持模块REPORT不动")
    parser.add_argument("--prompt-variant", choices=("current", "light"), default="current",
                        help="评测系统提示variant：current=模块常量现行为；light=可信候选常量"
                             "（light_prompts），不接受用户自由提示；manifest冻结其hash，同ID混用即拒绝")
    args = parser.parse_args(argv)
    if args.limit < 0:
        parser.error("limit不能为负数")
    if args.dry_run and args.run_model:
        parser.error("--dry-run与--run-model互斥")

    # 子集清单纯构建路径：不加载LLM/config、不发任何模型调用
    if args.create_subset_manifest is not None:
        if args.run_model:
            parser.error("--create-subset-manifest为纯构建，与--run-model互斥")
        # 采样器模块在main需要时才import，避免eval与sampler循环import
        import evaluation.task3_sampling as t3
        manifest_path = Path(args.create_subset_manifest)
        if not manifest_path.is_absolute():
            manifest_path = HERE / manifest_path
        manifest_args = SimpleNamespace(datasets=("cosql", "zh"), split="all", all_turns=True,
                                        limit=0, diagnose_first_option=False, bird_ids="")
        cases_c, source_hashes_c, _ = _build_cases(manifest_args)
        manifest = t3.build_subset_manifest(all_cases=cases_c, source_hashes=source_hashes_c,
                                            selector_code_hash=_selector_code_hash(),
                                            target=t3.DEFAULT_TARGET,
                                            rule_version=t3.RULE_VERSION)
        t3.write_manifest(manifest_path, manifest)
        m = manifest
        print(f"子集清单已写入 {manifest_path}：实际{m['actual_count']}条（cosql{m['actual_count'] - 20}+zh20），"
              f"规则版{m['rule_version']}，全量有效轮{m['total_valid_turns']}，"
              f"全体对话{m['total_dialog_count']}，选定完整对话{m['selected_dialog_count']}，"
              f"库覆盖{json.dumps(m['selected_databases'], ensure_ascii=False)}，"
              f"分区{json.dumps(m['partition_counts'], ensure_ascii=False)}，标签分布"
              f"{json.dumps(m['label_distribution'], ensure_ascii=False)}，种子{m['seed']}，"
              f"选择器hash{m['selector_code_hash'][:16]}，清单hash{m['manifest_hash'][:16]}")
        print("纯构建完成；未调用模型；评测时--subset-manifest引用本清单")
        return 0

    cases, source_hashes, data_map = _build_cases(args)

    # 子集模式：硬冲突检查+只读校验筛选（校验全部通过后清单即冻结分母，实际数为准）
    if args.subset_manifest:
        import evaluation.task3_sampling as t3
        _check_subset_conflicts(args, parser)
        manifest = json.loads(Path(args.subset_manifest).read_text(encoding="utf-8"))
        cases = t3.filter_and_verify_cases(manifest, cases, source_hashes, _selector_code_hash())
        print(f"子集模式：按清单筛选出实际{len(cases)}条（清单冻结分母；"
              f"种子{manifest['seed']}，清单hash{manifest['manifest_hash'][:16]}）")
    runnable = [c for c in cases if c.primary_label != "UNADJUDICATED"]
    if args.limit:
        runnable = runnable[:args.limit]

    # 纯构建与dry-run：只打印摘要，不写报告、不加载LLM/config
    if not args.run_model:
        stats = build_stats(data_map, args.all_turns, cases)
        print(json.dumps(stats, ensure_ascii=False))
        _print_summary(cases, stats, source_hashes)
        print("未调用模型；成绩与配置均为null；模型运行请显式--run-model --run-id")
        return 0

    if not args.run_id:
        parser.error("--run-model必须指定--run-id")
    # 仅显式--report时替换本进程REPORT；默认保持模块常量（测试monkeypatch不受影响）
    if args.report:
        global REPORT
        REPORT = Path(args.report).resolve()
    return _run_model(args, cases, runnable, source_hashes)


if __name__ == "__main__":
    sys.exit(main())
