"""BIRD执行评测：完整结果比较与同库完整/裁剪配对，显式授权后才调用模型。

并发隔离契约（第二轮复核修订）：
- 每工作线程持有独立pipeline与独立LLM计量（线程本地惰性构造并复用），删除了旧的全局
  _tls/build_pipeline/reset_thread_state；SchemaLinker绝不跨线程共享；
- 候选SQL只有res.ok为真且串库检查通过才允许完整重执；候选允许表 = res.tables与本题
  scope交集，blocked携带的SQL绝不用全库scope绕过生产安全拒绝；
- full模式model_unavailable后不再调用pruned（pruned标not_attempted）；
- 主线程用wait(FIRST_COMPLETED)批式消费，最多workers个future在途；每个future完成后
  主线程立即合并记录、原子checkpoint并打印进度；任务异常转为task_error记录保留分母，
  main以非0退出且不回显异常正文；
- manifest全语义字段等值校验（含样本顺序、max_bytes、python、sqlglot、模型冻结标识），
  且已有records的键必须严格等于选题集、逐条sample_id/db_id一致；缺manifest含records拒绝；
- LLM客户端在评测内使用冻结的resolved provider/settings私有快照（深拷贝，密钥仅存内存），
  全部worker同一快照；错误分类用HTTPStatusError响应码枚举，不回显供应商原文。
"""
import argparse
import copy
import hashlib
import json
import threading
import time
import uuid
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, wait
from dataclasses import dataclass
from decimal import Decimal
import datetime as dt
from pathlib import Path
import sys

import httpx
import psycopg2
from psycopg2 import sql as pgsql

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from backend.data_access.relational import prepare_sql, validate_sql
from evaluation.eval_schema_link import REPORT, fingerprint, load_items


@dataclass(frozen=True)
class FullResult:
    """只有状态OK才允许评分；超限结果绝不拿前缀冒充完整结果。"""
    status: str
    columns: int = 0
    rows: tuple = ()
    error_code: str = ""


class RunAbortedError(Exception):
    """调度中途终止（模型/库/任务异常）；main捕获后以非0退出，不回显异常正文。"""
    def __init__(self, reason, exception_type=None):
        super().__init__(reason)
        self.reason = reason
        self.exception_type = exception_type


def canonical(value):
    """保留NULL、重复次数和数值精度；Decimal不经浮点中转。"""
    if value is None:
        return ("null",)
    if isinstance(value, bool):
        return ("bool", value)
    if isinstance(value, (int, float, Decimal)):
        number = Decimal(str(value))
        return ("number", "nan" if number.is_nan() else number)
    if isinstance(value, bytes):
        return ("bytes", value)
    if isinstance(value, (list, tuple)):
        return ("array", tuple(canonical(v) for v in value))
    if isinstance(value, dict):
        return ("mapping", tuple(sorted((str(k), canonical(v)) for k, v in value.items())))
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return (type(value).__name__, value.isoformat())
    return (type(value).__name__, str(value))


def compare_results(candidate, reference, *, ordered=False):
    """顺序规则由评测预先声明；无序比较使用多重集而非集合或截断repr。"""
    if reference.status != "OK":
        return "reference_" + reference.status.lower()
    if candidate.status != "OK":
        return "candidate_" + candidate.status.lower()
    if candidate.columns != reference.columns or len(candidate.rows) != len(reference.rows):
        return "different_shape"
    c = tuple(tuple(canonical(v) for v in row) for row in candidate.rows)
    r = tuple(tuple(canonical(v) for v in row) for row in reference.rows)
    equal = c == r if ordered else Counter(c) == Counter(r)
    return "match" if equal else "different_values_or_order"


def execute_full(source, sql, allowed_tables, schema, *, max_rows=100000, max_bytes=32000000,
                 trusted_reference=False):
    """评测独立完整读取；原始参考SQL不转写，候选复用生产安全规范化。"""
    if schema not in source.allowed_schemas or not set(allowed_tables) <= source.allowed_schemas:
        return FullResult("REJECTED", error_code="source_schema_scope")
    try:
        if trusted_reference:
            validate_sql(sql, allowed_tables, schema)
            query = sql
        else:
            query = prepare_sql(sql, allowed_tables, schema)
    except Exception:
        return FullResult("REJECTED", error_code="readonly_or_scope")
    conn = None
    try:
        conn = psycopg2.connect(source.database_url, connect_timeout=10)
        conn.set_session(readonly=True, autocommit=False)
        with conn, conn.cursor() as cur:
            cur.execute("SET LOCAL statement_timeout TO 30000")
            cur.execute("SET LOCAL TIME ZONE 'UTC'")
            if trusted_reference:
                # 可信基准原文不转写；业务schema仅用于原始参考表解析，不开放给候选。
                cur.execute(pgsql.SQL("SET LOCAL search_path TO {}, {}").format(
                    pgsql.Identifier("pg_catalog"), pgsql.Identifier(schema)))
            else:
                cur.execute("SET LOCAL search_path TO pg_catalog")
            cur.execute(query)
            if not cur.description:
                return FullResult("ERROR", error_code="missing_result_set")
            columns, rows, size = len(cur.description), [], 0
            while True:
                chunk = cur.fetchmany(2048)
                if not chunk:
                    break
                size += sum(len(repr(row).encode("utf-8")) for row in chunk)
                if len(rows) + len(chunk) > max_rows or size > max_bytes:
                    return FullResult("RESOURCE_LIMIT", columns=columns, error_code="result_budget")
                rows.extend(tuple(row) for row in chunk)
            return FullResult("OK", columns, tuple(rows))
    except psycopg2.Error as exc:
        state = getattr(exc, "pgcode", None)
        code = state or "connection_or_query"
        return FullResult("TIMEOUT" if state == "57014" else "ERROR", error_code=code)
    finally:
        if conn is not None:
            conn.close()


# 受控安全错误码枚举：来自生产执行层安全函数，错误分类只记录枚举码，绝不记录供应商/数据库原文。
SQL_SAFETY_STEPS = frozenset({
    "sql_read_only", "sql_multi_statement", "sql_not_select", "sql_incompatible",
    "sql_table_outside_scope", "sql_function_restricted", "sql_custom_type_rejected",
    "sql_default_schema_outside_scope",
})

# SQLSTATE故障类别：08xx连接异常、28xx认证失败、42501权限不足，以及无pgcode的连接失败。
DB_STOP_CODES = ("connection_or_query", "source_metadata_unavailable")


def classify_pipeline_error(response_error):
    """把生产执行层错误映射为受控枚举类别，不保留任何原始报文。"""
    err = str(response_error) if response_error is not None else ""
    return "sql_safety" if err in SQL_SAFETY_STEPS else "execute_failed"


def is_db_unavailable(code):
    """判断是否为库级故障（需停止新增调度）；参考SQL语法失败不属于库故障。"""
    if code in DB_STOP_CODES:
        return True
    return bool(code) and (code.startswith("08") or code.startswith("28") or code == "42501")


def is_pipeline_db_fault(error):
    """pipeline执行层错误是否属于库/元数据级故障（候选执行前DB已断连，保守停止）。"""
    return str(error or "") in DB_STOP_CODES


def classify_http_error(exc):
    """按HTTPStatusError响应码做受控分类，不回显供应商错误正文。"""
    status = getattr(exc, "response", None)
    status = getattr(status, "status_code", None) if status is not None else None
    if status in (401, 403):
        return "auth_error"
    if status in (429,):
        return "transient_rate_limited"
    if 500 <= (status or 0) < 600:
        return "transient_server_error"
    if status in (400, 404, 422):
        return "config_error"
    return "unknown_error"


def classify_model_fault(exc):
    """模型故障分类：网络/超时/限流为transient可续跑，鉴权/配置/未知为permanent终止。"""
    if isinstance(exc, httpx.HTTPStatusError):
        return classify_http_error(exc)
    if isinstance(exc, (httpx.TimeoutException, httpx.ConnectError,
                        httpx.RemoteProtocolError, httpx.ReadError, httpx.NetworkError)):
        return "transient_network"
    text = str(exc)
    if text.startswith("模型接口不可用（额外重试"):
        return "transient_network"
    if text.startswith("已指定供应商") or text.startswith("未配置任何大模型"):
        return "config_error"
    return "unknown_error"


class LLMMonitor:
    """每题独立计量的LLM监视器：只统计当前题窗口，原始calls不无限累积，线程安全。"""
    def __init__(self):
        self._calls = []
        self._lock = threading.Lock()
        self._base = 0
        self.last_error_class = None

    def start_case(self):
        """题开始：重置窗口基线与故障分类，使本题计量与别的题/线程完全隔离。"""
        with self._lock:
            self._base = len(self._calls)
            self.last_error_class = None

    def base(self):
        """题内基线索引：单题汇总以题开始为起点，绝不跨题累计。"""
        with self._lock:
            return self._base

    def snapshot(self):
        """当前调用总数快照：用于切出单个模式的独立窗口，避免pruned重含full。"""
        with self._lock:
            return len(self._calls)

    def new_call(self):
        """登记一次chat调用；按题窗口统计，不跨题累计。"""
        with self._lock:
            stats = LLMCallStats(started=time.perf_counter())
            self._calls.append(stats)
        return stats

    def finish(self, stats, response_chars=0, error_class=None):
        with self._lock:
            stats.duration_s = round(time.perf_counter() - stats.started, 4)
            stats.response_chars = response_chars
            stats.error_class = error_class
            stats.usage = None  # 供应商usage不可得一律标null，不按正文折算token
            if error_class:
                self.last_error_class = error_class

    def case_s(self, base_index):
        """本题模式窗口的LLM耗时与调用次数（相对题开始基线）。"""
        with self._lock:
            window = self._calls[base_index:]
        return round(sum(c.duration_s for c in window), 3), len(window)

    def case_totals(self):
        """题结束：返回本题LLM汇总后重置基线；不保留跨题累积。"""
        with self._lock:
            calls = self._calls[self._base:]
            self._base = len(self._calls)
        return {
            "llm_calls": len(calls),
            "llm_total_s": round(sum(c.duration_s for c in calls), 3),
            "prompt_chars": sum(c.prompt_chars for c in calls),
            "response_chars": sum(c.response_chars for c in calls),
            "usage_supported": False,
            "usage_source": "null_no_vendor_usage",
            "note": "prompt_chars是字符数不是token数；供应商usage不可得一律标null",
        }


@dataclass
class LLMCallStats:
    """单次chat调用计量；usage不可得保持None，禁止按字符数折算token。"""
    started: float
    duration_s: float = 0.0
    prompt_chars: int = 0
    response_chars: int = 0
    usage: object = None
    error_class: object = None


def build_frozen_llm_client(monitor, provider, settings):
    """评测专用冻结LLM客户端：绑定main启动时一次性resolve的provider快照与settings深拷贝。

    不修改公共LLMClient类与全局settings缓存；密钥只存在私有内存副本内，
    永不序列化进manifest或报告；全部worker复用同一快照，不再各自_select_provider。
    """
    from backend.core.llm_client import LLMClient
    frozen_provider = dict(provider)
    frozen_settings = copy.deepcopy(settings)  # 私有内存快照，避免共享全局缓存被修改

    class _FrozenLLMClient(LLMClient):
        """评测only子类：供应商选择被覆盖为启动时冻结的副本。"""
        def _select_provider(self):
            return dict(self._frozen_provider)

    client = _FrozenLLMClient()
    client.settings = frozen_settings
    client._frozen_provider = frozen_provider

    def chat(self, messages, temperature=0.1, **kwargs):
        """计量包装：prompt字符数（不是token数）、耗时、受控故障分类；不发起额外调用。"""
        stats = monitor.new_call()
        stats.prompt_chars = sum(len(m.get("content") or "") for m in messages)
        try:
            # 走基类实现（内部读私有frozen副本），生产LLMClient类本身不变。
            content = LLMClient.chat(self, messages, temperature=temperature, **kwargs)
        except Exception as exc:
            # pipeline吞异常时分类仍可从monitor读取；不回显供应商原文。
            monitor.finish(stats, error_class=classify_model_fault(exc))
            raise
        monitor.finish(stats, response_chars=len(content))
        return content

    import types
    client.chat = types.MethodType(chat, client)  # 绑定实例方法：只包chat路径，生产函数不变
    return client


def resolve_llm_snapshot(settings=None):
    """main启动时一次性resolve出provider并深拷贝settings，全部worker与标识共用此快照。

    不在每个worker内重复_select_provider；密钥只存内存副本，不进报告；.env只经
    Settings正常加载，不直接读/回显。--dry-run路径不会调用本函数，故不加载密钥。
    """
    from backend.config import get_settings
    from backend.core.llm_client import LLMClient
    if settings is None:
        settings = get_settings()
    frozen_provider = dict(LLMClient()._select_provider())
    frozen_settings = copy.deepcopy(settings)
    return frozen_provider, frozen_settings


def model_identifier(provider, settings):
    """由启动时一次性resolve的冻结快照生成安全标识；端点仅散列去用户信息地址。

    密钥与连接串永不记录；.env只经Settings正常加载，不直接读或回显。
    """
    # 服务地址仅保留host部分参与散列（去掉协议与任何用户信息），且只取16位摘要。
    host_part = provider["base_url"].split("//", 1)[-1].split("@")[-1]
    endpoint_hash = hashlib.sha256(host_part.encode("utf-8")).hexdigest()[:16]
    return {
        "provider": provider["name"],
        "model": provider["model"],
        "endpoint_sha256_16": endpoint_hash,
        "llm_request_timeout_s": settings.llm_request_timeout,
        "llm_max_retries": settings.llm_max_retries,
        "frozen": True,
        "note": "同一冻结resolved provider/model私有深拷贝建全部worker客户端；不记录.env值或连接串",
    }


def select_samples(items, per_db, all_samples):
    """选题：默认每库前per_db条；--all显式全量500并核验唯一sample_id与各子库计数。"""
    if all_samples:
        selected = list(items)
        verify_full_selection(selected)
        return selected
    if per_db < 1:
        raise ValueError("per-db取值必须为正整数")
    chosen = []
    for db in sorted({x["db_id"] for x in items}):
        chosen.extend([x for x in items if x["db_id"] == db][:per_db])
    return chosen


def verify_full_selection(selected):
    """全量选择必须恰好500、sample_id全局唯一、11个子库计数逐一核验，不用per-db估算。"""
    if len(selected) != 500:
        raise ValueError(f"全量选择必须恰好500题，实际{len(selected)}")
    if len({x["_sample_id"] for x in selected}) != 500:
        raise ValueError("sample_id必须全局唯一")
    counts = dict(Counter(x["db_id"] for x in selected))
    if len(counts) != 11:
        raise ValueError(f"子库必须恰好11个，实际{len(counts)}")
    return counts


def build_manifest(selected, model_cfg, ordered, all_samples, per_db):
    """完整代码/输入/运行环境与模型冻结标识；含fingerprint完整files清单供审计。"""
    fp = fingerprint()
    return {
        "fingerprint": fp["sha256"],
        "fingerprint_files": fp["files"],
        "python": fp["python"],
        "sqlglot": fp["sqlglot"],
        "samples": [x["_sample_id"] for x in selected],
        "sub_db_counts": dict(Counter(x["db_id"] for x in selected)),
        "selection": "all_500" if all_samples else f"per_db_{per_db}",
        "model_identifier": model_cfg,
        "ordered": ordered,
        "max_rows": 100000,
        "max_bytes": 32000000,
    }


def check_manifest(manifest, run, items=None):
    """manifest全语义字段等值校验；已有records键必须严格等于选题集且逐条id/db一致。

    缺manifest但已有records直接拒绝，禁止跨版本补盖混跑。
    """
    previous = run.get("manifest")
    if previous is None:
        return len(run.get("records", {})) == 0
    # 全部语义字段逐一等值（样本顺序、资源预算、环境、模型冻结标识）。
    for field in ("fingerprint", "fingerprint_files", "python", "sqlglot", "samples",
                  "sub_db_counts", "selection", "model_identifier", "ordered",
                  "max_rows", "max_bytes"):
        if previous.get(field) != manifest.get(field):
            return False
    records = run.get("records", {})
    expected_keys = set(manifest.get("samples", []))
    if set(records.keys()) - expected_keys:
        return False  # records出现选题集之外的键，分母膨胀拒绝
    if items is not None:
        by_id = {x["_sample_id"]: x for x in items}
        for key, record in records.items():
            if key not in by_id:
                return False
            if record.get("db_id") not in (None, by_id[key]["db_id"]):
                return False
            if record.get("sample_id") is not None and record.get("sample_id") != key:
                return False
    return True


def atomic_write_json(path, obj):
    """同目录临时文件replace后清理；异常时finally删除temp，不留中间文件。"""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def acquire_report_write_lock(report_path):
    """拒绝两个评测运行并发覆写同一报告；锁文件存在即退出，不引入新依赖。"""
    lock_path = Path(str(report_path) + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(lock_path, "x") as handle:
            handle.write(json.dumps({"ts": time.time()}, ensure_ascii=False))
    except FileExistsError:
        raise SystemExit("检测到另一个评测运行已持有该报告写锁；并发覆写被拒绝，退出")


def release_report_write_lock(report_path):
    try:
        Path(str(report_path) + ".lock").unlink()
    except FileNotFoundError:
        pass


def evaluate_case(pipeline, item, reference_sql, *, ordered=True,
                  model_call=None, execute=None, run_ref=None, monitor=None):
    """只给生产问题和真实子库；参考结果从不参与模式选择或修复。

    候选SQL只有res.ok为真且串库检查通过才允许完整重执，候选允许表受res.tables约束；
    隔离失败在执行前阻断；full模型故障后不再调用pruned；金标SQL永不进入pipeline。
    """
    db_id = item["db_id"]
    timing = {"ref_s": None, "full": {}, "pruned": {}}
    candidate_meta = {}

    pipeline.linker.load("bird", db_id)
    scope = pipeline.linker.index.allowed_tables
    schema = pipeline.linker.index.schema_name

    if run_ref is not None:
        reference = run_ref
    else:
        t0 = time.perf_counter()
        if execute is not None:
            reference = execute(reference_sql, trusted=True, scope=scope, schema=schema)
        else:
            source = pipeline.registry.get_relational("bird")
            reference = execute_full(source, reference_sql, scope, schema, trusted_reference=True)
        timing["ref_s"] = round(time.perf_counter() - t0, 3)
    if reference.status != "OK":
        return {"sample_id": item["_sample_id"], "db_id": db_id, "question_id": item["question_id"],
                "state": "reference_error", "reference_state": reference.status,
                "reference_error_code": reference.error_code, "timing": timing}
    import sqlglot
    # 只看顶层排序，子查询ORDER BY不要求最终输出按序。
    has_order = bool(sqlglot.parse_one(reference_sql, read="postgres").args.get("order"))
    if monitor is not None:
        monitor.start_case()

    def run_mode(mode):
        timing[mode] = {}
        # 每mode取当前calls长度的独立snapshot，pruned窗口不含full；单题totals仍完整。
        base = monitor.snapshot() if monitor is not None else 0
        t_pipe = time.perf_counter()
        res = model_call(item, mode) if model_call else pipeline.run(
            "bird", db_id, item["question"], schema_mode=mode)
        # 串库/越界快照校验（在res.ok判断前）：current_db必须严格等于本库且schema一致，
        # res.tables必须是原scope子集；任一越界（含current_db=None）立即isolation，绝不重执。
        current = getattr(pipeline.linker.index, "current_db", None)
        cur_schema = getattr(pipeline.linker.index, "schema_name", None)
        res_tables = res.get("tables") or []
        scope_tables = (scope.get(schema) or set()) if schema else set()
        isolated = (
            current != db_id
            or cur_schema != schema
            or any(t not in scope_tables for t in res_tables)
        )
        timing[mode]["pipeline_s"] = round(time.perf_counter() - t_pipe, 3)
        if monitor is not None:
            llm_s, llm_n = monitor.case_s(base)
            timing[mode]["llm_s"] = llm_s
            timing[mode]["llm_calls"] = llm_n

        # 串库/越界在执行前阻断：绝不执行候选SQL。
        if isolated:
            candidate_meta[mode] = {"candidate_sql": None, "error_class": "isolation_error",
                                    "tables": res.get("tables", []), "repaired": False,
                                    "row_count": None, "executed": False}
            return {"state": "isolation_error", "ex": None, "stage": "isolation_error",
                    "tables": res.get("tables", []), "repaired": False, "row_count": None,
                    "error_class": "isolation_error", "isolated": True, "executed": False}

        if res["stage"] == "model_unavailable":
            # 故障分类可来自LLM代理（含repair模型故障，pipeline吞异常时monitor仍留有分类）。
            error_class = (monitor.last_error_class if monitor is not None else None) or "model_unavailable"
            candidate_meta[mode] = {"candidate_sql": res.get("sql"), "error_class": error_class,
                                    "tables": res.get("tables", []), "repaired": False,
                                    "row_count": None, "executed": False}
            return {"state": "pending_model", "ex": None, "stage": "model_unavailable",
                    "tables": res.get("tables", []), "repaired": False, "row_count": None,
                    "error_class": error_class, "isolated": False, "executed": False}

        # 库/元数据级故障（参考成功后DB断连）：转未评分pending（ex=None），不当能力错计False。
        if not res.get("ok") and is_pipeline_db_fault(res.get("error")):
            candidate_meta[mode] = {"candidate_sql": res.get("sql"),
                                    "error_class": "candidate_db_unavailable",
                                    "tables": res.get("tables", []), "repaired": False,
                                    "row_count": None, "executed": False}
            return {"state": "candidate_db_unavailable", "ex": None, "stage": res["stage"],
                    "tables": res.get("tables", []), "repaired": False, "row_count": None,
                    "error_class": "candidate_db_unavailable", "isolated": False, "executed": False}

        # 恢复旧契约：只有res.ok为真才允许候选完整重执；blocked携带的SQL绝不执行。
        if not res.get("ok"):
            # 修复模型故障（monitor记有模型层错误分类）：转未评分pending，阻断后续模式，
            # 不当候选语义错误；保持错误类别供排查。
            if monitor is not None and monitor.last_error_class and \
                    classify_pipeline_error(res.get("error")) != "sql_safety":
                candidate_meta[mode] = {"candidate_sql": res.get("sql"),
                                        "error_class": "repair_model_fault",
                                        "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                                        "row_count": None, "executed": False}
                return {"state": "repair_model_fault", "ex": None, "stage": res["stage"],
                        "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                        "row_count": None, "error_class": "repair_model_fault",
                        "isolated": False, "executed": False}
            error_class = classify_pipeline_error(res.get("error"))
            candidate_meta[mode] = {"candidate_sql": res.get("sql"), "error_class": error_class,
                                    "tables": res.get("tables", []), "repaired": False,
                                    "row_count": None, "executed": False}
            return {"state": "candidate_blocked", "ex": False, "stage": res["stage"],
                    "tables": res.get("tables", []), "repaired": False, "row_count": None,
                    "error_class": error_class, "isolated": False, "executed": False}

        # 候选允许表 = res.tables与本题scope交集；不改变readonly规则。
        allowed = {schema: {t for t in res_tables if t in scope_tables}}
        t_exec = time.perf_counter()
        if execute is not None:
            candidate = execute(res.get("sql") or "", trusted=False,
                                scope=allowed, schema=schema)
        else:
            source = pipeline.registry.get_relational("bird")
            candidate = execute_full(source, res.get("sql") or "", allowed, schema)
        timing[mode]["candidate_execution_s"] = round(time.perf_counter() - t_exec, 3)

        # candidate完整执行同样识别库级故障（候选执行中途DB断连）：转未评分pending，不計能力错。
        if candidate.status in ("ERROR", "TIMEOUT", "REJECTED") and \
                is_db_unavailable(candidate.error_code):
            candidate_meta[mode] = {"candidate_sql": res.get("sql"),
                                    "error_class": "candidate_db_unavailable",
                                    "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                                    "row_count": None, "executed": True}
            return {"state": "candidate_db_unavailable", "ex": None, "stage": "candidate_db_unavailable",
                    "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                    "row_count": None, "error_class": "candidate_db_unavailable",
                    "isolated": False, "executed": True}

        t_cmp = time.perf_counter()
        match = compare_results(candidate, reference, ordered=ordered and has_order)
        timing[mode]["comparison_s"] = round(time.perf_counter() - t_cmp, 3)

        candidate_meta[mode] = {"candidate_sql": res.get("sql"),
                                "error_class": None if candidate.status == "OK" else candidate.error_code,
                                "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                                "row_count": len(candidate.rows) if candidate.status == "OK" else None,
                                "executed": True}
        return {"state": match, "ex": match == "match", "stage": res["stage"],
                "tables": res.get("tables", []), "repaired": res.get("repaired", False),
                "row_count": len(candidate.rows) if candidate.status == "OK" else None,
                "error_class": None if candidate.status == "OK" else candidate.error_code,
                "isolated": False, "executed": True}

    modes = {}
    for mode in ("full", "pruned"):
        modes[mode] = run_mode(mode)
        # 串库/模型故障/库断连/修复故障：立即终止，pruned标not_attempted，绝不继续调用。
        if modes[mode].get("isolated"):
            modes[mode]["state"] = "isolation_error"
            break
        if modes[mode]["state"] in ("pending_model", "candidate_db_unavailable", "repair_model_fault"):
            break
    else:
        pass
    # 被终止而未运行的模式显式标not_attempted（分母保留）。
    for mode in ("full", "pruned"):
        if mode not in modes:
            modes[mode] = {"state": "not_attempted", "ex": None, "stage": "not_attempted",
                            "tables": [], "repaired": False, "row_count": None,
                            "error_class": None, "isolated": False, "executed": False}
            candidate_meta[mode] = {"candidate_sql": None, "error_class": None, "tables": [],
                                    "repaired": False, "row_count": None, "executed": False}
    isolation = any(m.get("isolated") for m in modes.values())
    # 未评分挂起：模型故障、库/元数据级故障、修复模型故障（均ex=None，不当能力错）记pending。
    pending = any(m["state"] in ("pending_model", "candidate_db_unavailable", "repair_model_fault")
                  for m in modes.values())
    record = {"sample_id": item["_sample_id"], "db_id": db_id, "question_id": item["question_id"],
        "state": "isolation_error" if isolation else ("pending" if pending else "completed"),
        "ordered": ordered and has_order, "modes": modes,
        "diagnostics": {"full": candidate_meta.get("full"), "pruned": candidate_meta.get("pruned")},
        "timing": timing}
    if monitor is not None:
        record["llm"] = monitor.case_totals()
    return record


def summary_counts(records):
    """固定计划分母（correct/planned）与可评配对分母（correct/completed）分开标明。"""
    planned = len(records)
    completed = [r for r in records.values() if r.get("state") == "completed"]
    pending = [r for r in records.values() if r.get("state") in ("pending", "isolation_error")]
    stopped = [r for r in records.values() if r.get("state") == "stopped_model"]
    not_attempted = [r for r in records.values() if r.get("state") == "not_attempted"]
    reference_error = [r for r in records.values() if r.get("state") == "reference_error"]
    task_error = [r for r in records.values() if r.get("state") == "task_error"]
    full_correct = sum(bool(r["modes"]["full"]["ex"]) for r in completed)
    pruned_correct = sum(bool(r["modes"]["pruned"]["ex"]) for r in completed)
    return {
        "planned": planned,
        # 固定计划分母：分子只对completed计分，分母永远planned，未完成不声称全量验收。
        "full_correct": full_correct,
        "pruned_correct": pruned_correct,
        "full_correct_over_planned": full_correct / planned if planned else None,
        "pruned_correct_over_planned": pruned_correct / planned if planned else None,
        # 可评配对分母：只对completed成对计EX，与固定分母显式分开。
        "paired_completed": len(completed),
        "full_ex_completed": full_correct / len(completed) if completed else None,
        "pruned_ex_completed": pruned_correct / len(completed) if completed else None,
        "pending_or_isolation": len(pending),
        "stopped_model": len(stopped),
        "not_attempted": len(not_attempted),
        "reference_error": len(reference_error),
        "task_error": len(task_error),
        "improved": sum(not r["modes"]["full"]["ex"] and r["modes"]["pruned"]["ex"] for r in completed),
        "regressed": sum(r["modes"]["full"]["ex"] and not r["modes"]["pruned"]["ex"] for r in completed),
        "note": "固定计划分母与可评配对分母分开标明；未完成/故障题保留分母状态，不消失",
    }


def run_parallel(selected, refs, *, workers, ordered=True, run=None, report=None,
                 execute=None, factory=None, frozen_snapshot=None):
    """主线程批式调度：最多workers个future在途，完成一个立即合并+原子checkpoint+flush进度。

    worker只return记录，主线程消费future时才append/checkpoint；finally收尾未消费future
    防Ctrl-C丢已完成；模型/库故障/隔离失败立即停止新增调度；任务异常转task_error保留分母
    后向main抛RunAbortedError（非0退出），不回显正文。frozen_snapshot为main一次性resolve
    的provider+settings深拷贝，两个worker共用，不再各自_select_provider。
    """
    stop_event = threading.Event()
    stop_reason = {"value": None}
    record_lock = threading.Lock()
    record_queue = []
    t_start = time.perf_counter()
    attempted_keys = set()
    done_count = 0

    def make_default_factory(provider, settings):
        """线程工厂：每线程一套独立pipeline+独立LLM监视器（线程本地惰性构造，绝不跨线程共享）。"""
        thread_local = threading.local()
        monitors = {}

        def _thread_pipeline():
            from backend.agents.text2sql.pipeline import Text2SQLPipeline
            monitor = getattr(thread_local, "monitor", None)
            if monitor is None:
                monitor = LLMMonitor()
                thread_local.monitor = monitor
                client = build_frozen_llm_client(monitor, provider, settings)
                thread_local.pipeline = Text2SQLPipeline(client)
                monitors[threading.get_ident()] = monitor
            return thread_local.pipeline

        class _Pool:
            def created(self):
                return len(monitors)

        pool = _Pool()
        pool._thread_pipeline = _thread_pipeline
        pool._monitors = monitors
        return pool

    # 接受工厂（返回pool）或pool对象本身：测试直接注入pool；生产用同一冻结快照建默认工厂。
    if factory is None:
        provider, settings = resolve_llm_snapshot() if frozen_snapshot is None else frozen_snapshot
        pool = make_default_factory(provider, settings)
    elif hasattr(factory, "_thread_pipeline"):
        pool = factory
    else:
        pool = factory()
    pending = [item for item in selected
               if not (run is not None and item["_sample_id"] in run["records"]
                       and run["records"][item["_sample_id"]].get("state") == "completed")]
    already = len(selected) - len(pending)

    def checkpoint():
        """主线程：合并新记录、按run全records聚合LLM、更新summary并原子写报告。"""
        if run is None:
            return
        with record_lock:
            for record in record_queue:
                run["records"][record["sample_id"]] = record
            record_queue.clear()
            # 模型/库故障时：只把从未动过的占位标stopped_model，已尝试失败题保持原状态。
            if stop_reason["value"] in ("model_unavailable", "database_unavailable",
                                        "candidate_db_unavailable", "repair_model_fault"):
                for item in selected:
                    key = item["_sample_id"]
                    if key not in attempted_keys and \
                            run["records"].get(key, {}).get("state") == "not_attempted":
                        run["records"][key]["state"] = "stopped_model"
            summary = summary_counts(run["records"])
            # LLM汇总只对本run全部records聚合，不混历史run；本轮吞吐另列segment_metrics。
            llm_agg = {"llm_calls": 0, "llm_total_s": 0.0, "prompt_chars": 0, "response_chars": 0}
            for rec in run["records"].values():
                for k, v in (rec.get("llm") or {}).items():
                    if k in llm_agg and isinstance(v, (int, float)):
                        llm_agg[k] = llm_agg[k] + v
            summary["llm"] = llm_agg
            segment = {
                "throughput_cases": len(pending),
                "cases_finished": done_count,
                "wall_elapsed_s": round(time.perf_counter() - t_start, 3),
                "note": "本run段吞吐指标，仅统计本次调度，不与历史run混淆",
            }
            summary["segment_metrics"] = segment
            latencies = [r["latency_s"] for r in run["records"].values() if "latency_s" in r]
            summary["mean_case_latency_s"] = round(sum(latencies) / len(latencies), 3) if latencies else None
            summary["wall_elapsed_s"] = segment["wall_elapsed_s"]
            summary["stop_reason"] = stop_reason["value"]
            run["summary"] = summary
            if report is not None:
                atomic_write_json(REPORT, report)

    # 提交任务前：占位与summary必须已落盘（main预置后调用），掉线也保留完整分母。
    if run is not None:
        checkpoint()

    from concurrent.futures import ThreadPoolExecutor
    executor = ThreadPoolExecutor(max_workers=workers)

    def process(item):
        """工作线程任务：独立pipeline+独立监视器处理一题，只把记录交回主线程。"""
        pipeline = pool._thread_pipeline()
        monitor = pool._monitors[threading.get_ident()]
        key = item["_sample_id"]
        t0 = time.perf_counter()
        try:
            def model_call(it, mode):
                # 金标永不进入pipeline；只传问题、真实子库与模式。
                return pipeline.run("bird", it["db_id"], it["question"],
                                    confirmed_slots=None, top_k=6, schema_mode=mode)
            record = evaluate_case(pipeline, item, refs[key]["sql"], ordered=ordered,
                                   model_call=model_call, execute=execute, monitor=monitor)
        except Exception as exc:
            # 任务级异常：保留题号与异常类型，不回显正文；由主线程落task_error记录。
            return {"__task_error__": True, "item": item, "exc_type": type(exc).__name__,
                    "latency_s": round(time.perf_counter() - t0, 3)}
        record["latency_s"] = round(time.perf_counter() - t0, 3)
        return record  # worker只return记录；不再写record_queue（主线程消费时append）。

    def consume(result, item):
        """主线程消费一条future结果：非task_error转队列，task_error直接入队，checkpoint。"""
        nonlocal done_count
        if result.get("__task_error__"):
            task_error_record = {"sample_id": item["_sample_id"], "db_id": item["db_id"],
                "question_id": item["question_id"], "state": "task_error",
                "task_error_type": result.get("exc_type"),
                "latency_s": result.get("latency_s"),
                "modes": {"full": {"state": "not_attempted", "ex": None},
                          "pruned": {"state": "not_attempted", "ex": None}}}
            with record_lock:
                record_queue.append(task_error_record)
            stop_event.set()
            stop_reason["value"] = "task_error"
            pending_queue[:] = []
            state = "task_error"
        else:
            state = result["state"]
            with record_lock:
                record_queue.append(result)
            if state == "pending":
                # 区分模型故障与候选库断连导致的pending，分别记受控停止原因。
                db_fault = any(
                    (m.get("error_class") == "candidate_db_unavailable")
                    for m in result["modes"].values())
                repair_fault = any(
                    (m.get("error_class") == "repair_model_fault")
                    for m in result["modes"].values())
                stop_event.set()
                stop_reason["value"] = ("candidate_db_unavailable" if db_fault
                                        else "repair_model_fault" if repair_fault
                                        else "model_unavailable")
                pending_queue[:] = []
            elif state == "reference_error" and \
                    is_db_unavailable(result.get("reference_error_code")):
                stop_event.set()
                stop_reason["value"] = "database_unavailable"
                pending_queue[:] = []
            elif state == "isolation_error":
                stop_event.set()
                stop_reason["value"] = "isolation_error"
                pending_queue[:] = []
        done_count += 1
        # 每个future完成即checkpoint：主线程合并+原子写+flush进度，不再等整轮。
        checkpoint()
        print(f"[{already + done_count}/{len(selected)}] {item['_sample_id']}  "
              f"{state}  本题{result.get('latency_s')}s", flush=True)

    futures = {}
    pending_queue = list(pending)
    aborted = False
    try:
        while pending_queue or futures:
            # 只在未停止时继续提交；每批最多workers个future在途（FIRST_COMPLETED消费完一批再补）。
            if not stop_event.is_set():
                while len(futures) < workers and pending_queue:
                    item = pending_queue.pop(0)
                    futures[executor.submit(process, item)] = item
            if not futures:
                break
            done, _ = wait(set(futures.keys()), return_when=FIRST_COMPLETED)
            for fut in done:
                item = futures.pop(fut)
                attempted_keys.add(item["_sample_id"])
                try:
                    consume(fut.result(), item)
                except Exception:
                    # 极端情况（池内异常）：同样记task_error保留分母。
                    consume({"__task_error__": True, "item": item,
                             "exc_type": "unknown", "latency_s": 0.0}, item)
        aborted = stop_reason["value"] in ("task_error", "model_unavailable",
                                           "database_unavailable", "candidate_db_unavailable",
                                           "repair_model_fault", "isolation_error")
    finally:
        executor.shutdown(wait=True)
        # 收尾仍未消费的在途future记录，防Ctrl-C丢已完成：cancel未开始，取已完成结果。
        for fut, item in list(futures.items()):
            if fut.cancelled() or fut.running():
                continue
            try:
                if fut.done():
                    consume(fut.result(), item)
            except Exception:
                pass
        futures.clear()
        checkpoint()

    # 终止条件：任务异常/模型故障/库故障/隔离失败时向main抛RunAbortedError（非0退出）。
    if aborted:
        raise RunAbortedError(stop_reason["value"])
    return stop_reason["value"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-models", action="store_true", help="明确授权真实模型调用；默认只说明边界")
    ap.add_argument("--per-db", type=int, default=2)
    ap.add_argument("--all", action="store_true",
                   help="显式选择完整500并核验唯一sample_id与各子库计数；不用per-db估算全量")
    ap.add_argument("--run-id", default="")
    ap.add_argument("--unordered", action="store_true", help="显式忽略顶层排序，结果仍保留重复次数")
    ap.add_argument("--workers", type=int, default=2, help="并发数；上限2，每worker独立pipeline")
    ap.add_argument("--dry-run", action="store_true",
                   help="无模型验证选题/唯一ID/子库计数并打印结果，不写或覆盖报告")
    args = ap.parse_args()
    if args.all and args.per_db != 2:
        ap.error("--all已显式固定500，禁止同时改动per-db；二者互斥")
    if not 1 <= args.workers <= 2:
        ap.error("并发数必须在1到2之间（真实API并发上限）")

    items, refs = load_items()
    selected = select_samples(items, per_db=args.per_db, all_samples=args.all)
    if args.dry_run:
        # 无模型dry-run：显式验证完整500、唯一ID、11子库；报告不落盘。
        counts = verify_full_selection(selected) if args.all else \
            dict(Counter(x["db_id"] for x in selected))
        print(json.dumps({
            "mode": "dry_run",
            "all_500": args.all,
            "selected": len(selected),
            "unique_sample_ids": len({x["_sample_id"] for x in selected}),
            "sub_db_count": len(counts),
            "sub_db_counts": counts,
            "report_written": False,
        }, ensure_ascii=False, indent=2))
        return

    if not args.run_models:
        print("未调用模型。真实执行须显式指定--run-models及独立--run-id；父流程统一调度预算。")
        return
    if not args.run_id:
        ap.error("真实执行必须有独立运行ID")

    # 冻结resolved provider/settings私有快照：main启动时一次resolve，标识与两个worker共用，
    # 不再每worker重复_select_provider；端点仅散列去用户信息地址，不存private进报告。
    frozen_provider, frozen_settings = resolve_llm_snapshot()
    model_cfg = model_identifier(frozen_provider, frozen_settings)
    manifest = build_manifest(selected, model_cfg, ordered=not args.unordered,
                              all_samples=args.all, per_db=args.per_db)

    acquire_report_write_lock(REPORT)
    exit_code = 0
    try:
        report = json.loads(REPORT.read_text(encoding="utf-8")) if REPORT.exists() else {}
        runs = report.setdefault("execution_runs", {})
        previous = runs.get(args.run_id)
        if previous is not None and not check_manifest(manifest, previous, items):
            raise ValueError("manifest校验失败（任一语义字段不一致或records越界），拒绝混合续跑")
        run = runs.setdefault(args.run_id, {"manifest": manifest, "records": {}})
        # 固定分母：选题集全部预置not_attempted占位，在任何任务提交前落盘。
        by_id = {x["_sample_id"]: x for x in selected}
        for key, x in by_id.items():
            run["records"].setdefault(key, {
                "sample_id": x["_sample_id"], "db_id": x["db_id"],
                "question_id": x["question_id"], "state": "not_attempted"})
        run["manifest"] = manifest
        atomic_write_json(REPORT, report)  # 预置占位先落盘，掉线也保留完整分母
        try:
            run_parallel(selected, refs, workers=args.workers, ordered=not args.unordered,
                         run=run, report=report,
                         frozen_snapshot=(frozen_provider, frozen_settings))
        except RunAbortedError as exc:
            # 终止不回显异常正文；summary已含task_error/stopped_model分母状态。
            exit_code = 1
            print(f"运行提前终止（{exc.reason}）；已完成记录与分母状态已保存，"
                  f"未完成题保留not_attempted/stopped_model，不显示成功。")
        summary = run["summary"]
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        print(f"墙钟总耗时{summary['wall_elapsed_s']}s；单题平均耗时{summary['mean_case_latency_s']}s")
    finally:
        release_report_write_lock(REPORT)
    if exit_code:
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
