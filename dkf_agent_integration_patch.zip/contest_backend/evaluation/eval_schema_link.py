"""任务4真实BIRD500离线配对评测；金标只在本脚本读取，生产仅接收问题和库身份。"""
import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import time
from pathlib import Path

import sqlglot
from sqlglot import exp
from sqlglot.optimizer.scope import traverse_scope

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
BIRD_JSON = HERE.parent / "data/raw/bird/original/minidev/MINIDEV/mini_dev_postgresql.json"
GOLD_SQL = HERE.parent / "data/raw/bird/original/minidev/MINIDEV/mini_dev_postgresql_gold.sql"
REPORT = HERE / "evaluation/reports/optimization_task4_20261010.json"
# 调试库在首次基线前固定；其余库仅用于冻结后验证，不按逐题金标增加词典。
DEBUG_DATABASES = frozenset({"debit_card_specializing", "student_club", "california_schools", "formula_1", "financial"})


def gold_tables(sql):
    """用SQL作用域排除CTE引用，保留子查询实际访问的表。"""
    parsed = sqlglot.parse_one(sql, read="postgres")
    tables = set()
    for scope in traverse_scope(parsed):
        for _, source in scope.selected_sources.values():
            if isinstance(source, exp.Table):
                tables.add(source.name.lower())
    return tables


def load_items():
    """核验问题、参考SQL数量与库标签，任何错位都中止评测。"""
    items = json.loads(BIRD_JSON.read_text(encoding="utf-8"))
    lines = GOLD_SQL.read_text(encoding="utf-8").splitlines()
    if len(items) != len(lines) or len(items) != 500:
        raise ValueError("BIRD问题与参考SQL应恰好各500条")
    references = {}
    for ordinal, (item, line) in enumerate(zip(items, lines)):
        # 原始question_id并非全局唯一，加入原始行号与库身份，避免金标覆盖和续跑漏题。
        sample_id = f"{ordinal:03d}:{item['db_id']}:{item['question_id']}"
        item["_sample_id"] = sample_id
        sql, tag = line.rsplit("\t", 1)
        if tag.strip() != item["db_id"]:
            raise ValueError("BIRD参考SQL库标签不一致")
        refs = gold_tables(sql)
        if not refs:
            raise ValueError("BIRD参考SQL未解析出真实表")
        references[item["_sample_id"]] = {"sql": sql, "tables": refs,
            "has_join": bool(sqlglot.parse_one(sql, read="postgres").find(exp.Join))}
    return items, references


def prf(pred, ref):
    """按题计算表元素精确率、召回率和F1；严格覆盖允许候选超集。"""
    p = len(pred & ref) / len(pred) if pred else 0.0
    r = len(pred & ref) / len(ref) if ref else 1.0
    return p, r, 2 * p * r / (p + r) if p + r else 0.0


def fingerprint():
    """记录生产代码、评测器与真实输入指纹，不散列会变化的报告。"""
    files = sorted((HERE / "backend/agents/task4_schema_linking").glob("*.py"))
    files += sorted((HERE / "backend/agents/text2sql").glob("*.py"))
    files += [HERE / "backend/data_access/relational.py", HERE / "backend/data_access/registry.py",
        HERE / "backend/core/llm_client.py", HERE / "backend/config.py",
        HERE / "processed/task4_schema/schema_index.json", HERE / "processed/task4_schema/fk_graph.json",
        Path(__file__), HERE / "evaluation/eval_text2sql.py", BIRD_JSON, GOLD_SQL,
        HERE / "processed/knowledge_base/databases.json",
        HERE.parent / "data/postgresql/bird/database_mapping.json",
        HERE.parent / "data/postgresql/cosql/database_mapping.json",
        HERE.parent / "data/postgresql/bird/import_native.sql",
        HERE.parent / "data/raw/chinook/ChinookDatabase/DataSources/Chinook_PostgreSql.sql"]
    # 原生导入文件包含真实数据，流式散列不把整份文件载入内存。
    hashes = {}
    for path in files:
        if path.exists():
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1048576), b""):
                    digest.update(chunk)
            hashes[str(path.relative_to(HERE.parent))] = digest.hexdigest()
    combined = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    return {"sha256": combined, "files": hashes, "python": platform.python_version(),
            "sqlglot": sqlglot.__version__}


def candidate_connected(ref, pred, bridges):
    """只检查候选集合内实际提供的连接证据，不能借用整个目录图。"""
    if not ref <= pred:
        return False
    adj = {t: set() for t in pred}
    for hop in bridges:
        a, b = hop["from_table"].lower(), hop["to_table"].lower()
        if a in adj and b in adj:
            adj[a].add(b)
            adj[b].add(a)
    start = next(iter(ref))
    seen, stack = {start}, [start]
    while stack:
        for nxt in adj[stack.pop()]:
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return ref <= seen


def aggregate(records):
    """分开初选和最终闭包，并记录真实多表题而不冒充JOIN题。"""
    out = {"n": len(records), "multi_table_n": sum(x["multi_table"] for x in records),
           "explicit_join_n": sum(x["has_join"] for x in records)}
    for stage in ("initial", "final"):
        sums = [0.0, 0.0, 0.0]
        strict, size = 0, 0
        for rec in records:
            pred, ref = set(rec[stage]), set(rec["reference"])
            sums = [a + b for a, b in zip(sums, prf(pred, ref))]
            strict += int(ref <= pred)
            size += len(pred)
        n = len(records)
        out[stage] = dict(zip(("precision", "recall", "f1"),
                             [round(v / n, 6) if n else None for v in sums]))
        out[stage].update(strict_count=strict, strict_recall=round(strict / n, 6) if n else None,
                         mean_tables=round(size / n, 6) if n else None)
    n_multi = out["multi_table_n"]
    out.update(candidate_bridge_hit=round(sum(x["bridge_ok"] for x in records if x["multi_table"]) / n_multi, 6) if n_multi else None,
        empty_candidates=sum(not x["final"] for x in records),
        outside_scope=sum(bool(x["outside_scope"]) for x in records),
        invalid_columns=sum(bool(x["invalid_columns"]) for x in records),
        unnecessary_clarification=sum(x["needs_clarification"] for x in records))
    return out


def paired(before, after):
    """严格按相同题目配对，分别记录补对和改坏，不只看汇总均值。"""
    old = {x["sample_id"]: x for x in before}
    out = {}
    for stage in ("initial", "final"):
        counts = {"both_covered": 0, "improved": 0, "regressed": 0, "both_missing": 0}
        changes = []
        for rec in after:
            prev = old[rec["sample_id"]]
            ref = set(rec["reference"])
            a, b = ref <= set(prev[stage]), ref <= set(rec[stage])
            key = "both_covered" if a and b else "improved" if b else "regressed" if a else "both_missing"
            counts[key] += 1
            changes.append(prf(set(rec[stage]), ref)[2] - prf(set(prev[stage]), ref)[2])
        counts.update(net_improved=counts["improved"] - counts["regressed"],
                      delta_mean_f1=round(sum(changes) / len(changes), 6))
        out[stage] = counts
    return out


def evaluate(limit=0):
    """生产接口只接收题目、子库和固定预算；金标始终留在评测侧。"""
    from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
    linker = SchemaLinker()
    items, references = load_items()
    records = []
    total = min(limit, len(items)) if limit else len(items)
    # 逐题打印进度：题号、库、本题耗时；每10题汇总一次均值。
    done, started = 0, time.perf_counter()
    for item in items[:limit or len(items)]:
        case_t0 = time.perf_counter()
        db_id = item["db_id"]
        linker.load("bird", sub_db=db_id)
        view = linker.link(item["question"], None, top_k=6)
        ref = references[item["_sample_id"]]
        catalog = {e["table"].lower(): set(e["columns"]) for e in linker.index.tables}
        initial = {c["table"].lower() for c in view["candidates"]}
        final = {t.lower() for t in view["tables"]}
        invalid = [f"{t}.{c}" for t, cols in view["columns"].items()
                   for c in cols if c not in catalog.get(t.lower(), set())]
        missing = sorted(ref["tables"] - final)
        records.append({"sample_id": item["_sample_id"], "question_id": item["question_id"], "db_id": db_id,
            "split": "debug" if db_id in DEBUG_DATABASES else "validation",
            "reference": sorted(ref["tables"]), "initial": sorted(initial), "final": sorted(final),
            "outside_scope": sorted(final - catalog.keys()), "invalid_columns": invalid,
            "multi_table": len(ref["tables"]) >= 2, "has_join": ref["has_join"],
            "bridge_ok": candidate_connected(ref["tables"], final, view["bridges"]),
            "needs_clarification": view["needs_clarification"], "status": view["status"],
            "failure_reasons": (["missing_required_tables"] if missing else [])
                + (["outside_scope"] if final - catalog.keys() else [])
                + (["invalid_columns"] if invalid else [])
                + (["no_candidates"] if not final else []), "missing": missing,
            "latency_s": round(time.perf_counter() - case_t0, 4)})
        done += 1
        if done % 10 == 0 or done == total:
            elapsed = time.perf_counter() - started
            print(f"[{done}/{total}] {item['_sample_id']}  本题{records[-1]['latency_s']:.2f}s  "
                  f"累计{elapsed:.1f}s  平均{elapsed / done:.2f}s/题", flush=True)
    return records


def audit_gold_policy():
    """参考SQL仅在评测侧做安全解析兼容性检查，不执行、不用于生成或停止判断。"""
    from collections import Counter
    from backend.agents.task4_schema_linking.schema_index import SchemaIndex
    from backend.data_access.relational import prepare_sql
    items, references = load_items()
    index, accepted, rejected = SchemaIndex(), 0, Counter()
    for item in items:
        index.load("bird", item["db_id"])
        try:
            prepare_sql(references[item["_sample_id"]]["sql"], index.allowed_tables, index.schema_name)
            accepted += 1
        except Exception as exc:
            rejected[str(exc)] += 1
    return {"n": len(items), "accepted": accepted, "rejection_codes": dict(rejected)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", choices=("baseline", "first", "final"), required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--replace-final", action="store_true", help="显式重测最终版，保留上一版概要；基线与首轮不可覆盖")
    args = ap.parse_args()
    report = json.loads(REPORT.read_text(encoding="utf-8")) if REPORT.exists() else {
        "dataset": "bird_minidev_postgresql", "debug_databases": sorted(DEBUG_DATABASES),
        "evaluation_boundary": "金标只供评测；75张跨库表不作真实库；无模型调用；本轮不报告SQL EX",
        "legacy_incomparability": ["旧桥接指标使用整个外键图", "旧全量指标实际仍为top6且混合独立业务库", "旧EX截断500行且全量DDL为空"],
        "script_identity_note": "原始question_id存在重复，配对采用原始行号+db_id+question_id，参考SQL始终逐行对齐",
        "feedback": {"debug_only": True, "first_findings": [
            "第一轮最终严格覆盖提高，但候选内桥接率下降，不能用覆盖提升掩盖连接退步",
            "固定调试库显示真实FK列被静态SQLite大小写拒绝；只读PG目录核验确认native导入字段折小写",
            "第二轮从既有PG导入DDL只读提取真实列标识，保留源名作为词形证据，不修改原JSON或源文件",
            "修复自定义类型AST检查，并补充当前表的自引用和真实FK列；这些为通用规则，不含逐题词典"
        ]},
        "runs": {}}
    report.setdefault("script_identity_note", "原始question_id存在重复；使用原始行号+db_id+question_id，金标逐行对齐")
    report.setdefault("evaluation_version", "table_closure_pairing_v1")
    if args.label == "final":
        report["feedback"] = {"debug_only": True, "first_findings": [
            "第一轮覆盖提高但桥接率下降，未宣称整体通过",
            "固定调试库的FK拒绝源于SQLite大小写与真实PG导入目录不一致；已只读核验PG元数据",
            "通用修复从已有import_native.sql的CREATE TABLE抽取真实PG列，遇COPY即停止；保留源名词形，源文件及旧索引不变",
            "安全复查修复USERDEFINED类型检查，补充自引用及真实FK列；未加入逐题词典"
        ], "remaining_risks": ["无声明外键的子库仍无法提供真实FK路径", "词面弱或隐含业务语义仍有漏表", "本轮没有真实模型EX，表覆盖不等于SQL正确"]}
    if args.replace_final and args.label != "final":
        ap.error("仅允许显式重测最终版；基线和首轮不可覆盖")
    if args.label in report["runs"]:
        if not args.replace_final:
            raise ValueError("已有同名运行，禁止盲覆盖已记录基线")
        previous = report["runs"]["final"]
        report.setdefault("final_rechecks", []).append({k: previous[k] for k in
            ("timestamp", "fingerprint", "aggregate", "splits", "paired_to_baseline")})
    records = evaluate(args.limit)
    run = {"timestamp": dt.datetime.now().isoformat(), "fingerprint": fingerprint(),
        "aggregate": aggregate(records), "splits": {s: aggregate([r for r in records if r["split"] == s])
        for s in ("debug", "validation")}, "per_db": {d: aggregate([r for r in records if r["db_id"] == d])
        for d in sorted({r["db_id"] for r in records})}, "records": records}
    report["runs"][args.label] = run
    if args.label != "baseline":
        run["paired_to_baseline"] = paired(report["runs"]["baseline"]["records"], records)
        if args.label == "final" and "first" in report["runs"]:
            run["paired_to_first"] = paired(report["runs"]["first"]["records"], records)
    if args.label == "final":
        baseline = report["runs"]["baseline"]["aggregate"]
        first = report["runs"]["first"]["aggregate"]
        report["gold_policy_audit"] = audit_gold_policy()
        report["feedback"]["tradeoffs"] = {
            "delta_mean_final_f1_vs_first": round(run["aggregate"]["final"]["f1"] - first["final"]["f1"], 6),
            "delta_debug_final_f1_vs_baseline": round(run["splits"]["debug"]["final"]["f1"] - report["runs"]["baseline"]["splits"]["debug"]["final"]["f1"], 6),
            "mean_final_tables_before": baseline["final"]["mean_tables"],
            "mean_final_tables_after": run["aggregate"]["final"]["mean_tables"],
            "no_real_model_ex": True}
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"label": args.label, "aggregate": run["aggregate"], "splits": run["splits"],
        "paired": run.get("paired_to_baseline")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
