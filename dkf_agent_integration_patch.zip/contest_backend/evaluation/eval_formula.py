"""HoF 金标公式及绑定组件一致性诊断；不是用户原文端到端成绩。

仅本评测进程读取测试金标，直接调用离线纯解析器与计算器。
不调用模型、生产 API、RAG、公式卡片或缓存。固定全量 413 题分母。
逐标注公式左侧量与唯一 arguments 项比对，不以答案数字或末行挑选目标。
唯一输出为 optimization_task6_20261010.json，不声称支持断点恢复。
"""
import argparse
from collections import Counter
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from backend.agents.task6_formula.formula_spec import normalize_symbol, spec_from_user_formula
from backend.agents.task6_formula.numeric_units import FormulaError, quantity_from_raw, split_number_unit
from backend.agents.task6_formula.safe_calculator import SafeCalculator

HOF = HERE.parent / "data" / "raw" / "formula_reasoning" / "data" / "FormulaReasoning" / "HoF_test.json"
OUTPUT = HERE / "evaluation" / "reports" / "optimization_task6_20261010.json"
FIXED_N = 413
REL_TOL = 0.01
ABS_TOL = 1e-12
ALIAS_FIELDS = ("en_name", "zh_name", "en_symbol", "zh_symbol")


def dataset_profile():
    """只输出字段和单位统计，供真实数据格式诊断。"""
    items = json.loads(HOF.read_text(encoding="utf-8"))
    fields, units = Counter(), Counter()
    for item in items:
        for argument in item.get("arguments", []):
            fields.update(argument.keys())
            units[str(argument.get("unit"))] += 1
    return {"n": len(items), "item_fields": list(items[0]), "argument_fields": dict(fields),
            "units": dict(units), "solution_lengths": dict(Counter(len(item["solution"].get("en", [])) for item in items))}


def parse_number(text):
    """兼容评测工具；完整数值或明确单位才返回，不截断前缀。"""
    try:
        return quantity_from_raw(text).value
    except FormulaError:
        return None


def isolated_numeric_expression(text):
    """仅评测层允许纯数值答案/标注数值式，不接受变量、等式或调用。"""
    if not isinstance(text, str) or len(text) > 256:
        raise FormulaError("gold_number_unsupported", "标注数值不是受限短字符串")
    if not re.fullmatch(r"[\d\s.,+\-*/^(){}×÷xXeE⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+", text):
        raise FormulaError("gold_number_unsupported", "标注数值含非纯算术内容")
    expression = re.sub(r"(?<=[\d)])\s*[xX]\s*(?=[\d(])", "*", text)
    spec = spec_from_user_formula(expression, source="evaluation_numeric_only")
    if spec.parse_status != "ok" or spec.target_symbol or spec.input_symbols:
        raise FormulaError("gold_number_unsupported", "标注数值式未通过受限纯数值解析")
    out = SafeCalculator().compute_spec(spec, {})
    if not out["ok"]:
        raise FormulaError(out["check_failed"], out["error"])
    return out["result"]


def _gold_argument(argument, index):
    """原标注单位决定换算；必要时在隔离层执行完整纯数值式。"""
    raw, unit = argument.get("num"), argument.get("unit")
    try:
        quantity = quantity_from_raw(raw, unit)
        number, embedded = split_number_unit(raw)
        actual_unit = unit if unit is not None else embedded
        numeric_mode = "literal"
    except FormulaError:
        # 单位失败不能伪装为数值失败；只对明确的纯算术字符串启用隔离求值。
        if not isinstance(raw, str) or not re.fullmatch(r"[\d\s.,+\-*/^(){}×÷xXeE⁺⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+", raw):
            raise
        number = isolated_numeric_expression(raw)
        actual_unit = unit
        quantity = quantity_from_raw(number, actual_unit)
        numeric_mode = "isolated_numeric_expression"
    return quantity, {"raw_value": number, "unit": actual_unit,
                      "source": {"kind": "HoF_arguments_oracle_only", "argument_index": index}}, numeric_mode


def _alias_index(arguments):
    """同名指向多个标注项视为冲突，即使数字相同也不猜是哪一项。"""
    aliases = {}
    for index, argument in enumerate(arguments):
        for field in ALIAS_FIELDS:
            value = argument.get(field)
            if isinstance(value, str) and value.strip():
                aliases.setdefault(normalize_symbol(value), set()).add(index)
    return aliases


def _unique_argument(name, aliases, role):
    matches = aliases.get(normalize_symbol(name), set())
    if not matches:
        raise FormulaError(f"missing_{role}_annotation", f"没有原名完全对应的标注项：{name}")
    if len(matches) != 1:
        raise FormulaError("annotation_conflict", f"变量名对应多个标注项：{name}")
    return next(iter(matches))


def fixed_group(item_id):
    """按题号冻结调试组，不参考问题、答案、公式或失败情况。"""
    return "debug" if int(hashlib.sha256(str(item_id).encode()).hexdigest()[:8], 16) % 5 == 0 else "holdout"


def numbers_consistent(actual, expected):
    """非零参考值只用预先固定的相对误差，绝对容差仅处理零值。"""
    return abs(actual - expected) <= (ABS_TOL if expected == 0 else REL_TOL * abs(expected))


def evaluate_item(item):
    """比较所有选定语言的标注公式，不筛选最容易算对的一行。"""
    arguments = item.get("arguments") or []
    aliases = _alias_index(arguments)
    solution = item.get("solution") or {}
    language = "en" if solution.get("en") else "zh"
    lines = solution.get(language) or []
    record = {"id": item["id"], "group": fixed_group(item["id"]), "language": language,
              "ok": False, "formulas": [], "oracle_only_bindings": True,
              "final_answer_scored": False, "target_selection": "each_lhs_unique_argument"}
    if not isinstance(lines, list) or not lines:
        record["failure_codes"] = ["missing_formula_annotation"]
        return record
    calculator = SafeCalculator()
    for index, expression in enumerate(lines):
        row = {"index": index, "expression": expression, "status": "unscored",
               "oracle_only_bindings": True, "comparable": False}
        try:
            spec = spec_from_user_formula(expression, source=f"hof_offline:{item['id']}:{index}")
            if spec.parse_status != "ok":
                raise FormulaError(getattr(spec, "error_code", "parse_status"), spec.constraints[0])
            if not spec.target_symbol:
                raise FormulaError("missing_target_annotation", "没有单一左侧目标量")
            target = spec.variables[spec.target_symbol].get("raw_name", spec.target_symbol)
            row["target"] = target
            target_index = _unique_argument(target, aliases, "target")
            expected, _, gold_mode = _gold_argument(arguments[target_index], target_index)
            if not expected.explicit_unit:
                raise FormulaError("missing_unit", "目标标注缺少单位；无量纲需显式空单位或 1")
            row.update({"target_argument_index": target_index, "target_unit": arguments[target_index].get("unit"),
                        "expected_normalized": expected.value, "gold_numeric_mode": gold_mode})
            bindings, input_indices = {}, {}
            for symbol in spec.input_symbols:
                original = spec.variables[symbol].get("raw_name", symbol)
                argument_index = _unique_argument(original, aliases, "input")
                if argument_index == target_index:
                    raise FormulaError("annotation_conflict", "目标标注不能作为待求量的输入")
                _, binding, mode = _gold_argument(arguments[argument_index], argument_index)
                bindings[symbol] = binding
                input_indices[original] = {"argument_index": argument_index, "numeric_mode": mode,
                                           "provenance": "oracle_only_may_be_gold_intermediate"}
            row["input_annotations"] = input_indices
            spec.expected_unit = arguments[target_index].get("unit")
            out = calculator.compute_spec(spec, bindings)
            if not out["ok"]:
                raise FormulaError(out["check_failed"], out["error"])
            row.update({"computed": out["result"], "unit": out["unit"],
                        "computed_normalized": out["normalized_result"], "comparable": True})
            if not numbers_consistent(out["normalized_result"], expected.value):
                raise FormulaError("value_mismatch", "公式结果与对应标注量不一致；不猜比例或修正答案")
            row["status"] = "passed"
        except FormulaError as exc:
            row.update({"status": exc.code, "reason": str(exc)})
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            row.update({"status": "annotation_structure_error", "reason": type(exc).__name__})
        record["formulas"].append(row)
    failures = sorted({row["status"] for row in record["formulas"] if row["status"] != "passed"})
    record["failure_codes"] = failures
    record["ok"] = not failures
    record["fully_comparable"] = all(row["comparable"] for row in record["formulas"])
    return record


def summarize(records, denominator):
    formulas = [row for record in records for row in record["formulas"]]
    passed = sum(record["ok"] for record in records)
    comparable = sum(row["comparable"] for row in formulas)
    statuses = Counter(row["status"] for row in formulas)
    unsupported_reasons = Counter(row.get("reason", "") for row in formulas if row["status"] == "unsupported_unit")
    return {"fixed_item_denominator": denominator, "evaluated_items": len(records),
            "all_formulas_consistent_items": passed,
            "all_formulas_consistent_item_rate": passed / denominator if denominator else None,
            "fully_comparable_items": sum(record.get("fully_comparable", False) for record in records),
            "fully_comparable_item_coverage": sum(record.get("fully_comparable", False) for record in records) / denominator if denominator else None,
            "items_with_any_comparable_formula": sum(any(row["comparable"] for row in record["formulas"]) for record in records),
            "formula_count": len(formulas), "passed_formulas": statuses.get("passed", 0),
            "comparable_formulas": comparable,
            "formula_comparison_coverage": comparable / len(formulas) if formulas else None,
            "consistent_rate_on_comparable_formulas": statuses.get("passed", 0) / comparable if comparable else None,
            "formula_status_counts": dict(sorted(statuses.items())),
            "unsupported_unit_reasons": dict(sorted(unsupported_reasons.items())),
            "items_by_failure_code": dict(sorted(Counter(code for record in records for code in record["failure_codes"]).items()))}


def fingerprints():
    paths = ["backend/agents/task6_formula/formula_spec.py", "backend/agents/task6_formula/safe_calculator.py",
             "backend/agents/task6_formula/numeric_units.py", "backend/agents/task6_formula/param_finder.py",
             "evaluation/eval_formula.py", "tests/test_formula_spec.py", "tests/test_task6_safety.py",
             "tests/test_task6_evaluation.py", "tests/test_task6_review_regressions.py", "docs/task6_formula_integration.md"]
    return {"dataset_sha256": hashlib.sha256(HOF.read_bytes()).hexdigest(),
            "files_sha256": {path: hashlib.sha256((HERE / path).read_bytes()).hexdigest()
                             for path in paths if (HERE / path).is_file()}}


def run_tests():
    """同进程运行离线夹具，无缓存和测试注册文件；保存真实测试计数。"""
    import pytest
    class Counts:
        def __init__(self):
            self.counts = Counter()
        def pytest_runtest_logreport(self, report):
            if report.when == "call" or (report.when == "setup" and not report.passed):
                self.counts[report.outcome] += 1
    counts = Counts()
    arguments = [str(HERE / "tests" / name) for name in
                 ("test_formula_spec.py", "test_task6_safety.py", "test_task6_evaluation.py", "test_task6_review_regressions.py")]
    code = pytest.main(arguments + ["-q", "-p", "no:cacheprovider"], plugins=[counts])
    return {"exit_code": int(code), "counts": dict(counts.counts), "pytest_version": pytest.__version__, "cache_provider": False,
            "python_dont_write_bytecode": sys.dont_write_bytecode,
            "note": "安全单元夹具不是数据集成绩"}


def run_diagnostic(round_name="initial", with_tests=False, show_debug=False):
    started = time.perf_counter()
    tests = run_tests() if with_tests else None
    if tests and tests["exit_code"]:
        raise SystemExit("安全测试失败，禁止生成真实诊断成绩")
    items = json.loads(HOF.read_text(encoding="utf-8"))
    if len(items) != FIXED_N or len({item["id"] for item in items}) != FIXED_N:
        raise SystemExit("HoF 题量或唯一题号不符合固定 413 分母")
    # 逐题评测并打印进度：题号、本题耗时；结束时输出总耗时与平均耗时。
    records, latencies = [], []
    t_loop = time.perf_counter()
    for idx, item in enumerate(items, 1):
        item_t0 = time.perf_counter()
        record = evaluate_item(item)
        elapsed_case = time.perf_counter() - item_t0
        latencies.append(elapsed_case)
        records.append(record)
        if idx % 25 == 0 or idx == len(items):
            print(f"[{idx}/{len(items)}] 题{item['id']}  本题{elapsed_case:.3f}s  "
                  f"平均{sum(latencies) / idx:.3f}s/题", flush=True)
    print(f"逐题评测完成：{len(records)}题，共{time.perf_counter() - t_loop:.1f}s", flush=True)
    metrics = summarize(records, FIXED_N)
    groups = {group: summarize([record for record in records if record["group"] == group],
                               sum(record["group"] == group for record in records))
              for group in ("debug", "holdout")}
    hashes = fingerprints()
    digest = hashlib.sha256(json.dumps(records, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()
    previous = json.loads(OUTPUT.read_text(encoding="utf-8")) if OUTPUT.is_file() else {}
    history = previous.get("round_history", [])
    history.append({"round": round_name, "metrics": metrics, "groups": groups, "fingerprints": hashes,
                    "details_sha256": digest, "tests": tests})
    previous_round = history[-2] if len(history) > 1 else None
    report = {"dataset": "FormulaReasoning_HoF_test", "mode": "gold_formula_binding_component_consistency",
              "environment": {"python_version": sys.version, "python_executable": sys.executable,
                              "standard_library_only_runtime": True},
              "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(), "metrics": metrics, "groups": groups,
              "policy": {"oracle_supplied_authorized": True, "gold_fields_read_by_evaluation_only": True,
                         "llm_calls": 0, "production_api_calls": 0, "rag_calls": 0, "cache_writes": 0,
                         "final_answer_accuracy": None, "numeric_ratio_fallback": False,
                         "all_bindings_oracle_only_may_include_gold_intermediates": True,
                         "target_selection": "all_annotated_formula_lhs_to_unique_argument_never_answer_or_last_line",
                         "relative_tolerance": REL_TOL, "absolute_tolerance_zero_only": ABS_TOL,
                         "resume_claim": False, "fixed_debug_group": "sha256(id) first 8 hex modulo 5 equals 0",
                         "unsupported_affine_temperature": "裸摄氏/华氏温标（含中文别名）歧义，一律拒绝；仅显式Δ/delta温差记号或quantity_kind='temperature_difference'授权才按K温差解析，绝对温度与转数r均拒绝，计入覆盖损失"},
              "baseline": {"original_formula_tests_passed": 17,
                           "note": "本会话先运行原17项测试全部通过，随后复现并修复安全反例；旧94.19%不作对照成绩"},
              "semantic_safety_review": {
                  "scope": "本轮语义安全审核摘要，不回写旧轮成绩",
                  "finding": "optimization_r3的385/413依赖裸摄氏/华氏一律按K温差解析的非物理假设（如20℃当20K、68°F-20℃直接线性相减），分数仅证明与金标一致，不证明物理正确",
                  "remediation": "恢复裸温标与转数r的拒绝边界，保留显式温差记号与kind授权的规范温差支持，不实现仿射温标系统",
                  "expectation": "新轮分数回落，temperature/r保守拒绝计入覆盖损失；分数差异不代表质量退步而是语义收紧"},
              "failure_analysis": {
                  "unsupported_unit": "绝对摄氏/华氏、未声明复合温差及旋转单位r保守不支持，计入覆盖损失",
                  "parse_status": "自引用或其他未支持结构一律拒绝；不排除目标后强算",
                  "annotation_conflict": "相同原名对应多条arguments，拒绝猜测或按数字选项",
                  "value_mismatch": "带单位规范化后公式与对应标注量仍冲突，保留原标注及符号，不修答案",
                  "unit_mismatch": "原数值所含单位与独立unit字段冲突，拒绝删除单位",
                  "general_repairs": ["占位符文字标签支持括号和英文所有格，但不成为代码",
                                      "补齐dm、l和标准乘号别名，不按答案猜尺度",
                                      "复核符号映射、兼容字形和返回JSON边界",
                                      "极小非零量只用相对容差，避免绝对容差掩盖倍数错误"]},
              "fingerprints": hashes, "details_sha256": digest, "round_history": history,
              "repeatability": {"same_fingerprints_as_previous": bool(previous_round and previous_round["fingerprints"] == hashes),
                                "same_details_as_previous": bool(previous_round and previous_round["details_sha256"] == digest)},
              "elapsed_s": round(time.perf_counter() - started, 4), "details": records,
              "interpretation": "固定413题的金标公式与绑定组件一致性，不代表用户原文抽参、最终问答或PDF视觉识别能力"}
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps({"round": round_name, "metrics": metrics, "groups": groups,
                      "repeatability": report["repeatability"], "output": str(OUTPUT)}, ensure_ascii=True, indent=2))
    if show_debug:
        failures = {}
        for record in records:
            if record["group"] != "debug":
                continue
            for row in record["formulas"]:
                if row["status"] != "passed" and len(failures.setdefault(row["status"], [])) < 3:
                    failures[row["status"]].append({"id": record["id"], **row})
        print(json.dumps({"debug_failures": failures}, ensure_ascii=True, indent=2))
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--round", default="initial")
    parser.add_argument("--with-tests", action="store_true")
    parser.add_argument("--show-debug", action="store_true")
    args = parser.parse_args()
    if args.profile:
        print(json.dumps(dataset_profile(), ensure_ascii=True, indent=2))
    else:
        run_diagnostic(args.round, args.with_tests, args.show_debug)


if __name__ == "__main__":
    main()
