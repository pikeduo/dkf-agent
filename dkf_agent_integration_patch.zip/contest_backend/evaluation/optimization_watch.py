#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""只读监控：任务3/任务4 优化报告闭环唤醒。

- 只读两份 JSON 报告，不改代码、不重跑任务、不发模型/数据库请求。
- 每 50/100 题里程碑、run 完成/停止/基础设施故障、报告 20 分钟无推进、
  运行期心跳（默认 15 分钟）输出一行 AGENT_LOOP_WAKE_ICT JSON 唤醒父 agent。
- 报告写入中/损坏时只记为本次不可读，不抛全文异常，且不据此删除已有缓存。
- 只打印聚合状态数值，不打印数据库内容、密钥、SQL、题文。
- 首次启动打印 WATCH_READY（非哨兵）；首个定时心跳在 --interval 秒后，不重复立即触发。
- 首次观察时已存在的 task4 历史 run（除 r6 外）不触发历史告警；
  从成功读取的报告中消失的 run 会从监控缓存中删除。

task3 真实字段口径（参照 eval_clarify 的报告结构，但绝不 import 生产代码）：
- 记录用 status：ready / needs_user / undecidable 族 / tool_error / not_attempted；
- 进度 progress = 已处理记录数（status != not_attempted）；答错(hit=False)与技术失败(tool_error)
  同样推进，不用正确率判断卡顿；里程碑按 progress 推进；
- 分母 planned 优先真实 accuracy_denominators / metrics 的 planned_n，或预置 records 数；
  不读 manifest.samples（全部 case 哈希 list，含未审核 500）；
- 完成契约：planned>0、len(records)==planned、全部已处理、run.status=completed、
  无未恢复 HARD_STOP（{"model_unavailable","auth_or_config"} 本地常量）；
- 停止后恢复 running 时刷新状态标志，后续再次停止/完成可再通知并重启停滞检测。

用法：python -B evaluation/optimization_watch.py --interval 900
"""
import argparse
import json
import ctypes
import json
import os
import platform
import threading
import time
from collections import Counter
from pathlib import Path

# Windows 共享读所需常量（ctypes 常量；仅标准库）
GENERIC_READ = 0x80000000
OPEN_EXISTING = 3
FILE_FLAG_POSIX_SEMANTICS = 0x01000000
FILE_ATTRIBUTE_NORMAL = 0x80
# 关键：FILE_SHARE_READ|WRITE|DELETE —— 读句柄不独占，允许写者 rename/删除/替换（os.replace 原子写）
FILE_SHARE_READ = 0x1
FILE_SHARE_WRITE = 0x2
FILE_SHARE_DELETE = 0x4
# 无效句柄标记（64bit 下 c_void_p(-1)）
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value


def _read_bytes_shared(path):
    """读取文件字节。Windows 用共享读句柄（CreateFileW 带 SHARE_READ|WRITE|DELETE），
    读完立即按所有权逐级关句柄，再交给调用方解析；绝不重复 CloseHandle。

    句柄所有权链（逐级转移，只关一次）：
    - CreateFileW 成功 → 持有 raw handle；
    - open_osfhandle 成功 → handle 归 fd（open_osfhandle 失败则仍须 CloseHandle raw）；
    - os.fdopen 成功 → fd 归 f（fdopen 失败则须 os.close(fd)）；
    - f.close() 时自动关闭 fd 与底层 handle，之后不再 CloseHandle。
    文件不存在/打开失败返回 None（不冒认空文件）；不升级权限/改 ACL/排除杀软。"""
    if platform.system() == "Windows":
        try:
            import msvcrt
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            # 64bit 正确声明：CreateFileW 返回 HANDLE（c_void_p），7 个参数
            kernel32.CreateFileW.restype = ctypes.c_void_p
            kernel32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32,
                                             ctypes.c_uint32, ctypes.c_void_p,
                                             ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
            # CloseHandle 声明 BOOL 返回 / c_void_p 参数
            kernel32.CloseHandle.restype = ctypes.c_bool
            kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
            share = FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE
            handle = kernel32.CreateFileW(str(path), GENERIC_READ, share, None,
                                          OPEN_EXISTING, FILE_FLAG_POSIX_SEMANTICS | FILE_ATTRIBUTE_NORMAL, None)
            if handle is None or handle == INVALID_HANDLE_VALUE or handle == -1:
                return None  # 文件不存在或打开失败：不冒认合法空文件
            fd = -1
            f = None
            data = None
            try:
                fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
                f = os.fdopen(fd, "rb")
                data = f.read()
            finally:
                # 逐级清理，仅走一条分支，避免重复关闭 handle
                if f is not None:
                    # f 关闭 → 自动关闭 fd → 自动关闭 handle；此处不再 CloseHandle
                    try:
                        f.close()
                    except OSError:
                        pass
                elif fd >= 0:
                    # fdopen 失败：仍持有 fd，关 fd（连带关 handle）
                    try:
                        os.close(fd)
                    except OSError:
                        pass
                else:
                    # open_osfhandle 未成功：仍持有 raw handle，CloseHandle 一次
                    kernel32.CloseHandle(handle)
            return data
        except OSError:
            return None
    # 非 Windows：普通读字节
    try:
        with open(str(path), "rb") as f:
            return f.read()
    except OSError:
        return None


def load_json_safe(path):
    """只读读取报告并解析；先读字节、关闭读句柄，再 json.loads。
    写入中/损坏/缺失返回 (None, False)，不抛全文异常；
    共享读句柄保证读监控不阻塞写者的 os.replace 原子替换。"""
    data = _read_bytes_shared(path)
    if data is None:
        return None, False
    try:
        # 兼容 utf-8-sig BOM：先剥离 BOM 再按 utf-8 解码
        if data.startswith(b"\xef\xbb\xbf"):
            data = data[3:]
        return json.loads(data.decode("utf-8")), True
    except (ValueError, UnicodeDecodeError):
        return None, False

SENTINEL = "AGENT_LOOP_WAKE_ICT"        # 唤醒哨兵前缀
BASELINE_RUN = "bird500_r6_isolated"   # 任务4 重点关注 run
NO_PROGRESS_S = 20 * 60                 # 20 分钟无推进阈值
MILESTONE_STEP = 50                   # 每 50/100 题里程碑步长
# 基础设施故障类别（参照任务3评测器 HARD_STOP_ERRORS 字符串，本地引用不 import 生产）
HARD_STOP_ERRORS = {"model_unavailable", "auth_or_config"}
PROMPT = ("请读取 evaluation/reports/optimization_task4_20261010.json 与 optimization_task3_20261010.json 全量指标，"
          "保持并发不超过2，先评估结果再由子agent实施，所有变更全量重测，"
          "不按金标题面调参，不覆盖原报告；pending/未运行/未恢复基础设施故障不可声称全量成绩；"
          "本监控程序不会自动重跑。")


def runs_of(data, tag="task3"):
    """提取 run 字典：task3 用 runs；task4 用 execution_runs（runs 为历史聚合旧字段，跳过）；兼容 dict 或 list。"""
    keys = ("runs", "execution_runs") if tag == "task3" else ("execution_runs", "runs")
    for key in keys:
        val = data.get(key) if isinstance(data, dict) else None
        if isinstance(val, dict):
            return {k: v for k, v in val.items() if isinstance(v, dict)}
        if isinstance(val, list):
            return {"run%d" % i: v for i, v in enumerate(val) if isinstance(v, dict)}
    return {}


def record_values(run):
    """取记录值集合：dict 记录取其 values；list 记录直接用；无记录返回空。"""
    recs = run.get("records") if isinstance(run, dict) else None
    if isinstance(recs, dict):
        return list(recs.values())
    if isinstance(recs, list):
        return recs
    return []


def state_counts(run, tag):
    """按报告聚合记录状态计数（不含题文/SQL）：task4 用 record.state，task3 用 record.status。"""
    key = "status" if tag == "task3" else "state"
    counts = Counter()
    for v in record_values(run):
        counts[str(v.get(key, "unknown")) if isinstance(v, dict) else str(v)] += 1
    return counts


def planned_of(run, records, tag):
    """分母只取可信字段。
    task4 用 summary.planned。
    task3 优先 accuracy_denominators.planned_n → metrics.planned_n → 预置 records 数；
    不读 manifest.samples（它是全部 case 哈希 list，含未审核 500，不能当 9233 run 的分母）。
    全部缺失时回退记录数（占位口径）。"""
    summ = run.get("summary") if isinstance(run.get("summary"), dict) else {}
    if tag == "task4":
        if isinstance(summ.get("planned"), int):
            return summ["planned"]
    else:
        for src in (run.get("accuracy_denominators"), run.get("metrics")):
            if isinstance(src, dict) and isinstance(src.get("planned_n"), int):
                return src["planned_n"]
    return len(records)


def hard_stop_unresolved(records):
    """未恢复的基础设施故障：非未运行记录且 error 属 HARD_STOP_ERRORS 字符串类别。"""
    return sum(1 for r in records
               if isinstance(r, dict) and r.get("status") != "not_attempted"
               and r.get("error") in HARD_STOP_ERRORS)


def t3_progress_counts(records):
    """task3 进度分类（不含题文/SQL/密钥）：
    - progress：已处理记录数（status != not_attempted），答错(hit=False)/技术失败(tool_error)
      同样推进——这是处理进度，不是正确率；
    - correct：hit 判定为 True 的记录数；
    - semantic_scored：已评分（hit 非空）记录数；
    - infra_failed：error 属 HARD_STOP_ERRORS 的非未运行记录数；
    - not_attempted：占位未运行记录数（不进任何分母）。
    """
    progress = correct = semantic_scored = infra_failed = not_attempted = 0
    for r in records:
        if not isinstance(r, dict):
            continue
        status = r.get("status")
        if status == "not_attempted":
            not_attempted += 1
            continue
        progress += 1
        if r.get("hit") is True:
            correct += 1
        if r.get("hit") is not None:
            semantic_scored += 1
        if r.get("error") in HARD_STOP_ERRORS:
            infra_failed += 1
    return {"progress": progress, "correct": correct, "semantic_scored": semantic_scored,
            "infra_failed": infra_failed, "not_attempted": not_attempted}


def run_flags(run, counts, tag, planned, records):
    """完成/停止/故障判定。
    task4：记录全 completed（无 pending/not_attempted）即完成。
    task3：必须 run.status=completed 且无 not_attempted 且无未恢复 hard_stop；
    未完成（incomplete/stopped/含未恢复故障）归基础设施停止类。
    """
    if tag == "task4":
        summ = run.get("summary") if isinstance(run.get("summary"), dict) else {}
        completed = bool(planned) and counts.get("completed", 0) >= planned and \
            counts.get("pending", 0) == 0 and counts.get("not_attempted", 0) == 0
        stopped = summ.get("stop_reason") is not None  # task4 停止只看 summary.stop_reason
        merr = (summ.get("stopped_model") or 0) > 0 or \
            any(k in counts for k in ("model_error", "stopped_model"))
    else:
        status = run.get("status")
        # 完成契约：planned>0、记录数齐、全部已处理（无 not_attempted）、run.status=completed、无未恢复 HARD_STOP
        completed = (bool(planned) and len(records) == planned
                     and counts.get("not_attempted", 0) == 0
                     and status == "completed"
                     and hard_stop_unresolved(records) == 0)
        unresolved = hard_stop_unresolved(records) > 0
        stopped = status in ("stopped", "incomplete") or unresolved or \
            (run.get("stop_reason") is not None and status != "completed")
        merr = unresolved  # task3 基础设施故障告警只认 HARD_STOP_ERRORS 类别
    return completed, stopped, merr


def emit(payload):
    """输出一行哨兵 JSON（ensure_ascii），即时刷新供终端实时接收。"""
    print(SENTINEL + " " + json.dumps(payload, ensure_ascii=True, sort_keys=True), flush=True)


class Watch:
    """扫描与告警状态：里程碑(语义完成推进)、完成/停止/故障、无推进；重复状态不刷屏。"""

    def __init__(self, prompt=PROMPT, milestone_step=MILESTONE_STEP, no_progress_s=NO_PROGRESS_S):
        self.prompt = prompt
        self.milestone_step = milestone_step
        self.no_progress_s = no_progress_s
        self.mon = {}                  # (report, run) -> 状态 dict
        self.initial_task4 = None       # 首次观察时的既有 task4 run 集合（历史，不告警）
        self.t3_status = "not_attempted"  # task3：absent/not_attempted/running/stopped/completed/unknown

    def _ensure_state(self, key, progress, total, now, flags):
        """建档：首次观察即锁定已处于的 完成/停止/故障 态与已跨里程碑，防止历史告警刷屏；
        之后的 状态迁移（如 running→stopped、语义完成跨 50 步）才触发一次性告警。"""
        if key not in self.mon:
            self.mon[key] = {"progress": progress, "last_prog": progress, "last_total": total,
                             # 首次观察即锁定已跨里程碑，防止历史告警刷屏
                             "last_mile": (progress // self.milestone_step) * self.milestone_step,
                             "last_change": now, "planned": None, "np_at": 0.0,
                             "completed_flag": flags[0], "stopped_flag": flags[1], "merr_flag": flags[2]}
        return self.mon[key]

    def _observe_run(self, tag, name, run, now):
        """单个 run 的观察。
        task3 progress = 已处理记录数（status != not_attempted），答错/技术失败也推进；
        task4 progress = completed 记录数。另列 correct/semantic_scored/infra_failed/not_attempted，
        不用正确率判断卡顿。"""
        alerts = []
        records = record_values(run)
        counts = state_counts(run, tag)
        planned = planned_of(run, records, tag)
        if tag == "task4":
            progress = counts.get("completed", 0)
            stats = {}
        else:
            progress = sum(1 for r in records
                           if isinstance(r, dict) and r.get("status") != "not_attempted")
            stats = t3_progress_counts(records)
        total = sum(counts.values())
        completed, stopped, merr = run_flags(run, counts, tag, planned, records)
        st = self._ensure_state((tag, name), progress, total, now, (completed, stopped, merr))
        st["planned"] = planned
        # 恢复：stopped/已完成后重新 running，刷新停止/完成/故障标志，
        # 让后续再次停止/完成能通知，并重启停滞检测
        if tag == "task3" and run.get("status") == "running" and \
                (st["stopped_flag"] or st["completed_flag"]):
            st.update(stopped_flag=False, merr_flag=False, completed_flag=False, np_at=0.0)
        if progress != st["last_prog"] or total != st["last_total"]:
            st.update(last_prog=progress, last_total=total, last_change=now)
        mile = (progress // self.milestone_step) * self.milestone_step
        if mile > st["last_mile"]:  # 跨 50/100 里程碑触发一次；重复进度不再触发
            st["last_mile"] = mile
            payload = {"type": "milestone", "report": tag, "run": name,
                       "progress": progress, "planned": planned, "milestone": mile,
                       "states": dict(counts)}
            if stats:
                payload.update({k: stats[k] for k in ("correct", "semantic_scored",
                                                       "infra_failed", "not_attempted")})
            # 记录仍在推进而 reported_status 是旧状态（如 incomplete/未收尾）时注明，
            # 不据此猜测进程活性（不凭锁文件/stop_reason 判断进程死活）
            old_status = run.get("status")
            if old_status in ("incomplete", "stopped", "completed"):
                payload["note"] = ("记录仍在推进，reported_status 为旧状态(%s)；"
                                   "进度以记录计数为准，不从锁文件猜测进程活性" % old_status)
            alerts.append(payload)
        if completed and not st["completed_flag"]:
            st["completed_flag"] = True
            payload = {"type": "run_completed", "report": tag, "run": name,
                      "progress": progress, "planned": planned,
                      "states": dict(counts), "run_status": run.get("status")}
            if stats:
                payload.update({k: stats[k] for k in ("correct", "semantic_scored",
                                                       "infra_failed", "not_attempted")})
            alerts.append(payload)
        if stopped and not st["stopped_flag"]:
            st["stopped_flag"] = True
            # task4 停止原因在 summary.stop_reason；task3 在 run.stop_reason
            stop_reason = ((run.get("summary") or {}).get("stop_reason") if isinstance(run.get("summary"), dict)
                           else None) if tag == "task4" else run.get("stop_reason")
            alerts.append({"type": "run_stopped" if tag == "task4" else "infra_stopped",
                           "report": tag, "run": name,
                           "run_status": run.get("status"),
                           "stop_reason": stop_reason,
                           "unresolved_hard_stops": hard_stop_unresolved(records) if tag == "task3" else None,
                           "states": dict(counts)})
        if merr and not st["merr_flag"]:
            st["merr_flag"] = True
            alerts.append({"type": "model_error" if tag == "task4" else "infra_error",
                           "report": tag, "run": name, "states": dict(counts)})
        in_progress = not st["completed_flag"] and not st["stopped_flag"]
        if (in_progress and now - st["last_change"] > self.no_progress_s
                and now - st.get("np_at", 0.0) >= self.no_progress_s):
            st["np_at"] = now
            alerts.append({"type": "no_progress", "report": tag, "run": name,
                           "idle_s": int(now - st["last_change"]),
                           "note": "20分钟无推进，需检查运行进程与数据库状态，不宣称已死"})
        return alerts

    def observe_task4(self, data, now):
        """task4：仅 r6 与后续新 run 告警；首次观察的既有历史 run 不触发历史告警。"""
        if not isinstance(data, dict):
            return []
        runs = runs_of(data, "task4")
        if self.initial_task4 is None:
            self.initial_task4 = set(runs)
        # 本轮 JSON 有效：从报告中消失的 run 从缓存删除（写入中 None 时不删）
        for key in [k for k in self.mon if k[0] == "task4" and k[1] not in runs]:
            del self.mon[key]
        return [a for name, run in runs.items()
                if name == BASELINE_RUN or name not in self.initial_task4
                for a in self._observe_run("task4", name, run, now)]

    def observe_task3(self, data, now):
        """task3：runs 用真实字段 runs/record.status/accuracy_denominators；
        无 runs 的 legacy 报告（model_run 假）记 not_attempted，不产生无进度告警。"""
        if not isinstance(data, dict):
            return []
        runs = runs_of(data, "task3")
        # 本轮 JSON 有效：消失的 run（如被任务3负责方清除的测试误写 unit-run）从缓存删除
        for key in [k for k in self.mon if k[0] == "task3" and k[1] not in runs]:
            del self.mon[key]
        alerts = []
        for name, run in runs.items():
            # 首观锁定既有 停止/完成/故障 态（任务3 历史 run 不刷历史告警）；
            # 其后 状态迁移（running→stopped、语义完成跨 50 步）触发一次性告警
            alerts.extend(self._observe_run("task3", name, run, now))
        # task3_status 真实反映：无 run=不存在；running/停止/完成按 run.status 汇总
        if not runs:
            self.t3_status = "not_attempted" if data.get("model_run") is False else "absent"
        elif any(r.get("status") == "running" for r in runs.values()):
            self.t3_status = "running"
        elif all(r.get("status") == "completed" for r in runs.values()):
            self.t3_status = "completed"
        elif any(r.get("status") in ("stopped", "incomplete") or r.get("stop_reason")
                 for r in runs.values()):
            self.t3_status = "stopped"
        else:
            self.t3_status = "unknown"
        return alerts

    def overview(self):
        ov = {"task3_status": self.t3_status, "focus": {}}
        for (tag, name), st in self.mon.items():
            ov["focus"].setdefault(tag, {})[name] = {"progress": st["last_prog"], "planned": st.get("planned")}
        return ov


def overview_str(watch, interval):
    """初始概览：进度/分母聚合值 + task3 真实状态，不含题文/SQL/密钥。"""
    parts = ["%s[%s]=%s/%s" % (tag, name, st["last_prog"], st.get("planned") or "?")
             for (tag, name), st in sorted(watch.mon.items())]
    parts += ["task3_status=%s" % watch.t3_status, "next_heartbeat_s=%d" % interval]
    return " ".join(parts)


def main(argv=None):
    ap = argparse.ArgumentParser(description="只读优化报告监控：仅唤醒父agent，不改代码、不重跑任务")
    ap.add_argument("--interval", type=int, default=900, help="心跳周期秒（默认900=15分钟）")
    ap.add_argument("--poll", type=int, default=30, help="报告扫描周期秒")
    args = ap.parse_args(argv)
    # 定时器参数必须为正数，防止 0/负数造成忙轮询或心跳立即触发
    if args.interval <= 0 or args.poll <= 0:
        raise SystemExit("interval 与 poll 必须为正数秒")
    base = Path(__file__).resolve().parent
    reports = [
        ("task4", base / "reports" / "optimization_task4_20261010.json"),
        ("task3", base / "reports" / "optimization_task3_20261010.json"),
    ]
    watch = Watch()
    timer = threading.Event()  # 内部事件等待定时；不使用 Shell sleep 循环
    start = time.time()
    hb_due = start + args.interval  # 首个定时心跳在 --interval 秒后，不重复立即触发
    first_scan = True
    while True:
        now = time.time()
        alerts = []
        for tag, path in reports:
            data, _ok = load_json_safe(path)
            alerts.extend(watch.observe_task4(data, now) if tag == "task4"
                          else watch.observe_task3(data, now))
        if first_scan:  # 首次启动打印 WATCH_READY 与初始概览（非哨兵）
            print("WATCH_READY pid=%d %s" % (os.getpid(), overview_str(watch, args.interval)), flush=True)
            first_scan = False
        for a in alerts:
            a["prompt"] = watch.prompt
            emit(a)
        if now >= hb_due:  # 运行期每 --interval 秒一次心跳，触发同一哨兵
            emit({"type": "heartbeat", "prompt": watch.prompt,
                  "overview": watch.overview(), "next_heartbeat_s": args.interval})
            hb_due = now + args.interval
        timer.wait(max(0.25, min(args.poll, max(0.25, hb_due - now))))


if __name__ == "__main__":
    main()
