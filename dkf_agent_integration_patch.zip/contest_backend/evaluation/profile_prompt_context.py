"""提示上下文序列化离线探针：只测量SQLGenerator待发送消息的字符体积，零模型调用。

边界（本轮唯一指定输出 evaluation/reports/prompt_context_probe_20261011.json）：
- BIRD全部500题，full/pruned两mode真实链路（SchemaLinker候选+真实DDL+真实FK桥接）
  生成"待发送"消息；LLMStub只抛异常，任何模型调用立即失败；
- 只读目录查询build_ddl（information_schema/pg_catalog），无SQL数据查询；
- 问题JSON只取白名单字段question/db_id/question_id/原始行号，不读gold.sql、不读evidence；
- 不调用registry（嵌入客户端绝不初始化），探针只触碰真实PG的只读目录查询；
- 无候选/需澄清/未注册schema按生产契约跳过生成，planned与blocked分母全记录；
- 对照为当前生产build_messages原样字节；变体只做可逆规范化：
  compact（紧凑JSON分隔符）、registry（重复join元信息进共享字典，$ref可逆还原）；
  解码后必须与原文语义与类型完全相等，任何roundtrip失败标"候选不合格"而非简化；
- DDL段、system规则、问题与用户确认原文在所有变体中字节不变（前缀长度显式计入体积）；
- 字符不是token，usage不可得一律null；本探针不声称任何延迟/EX改进。
"""
import datetime as dt
import hashlib
import json
import sys
import time
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))

# 输入白名单读取：只取identity与问题，金标SQL与官方evidence永不进入本探针。
BIRD_JSON = HERE.parent / "data/raw/bird/original/minidev/MINIDEV/mini_dev_postgresql.json"
OUT = HERE / "evaluation/reports/prompt_context_probe_20261011.json"

# 各库真实PG连接（只读目录查询；探针只连information_schema/pg_catalog）。
PG_URL = {"bird": "postgresql://DB_USER:DB_PASSWORD@localhost:5432/ict_bird",
          "cosql": "postgresql://DB_USER:DB_PASSWORD@localhost:5432/ict_cosql",
          "chinook": "postgresql://DB_USER:DB_PASSWORD@localhost:5432/chinook"}

# 资源门槛（预先声明，全量实测后判定，不为几十字符再烧模型预算）：
GATE_MEAN_SAVE_PER_CALL = 800        # 平均每调用节约字符
GATE_TOTAL_INPUT_REDUCTION = 0.10    # 总input字符减少比例


class LLMStub:
    """只用于构造SQLGenerator的消息路径；任何调用都抛异常，证明零模型请求。"""

    def __init__(self):
        self.calls = 0

    def chat(self, *args, **kwargs):
        # 一旦生产路径尝试调模型，探针立即失败，绝不静默发出请求。
        self.calls += 1
        raise RuntimeError("llm_stub_called_forbidden")


def compact_json(obj):
    """与原文相同的json.dumps调用规则，仅去掉多余空白分隔符。"""
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def encode_registry(context):
    """重复join元信息（固定note/共享中间表文本/相同alternatives对象）进共享字典。

    只把真正重复（出现≥2次）的键值搬进context末尾shared_registry，并以整数索引的
    $ref指回；唯一值原样保留，避免引用开销超过节约。编码与解码都必须逐字段（含类型）
    还原出原文，任何roundtrip失败由调用方判"候选不合格"，绝不偷偷简化。
    """
    if not isinstance(context, dict) or not isinstance(context.get("authorized_join_evidence"), list):
        return context
    items = context["authorized_join_evidence"]
    # 逐值统计出现次数；只有≥2次才值得共享（唯一值共享只会变大）。
    note_counts = Counter()
    between_counts = Counter()
    alt_occurrences = Counter()  # 按canonical key计alternatives值出现次数
    for item in items:
        if isinstance(item.get("note"), str):
            note_counts[item["note"]] += 1
        key = "|".join(item.get("between") or [])
        if key:
            between_counts[key] += 1
        for alt in item.get("alternatives") or []:
            alt_occurrences[_canon(alt)] += 1
    # 按字符串排序生成稳定索引表；解码用同一索引还原。
    shared_notes = sorted(v for v, c in note_counts.items() if c > 1)
    shared_between = sorted(k for k, c in between_counts.items() if c > 1)
    shared_alt_keys = sorted(k for k, c in alt_occurrences.items() if c > 1)
    alt_by_key = {}  # canonical key -> 该值第一次出现时的原对象（共享进registry）
    for item in items:
        for alt in item.get("alternatives") or []:
            alt_by_key.setdefault(_canon(alt), alt)
    encoded_items = []
    for item in items:
        rec = dict(item)
        note = item.get("note")
        if note in shared_notes:
            rec["note"] = {"$ref": "shared_registry.notes." + str(shared_notes.index(note))}
        key = "|".join(item.get("between") or [])
        if key in shared_between:
            rec["between"] = {"$ref": "shared_registry.between." + str(shared_between.index(key))}
        if item.get("alternatives") and shared_alt_keys:
            rec["alternatives"] = [
                {"$ref": "shared_registry.alternates." + str(shared_alt_keys.index(_canon(alt)))}
                if _canon(alt) in shared_alt_keys else alt
                for alt in item["alternatives"]]
        encoded_items.append(rec)
    encoded = dict(context)
    encoded["authorized_join_evidence"] = encoded_items
    if shared_notes or shared_between or shared_alt_keys:
        encoded["shared_registry"] = {
            "notes": shared_notes,
            # between注册为完整"表A|表B"字符串，解码$ref直接还原为原文的列表值。
            "between": {str(i): s for i, s in enumerate(shared_between)},
            "alternates": [alt_by_key[k] for k in shared_alt_keys],
        }
    return encoded


def _canon(value):
    """值的canonical键：用于跨位置判定"同一对象重复出现"；同对象在原文里本就是同值。"""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _resolve_refs(obj, registry, stack=0):
    """逐层还原$ref；registry本身为纯对象（编码规则保证），可安全展开。

    索引在内存dict里是字符串键（与JSON同形），between段存的是"|".join后的
    完整串，还原为原文的字符串列表，保证解码结果与原文逐字段、逐类型相等。
    """
    if stack > 64:
        raise ValueError("$ref嵌套过深")
    if isinstance(obj, dict):
        if len(obj) == 1 and isinstance(obj.get("$ref"), str):
            # 只解码本编码器产出的shared_registry段；任何其它$ref形状直接失败显形。
            parts = obj["$ref"].split(".")
            if len(parts) != 3 or parts[0] != "shared_registry" or parts[1] not in ("notes", "between", "alternates"):
                raise ValueError("malformed_ref:" + obj["$ref"])
            section, index = parts[1], parts[2]
            table = registry[section]
            # between是{索引: 完整串}的dict，其余是列表；键统一按字符串查。
            if isinstance(table, list):
                node = table[int(index)]
            else:
                node = table[index]
            if section == "between":
                return str(node).split("|")
            return _resolve_refs(node, registry, stack + 1)
        return {k: _resolve_refs(v, registry, stack + 1) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_resolve_refs(v, registry, stack + 1) for v in obj]
    return obj


def decode_registry(encoded_context):
    """独立解码器：把registry表示还原为原文；与原文逐字段（含类型）相等才算无损。"""
    registry = encoded_context.get("shared_registry")
    if registry is None:
        return encoded_context
    return _resolve_refs({k: v for k, v in encoded_context.items() if k != "shared_registry"},
                         registry)


def measure_variants(message, context, ddl):
    """对一条待发送消息做生产原样/compact/registry三种序列化测量。

    前缀（system规则+授权DDL段）在全部变体中字节不变，按原长度计入体积。
    """
    prefix_chars = len(message[0]["content"]) + len("授权DDL：\n") + len(ddl) + len("\n输入数据：\n")
    compact_text = compact_json(context)
    registry_encoded = encode_registry(context)
    registry_text = json.dumps(registry_encoded, ensure_ascii=False)
    restored = decode_registry(registry_encoded)
    # 体积口径：system规则+user内容（前缀字节不变，变体只改输入数据JSON部分）。
    prod_total = len(message[0]["content"]) + len(message[1]["content"])
    return {
        "prod_chars": prod_total,
        "compact_chars": prefix_chars + len(compact_text),
        "registry_chars": prefix_chars + len(registry_text),
        "compact_save": prod_total - (prefix_chars + len(compact_text)),
        "registry_save": prod_total - (prefix_chars + len(registry_text)),
        "registry_roundtrip_ok": restored == context,
        "registry_noop": "shared_registry" not in registry_encoded,
    }


def probe_case(linker, generator, db, sub_db, question, slots, mode, schema=None):
    """按生产契约跑到生成前一步：候选/澄清阻断跳过生成，但分母保留。"""
    full_baseline = mode == "full"
    view = linker.link(question, None, top_k=6, full_baseline=full_baseline,
                       confirmed_slots=slots)
    if view["needs_clarification"]:
        return {"stage": "needs_user", "tables": view["tables"], "bridges": [], "ddls": 0,
                "msg_chars": 0, "messages": [], "metrics": [], "warnings": []}
    if not view["tables"]:
        return {"stage": "candidate_insufficient", "tables": [], "bridges": [], "ddls": 0,
                "msg_chars": 0, "messages": [], "metrics": [], "warnings": []}
    schema = schema or linker.index.schema_name
    from backend.agents.text2sql.ddl import build_ddl
    ddl = build_ddl(PG_URL[db], view["tables"], schema=schema)  # 只读目录查询
    constraints = {"metric_hints": view["metric_hints"],
                   "granularity_warnings": view["granularity_warnings"]}
    message = generator.build_messages(question, ddl, view["bridges"],
                                       confirmed_slots=slots, **constraints)
    context = {"question": question, "confirmed_slots": slots or {},
               "authorized_join_evidence": view["bridges"],
               "verified_metric_hints": view["metric_hints"] or [],
               "structural_warnings": view["granularity_warnings"] or []}
    return {"stage": "generated", "tables": view["tables"], "bridges": view["bridges"],
            "ddls": len(view["tables"]), "msg_chars": len(message[1]["content"]),
            "messages": [measure_variants(message, context, ddl)],
            "metrics": view["metric_hints"], "warnings": view["granularity_warnings"]}


def percentile(values, p):
    """最近秩法：第p百分位（p为0到100），空集返回None。"""
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int(round(p / 100 * len(ordered))) - 1))
    return ordered[index]


def fingerprint():
    """输入与生产代码指纹；只散列摘要，不落逐题明文。"""
    files = [HERE / "backend/agents/text2sql/sql_generator.py",
             HERE / "backend/agents/text2sql/pipeline.py",
             HERE / "backend/agents/text2sql/ddl.py",
             HERE / "backend/agents/task4_schema_linking/schema_linker.py",
             HERE / "backend/agents/task4_schema_linking/fk_graph_builder.py",
             HERE / "processed/knowledge_base/databases.json",
             HERE / "processed/task4_schema/fk_graph.json",
             HERE / "processed/task4_schema/schema_index.json",
             BIRD_JSON,
             HERE.parent / "data/postgresql/bird/database_mapping.json",
             HERE.parent / "data/postgresql/cosql/database_mapping.json",
             Path(__file__)]
    hashes = {}
    for path in files:
        if path.exists():
            digest = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1048576), b""):
                    digest.update(chunk)
            hashes[str(path.relative_to(HERE.parent))] = digest.hexdigest()
    return {"sha256": hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest(),
            "files": hashes}


class CoSQLSchemaIndex:
    """探针专用：把CoSQL单一catalog身份拆回166个真实schema子库（映射恢复身份，不改生产）。

    生产目录对CoSQL只有一个catalog身份（873张表跨166个真实schema）；这里在探针内存里
    按真实schema过滤表，身份与PK仍来自同一mapping，不动任何共享索引文件；
    非本类自有属性委托内层生产目录，保持SchemaLinker看到的接口形状。
    """

    def __init__(self, index_dir=None, target_schema=None):
        from backend.agents.task4_schema_linking.schema_index import SchemaIndex
        self.inner = SchemaIndex(index_dir)
        self.target_schema = target_schema
        self.tables, self._by_name = [], {}
        self.current_db = self.current_dataset = None

    def load(self, database, sub_db=None):
        # 内层load走生产目录（子库身份=source stem）；本代理只在内存里按目标
        # schema过滤，身份与PK仍来自同一mapping，不污染共享catalog。
        self.inner.load(database, sub_db)
        self.tables = [e for e in self.inner.tables
                       if (e.get("schema") or "public") == self.target_schema]
        self._by_name = {e["table"]: e for e in self.tables}
        self.current_db = sub_db or self.target_schema

    @property
    def schema_name(self):
        return self.tables[0].get("schema") or "public" if self.tables else None

    @property
    def allowed_tables(self):
        """执行允许集合仅覆盖当前真实schema子库，不使用测试金标收缩权限。"""
        return {self.schema_name: {e["table"] for e in self.tables}} if self.tables else {}

    def get_table(self, name):
        return self._by_name.get(name)

    def __getattr__(self, name):
        # 别名表/resolve等其余属性委托内层生产目录，绝不另造第二套索引。
        return getattr(self.inner, name)


def bird_section():
    """BIRD全部500题两mode真实待发送消息测量；零LLM、零数据SQL。"""
    from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
    from backend.agents.text2sql.sql_generator import SQLGenerator
    raw = json.loads(BIRD_JSON.read_text(encoding="utf-8"))
    if len(raw) != 500:
        raise ValueError("BIRD问题必须恰好500条")
    # 白名单identity：原始行号+db_id+question_id；不取SQL/evidence字段。
    items = [{"ordinal": i, "db_id": x["db_id"], "question_id": x["question_id"],
              "question": x["question"]} for i, x in enumerate(raw)]
    linker = SchemaLinker()
    stub = LLMStub()
    generator = SQLGenerator(stub)
    per_mode = {}
    blocked = {"needs_user": 0, "candidate_insufficient": 0, "error": 0}
    errors = []
    t0 = time.perf_counter()
    for idx, item in enumerate(items):
        linker.load("bird", item["db_id"])
        row = {"id": f"{item['ordinal']:03d}:{item['db_id']}:{item['question_id']}",
               "modes": {}}
        for mode in ("full", "pruned"):
            try:
                out = probe_case(linker, generator, "bird", item["db_id"],
                                 item["question"], None, mode)
            except Exception as exc:
                out = {"stage": "error", "tables": [], "bridges": [], "ddls": 0,
                       "msg_chars": 0, "messages": [], "metrics": [], "warnings": [],
                       "error_type": type(exc).__name__}
                blocked["error"] += 1
                errors.append({"id": row["id"], "mode": mode, "type": out.get("error_type")})
            if out["stage"] == "needs_user":
                blocked["needs_user"] += 1
            elif out["stage"] == "candidate_insufficient":
                blocked["candidate_insufficient"] += 1
            row["modes"][mode] = out
        for mode in ("full", "pruned"):
            out = row["modes"][mode]
            stat = per_mode.setdefault(mode, {"messages": 0, "blocked": 0, "ddls": 0,
                "prod_total": 0, "compact_total": 0, "registry_total": 0,
                "compact_saves": [], "registry_saves": [], "max_prompt": 0,
                "registry_roundtrip_fail": 0, "registry_noop": 0})
            stat["ddls"] += out["ddls"]
            stat["max_prompt"] = max(stat["max_prompt"], out["msg_chars"])
            if not out["messages"]:
                stat["blocked"] += 1
                continue
            m = out["messages"][0]
            stat["messages"] += 1
            stat["prod_total"] += m["prod_chars"]
            stat["compact_total"] += m["compact_chars"]
            stat["registry_total"] += m["registry_chars"]
            stat["compact_saves"].append(m["compact_save"])
            stat["registry_saves"].append(m["registry_save"])
            stat["registry_roundtrip_fail"] += 0 if m["registry_roundtrip_ok"] else 1
            stat["registry_noop"] += int(m["registry_noop"])
        if (idx + 1) % 50 == 0:
            print(f"[bird {idx + 1}/500] 已处理，耗时{time.perf_counter() - t0:.1f}s", flush=True)
    summary = {}
    for mode in ("full", "pruned"):
        stat = per_mode[mode]
        n = stat["messages"] or 1
        summary[mode] = {
            "planned": 500, "messages": stat["messages"], "blocked": stat["blocked"],
            "ddls": stat["ddls"], "max_prompt": stat["max_prompt"],
            "prod_total_chars": stat["prod_total"], "compact_total_chars": stat["compact_total"],
            "registry_total_chars": stat["registry_total"],
            "reduction_pct": {"compact": round(1 - stat["compact_total"] / stat["prod_total"], 6)
                              if stat["prod_total"] else None,
                              "registry": round(1 - stat["registry_total"] / stat["prod_total"], 6)
                              if stat["prod_total"] else None},
            "save_mean": round(sum(stat["compact_saves"]) / n, 1),
            "save_p50": percentile(stat["compact_saves"], 50),
            "save_p95": percentile(stat["compact_saves"], 95),
            "registry_save_mean": round(sum(stat["registry_saves"]) / n, 1),
            "registry_roundtrip_fail": stat["registry_roundtrip_fail"],
            "registry_noop_messages": stat["registry_noop"],
        }
    all_saves = [s for mode in ("full", "pruned") for s in per_mode[mode]["compact_saves"]]
    prod_all = sum(per_mode[mode]["prod_total"] for mode in ("full", "pruned"))
    compact_all = sum(per_mode[mode]["compact_total"] for mode in ("full", "pruned"))
    total_calls = sum(per_mode[mode]["messages"] for mode in ("full", "pruned"))
    gate = {
        "mean_save_per_call": round(sum(all_saves) / total_calls, 1) if total_calls else None,
        "total_input_reduction_pct": round(1 - compact_all / prod_all, 6) if prod_all else None,
        "passed": bool(all_saves and 1 - compact_all / prod_all >= GATE_TOTAL_INPUT_REDUCTION
                       and sum(all_saves) / total_calls >= GATE_MEAN_SAVE_PER_CALL),
        "thresholds": {"mean_save_per_call": GATE_MEAN_SAVE_PER_CALL,
                        "total_input_reduction": GATE_TOTAL_INPUT_REDUCTION},
        "unit": "字符（不是token）；usage不可得一律null",
    }
    return {"gate": gate, "per_mode": summary, "blocked": blocked,
            "llm_calls": stub.calls, "wall_s": round(time.perf_counter() - t0, 1),
            "errors": errors[:20], "error_n": len(errors)}


def chinook_section():
    """Chinook全部11张真实表：单mode生成+自引用外键边界（只目录/真实DDL）。"""
    from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
    from backend.agents.text2sql.sql_generator import SQLGenerator
    stub = LLMStub()
    generator = SQLGenerator(stub)
    linker = SchemaLinker()
    linker.load("chinook")
    # 全库11表走full基准，覆盖Chinook真实DDL与employee自引用外键。
    out = probe_case(linker, generator, "chinook", "chinook",
                     "Which albums belong to customer 5", {"customer": "5"}, "full")
    return {"stage": out["stage"], "tables_n": len(out["tables"]), "ddls": out["ddls"],
            "msg_chars": out["msg_chars"], "messages": out["messages"],
            "self_ref_fk_covers": "employee" in out["tables"],
            "llm_calls": stub.calls}


def cosql_section():
    """CoSQL全部可加载catalog（166个真实schema子库）：结构协议夹具，非自然语言问答成绩。

    问题串由真实表名拼接（明确标注为结构夹具）；CoSQL的FK图无目录边，
    重点验证真实DDL段（复合主键/多FK/自引用）与空join的roundtrip，不做评分。
    """
    from backend.agents.task4_schema_linking.schema_linker import SchemaLinker
    from backend.agents.text2sql.sql_generator import SQLGenerator
    mapping = json.loads((HERE.parent / "data/postgresql/cosql/database_mapping.json")
                         .read_text(encoding="utf-8"))
    stub = LLMStub()
    generator = SQLGenerator(stub)
    loaded, failed = 0, 0
    categories = {}
    roundtrip_fail = 0
    noop = 0
    messages_n = 0
    prod_total = compact_total = registry_total = 0
    t0 = time.perf_counter()
    for entry in mapping:
        schema = entry["schema"]
        target = sorted({t["name"] for t in entry["tables"]})
        # 真实子库身份：mapping的source stem（与生产目录恢复身份一致），不是schema名。
        source = str(entry.get("source_key") or entry.get("source") or "").replace("\\", "/")
        sub_db = Path(source).stem or schema
        index = CoSQLSchemaIndex(target_schema=schema)
        try:
            index.load("cosql", sub_db)
            if not index.tables:
                failed += 1
                categories["no_tables_after_schema_filter"] = \
                    categories.get("no_tables_after_schema_filter", 0) + 1
                continue
        except Exception as exc:
            failed += 1
            category = ("load_" + type(exc).__name__).lower()
            categories[category] = categories.get(category, 0) + 1
            continue
        # 每库一个独立SchemaLinker（共享FK/指标目录无状态，仅catalog身份来自过滤代理）。
        linker = SchemaLinker()
        linker.index = index
        question = " | ".join(target[:3])  # 结构夹具：表名拼接，非真实问题
        out = probe_case(linker, generator, "cosql", sub_db, question,
                         {target[0] + " id": "1"}, "pruned", schema=schema)
        if out["stage"] != "generated":
            categories[out["stage"]] = categories.get(out["stage"], 0) + 1
            continue
        loaded += 1
        messages_n += 1
        m = out["messages"][0]
        prod_total += m["prod_chars"]
        compact_total += m["compact_chars"]
        registry_total += m["registry_chars"]
        roundtrip_fail += 0 if m["registry_roundtrip_ok"] else 1
        noop += int(m["registry_noop"])
        if loaded % 40 == 0:
            print(f"[cosql {loaded}/166] 已处理，耗时{time.perf_counter() - t0:.1f}s", flush=True)
    return {"schema_total": len(mapping), "loaded": loaded, "load_failed": failed,
            "categories": categories, "messages": messages_n,
            "prod_total_chars": prod_total, "compact_total_chars": compact_total,
            "registry_total_chars": registry_total,
            "reduction_pct": {"compact": round(1 - compact_total / prod_total, 6) if prod_total else None,
                              "registry": round(1 - registry_total / prod_total, 6) if prod_total else None},
            "registry_roundtrip_fail": roundtrip_fail, "registry_noop_messages": noop,
            "llm_calls": stub.calls, "wall_s": round(time.perf_counter() - t0, 1),
            "note": "结构协议夹具（目录+真实DDL+确认条件），不是自然语言问答成绩"}


# 固定夹具DDL（真实形态：同表名不同schema、复合主键、多FK、自引用、Unicode/确认条件）。
FIXTURE_DDL = (
    'CREATE TABLE "beta"."item" (\n  "item_id" BIGINT NOT NULL,\n  "batch_id" TEXT NOT NULL,\n'
    '  "parent_id" BIGINT,\n  PRIMARY KEY ("item_id", "batch_id"),\n'
    '  CONSTRAINT "beta_item_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "beta"."item" ("item_id")\n);\n\n'
    'CREATE TABLE "alpha"."item" (\n  "item_id" TEXT,\n'
    '  CONSTRAINT "alpha_item_ref" FOREIGN KEY ("item_id") REFERENCES "beta"."item" ("item_id")\n);\n\n'
    'CREATE TABLE "alpha"."event" (\n  "event_id" INTEGER,\n  "item_ref" TEXT\n);')

FIXTURE_BRIDGE = [{
    "from_table": "alpha.item", "to_table": "beta.item",
    "pairs": [{"from_column": "item_ref", "to_column": "item_id"}],
    "constraint": "alpha_item_ref",
    "alternatives": [{"constraint": "alpha_item_ref",
                      "pairs": [{"from_column": "item_ref", "to_column": "item_id"}]}],
    "is_bridge": True, "note": "最短结构候选；多约束需按问题选择，不得将全部备选条件同时AND",
    "between": ["alpha.item", "beta.item"]}]

FIXTURE_MULTI_BRIDGE = [
    dict(FIXTURE_BRIDGE[0]),
    {"from_table": "beta.item", "to_table": "beta.item",
     "pairs": [{"from_column": "parent_id", "to_column": "item_id"}],
     "constraint": "beta_item_parent_fk",
     "alternatives": [{"constraint": "beta_item_parent_fk",
                       "pairs": [{"from_column": "parent_id", "to_column": "item_id"}]}],
     "is_bridge": False, "note": FIXTURE_BRIDGE[0]["note"], "between": ["beta.item", "beta.item"]}]


def fixture_section(generator, stub):
    """无PG夹具：同表名不同schema、复合键、多FK、空joins、自引用、确认条件/Unicode引号。"""
    cases = {
        "cross_schema_same_table": ("alpha.event哪条记录对应beta.item？", {}, FIXTURE_DDL, FIXTURE_BRIDGE),
        "composite_pk_multi_fk_selfref": ("alpha.item里父项指向自己的有多少？", {},
                                           FIXTURE_DDL, FIXTURE_MULTI_BRIDGE),
        "empty_joins": ("alpha.event按事件列一行", {},
                        'CREATE TABLE "alpha"."event" (\n  "event_id" INTEGER NOT NULL,\n'
                        '  PRIMARY KEY ("event_id")\n);', []),
        "confirmed_unicode_slots": ("曲目“北京”的歌手？", {"专辑": "精选“2009”", "歌手": "周杰伦"},
                                    FIXTURE_DDL, FIXTURE_BRIDGE),
    }
    out = {}
    for name, (question, slots, ddl, bridges) in cases.items():
        context = {"question": question, "confirmed_slots": slots,
                   "authorized_join_evidence": bridges,
                   "verified_metric_hints": [], "structural_warnings": ["跨schema同名表已按限定标识区分"]}
        message = generator.build_messages(question, ddl, bridges,
                                           confirmed_slots=slots)
        m = measure_variants(message, context, ddl)
        # 前缀（system+授权DDL段）字节不变验证：原文user内容必须以此前缀开头。
        prefix = "授权DDL：\n" + ddl + "\n输入数据：\n"
        out[name] = {
            "prod_chars": m["prod_chars"], "compact_chars": m["compact_chars"],
            "registry_chars": m["registry_chars"],
            "registry_roundtrip_ok": m["registry_roundtrip_ok"],
            "ddl_and_system_prefix_bytes_unchanged": message[1]["content"].startswith(prefix),
        }
    out["llm_calls"] = stub.calls
    return out


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="all", choices=("all", "bird", "chinook", "cosql", "fixture"),
                    help="只跑指定段（开发用；正式全量探针用all）")
    args = ap.parse_args()
    from backend.agents.text2sql.sql_generator import SQLGenerator
    stub = LLMStub()
    generator = SQLGenerator(stub)
    report = {"probe": "prompt_context_probe",
              "timestamp": dt.datetime.now().isoformat(),
              "fingerprint": fingerprint(),
              "boundary": {"llm_calls": 0, "sql_data_queries": 0,
                           "registry_embedding_init": False,
                           "gold_or_evidence_in_prompt": False,
                           "chars_not_tokens": True, "usage": None,
                           "unit_note": "字符不是token；供应商usage不可得一律null；"
                                         "本探针无模型结果，不声称延迟/EX改进"}}
    if args.only in ("all", "bird"):
        report["bird"] = bird_section()
    if args.only in ("all", "chinook"):
        report["chinook"] = chinook_section()
    if args.only in ("all", "cosql"):
        report["cosql"] = cosql_section()
    if args.only in ("all", "fixture"):
        report["fixture"] = fixture_section(generator, stub)
    # 汇总门槛判定：roundtrip全过且BIRD资源门槛过才建议下一轮（父agent复核后决定）。
    gate = report.get("bird", {}).get("gate")
    roundtrip_fail = sum(report.get(section, {}).get("registry_roundtrip_fail", 0)
                         for section in ("bird", "cosql"))
    report["verdict"] = {
        "registry_candidate_eligible": roundtrip_fail == 0,
        "resource_gate_passed": bool(gate and gate["passed"]),
        "recommend_next_round_model_budget": bool(gate and gate["passed"]
                                                   and roundtrip_fail == 0),
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    tmp = OUT.with_name(OUT.name + ".tmp")
    try:
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(OUT)
    finally:
        if tmp.exists():
            tmp.unlink()
    print(json.dumps({"verdict": report["verdict"]}, ensure_ascii=False))
    print(f"报告已写入 {OUT.relative_to(HERE.parent)}；bird llm_calls="
          f"{report.get('bird', {}).get('llm_calls', 0)}")


if __name__ == "__main__":
    main()
