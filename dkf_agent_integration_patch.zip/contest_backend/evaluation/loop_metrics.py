"""闭环评测的公共指标与稳定划分；失败单独记录，禁止删除失败样本抬高准确率。"""
import hashlib
import math
from collections import Counter
from statistics import mean


def partition(group_id: str, seed: str = "ict-loop-v1") -> str:
    """按对话或问题族稳定划分；同组绝不跨调试集与留出集。"""
    bucket = int(hashlib.sha256(f"{seed}:{group_id}".encode()).hexdigest()[:8], 16) % 5
    return "holdout" if bucket == 0 else "development"


def percentile(values, fraction):
    """线性插值分位数，空记录返回 None，不把缺失延迟当零。"""
    xs = sorted(float(x) for x in values if x is not None and math.isfinite(float(x)))
    if not xs:
        return None
    pos = (len(xs)-1) * fraction
    low, high = math.floor(pos), math.ceil(pos)
    return xs[low] + (xs[high]-xs[low]) * (pos-low)


def classification_metrics(rows):
    """need 为 bool 的语义判定与 need=None 的技术失败分开，但总分母包含失败。"""
    n = len(rows)
    positive = [r for r in rows if r.get("expected") is True]
    negative = [r for r in rows if r.get("expected") is False]
    tp = sum(r.get("need") is True for r in positive)
    tn = sum(r.get("need") is False for r in negative)
    fp = sum(r.get("need") is True for r in negative)
    fn = sum(r.get("need") is False for r in positive)
    errors = sum(r.get("need") is None for r in rows)
    recall = tp/len(positive) if positive else None
    specificity = tn/len(negative) if negative else None
    latencies = [r.get("latency_s") for r in rows if r.get("latency_s") is not None]
    return {
        "n": n, "correct": tp+tn, "accuracy_including_failures": (tp+tn)/n if n else None,
        "tp": tp, "tn": tn, "fp": fp, "fn": fn, "technical_or_validation_failures": errors,
        "clarification_recall": recall, "clarification_precision": tp/(tp+fp) if tp+fp else None,
        "unnecessary_question_rate": fp/len(negative) if negative else None,
        "balanced_accuracy": (recall+specificity)/2 if recall is not None and specificity is not None else None,
        "majority_baseline": max(len(positive),len(negative))/n if n else None,
        "latency_mean_s": mean(latencies) if latencies else None,
        "latency_p50_s": percentile(latencies,0.5), "latency_p90_s": percentile(latencies,0.9),
        "failure_types": dict(Counter(r.get("error_code", "unknown") for r in rows if r.get("need") is None)),
    }


def paired_changes(before, after):
    """按同一 id 对比改对/改坏；缺失记录与失败不会消失在交集外。"""
    left = {r["id"]: r for r in before}
    right = {r["id"]: r for r in after}
    if len(left) != len(before) or len(right) != len(after):
        raise ValueError("评测 id 不得重复")
    if set(left) != set(right):
        raise ValueError("配对评测必须使用完全相同样本")
    corrected, regressed = [], []
    for key in sorted(left):
        old, new = bool(left[key].get("correct")), bool(right[key].get("correct"))
        if not old and new:
            corrected.append(key)
        if old and not new:
            regressed.append(key)
    return {"corrected": corrected, "regressed": regressed, "net": len(corrected)-len(regressed)}
