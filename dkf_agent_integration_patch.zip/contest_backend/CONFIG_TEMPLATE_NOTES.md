# config.py 脱敏差异说明（仅 code_package 内副本；agent/backend/config.py 原代码未改动）

| 字段 | 原默认值（运行代码） | 包内模板值 | 原因 |
| --- | --- | --- | --- |
| database_url | postgresql://ict_****:****@localhost:5432/ict_main | postgresql://DB_USER:DB_PASSWORD@DB_HOST:5432/DB_NAME | 默认连接示例含账号/密码，模板化；实际值由 .env 的 DATABASE_URL 提供 |
| wb_base_url | （内网网关 IP:PORT，已隐去） | http://LLM_GATEWAY_HOST:PORT | 内网网关地址不入包 |
| imajev_history_endpoint | （本地服务地址，已占位） | http://IMAJEV_HOST:PORT/v1/systemone | 本地服务地址占位 |

注意：
- 运行可执行性按原代码验证的口径不变；包内 config.py 为脱敏模板副本，
  在干净环境实际运行前必须先填 .env，且上述三处占位不能直接用于启动。
- .env.example（包内保留）中的示例账号/密码为本地开发默认占位，未替换
  （赛题要求密钥用占位变量，.env.example 本身不含真实密钥）；
  提交前请复核 .env.example 中无真实值。
- 代码包内不含 .env、连接密码、会话、logs、临时文件。

## 其他脱敏差异（仅包内副本）

| 文件 | 原值 | 包内模板值 | 说明 |
| --- | --- | --- | --- |
| agent/processed/knowledge_base/databases.json | database_url 含示例连接串（账号/密码已打码：ict_****:****@localhost:5432） | DB_USER:DB_PASSWORD@DB_HOST:5432 | 注册表示例连接串模板化；原文件未改 |
| agent/evaluation/profile_prompt_context.py、agent/scripts/build_schema_index.py、build_fk_graph.py | PG_URL 硬编码示例连接串（ict_****:****@localhost:5432） | DB_USER:DB_PASSWORD@DB_HOST:5432 | 同上；干净环境运行前需按 .env 实际值调整这些脚本常量 |

注意：上述脚本内的 DSN 是硬编码常量，脱敏后占位值不能直接连接数据库；
可执行性以原代码 + .env 实际配置的口径为准，本包副本仅用于提交审阅。
